<?php

namespace Types;

use \Doctrine\DBAL\Platforms\AbstractPlatform;

/**
 * Doctrine can not handle our date 00-00-0000 because it is not a valid date.
 * So in the code we use NULL, but insert 00-00-0000 
*/
class AmountValueType extends \Doctrine\DBAL\Types\IntegerType
{

    public function convertToDatabaseValue($value, AbstractPlatform $platform)
    {
        return ($value !== null) ? $value * 100 : 0;
    }
    
    public function convertToPHPValue($value, AbstractPlatform $platform)
    {
        return (int) $value / 100;
    }
}
