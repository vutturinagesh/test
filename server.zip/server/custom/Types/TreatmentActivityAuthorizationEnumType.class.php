<?php

namespace Types;

use \Doctrine\DBAL\Platforms\AbstractPlatform;

/**
 * In 2.x code we don't want to use the ja, nee (yes, no) enum types in the database anymore
 * This custom type will map ja to 1 and nee to 0
*/
class TreatmentActivityAuthorizationEnumType extends \Doctrine\DBAL\Types\BooleanType
{

	/*
	'Succesvol ontvangen door verzekeraar','In behandeling bij verzekeraar','Offline afgekeurd','Goedgekeurd en afgehandeld','Gedeeltelijk goedgekeurd',
	'Ingetrokken door zorgaanbieder','Verwijderd','Beeindigd door zorgverzekeraar')
	*/
	
	private static $types = array(
		"leeg" => null,
		"Patient betaalt" => "1",
		"Opgeslagen" => "2",
		"Online afgekeurd" => "3",
		"Online goedgekeurd" => "4",
		"Verzonden naar verzekeraar" => "5", 
		"Succesvol ontvangen door verzekeraar" => "6",
		"In behandeling bij verzekeraar" => "7",
		"Offline afgekeurd" => "8",
		"Goedgekeurd en afgehandeld" => "9",
		"Gedeeltelijk goedgekeurd" => "10",
		"Ingetrokken door zorgaanbieder" => "11",
		"Verwijderd" => "12",
		"Beëindigd door zorgverzekeraar" => "13"
		
	);
    public function getSQLDeclaration(array $fieldDeclaration, AbstractPlatform $platform)
    {
        return "ENUM('leeg','Patient betaalt','Opgeslagen','Online afgekeurd','Online goedgekeurd','Verzonden naar verzekeraar','Succesvol ontvangen door verzekeraar','In behandeling bij verzekeraar','Offline afgekeurd','Goedgekeurd en afgehandeld','Gedeeltelijk goedgekeurd','Ingetrokken door zorgaanbieder','Verwijderd','Beëindigd door zorgverzekeraar') NULL COMMENT '(DC2Type:".$this->getName().")'";
    }
    
    public function convertToDatabaseValue($value, AbstractPlatform $platform)
    {
		if (in_array($value, self::$types)) {
			return array_search($value, self::$types);
		} 
	    
		return null;
    }
   
    public function convertToPHPValue($value, AbstractPlatform $platform)
    {
	   if (array_key_exists($value, self::$types)) {
			return self::$types[$value];
		} 
		return null;
    }

}

