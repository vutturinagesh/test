<?php

namespace Types;

use \Doctrine\DBAL\Platforms\AbstractPlatform;

/**
 * TreatmentApplicationEnumType
 *      We don't want the dutch values to propgate to the new 2.x code,
 *      This code will convert application field in the treatment table from 
 *      dutch values to english value and nvt to null
 * 
 * @author      Anush Prem <anush.prem@medicore.nl>
 *  
 */
class TreatmentApplicationEnumType extends \Doctrine\DBAL\Types\BooleanType
{

    /**
     * getSQLDeclaration
     * 
     * @param array $fieldDeclaration
     * @param \Doctrine\DBAL\Platforms\AbstractPlatform $platform
     * @return String
     */
    public function getSQLDeclaration(array $fieldDeclaration, AbstractPlatform $platform)
    {
        return "ENUM ('nvt','links','rechts','beide') NOT NULL DEFAULT 'nvt' COMMENT '(DC2Type:".$this->getName().")'";
    }
    
    /**
     * convertToDatabaseValue
     * 
     * @param String $value
     * @param \Doctrine\DBAL\Platforms\AbstractPlatform $platform
     * @return string
     */
    public function convertToDatabaseValue($value, AbstractPlatform $platform)
    { 
        switch ($value) {
            case 'left':
                $value = 'links';
                break;
            case 'right':
                $value = 'rechts';
                break;
            case 'both':
                $value = 'beide';
                break;
            default:
                $value = 'nvt';                
        }
        
        return $value;
    }
    
    /**
     * convertToPHPValue
     * 
     * @param String $value
     * @param \Doctrine\DBAL\Platforms\AbstractPlatform $platform
     * @return String
     */
    public function convertToPHPValue($value, AbstractPlatform $platform)
    {
        switch ($value) {
            case 'links':
                $value = 'left';
                break;
            case 'rechts':
                $value = 'right';
                break;
            case 'beide':
                $value = 'both';
                break;
            default:
                $value = null;                
        }
        
        return $value;
    }

}
