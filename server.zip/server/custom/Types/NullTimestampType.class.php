<?php
/**
 * MCIS
 *
 * @author Vishwas Deshmane<vishwas.yashwant@medicore.nl>
 *
 * @package Patient
 */

namespace Types;

use \Doctrine\DBAL\Platforms\AbstractPlatform;

/**
 * Doctrine can not handle our date 0000-00-00 00:00:00 because it is not a valid date.
 * So in the code we use NULL, but insert 0000-00-00 00:00:00
 *
 * @author Vishwas Deshmane<vishwas.yashwant@medicore.nl>
 *
 * @package Patient
 */
class NullTimestampType extends \Doctrine\DBAL\Types\DateType
{
    /**
     * Convert given date string to database compatible value
     *
     * @param string $value
     * @param \Doctrine\DBAL\Platforms\AbstractPlatform $platform
     *
     * @return string
     */
    public function convertToDatabaseValue($value, AbstractPlatform $platform)
    {
        return ($value !== null)
            ? $value->format($platform->getDateTimeFormatString()) : '0000-00-00 00:00:00';
    }

    /**
     * Convert value retrieved from database to desired format to display on screen
     *
     * @param string $value
     * @param \Doctrine\DBAL\Platforms\AbstractPlatform $platform
     *
     * @return null | \DateTime
     *
     * @throws \Doctrine\DBAL\Types\ConversionException
     */
    public function convertToPHPValue($value, AbstractPlatform $platform)
    {
        if ($value === null) {
            return null;
        } elseif (strstr($value, '0000-00-00 00:00:00') != false) {
            return null;
        }

        if (mb_strlen($value) > mb_strlen('yyyy-mm-dd')) {
            //we have a datetime probably
            $val = \DateTime::createFromFormat('!'.$platform->getDateTimeFormatString(), $value);
        } else {
            $val = \DateTime::createFromFormat('!'.$platform->getDateFormatString(), $value);
        }
        if (!$val) {
            throw \Doctrine\DBAL\Types\ConversionException::conversionFailed($value, $this->getName());
        }

        return $val;
    }
}
