<?php

namespace Types;

use \Doctrine\DBAL\Platforms\AbstractPlatform;

/**
 * Doctrine can not handle our date 00-00-0000 because it is not a valid date.
 * So in the code we use NULL, but insert 00-00-0000
*/
class NullDateType extends \Doctrine\DBAL\Types\DateType
{

    public function convertToDatabaseValue($value, AbstractPlatform $platform)
    {
        return ($value !== null && $value instanceof \DateTime)
            ? $value->format($platform->getDateTimeFormatString()) : '0000-00-00';
    }

    public function convertToPHPValue($value, AbstractPlatform $platform)
    {
        if ($value === null) {
            return null;
        } else if (strstr($value, '0000-00-00') != false) {
            return null;
        }

        if (mb_strlen($value) > mb_strlen('yyyy-mm-dd')) {
            //we have a datetime probably
            $val = \DateTime::createFromFormat('!'.$platform->getDateTimeFormatString(), $value);
        } else {
            $val = \DateTime::createFromFormat('!'.$platform->getDateFormatString(), $value);
        }
        if (!$val) {
            throw \Doctrine\DBAL\Types\ConversionException::conversionFailed($value, $this->getName());
        }
        return $val;
    }
}
