<?php

namespace Types;

use \Doctrine\DBAL\Platforms\AbstractPlatform;
use \Doctrine\DBAL\Types\BooleanType;

class PhaseType extends BooleanType
{
    /**
     * Holds the possible enum types.
     *
     * @var array
     */
    private static $types = array(
        "default",
        "ctg",
        "dayofstay",
        "daycare",
        "special",
        "other",
    );

    /**
     * Get part of the SQL Declaration.
     *
     * @param array                                     $fieldDeclaration
     * @param \Doctrine\DBAL\Platforms\AbstractPlatform $platform
     *
     * @return string
     */
    public function getSQLDeclaration(array $fieldDeclaration, AbstractPlatform $platform)
    {
        return "ENUM('default','ctg','dayofstay','daycare','special','other') NULL COMMENT '(DC2Type:".$this->getName().")'";
    }

    /**
     * Convert PHP value to value used in database.
     *
     * @param string                                    $value
     * @param \Doctrine\DBAL\Platforms\AbstractPlatform $platform
     *
     * @return string|null
     */
    public function convertToDatabaseValue($value, AbstractPlatform $platform)
    {
        if (in_array($value, self::$types)) {
            return $value;
        }
        return null;
    }

    /**
     * Convert database value to value used in php.
     *
     * @param string                                    $value
     * @param \Doctrine\DBAL\Platforms\AbstractPlatform $platform
     *
     * @return string|null
     */
    public function convertToPHPValue($value, AbstractPlatform $platform)
    {
        if (array_key_exists($value, self::$types)) {
            return $value;
        }
        return null;
    }
}