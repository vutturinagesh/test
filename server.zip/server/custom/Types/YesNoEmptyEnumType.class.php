<?php

namespace Types;

use \Doctrine\DBAL\Platforms\AbstractPlatform;

/**
 * In 2.x code we don't want to use the ja, nee (yes, no) enum types in the database anymore
 * This custom type will map ja to 1 and nee to 0
*/
class YesNoEmptyEnumType extends \Doctrine\DBAL\Types\BooleanType
{
    public function getSQLDeclaration(array $fieldDeclaration, AbstractPlatform $platform)
    {
        return "ENUM('ja','nee','empty') null COMMENT '(DC2Type:".$this->getName().")'";
    }

    public function convertToDatabaseValue($value, AbstractPlatform $platform)
    { 
        if ($value === null) {
            $value = 'empty';
        } else if ($value === true) {
            $value = 'ja';
        } else if ($value === false) {
            $value = 'nee';
        }

        return $value;
    }

    public function convertToPHPValue($value, AbstractPlatform $platform)
    {
        if ($value === 'ja') {
            return true;
        }

        if ($value === 'empty') {
            return null;
        }

        return false;
    }

}
