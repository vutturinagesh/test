<?php

$customTypes = array(
    'nulldate' => 'Types\NullDateType',
    'yesnoenum' => 'Types\YesNoEnumType',
    'amountvalue' => 'Types\AmountValueType',
    'yesnoemptyenum' => 'Types\YesNoEmptyEnumType',
    'treatmentactivityauthorizationenum' => 'Types\TreatmentActivityAuthorizationEnumType',
    'treatmentapplicationenum' => 'Types\TreatmentApplicationEnumType',
    'malefemaleenum' => 'Types\GenderMaleFemaleType',
    'nulldatetime' => 'Types\NullDateTimeType',
    'nulltimestamp' => 'Types\NullTimestampType',
    'nullemptystring' => 'Types\NullEmptyStringType',
    'nullzerointeger' => 'Types\NullZeroIntegerType',
    'nullemptytext' => 'Types\NullEmptyTextType',
    'phasetypeenum' => 'Types\PhaseType',
);
