<?php

namespace Types;

use \Doctrine\DBAL\Platforms\AbstractPlatform;

/**
 * Doctrine can not handle our date 0000-00-00 00:00:00 because it is not a valid date.
 * So in the code we use NULL, but insert 0000-00-00 00:00:00
*/
class NullDateTimeType extends \Doctrine\DBAL\Types\DateType
{

    public function convertToDatabaseValue($value, AbstractPlatform $platform)
    {
        return ($value !== null)
            ? $value->format($platform->getDateTimeFormatString()) : '0000-00-00 00:00:00';
    }

    public function convertToPHPValue($value, AbstractPlatform $platform)
    {
        if ($value === null) {
            return null;
        } else if (strstr($value, '0000-00-00 00:00:00') != false) {
            return null;
        }

        if (mb_strlen($value) > mb_strlen('yyyy-mm-dd')) {
            //we have a datetime probably
            $val = \DateTime::createFromFormat('!'.$platform->getDateTimeFormatString(), $value);
        } else {
            $val = \DateTime::createFromFormat('!'.$platform->getDateFormatString(), $value);
        }
        if (!$val) {
            throw \Doctrine\DBAL\Types\ConversionException::conversionFailed($value, $this->getName());
        }
        
        return $val;
    }
}
