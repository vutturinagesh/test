<?php

namespace Types;

/**
 * Registers custom types to Doctrine
 * 
 * Why is this needed?
 * Instead of adding ugly lines in our bootstrap now we have a nice class that handles our registration.
 */
class CustomTypesRegister
{
    private static $types=array();

	/**
	 * registers the custom types we need for Doctrine
	 * addType throws an exception if anything goes wrong, so if we come to 
	 * return then it should be OK
	 * @return boolean
	 */
	public static function register()
	{
		if (empty(self::$types)) {
			self::load();
		}
		if (!empty(self::$types)) {
			foreach (self::$types as $mappingTypeName => $customTypeName) {				
				\Doctrine\DBAL\Types\Type::addType($mappingTypeName, $customTypeName);
			}
		} 
		return true;
	}

	/**
	 * Load the custom data types
	 * @return array
	 */
    private static function load()
    {
        include('CustomTypesArray.php');
        if ( !empty($customTypes) ) {
			self::$types = $customTypes;
        }
    }
	
}

