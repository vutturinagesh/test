<?php

namespace Types;

use \Doctrine\DBAL\Platforms\AbstractPlatform;

/**
 * We want to put zero into the database for few fields which are integer values
 * So in the code we use NULL, but insert 0
 */
class NullZeroIntegerType extends \Doctrine\DBAL\Types\IntegerType
{

    public function convertToDatabaseValue($value, AbstractPlatform $platform)
    {
        return ($value == null ? 0 : $value);
    }

    public function convertToPHPValue($value, AbstractPlatform $platform)
    {
        if ($value == 0) {
            return null;
        }
        return $value;
    }
}
