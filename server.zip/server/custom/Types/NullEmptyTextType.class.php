<?php

namespace Types;

use \Doctrine\DBAL\Platforms\AbstractPlatform;

/**
 * We want to insert customly None in to the db when there is a null value for few fields
 * So in the code we use NULL, but insert None
*/
class NullEmptyTextType extends \Doctrine\DBAL\Types\TextType
{

    public function convertToDatabaseValue($value, AbstractPlatform $platform)
    {
        return ($value == null ? '' : $value);
    }
    
    public function convertToPHPValue($value, AbstractPlatform $platform)
    {
        if ($value === '') {
            return null;
        }
        return $value;
    }
}
