<?php
/**
 * MCIS
 *
 * @author     Gerben de Graaf <gerben@medicore.nl>
 * @author     Barry Haanstra <barry.haanstra@medicore.nl>
 * @author     Jordy de Jong <jordy@medicore.nl>
 *
 * @copyright  Copyright (c) 2007 Medicore B.V.
 *
 * @category   MCIS
 * @package    MCIS
 * @version    $Id: constants.conf.php 40991 2013-05-15 14:39:29Z system $
 */

/**
 * Caching configuration
 */
define('CACHE_DIR',                '/tmp/');
define('CACHE_FILELOCKING',        TRUE);
define('CACHE_CLEANINGFACTOR',     150);
define('CACHE_DEFAULT_LIFETIME',   600);     // 10 min
define('CACHE_DIRTY_LIFETIME',     3600);    // 1 hour
define('CACHE_METAMODEL_LIFETIME', 1209600); // 2 weeks

/**
 * Disables all alt_print's
 */
define('DISABLE_ALT_PRINT', false);

/**
 * Default HTTP Request URI layouts
 */
$serviceURILayout = array('viewtype', 'service', 'action', '%');
$moduleURILayout  = array('viewtype', 'package', 'module', 'moduleid');
define('SERVICE_REQUEST_LAYOUT', serialize($serviceURILayout));
define('MODULE_REQUEST_LAYOUT', serialize($moduleURILayout));

/**
 * Default output renderer
 */
define('VIEW_TYPE', System_View::VIEW_JSON);

/**
 * Dispatcher fallback configuration
 * Because the Request parses different parameters for module requests,
 * the Dispatcher cannot locate Services. We exploit this by
 * telling the Dispatcher to fall back to the ModulesService
 */
define('DISPATCHER_FALLBACK_SERVICE', 'Modules');
define('DISPATCHER_FALLBACK_ACTION', 'index');

/**
 * Adresxpress xml rpc information
 */
define('ADRESXPRESS_HOSTNAME', 'www.cendris.nl');
define('ADRESXPRESS_SERVICE', '/webservices/services/xmlrpc');
define('ADRESXPRESS_MESSAGE', 'adresxpress.postcode');
define('ADRESXPRESS_USERNAME', 'mcis');
define('ADRESXPRESS_PASSWORD', 'IuWrh21!');

// Extranet RSS feed URL
define('EXTRANET_FEED_URL', 'http://extranet.medicore.nl/rss.xml');


/**
 * Password salting needs AUTH_SPICE defined.
 */
if (!defined('AUTH_SPICE')) {
    define('AUTH_SPICE', 'FyhjUi873jNHhK');
}

define('TEXTMESSAGE_ENCRYPT_SECRET', '#$%#RGGKRE__456!');

/**
 * Debug mode / dojo build / calendar refresh / dancing banana / etc...
 * supportaccount: default on
 *
 * TODO: move this code out of here.
 * This is a *CONSTANTS.CONF*, as in, filled with *CONSTANTS*
 * PLEASE *THINK* BEFORE YOU CODE NEXT TIME
 * THANK YOU
 */
if (!isset($_SESSION['settings'])) {

    // retrieve all settings once
    $rep = ActinidiumSettingRepository::getInstance();
    $critset = new CtrlAlt_CriteriaSet();
    $critset->addOrderBy('ActinidiumSetting', 'name');

    $settings = $rep->fetchCollection('ActinidiumSetting', $critset);


    foreach ($settings as $setting) {

        // make sure value is in correct type
        $valid = true;
        $value = $setting['value'];

        if ($setting['valueoptions'] != '') {
            // is this a valid option?
            $options = array_map('trim', explode(",", $setting['valueoptions']));
            $valid = in_array($value, $options);
        }

        // $_SESSION['settings']['customer_type'] is set according to the ACTINIDIUM_setting table
        // but when the 'SOM-MHC switching feature is active, it must be overridden for
        // authenticated users
        if ($valid) {
            $_SESSION['settings'][$setting['name']] = $value;
        }
    }

    // this should be overwritten in the business space for correct caching
    $_SESSION['settings']['revision'] = time();

}


// development mode? default false UNLESS we're logged in as Supportaccount in a local development branch

preg_match('/w([^.]+)\.([^.]+)\.mcis.[^\.]*(.efocus){0,1}.(nl|local)/', ( isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : "" ), $matches);
$devMode = isset($_SERVER['MCIS_DEV_MODE']) || (isset($matches[1]) && intval($matches[1]) > 0);
$developmentMode = false;
if ($devMode && isset($_SESSION['user']->username)) {

    if (isset($_SESSION['settings']['development_mode']) && isset($_SESSION['settings']['development_mode_username']) &&
        $_SESSION['settings']['development_mode_username'] != $_SESSION['user']->username) {

        // the development_mode setting in our session can't be trusted, because it was set for another username
        unset($_SESSION['settings']['development_mode']);
    }

    if (!isset($_SESSION['settings']['development_mode'])) {
         // remember for which user we are remembering this, to prevent unwanted behaviour when switching
        $_SESSION['settings']['development_mode_username'] = $_SESSION['user']->username;
        $_SESSION['settings']['development_mode'] = (isset($_SESSION['user']->username) && $_SESSION['user']->username == 'medicore');
    }
    $developmentMode = intval($_SESSION['settings']['development_mode']);
}

if (!defined('DEVELOPMENT_MODE')) {
    define('DEVELOPMENT_MODE', $developmentMode);
}


