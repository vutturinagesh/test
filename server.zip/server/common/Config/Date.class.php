<?php
/**
 */

namespace Config;

/**
 * Class contains some configuration for DateTime
 */
class Date
{
    const FORMAT_DATE = 'Y-m-d';
    const FORMAT_DATETIME = 'Y-m-d H:i';
    const FORMAT_TIME = 'H:i';
}
