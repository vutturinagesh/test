<?php

namespace Config;
/**
 * Configuration settings of MCIS
 *
 * @author eddy.de.boer
 */
class Config
{
   const DOT_START_DATE = '2012-01-01';
}

