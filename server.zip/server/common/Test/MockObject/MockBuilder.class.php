<?php

namespace Test\MockObject;

use PHPUnit_Framework_MockObject_MockBuilder;
use ReflectionClass;

/**
 * Mock builder.
 */
class MockBuilder extends PHPUnit_Framework_MockObject_MockBuilder
{
    /**
     * Create a mock of all except the specified methods.
     *
     * @param array $methods
     *
     * @return \Test\MockObject\MockBuilder
     */
    public function setMethodsExcept($methods)
    {
        $reflectionClass = new ReflectionClass($this->className);
        $reflectionMethods = $reflectionClass->getMethods();

        $classMethods = array();
        foreach ($reflectionMethods as $method) {
            $classMethods[] = $method->getName();
        }

        $methods = array_diff($classMethods, (array)$methods);
        return $this->setMethods($methods);
    }
}