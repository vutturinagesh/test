<?php

namespace Test;

use Test\MockObject\MockBuilder;
use PHPUnit_Framework_TestCase;
use ReflectionClass;

/**
 * Test case.
 */
abstract class TestCase extends PHPUnit_Framework_TestCase
{
    /**
     * Override getMockBuilder() to return custom mock builder.
     *
     * @param string $className
     *
     * @return \Test\MockObject\MockBuilder
     */
    public function getMockBuilder($className)
    {
        return new MockBuilder($this, $className);
    }

    /**
     * Invoke a class method, even though it has access level "protected" or "private".
     *
     * @param mixed $object
     * @param string $method
     * @param array $arguments
     *
     * @return mixed
     */
    protected function invokeMethod($object, $method, array $arguments = array())
    {
        $reflectionClass = new ReflectionClass($object);
        $reflectionMethod = $reflectionClass->getMethod($method);
        $reflectionMethod->setAccessible(true);
        return $reflectionMethod->invokeArgs($object, $arguments);
    }


    /**
     * Set a class property value, even though it has access level "protected".
     *
     * @param mixed $object
     * @param string $property
     * @param mixed $value
     */
    protected function setProperty($object, $property, $value)
    {
        $reflectionClass = new ReflectionClass($object);
        $reflectionProperty = $reflectionClass->getProperty($property);
        $reflectionProperty->setAccessible(true);
        $reflectionProperty->setValue($object, $value);
    }


    /**
     * Get a class property value, even though it has access level "protected".
     *
     * @param mixed $object
     * @param string $property
     *
     * @return mixed
     */
    protected function getProperty($object, $property)
    {
        $reflectionClass = new ReflectionClass($object);
        $reflectionProperty = $reflectionClass->getProperty($property);
        $reflectionProperty->setAccessible(true);
        return $reflectionProperty->getValue($object);
    }
}