<?php

namespace Encoding;

use Exception;

class Utf8
{
    /**
     * Convert any Input to UTF-8.
     *
     * @param mixed  $input
     * @param string $fromEncoding
     *
     * @throws \Exception
     */
    public static function convert(&$input, $fromEncoding='auto')
    {
        if (!method_exists(get_class(), $fromEncoding)) {
            throw new Exception('UTF-8 conversion from ' . $fromEncoding . ' does not exist.');
        }

        if (is_string($input)) {
            $input = self::$fromEncoding($input);
        } else if (is_array($input)) {
            foreach ($input as &$value) {
                self::convert($value, $fromEncoding);
            }
        } else if (is_object($input)) {
            $vars = array_keys(get_object_vars($input));
            foreach ($vars as $var) {
                $input->$var = self::$fromEncoding($input->$var);
            }
        }
    }

    /**
     * UTF8 encodes mixed input from ISO-88591-1.
     *
     * @param string $input
     *
     * @return string
     */
    private static function iso88591($input)
    {
        return utf8_encode($input);
    }

    /**
     * Convert to UTF-8 from 'ASCII, JIS, UTF-8, EUC-JP, SJIS'.
     *
     * @param string $input
     *
     * @return string
     */
    private static function auto($input)
    {
        return mb_convert_encoding($input, 'UTF-8', 'auto');
    }
}