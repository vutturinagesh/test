<?php
/**
 * Pagination adapter to wrap the pagination object
 */

namespace Response;

use Actinidium\API\Response\Pagination;

/**
 * Pagination Adaptor
 *
 */

class PaginationAdaptor
{
    /**
     * Holds the maximum number of the rows a page can have
     *
     * @var integer
     */
    const MAXLIMIT = 30;

    /**
     * Get the paginator object
     *
     * @param unknown $currentPage
     * @param unknown $rowsTotal
     * @param unknown $limit
     *
     * @return \Actinidium\API\Response\Pagination
     */
    public function getPaginator($currentPage, $rowsTotal, $limit = self::MAXLIMIT)
    {
        // get the total number of pages
        $totalPages = intval($rowsTotal / $limit);

        if ($rowsTotal % $limit >= 1) {
            $totalPages++;
        }

        // get the current page rows
        if ($currentPage == $totalPages && ($rowsTotal % $limit != 0)) {
            $rowsInCurrentPage = ($rowsTotal % $limit);
        } else if ($rowsTotal < $limit) {
            $rowsInCurrentPage = $rowsTotal;
        } else {
            $rowsInCurrentPage = $limit;
        }

        $paginator = new Pagination($rowsInCurrentPage, $rowsTotal, $limit, $currentPage);

        return $paginator;
    }

    /**
     * Return the number of rows per page.
     *
     * @return string
     */
    public function getMaxRowsLimit()
    {
        return self::MAXLIMIT;
    }

}
