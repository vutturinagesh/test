<?php

namespace Response;

final class Error
{
    /**
     * Error 401 Unauthorized.
     *
     * Receiving a 401 response is the server telling you, "you aren't authenticated (either not authenticated at all or
     * authenticated incorrectly) but please reauthenticate and try again.".
     *
     * Similar to 403 Forbidden, but specifically for use when authentication is required and has failed or has not yet
     * been provided.
     */
    public function unauthorized()
    {
        static::disableCache();
        header('Status: 401 Unauthorized');
        header('HTTP/1.1 401 Unauthorized');
        readfile(__DIR__ . '/../../../client/old/401.html');
        exit;
    }

    /**
     * Error 403 Forbidden.
     *
     * Receiving a 403 response is the server telling you, "I'm sorry. I know who you are (I believe who you say you
     * are) but you just don't have permission to access this resource. Maybe if you ask the system administrator
     * nicely, you'll get permission. But please don't bother me again until your predicament changes.".
     *
     * The request was a valid request, but the server is refusing to respond to it. Unlike a 401 Unauthorized response,
     * authenticating will make no difference.
     */
    public function forbidden()
    {
        static::disableCache();
        header('Status: 403 Forbidden');
        header('HTTP/1.1 403 Forbidden');
        readfile(__DIR__ . '/../../../client/old/403.html');
        exit;
    }

    /**
     * Disable cache.
     */
    private function disableCache()
    {
        header('Cache-Control: no-cache, no-store, must-revalidate'); // HTTP 1.1.
        header('Pragma: no-cache'); // HTTP 1.0.
        header('Expires: 0'); // Proxies.
    }
}