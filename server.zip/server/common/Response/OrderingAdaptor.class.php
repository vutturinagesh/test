<?php
/**
 * 
 * @author prasanth.pillai
 *
 */

namespace Response;

use Actinidium\API\Response\Pagination;
use Actinidium\API\Response\Ordering;
use Actinidium\API\Response\SortOrder;

/**
 * Ordering Adaptor
 * @author prasanth.pillai
 *
 */

class OrderingAdaptor
{
    private $orderingCollection;
    
    /**
     * Generate the ordering object
     * 
     * @param string $fieldName
     * @param string $direction
     * 
     * @return \Actinidium\API\Response\SortOrder
     */
    public function add($fieldName, $direction)
    {
        $ordering = new SortOrder($fieldName, $direction);
        $this->getOrderingCollectionObject()->add($ordering);
    }
    
    /**
     * Get the ordering collection object
     * 
     * @return \Actinidium\API\Response\OrderingCollection
     */
    private function getOrderingCollectionObject()
    {
        if (!$this->orderingCollection instanceof \Actinidium\API\Response\SortOrderCollection) {
            $this->orderingCollection = new \Actinidium\API\Response\SortOrderCollection;
        }
        return $this->orderingCollection;
    }
    
    /**
     * return the generated ordering collection
     * 
     * @return \Actinidium\API\Response\SortOrderCollection
     */
    public function getOrderingCollection()
    {
        return $this->orderingCollection;
    }
}
