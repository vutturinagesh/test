<?php


namespace Tree\Node;

use Tree\Manager\ManagerInterface;
use Tree\Manager\StandardManager;

/**
 *
 */
class Node implements NodeInterface
{
    /**
     * @var mixed
     */
    protected $key;

    /**
     * @var NodeInterface|null
     */
    protected $left;

    /**
     * @var NodeInterface|null
     */
    protected $right;

    /**
     * @var ManagerInterface
     */
    protected $manager;

    /**
     * @param mixed $key
     */
    public function __construct($key)
    {
        $this->key = $key;
    }

    /**
     * Get key of node
     *
     * @return mixed
     */
    public function getKey()
    {
        return $this->key;
    }

    /**
     * Get left node
     *
     * @return null|NodeInterface
     */
    public function getLeft()
    {
        return $this->left;
    }

    /**
     * Check if left node exists
     *
     * @return bool
     */
    public function hasLeft()
    {
        return !is_null($this->getLeft());
    }

    /**
     * Set left node
     *
     * @param NodeInterface|null $node
     *
     * @return $this
     */
    public function setLeft(NodeInterface $node = null)
    {
        $this->left = $node;

        return $this;
    }

    /**
     * Get right node
     *
     * @return null|NodeInterface
     */
    public function getRight()
    {
        return $this->right;
    }

    /**
     * Check if right node exists
     *
     * @return bool
     */
    public function hasRight()
    {
        return !is_null($this->getRight());
    }

    /**
     * Set right node
     *
     * @param NodeInterface|null $node
     *
     * @return $this
     */
    public function setRight(NodeInterface $node = null)
    {
        $this->right = $node;

        return $this;
    }

    /**
     * Check if node is a leaf
     *
     * @return bool
     */
    public function isLeaf()
    {
        return (!$this->hasLeft() && !$this->hasRight());
    }

    /**
     * Get depth of node
     *
     * @return int
     */
    public function getDepth()
    {
        return $this->getManager()->calculateDepth($this);
    }

    /**
     * Compares key with node key
     *
     * @param mixed $key
     *
     * @return int 0 if equal, 1 if key is larger, -1 if key is smaller
     */
    public function compare($key)
    {
        if ($this->getKey() == $key) {
            return NodeInterface::COMP_EQUAL;
        }

        return $this->getKey() > $key ? NodeInterface::COMP_LEFT : NodeInterface::COMP_RIGHT;
    }

    /**
     * Merges key with node key
     * - Default implementation is a stub
     *
     * @param mixed $key
     * @param array $options
     *
     * @return NodeInterface
     */
    public function merge($key, array $options = array())
    {
        return $this;
    }

    /**
     * Get node manager
     *
     * @return ManagerInterface
     */
    public function getManager()
    {
        if(!$this->manager) {
            $this->manager = new StandardManager();
        }
        return $this->manager;
    }

    /**
     * Set node manager
     *
     * @param ManagerInterface $manager
     *
     * @return $this
     */
    public function setManager(ManagerInterface $manager)
    {
        $this->manager = $manager;

        return $this;
    }

    /**
     * Transform node to array representation
     *
     * @return array
     */
    public function toArray()
    {
        $left = null;
        if ($this->hasLeft()) {
            $left = $this->getLeft()->toArray();
        }

        $right = null;
        if ($this->hasRight()) {
            $right = $this->getRight()->toArray();
        }

        return array(
            'key' => $this->getKey(),
            'depth' => $this->getDepth(),
            'left' => $left,
            'right' => $right
        );
    }

    /**
     * Transform node to linear (flat) array representation
     *
     * @return array
     */
    public function toLinearArray()
    {
        $arr = array($this->getKey());
        if ($this->hasLeft()) {
            $arr = array_merge($this->getLeft()->toLinearArray(), $arr);
        }

        if ($this->hasRight()) {
            $arr = array_merge($arr, $this->getRight()->toLinearArray());
        }

        return $arr;
    }
}