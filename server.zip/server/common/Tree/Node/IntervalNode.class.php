<?php


namespace Tree\Node;

use Calendar\Interval as Interval;
use Calendar\Interval\MetaInterface as IntervalMeta;
use RuntimeException;

/**
 *
 */
class IntervalNode extends Node implements NodeInterface
{
    /**
     * @param \Calendar\Interval $interval
     */
    public function __construct(Interval $interval)
    {
        parent::__construct($interval);
    }

    /**
     * Get key
     *
     * @return Interval
     */
    public function getKey()
    {
        return $this->key;
    }

    /**
     * Compares key with node key
     *
     * @param Interval $interval
     *
     * @return int 0 if equal, 1 if key is larger, -1 if key is smaller
     */
    public function compare($key)
    {
        if (!$key instanceof Interval) {
            throw new RuntimeException(sprintr('Cannot compare with %s', gettype($key)));
        }

        $current = $this->getKey();

        if ($current->after($key)) {
            return NodeInterface::COMP_RIGHT;
        } elseif ($current->before($key)) {
            return NodeInterface::COMP_LEFT;
        } else {
            return NodeInterface::COMP_EQUAL;
        }
    }

    /**
     * Merges key with node key
     *
     * @param Interval $key
     * @param array $options
     *
     * @return NodeInterface
     */
    public function merge($key, array $options = array())
    {
        if (!$key instanceof Interval) {
            throw new RuntimeException(sprintr('Cannot merge with %s', gettype($key)));
        }

        $currentKey = $this->getKey();
        if ($currentKey->overlaps($key)) {
            $cStart = $currentKey->getDtStart();
            $cEnd = $currentKey->getDtEnd();
            $cMeta = $currentKey->getMeta();
            $kStart = $key->getDtStart();
            $kEnd = $key->getDtEnd();
            $kMeta = $key->getMeta();

            if ($cMeta instanceof IntervalMeta && $kMeta instanceof IntervalMeta) {
                $mergedMeta = clone($cMeta);
                $mergedMeta->merge($kMeta);
            } elseif ($cMeta && $kMeta) {
                // Just to not lose it..
                $mergedMeta = array($cMeta, $kMeta);
            } else {
                $mergedMeta = null;
            }

            // overlap
            $this->key->setDtStart(max($cStart, $kStart));
            $this->key->setDtEnd(min($cEnd, $kEnd));
            $this->key->setMeta($mergedMeta);

            if ($cStart < $kStart) {
                $leftInterval = clone($currentKey);
                $leftInterval->setDtStart($cStart);
                $leftInterval->setDtEnd($kStart);
                $leftInterval->setMeta($cMeta);
                $this->getManager()->insert($leftInterval, $this, array('balance' => false));
            }

            if ($cEnd < $kEnd) {
                $rightInterval = $key;
                $rightInterval->setDtStart($cEnd);
                $rightInterval->setDtEnd($kEnd);
                $this->getManager()->insert($rightInterval, $this, array('balance' => false));
            }
        }

        return $this;
    }
}