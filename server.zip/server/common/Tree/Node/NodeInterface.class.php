<?php


namespace Tree\Node;

use Tree\Manager\ManagerInterface;

/**
 *
 */
interface NodeInterface
{
    const COMP_EQUAL = 0;
    const COMP_LEFT = -1;
    const COMP_RIGHT = 1;

    /**
     * Get key of node
     *
     * @return mixed
     */
    public function getKey();

    /**
     * Get left node
     *
     * @return null|NodeInterface
     */
    public function getLeft();

    /**
     * Check if left node exists
     *
     * @return bool
     */
    public function hasLeft();

    /**
     * Set left node
     *
     * @param NodeInterface|null $node
     *
     * @return NodeInterface
     */
    public function setLeft(NodeInterface $node = null);

    /**
     * Get right node
     *
     * @return null|NodeInterface
     */
    public function getRight();

    /**
     * Check if right node exists
     *
     * @return bool
     */
    public function hasRight();

    /**
     * Set right node
     *
     * @param NodeInterface|null $node
     *
     * @return NodeInterface
     */
    public function setRight(NodeInterface $node = null);

    /**
     * Check if node is a leaf
     *
     * @return bool
     */
    public function isLeaf();

    /**
     * Get depth of node
     *
     * @return int
     */
    public function getDepth();

    /**
     * Compares key with node key
     *
     * @param mixed $key
     *
     * @return int 0 if equal, 1 if key is larger, -1 if key is smaller
     */
    public function compare($key);

    /**
     * Merges key with node key
     *
     * @param mixed $key
     * @param array $options
     *
     * @return NodeInterface
     */
    public function merge($key, array $options = array());

    /**
     * Get node manager
     *
     * @return ManagerInterface
     */
    public function getManager();

    /**
     * Set node manager
     *
     * @param ManagerInterface $manager
     *
     * @return NodeInterface
     */
    public function setManager(ManagerInterface $manager);

    /**
     * Transform node to array representation
     *
     * @return array
     */
    public function toArray();

    /**
     * Transform node to linear (flat) array representation
     *
     * @return array
     */
    public function toLinearArray();
}