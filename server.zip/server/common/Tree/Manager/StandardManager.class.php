<?php


namespace Tree\Manager;

use Tree\Node\NodeInterface;
use Tree\Factory\FactoryInterface;
use Tree\Factory\StandardFactory;

/**
 *
 */
class StandardManager implements ManagerInterface
{
    /**
     * @var FactoryInterface
     */
    private $factory;

    /**
     * Insert new key into a node
     *
     * @param mixed $key
     * @param NodeInterface|null $node
     * @param array $options
     *
     * @return NodeInterface
     */
    public function insert($key, NodeInterface $node = null, array $options = array())
    {
        if (is_null($key)) {
            return null;
        }

        $factory = $this->getFactory();

        if (is_null($node)) {
            return $factory->createNode($key);
        }

        $cmp = $node->compare($key);

        if ($cmp === NodeInterface::COMP_LEFT) {
            $this->addToLeft($node, $key, $options);
        } elseif ($cmp === NodeInterface::COMP_RIGHT) {
            $this->addToRight($node, $key, $options);
        } else {
            $node->merge($key, $options);
        }

        return $node;
    }

    /**
     * Add key to left node
     *
     * @param NodeInterface $node
     * @param mixed $key
     * @param array $options
     *
     * @return NodeInterface
     */
    protected function addToLeft(NodeInterface $node, $key, array $options = array())
    {
        return $node->setLeft($this->insert($key, $node->getLeft(), $options));
    }

    /**
     * Add key to right node
     *
     * @param NodeInterface $node
     * @param mixed $key
     * @param array $options
     *
     * @return NodeInterface
     */
    protected function addToRight(NodeInterface $node, $key, array $options = array())
    {
        return $node->setRight($this->insert($key, $node->getRight(), $options));
    }

    /**
     * Get node factory
     *
     * @return \Tree\Factory\FactoryInterface
     */
    public function getFactory()
    {
        if (!$this->factory) {
            $this->factory = new StandardFactory($this);
        }
        return $this->factory;
    }

    /**
     * Set node factory
     *
     * @param FactoryInterface $factory
     *
     * @return FactoryInterface
     */
    public function setFactory(FactoryInterface $factory)
    {
        $this->factory = $factory;

        return $this->factory;
    }

    /**
     * Calculate depth for node
     *
     * @param NodeInterface $node
     *
     * @return int
     */
    public function calculateDepth(NodeInterface $node)
    {
        $leftDepth = 0;
        $rightDepth = 0;
        if ($node->hasLeft()) {
            $leftDepth = $this->calculateDepth($node->getLeft());
        }
        if ($node->hasRight()) {
            $rightDepth = $this->calculateDepth($node->getRight());
        }

        return (max($leftDepth, $rightDepth) + 1);
    }
}