<?php


namespace Tree\Manager;

use Tree\Node\NodeInterface;
use Tree\Factory\FactoryInterface;

/**
 *
 */
interface ManagerInterface
{
    /**
     * Insert new key into a node
     *
     * @param mixed $key
     * @param NodeInterface|null $node
     * @param array $options
     *
     * @return NodeInterface
     */
    public function insert($key, NodeInterface $node = null, array $options = array());

    /**
     * Calculate depth of a node
     *
     * @param NodeInterface $node
     *
     * @return int
     */
    public function calculateDepth(NodeInterface $node);

    /**
     * Get node factory
     *
     * @return FactoryInterface
     */
    public function getFactory();
}