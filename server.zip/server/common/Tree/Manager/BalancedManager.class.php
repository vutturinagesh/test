<?php

namespace Tree\Manager;

use Tree\Node\NodeInterface;

/**
 *
 */
class BalancedManager extends StandardManager implements ManagerInterface
{
    /**
     * Insert new key into a node
     *
     * @param mixed $key
     * @param NodeInterface|null $node
     * @param array $options
     *
     * @return NodeInterface
     */
    public function insert($key, NodeInterface $node = null, array $options = array())
    {
        if (is_null($key)) {
            // Nothing changed, so don't balance
            return $this;
        }

        $changedNode = parent::insert($key, $node, $options);

        if(!array_key_exists('balance', $options) || $options['balance'] === true) {
            return $this->balance($changedNode);
        } else {
            return $changedNode;
        }
    }

    /**
     * Calculate depth for node (and its parents)
     *
     * @param NodeInterface $node
     *
     * @return int
     */
    public function calculateDepth(NodeInterface $node)
    {
        $leftDepth = 0;
        $rightDepth = 0;
        if ($node->hasLeft() && $node->hasRight()) {
            $leftDepth = $node->getLeft()->getDepth();
            $rightDepth = $node->getRight()->getDepth();
        }

        return min($leftDepth, $rightDepth) + 1;
    }

    /**
     * Balance node
     *
     * @param NodeInterface $node
     *
     * @return NodeInterface New 'root'
     */
    protected function balance(NodeInterface $node)
    {
        if ($node->isLeaf()) {
            return $node;
        }

        $skew = $this->skew($node);
        $split = $this->split($skew);

        return $split;
    }

    /**
     * Skew (right rotation) a node
     *
     * @param NodeInterface $node
     *
     * @return NodeInterface
     */
    private function skew(NodeInterface $node)
    {
        if ($node->hasLeft() && $node->getLeft()->getDepth() == $node->getDepth()) {
            $tmp = $node;
            $node = $node->getLeft();
            $tmp->setLeft($node->getRight());
            $node->setRight($tmp);
        }
        if ($node->hasRight()) {
            $node->setRight($this->skew($node->getRight()));
        }

        return $node;
    }

    /**
     * Split (left rotation) a node
     *
     * @param NodeInterface $node
     *
     * @return NodeInterface
     */
    private function split(NodeInterface $node)
    {
        if ($node->hasRight() && $node->getRight()->hasRight()) {
            if ($node->getDepth() == $node->getRight()->getDepth()) {
                if ($node->getDepth() == $node->getRight()->getRight()->getDepth()) {
                    $tmp = clone($node);
                    $node = $node->getRight();
                    $tmp->setRight($node->getLeft());
                    $node->setLeft($tmp);
                    $node->setRight($this->split($node->getRight()));
                }
            }
        }

        return $node;
    }
}
