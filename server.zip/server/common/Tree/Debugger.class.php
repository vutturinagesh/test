<?php


namespace Tree;

use Tree\Node\NodeInterface;

/**
 *
 */
class Debugger
{
    private static $separator = ' ';

    public static function toString(NodeInterface $node)
    {
        $lines = self::getDisplayLines($node);

        foreach ($lines as $key => $line) {
            $lines[$key] = rtrim($line, self::$separator);
        }

        return implode(PHP_EOL, $lines);
    }

    public static function toHtml(NodeInterface $node)
    {
        return implode('<br />', self::getDisplayLines($node));
    }

    /**
     * Get lines to display a node (and its children)
     *
     * @param NodeInterface|null $node
     *
     * @return array
     */
    private static function getDisplayLines(NodeInterface $node = null)
    {
        $separator = self::$separator;

        if (!$node) {
            return array('X');
        }

        $value = 'O';

        $leftLines = self::getDisplayLines($node->getLeft());
        $leftLength = strlen($leftLines[0]);
        $rightLines = self::getDisplayLines($node->getRight());
        $rightLength = strlen($rightLines[0]);

        $nodeSeparator = 3;

        if ($node->hasLeft() && !$node->hasRight()) {
            $leftRightLength = strlen(substr($leftLines[0], strpos($leftLines[0], 'O') + 1));
            if ($leftRightLength == 2) {
                $leftLength -= 2;
                $nodeSeparator = 1;
            }
        }
        if ($node->hasRight() && !$node->hasLeft()) {
            $rightLeftLength = strlen(substr($rightLines[0], 0, strpos($rightLines[0], 'O')));
            if ($rightLeftLength == 2) {
                $rightLength -= 2;
                $nodeSeparator = 1;
            }
        }

        $lines = array();
        $lines[] = $separator . $value . $separator;
        $lines[] = '/' . $separator . '\\';
        foreach ($lines as $key => $line) {
            $lines[$key] = str_repeat($separator, $leftLength) . $line . str_repeat($separator, $rightLength);
        }

        $maxLines = max(count($leftLines), count($rightLines));
        for ($i = 0; $i < $maxLines; $i++) {
            $lines[2 + $i] = str_repeat($separator, $nodeSeparator);
            if (!array_key_exists($i, $leftLines)) {
                $lines[2 + $i].= str_repeat($separator, $leftLength);
            }
        }

        foreach ($leftLines as $key => $line) {
            $lines[2 + $key] = $line . $lines[2 + $key];
        }

        foreach ($rightLines as $key => $line) {
            $lines[2 + $key] .= $line;
        }

        return $lines;
    }
}