<?php


namespace Tree\Factory;

use Tree\Node\NodeInterface;
use Tree\Manager\ManagerInterface;

/**
 *
 */
interface FactoryInterface
{
    /**
     * @param ManagerInterface $manager
     */
    public function __construct(ManagerInterface $manager);

    /**
     * Get node manager
     *
     * @return ManagerInterface
     */
    public function getManager();

    /**
     * Create a new Node
     *
     * @param mixed $key
     * @param mixed $meta
     *
     * @return NodeInterface
     */
    public function createNode($key, $meta = null);
}