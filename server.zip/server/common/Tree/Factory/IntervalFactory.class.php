<?php


namespace Tree\Factory;

use Tree\Node\NodeInterface;
use Tree\Node\IntervalNode;
use RuntimeException;

/**
 *
 */
class IntervalFactory extends StandardFactory implements FactoryInterface
{
    /**
     * Create new node
     *
     * @param mixed $key
     * @param mixed $meta
     *
     * @return IntervalNode|NodeInterface
     */
    public function createNode($key, $meta = null)
    {
        if (!is_array($key) && !$key instanceof \Calendar\Interval) {
            throw new RuntimeException(sprintf('Expected an array or an instance of Calendar\Interval, got %s', gettype($key)));
        }

        if (is_array($key)) {
            if (!array_key_exists('start', $key) || !array_key_exists('end', $key)) {
                throw new RuntimeException(sprintf('Expected an array containing at least [start, end], got [%s]', implode(', ', array_keys($key))));
            }

            $start = $key['start'] instanceof \DateTime ? $key['start'] : new \DateTime($key['start']);
            unset($key['start']);
            $end = $key['end'] instanceof \DateTime ? $key['end'] : new \DateTime($key['end']);
            unset($key['end']);

            $key = new \Calendar\Interval($start, $end);
        }

        $node = new IntervalNode($key, $meta);
        $node->setManager($this->getManager());
        return $node;
    }
}