<?php


namespace Tree\Factory;

use Tree\Node\NodeInterface;
use Tree\Node\Node;
use Tree\Manager\ManagerInterface;

/**
 *
 */
class StandardFactory implements FactoryInterface
{
    /**
     * @var ManagerInterface
     */
    private $manager;

    /**
     * @param ManagerInterface $manager
     */
    public function __construct(ManagerInterface $manager)
    {
        $this->manager = $manager;
    }

    /**
     * Get node manager
     *
     * @return ManagerInterface
     */
    public function getManager()
    {
        return $this->manager;
    }

    /**
     * Create new node
     *
     * @param mixed $key
     * @param mixed $meta
     *
     * @return Node|NodeInterface
     */
    public function createNode($key, $meta = null)
    {
        $node = new Node($key, $meta);
        $node->setManager($this->getManager());
        return $node;
    }
}