<?php

namespace Tree;

use Tree\Node\NodeInterface;
use Tree\Manager\ManagerInterface;
use Tree\Manager\StandardManager;

/**
 * Tree object
 */
class Tree
{
    /**
     * @var NodeInterface
     */
    private $root;

    /**
     * @var ManagerInterface
     */
    private $manager;

    /**
     * Set node manager
     *
     * @param ManagerInterface $manager
     *
     * @return $this
     */
    public function setManager(ManagerInterface $manager)
    {
        $this->manager = $manager;

        return $this;
    }

    /**
     * Get node manager
     *
     * @return ManagerInterface
     */
    public function getManager()
    {
        if (!$this->manager) {
            $this->manager = new StandardManager();
        }
        return $this->manager;
    }

    /**
     *
     *
     * @return NodeInterface
     */
    public function getRoot()
    {
        return $this->root;
    }

    /**
     * Add a value to tree
     *
     * @param mixed $value
     *
     * @return $this
     */
    public function addValue($value)
    {
        $this->root = $this->getManager()->insert($value, $this->getRoot());

        return $this;
    }

    /**
     * Add multiple values to tree
     *
     * @param array $values
     *
     * @return $this
     */
    public function addValues(array $values)
    {
        foreach ($values as $value) {
            $this->addValue($value);
        }

        return $this;
    }

    /**
     * Transform entire tree to array representation
     *
     * @return array
     */
    public function toArray()
    {
        $root = $this->getRoot();
        if ($root) {
            return $root->toArray();
        } else {
            return array();
        }
    }

    /**
     * Transform entire tree to linear (flat) array representation
     *
     * @return array
     */
    public function toLinearArray()
    {
        $root = $this->getRoot();
        if ($root) {
            return $root->toLinearArray();
        } else {
            return array();
        }
    }
}