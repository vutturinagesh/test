<?php


namespace Date;

/**
 * Returns the date format
 * @author eddy.de.boer
 */
class Format
{
    const DATE_TIME = 'Y-m-d H:i:s';
    const DATE = 'Y-m-d';
    const TIME = 'H:i:s';
    const INTERVAL_TIME = '%H:%I:%S';


    public static function getFormat()
    {
        return self::DATE;
    }

    public static function getFormatDate()
    {
        return self::DATE;
    }
}
