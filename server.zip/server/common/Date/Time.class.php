<?php


namespace Date;

/**
 * Returns the date Time
 *
 * @author eddy.de.boer
 */
class Time
{
    
     /**
	 * validates a  time string (format:hh:mm:ss)
	 * 
	 * @param type $timeString
	 * @return boolean
	 */
	public static function isValidTimeString($timeString)
	{
		$pattern = "/^([01][0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$/";
		 if (preg_match($pattern,$timeString)) { 
			return true; 
		 }	
		 return false;
	}
	/**
	 * check timefrom and time Until
	 * 
	 * @param type $timeFrom
	 * @param type $timeUntil
	 * @return boolean
	 */
	public static function checkTimes($timeFrom,$timeUntil)
	{
		 $timeFrom =   \DateTime::createFromFormat("H:i:s", $timeFrom);
         $timeUntil =  \DateTime::createFromFormat("H:i:s", $timeUntil);
         if($timeFrom < $timeUntil){
            return true;
		 }
		 return false;
	}
	
}

