<?php

namespace Exception;

class NotAuthorizedException extends \Exception
{
}
