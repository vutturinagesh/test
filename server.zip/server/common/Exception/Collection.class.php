<?php
/**
 * class to hold collection of exception objects to propagate to GUI
 * 
 * @package Common
 * @subpackage Exception
 * 
 */

namespace Exception;

/**
 * Exception collection
 */
class Collection implements \Iterator, \Countable
{
    
    /**
     * @var \Exception[] to hold the exception objects
     */
    private $exceptions;
    
    /**
     * @var integer
     */
    private $key;
    
    /**
     * 
     * @param array $exceptions
     */
    public function __construct(array $exceptions = null)
    {
        if (is_array($exceptions)) {
            foreach ($exceptions as $exception) {
                $this->exceptions[] = $exception;
            }
        }
        $this->rewind();
    }
    
    /**
     * Add one exception at a time
     * 
     * @param \Exception $exception
     */
    public function add(\Exception $exception)
    {
        $this->exceptions[] = $exception; 
    }
    
    
    
    /**
     * @see \Iterator::current()
     * @return \Exception[]
     */
    public function current()
    {
        return $this->exceptions[$this->key];
    }
    
    /**
     * @see \Iterator::key()
     * @return int
     */
    public function key()
    {
        return $this->key;
    }
    
    /**
     * @see \Iterator::next()
     * @return void
     */
    public function next()
    {
        $this->key++;
    }
    
    /**
     * @see \Iterator::rewind()
     * @return void
     */
    public function rewind()
    {
        $this->key = 0;
    }
    
    /**
     * @see \Iterator::valid()
     * @return bool
     */
    public function valid()
    {
        return (array_key_exists($this->key, $this->exceptions));
    }
    
    /**
     * @see \Countable::count()
     * @return int
     */
    public function count()
    {
        return count($this->exceptions);
    }
}

