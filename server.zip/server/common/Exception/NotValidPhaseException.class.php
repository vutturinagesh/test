<?php

namespace Exception;

use Exception;

class NotValidPhaseException extends Exception
{
    public function __construct()
    {
        $this->message = "Trying to set invalid phase value.Phase should be an instance of \Medical\Phase or \Medical\MHC\Basic\Component";
    }
}
