<?php

namespace Factory;

use Symfony\Component\Translation\Loader\XliffFileLoader;
use Symfony\Component\Translation\Translator;
use Generic\User;

/**
 * This class can instantiate all kinds of Symfony objects, as we don't have Dependency Injection yet.
 *
 */
class TranslatorFactory
{
    /**
     * Language domain constants.
     */
    const TRANS_DOMAIN_MEDICAL = 'medical';
    const TRANS_DOMAIN_GENERIC = 'generic';
    const TRANS_DOMAIN_MENU = 'menu';
    const TRANS_DOMAIN_MEDICAL_VALIDATIONS = 'medical_validations';
    const TRANS_DOMAIN_PATIENT = 'patient';

    /**
     * Supported language constants.
     */
    const TRANS_LANG_NL = 'nl';
    const TRANS_LANG_EN = 'en';

    /**
     * Default settings
     */
    const TRANS_LANG_DEFAULT = self::TRANS_LANG_NL;
    const DEFAULT_RESOURCE_DIRECTORY = '/../../../../app/Resources/translations';

    /**
     * The resource directory where the xliff files can be found.
     *
     * @var null|string
     */
    private $resourceDirectory = null;

    /**
     * Create the Factory using a resource directory with xliff files.
     *
     * @param null|string $resourceDirectory
     */
    public function  __construct($resourceDirectory = null)
    {
        if ($resourceDirectory === null) {
            $resourceDirectory = $this->getDefaultResourceDirectory();
        }

        $this->resourceDirectory = $resourceDirectory;
    }

    /**
     * Instantiates a Translator object.
     *
     * @return Translator
     */
    public function getTranslator()
    {
        static $translator;

        if (!$translator) {
            $translator = new Translator($this->getTranslationLanguage());
            $translator->addLoader('xliff', new XliffFileLoader());
            $this->loadAllTranslationFiles(
                $translator,
                $this->getDefaultResourceDirectory()
            );
        }

        return $translator;
    }

    /**
     * Function used to get translation language.
     *
     * @return string settings language
     */
    private function getTranslationLanguage()
    {
        $settingLanguage = self::TRANS_LANG_DEFAULT;
        if (isset($_SESSION['settings']['language'])) {
            $settingLanguage = $_SESSION['settings']['language'];
        }
        
        return $settingLanguage;
    }

    /**
     * Loads all translations files in app/Resources/translations.
     *
     * @param Translator $translator
     * @param string $location
     */
    private function loadAllTranslationFiles(Translator $translator, $location)
    {
        $files = glob($location . '/*.xliff', GLOB_BRACE);
        foreach ($files as $file) {
            $fileInfo = (explode('.', basename($file)));
            $translator->addResource('xliff', $file, $fileInfo[1]); // add to default domain
            $translator->addResource('xliff', $file, $fileInfo[1], $fileInfo[0]); // add to container domain
        }
    }

    /**
     * Retrieve the default resource directory if no directory is specified in the constructor.
     *
     * @return string
     */
    private function getDefaultResourceDirectory()
    {
        return __DIR__ . self::DEFAULT_RESOURCE_DIRECTORY;
    }
}
