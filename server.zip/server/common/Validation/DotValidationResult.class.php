<?php

namespace Validation;

/**
 * Class DotValidationResult
 *
 * @package Validation
 */
class DotValidationResult
{
    const STATUS_ERROR = 'error';

    /**
     * Convenience method for adding messages received from dotvalidations to controller's Meta object
     *
     * @param array $validationResults
     * @param \Actinidium\API\Response\Meta $meta
     */
    public static function addMessagesToMeta(array $validationResults, \Actinidium\API\Response\Meta $meta)
    {
        if ($meta && ($validationResults && isset($validationResults['messages']))) {

            foreach ($validationResults['messages'] as $level => $messages) {
                foreach ($messages as $code => $message) {
                        $meta->addMessage($level, utf8_encode($message));
                    }
            }
        }
    }

    /**
     * Returns true if there is an error from the legacy validations.
     *
     * @param array $validationResults
     *
     * @return bool
     */
    public static function containsErrors(array $validationResults)
    {
        return ($validationResults && isset($validationResults['status']) && $validationResults['status'] == self::STATUS_ERROR);
    }
}
