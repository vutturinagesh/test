<?php

namespace Security;

/**
 * Sanitizes the input of the passed parameters.
 *
 */
class Sanitizer
{

    /**
     * Function to check if the input is an integer.
     *
     * expects an int , needed to have a sanity check on entityIds.
     *
     * @param int $input
     *
     * @return bool
     */
    public static function isInteger($input)
    {
        return ((string)(int)$input == $input);
    }

    /**
     * Function to check if the input is > 0.
     *
     * expect an int > 0, needed to have a sanity check on entityIds
     *
     * @param int $input
     *
     * @return bool
     */
    public static function isPositiveInteger($input)
    {
        return (self::isInteger($input) && $input > 0 );
    }

    /**
     * Function to check if the input is greater than 0 or 0.
     *
     * expect an int >= 0, needed to have a sanity check on entityIds
     *
     * @param $input
     *
     * @return bool
     */
    public static function isPositiveIntegerOrZero($input)
    {
        return (self::isInteger($input) && $input >= 0 );
    }

    /**
     * Function to check if the input is between floor and ceiling.
     *
     * checks:
     * - if $input is integer
     * - and >= $floor and <= $ceiling
     *
     * @param int $input
     * @param int $floor
     * @param int $ceiling
     *
     * @return boolean returns true if is integer and between $floor and $ceiling
     */
    public static function isIntegerBetween($input, $floor, $ceiling)
    {
        return (self::isInteger($input) && $input >= $floor && $input <= $ceiling);
    }

    /**
     * Function to check if a variable is empty.
     *
     * expect an int > 0, needed to have a sanity check on entityIds
     *
     * @param array|string $input
     *
     * @return bool
     */
    public static function isEmpty($input)
    {
        switch (gettype($input)) {
            case 'string':
                return (false == mb_strlen($input));
            case 'array':
                return self::isEmptyArray($input);
            case 'NULL':
                return true;
            case 'boolean':
                return !$input;
            default:
                return false;
        }
    }

    /**
     * Function to check if the array has at least one key => value pair.
     *
     * @param array $input
     *
     * @return bool
     */
    private static function isEmptyArray(array $input)
    {
        $isEmpty = true;
        foreach ($input as $key => $value) {

            if ((is_string($key) || is_int($key)) && strlen(trim($key)) > 0) {
                $isEmpty = false;
            }
        }
        
        return $isEmpty;
    }

    /**
     * Returns a treatmentActivity object if the $id is valid.
     *
     * @param int                               $id
     * @param \Medical\TreatmentActivityService $serviceModel
     *
     * @return \Medical\TreatmentActivity
     */
    public static function treatmentActivityId($id, \Medical\TreatmentActivityService $serviceModel)
    {
        return self::entityId($id, $serviceModel, "Medical\\TreatmentActivity");
    }

    /**
     * Returns a treatment object if the $id is valid.
     *
     * @param int                       $id
     * @param \Medical\TreatmentService $serviceModel
     *
     * @return \Medical\Treatment
     */
    public static function treatmentId($id, \Medical\TreatmentService $serviceModel)
    {
        return self::entityId($id, $serviceModel, "Medical\\Treatment");
    }

    /**
     * Returns an entity if the $id is valid.
     *
     * passed $serviceModel is the service in the model, to find the entity with the $id
     *
     * @param int                      $id
     * @param \Service\AbstractService $service
     * @param string                   $class
     *
     * @return mixed Entity object
     */
    public static function entityId($id, \Service\AbstractService $service, $class)
    {
        if (!$service) {
            throw new \Exception("Could not find $id for $class in service ". get_class($service));
        }

        $object = $service->find($id);
        if (!$object or !($object instanceof $class)) {
            return null;
        }
        return $object;
    }

    /**
     * Function to check if the value is a string.
     *
     * @param string $value
     *
     * @return bool
     */
    public static function isString($value)
    {
        return (bool)(preg_match('/^[a-z0-9_]+$/', $value));
    }

    /**
     * Function to check if a value is a valid string.
     *
     * Returns a sanitized string
     *
     * @param type $value
     *
     * @return bool
     */
    public static function isValidString($value)
    {
        /*
          if (is_object($value)) {
          return false;
          } else if(preg_match('/[\'^£$%&*()}{@#~?><>,|=_+¬]/', $value)) {
          return false;
          } else {
          return (bool) (preg_match('/^[A-Za-z.\ \-]+$/', $value));
          }
         */
        //Added to search for a particular pattern now it has been removed to acccept any characters
        //@Todo: Take inputs from the FOER and do the changes as necessary
        // As the data has may variations in handling with preg match we have just returned true
        // with checking for is_string
        if (is_string($value) || is_null($value)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Function to urlencode a string.
     *
     * @param string $value
     *
     * @return string
     */
    public static function strUrlencode($value)
    {
        return urlencode($value);
    }

    /**
     * Function to to typecast a string to a boolean.
     *
     * @param string|boolean $value
     *
     * @return boolean
     */
    public static function boolean($value)
    {
        if ($value === "true" || $value === true) {
            return true;
        }
        return false;
    }

    /**
     * Function to check if the passed value is a boolean.
     *
     * @param string|boolean $value
     *
     * @return boolean
     */
    public static function isBoolean($value)
    {
        return ($value === "true" || $value === true || $value === "false" || $value === false);
    }

    /**
     * Function to check if the passed date is between the floor and ceiling dates.
     *
     * checks:
     *          - if $input, $floor and $ceiling are valid dates
     *          - and >= $floor and <= $ceiling
     *          - Validate date must be between 2 dates
     *
     * @param \DateTime $input
     * @param \DateTime $floor
     * @param \DateTime $ceiling
     *
     * @return  boolean returns true if the input is between $floor and $ceiling
     */
    public static function isDateBetween(
        \DateTime $date,
        \DateTime $floor = null,
        \DateTime $ceiling = null
    ) {

        if (!$floor && !$ceiling) {
            return true;
        }

        if ($floor  && !$ceiling) {
            if ($date >= $floor) {
                return true;
            }
        }

        if ($floor && $ceiling) {
            if ($date >= $floor && $date <= $ceiling) {
                return true;
            }
        }

        if (!$floor && $ceiling) {
            if ($date <= $ceiling) {
                return true;
            }
        }
        return false;
    }

    /**
     * Checks if the given enddate is later than the startdate.
     *
     * @param string $floor
     * @param string $ceiling
     *
     * @return boolean
     */
    public static function isEnddateLaterThanStartDate($floor, $ceiling)
    {
        if (!self::isValidDate($floor) && !self::isValidDate($ceiling)) {
            if (self::date($floor) < self::date($ceiling)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Function to check if a passed value is a valid date.
     *
     * @param string $dateString
     *
     * @return boolean
     */
    public static function isValidDate($dateString)
    {
        $y = (int)substr($dateString, 0, 4);
        $m = (int)substr($dateString, 5, 2);
        $d = (int)substr($dateString, 8, 2);

        return checkdate($m, $d, $y);
    }

    /**
     * Function to create a date object from a passed datestring.
     *
     * @param string $dateString
     *
     * @return \DateTime | null
     */
    public static function date($dateString)
    {
        return \Actinidium\Date\ValidDateCreator::createDateTimeObject($dateString);
    }

    /**
     * Will check string length is <= given limit.
     *
     * @param string $string
     * @param int    $limit
     *
     * @return boolean
     */
    public static function isStringLengthIsValid($string, $limit = 255)
    {
        if (strlen($string) > $limit) {
            return false;
        }

        return true;
    }

    /**
     * Check if the string is the expected stringlength.
     *
     * @param string $string
     * @param int    $length
     *
     * @return boolean
     */
    public static function isValidLengthString($string, $length)
    {
        if (mb_strlen($string) == $length) {
            return true;
        }
        return false;
    }

    /**
     * Function to transform tags in the string to htmlentities.
     *
     * @param string $string
     *
     * @return string
     */
    public function string($string)
    {
        return htmlentities($string);
    }

    /**
     * Function to check if string is integer and it is >= $minLimit && <= $maxLimit.
     *
     * @param $input
     * @param $minLimit
     * @param $maxLimit
     *
     * @return bool
     */
    public static function isIntegerInBetween($input, $minLimit, $maxLimit)
    {
        if (is_numeric($input) &&  ($input >= $minLimit && $input <= $maxLimit)) {
            return true;
        }
        return false;
    }

    /**
     * Check if the passed value is a valid email.
     *
     * @param string $value
     *
     * @return boolean
     */
    public static function isValidEmail($value)
    {
        if (filter_var($value, FILTER_VALIDATE_EMAIL) === $value) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Check if the passed value is a valid phonenumber.
     *
     * @todo: check international phonenumbers as well.
     *
     * @param string $value
     *
     * @return boolean
     */
    public static function isValidPhoneNumber($value)
    {
        $regex = '/[A-Za-z!=_@#$%^&*{},.\/\|;:]/i';

        if (intval(preg_match($regex, $value)) > 0) {
            return false;
        }

        return true;
    }

    /**
     * Check if the passed value is a number.
     *
     * The value can be decimals also
     *
     * @param float $value
     *
     * @return boolean
     */
    public static function isValidNumber($value)
    {
        if (is_numeric($value)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Function to check if a value is greater than 0.
     *
     * @param int $value
     *
     * @return boolean
     */
    public static function isValidIntegerGreaterThanZero($value)
    {
        if (self::isInteger($value) <= 0) {
            return false;
        } else {
            return (bool)(preg_match('/^\d+$/', $value));
        }
    }

    /**
     * Sanitize the address house number and address house suffix.
     *
     * @param string $value
     *
     * @return boolean
     */
    public static function isValidStringWithNumbers($value)
    {
        if (is_object($value)) {
            return false;
        } else {
            return (bool)(preg_match('/^[a-zA-Z0-9]+$/', $value));
        }
    }

    /**
     * Sanitize for a valid postcode.
     *
     * @param string $value
     *
     * @return boolean
     */
    public static function isValidPostCode($value)
    {
        if (is_object($value)) {
            return false;
        } else {
            return (bool)(preg_match('/\d{4}\s{0,1}[A-Za-z]{2}/', $value));
        }

    }

    /**
     * Sanitize the gender.
     *
     * @param string $value
     *
     * @return boolean
     */
    public static function isValidGender($value)
    {
        if (strtolower($value) === 'male' || strtolower($value) === 'female') {
            return true;
        } else {
            return false;
        }
    }
}
