<?php

namespace Legacy;

/**
 * Gateway
 * This service functions as a proxy and can perform
 *  HTTP request against both v2.0 (performSubRequest) and v1.10 (executeAction) code.
 *
 *
 * @category    MCIS
 * @package     MCIS_Services
 * @copyright   Copyright (c) 2007-2008 Medicore B.V.
 */
class Gateway
{
    private $cookie_key = null;

    const USER_AGENT_STRING = "MCIS_GatewayService"; // dont use whitespace


    public function flushSessionCacheInternal()
    {
        $gateway = \Generic_GatewayRepository::getInstance($_SESSION['user']->sessionkey['sessionkey']);
        $result = $gateway->flushSessionCacheInternal();

        if (in_array($result, array('gateway failed', 'session flushed'))) {
            $data = $result;
        } else {

            $data = unserialize($result);
        }

        return $data;
    }



    /**
     * used to perform HTTP(S) requests against the v1.10.
     *
     * @param string $class
     * @param int $id
     * @param string $method
     * @param array $params
     * @param bool $startWithEmptySession
     * @param bool $convertClassNameToLowerCase
     *
     * @return mixed
     */
    public function execute($class = null, $id = null, $method = null, $params = null, $startWithEmptySession = false, $convertClassNameToLowerCase = true)
    {
        $storeSession = serialize($_SESSION);
        mb_internal_encoding("UTF-8");

        $gateway = \Generic_GatewayRepository::getInstance($_SESSION['user']->sessionkey['sessionkey']);
        $result = $gateway->callLegacyCode($class, $id, $method, $params, 1, $startWithEmptySession, $convertClassNameToLowerCase);
        $data = unserialize($result);
        unset($_SESSION);
        $_SESSION = unserialize($storeSession);
        unset($storeSession);

        return $data;
    }

    /**
     * setUp3xto2x
     *      set up the basic system dispatcher so that that we can call the
     *      2.x service layer from the 3.x code
     *
     * @author  Anush Prem <anush.prem@medicore.nl>
     */
    public static function setUp3xto2x()
    {
        $data = array (
            "GET" => array("callfrom3.x" => true),
            "POST" => array(),
            "FILES" => array()
        );

        $systemRequest = new \System_Request_HTTP();
        $systemRequest->setData($data);
        \System_Dispatcher::setRequest($systemRequest);
    }
}
