<?php

namespace Input;

use Zend\InputFilter\ArrayInput as ZendArrayInput;

/**
 * Class ArrayInput
 *
 * @package Input
 */
class SingleArrayInput extends ArrayInput
{
    /**
     * @param  mixed $context Extra "context" to provide the validator
     * @return bool
     */
    public function isValid($context = null)
    {

        $this->injectNotEmptyValidator();
        $validator = $this->getValidatorChain();
        $values    = $this->getValue();
        $result    = true;

        foreach ($values as $key => $value) {
            $newValue = array($key => $value);
            $result = $validator->isValid($newValue, $context);
            if (!$result) {
                if ($fallbackValue = $this->getFallbackValue()) {
                    $this->setValue($fallbackValue);
                    $result = true;
                }
                break;
            }
        }

        return $result;
    }
}
