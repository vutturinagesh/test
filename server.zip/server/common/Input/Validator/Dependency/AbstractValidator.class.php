<?php

namespace Input\Validator\Dependency;

use Zend\Validator\AbstractValidator as BaseAbstractValidator;
use Zend\InputFilter\Input;
use Zend\Validator\Exception\RuntimeException;

/**
 * Class Dependent
 * @package Input\Validator
 */
abstract class AbstractValidator extends BaseAbstractValidator
{
    /**
     * @var array List of fields this validator depends on
     */
    private $fieldNames = array();

    /**
     * Array of validation failure messages
     *
     * @var array
     */
    protected $messages = array();

    /**
     * {@inheritDoc}
     */
    public function __construct(array $options)
    {
        parent::__construct($options);

        if(empty($this->fieldNames) && count($this->fieldNames) > 1) {
            throw new RuntimeException('fieldNames must be provided and contain at least 2 fieldNames');
        }
    }

    /**
     * Set fieldNames
     *
     * @param array $fieldNames
     *
     * @return $this
     */
    public function setFieldNames(array $fieldNames)
    {
        $this->fieldNames = $fieldNames;

        return $this;
    }

    /**
     * Get fieldNames
     *
     * @return array
     */
    public function getFieldNames()
    {
        return $this->fieldNames;
    }

    /**
     * Get messages
     *
     * @return array
     */
    public function getMessages()
    {
        return $this->messages;
    }

    /**
     * Verify that all fields this validator depends on are valid
     *
     * @param Input[] $inputs Valid inputs
     *
     * @return bool
     */
    public function canValidate(array $inputs)
    {
        $inputNames = array_keys($inputs);
        foreach($this->fieldNames as $fieldName) {
            if(!in_array($fieldName, $inputNames)) {
                return false;
            }
        }

        return true;
    }

    /**
     * {@inheritDoc}
     */
    public function isValid($value)
    {
        $values = array();
        foreach($this->fieldNames as $fieldName) {
            $values[$fieldName] = $value->getValue($fieldName);
        }

        return $this->validateDependencies($values);
    }

    /**
     * Validate dependencies
     *
     * @param array $values The values of the dependencies to validate
     *
     * @return bool
     */
    abstract public function validateDependencies(array $values);
}