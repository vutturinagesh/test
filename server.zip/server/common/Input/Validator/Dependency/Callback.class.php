<?php

namespace Input\Validator\Dependency;

use Zend\Validator\Exception\InvalidArgumentException;
use Zend\Validator\Exception\RuntimeException;

/**
 *
 */
class Callback extends AbstractValidator
{
    /**
     * Invalid callback
     */
    const INVALID_CALLBACK = 'callbackInvalid';

    /**
     * Invalid value
     */
    const INVALID_VALUE = 'callbackValue';

    /**
     * Validation failure message template definitions
     *
     * @var array
     */
    protected $messageTemplates = array(
        self::INVALID_VALUE => "The input is not valid",
        self::INVALID_CALLBACK => "An exception has been raised within the callback",
    );

    /**
     * @var string|array|callable
     */
    private $callback;

    /**
     * Set error message
     *
     * @param string $message
     *
     * @return $this
     */
    public function setMessage($message)
    {
        $this->messageTemplates[self::INVALID_VALUE] = $message;

        return $this;
    }

    /**
     * Set callback
     *
     * @param string|array|callable $callback
     *
     * @return $this
     *
     * @throws \Zend\Validator\Exception\RuntimeException
     */
    public function setCallback($callback)
    {
        if (!is_callable($callback)) {
            throw new RuntimeException('Invalid callback given');
        }

        $this->callback = $callback;

        return $this;
    }

    /**
     * Get callback
     *
     * @return array|callable|string
     */
    public function getCallback()
    {
        return $this->callback;
    }

    /**
     * {@inheritDoc}
     */
    public function validateDependencies(array $values)
    {
        $callback = $this->getCallback();
        if (empty($callback)) {
            throw new InvalidArgumentException('No callback given');
        }

        $args = array($values, $this);

        try {
            if (!call_user_func_array($callback, $args)) {
                $this->messages = array($this->messageTemplates[self::INVALID_VALUE]);

                return false;
            }
        } catch (\Exception $e) {
            $this->messages = array($this->messageTemplates[self::INVALID_CALLBACK]);

            return false;
        }

        return true;
    }
}