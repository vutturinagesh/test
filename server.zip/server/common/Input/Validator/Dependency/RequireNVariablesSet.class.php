<?php

namespace Input\Validator\Dependency;

use Zend\Validator\NotEmpty;

class RequireNVariablesSet extends AbstractValidator{

    /**
     * Number of fields that should be provided
     *
     * @var int
     */
    protected $numberRequired = 1;

    /**
     * Number of fields that have been provided
     *
     * @var int
     */
    protected $numberFieldsSet = 0;

    /**
     * Set number of reuired fields
     *
     * @param $numberRequired
     */
    public function setNumberRequired($fieldName)
    {
        $this->numberRequired = $fieldName;
    }

    /**
     * Validates the set input-dependencies
     *
     * @param array $values
     *
     * @return bool
     *
     * @throws \Exception
     */
    public function validateDependencies(array $values)
    {
        if ((!is_int($this->numberRequired)) || ($this->numberRequired <= 0)) {
            throw new \Exception('NumberRequired should be integer higher than 0');
        }
        if (count($this->getFieldNames()) < $this->numberRequired) {
            throw new \Exception('Supplied number of fields ('.$this->numberFieldsSet.') is smaller than number of fields required ('.$this->numberRequired.')');
        }

        foreach ($this->getFieldNames() as $field) {
            $notEmpty = new NotEmpty();
            if ($notEmpty->isValid($values[$field])) {
                $this->numberFieldsSet += 1;
            }
        }
        if ($this->numberRequired > $this->numberFieldsSet) {
            $this->messages = 'At least '.$this->numberRequired.' field(s) should be set. At this moment there are(/is) '.$this->numberFieldsSet.' fields set out of '.implode(', ',$this->getFieldNames()).'.' ;

            return false;
        }

        return true;
    }
}