<?php

namespace Input\Validator\Dependency;

use Config\Date as DateConfig;
use Input\Validator\Time\GreaterThan;
use Zend\Validator\Exception\RuntimeException;

/**
 *
 */
class Time extends AbstractValidator
{
    /**
     * FieldName containing start time
     *
     * @var string
     */
    private $startFieldName = 'timeStart';

    /**
     * FieldName containing end time
     *
     * @var string
     */
    private $endFieldName = 'timeEnd';

    /**
     * Set start fieldName
     *
     * @param string $fieldName
     */
    public function setStart($fieldName)
    {
        $this->startFieldName = $fieldName;
    }

    /**
     * Set end fieldName
     *
     * @param string $fieldName
     */
    public function setEnd($fieldName)
    {
        $this->endFieldName = $fieldName;
    }

    /**
     * {@inheritDoc}
     */
    public function validateDependencies(array $values)
    {
        if(!array_key_exists($this->startFieldName, $values)) {
            throw new RuntimeException('Unknown fieldName '. $this->startFieldName);
        }

        if(!array_key_exists($this->endFieldName, $values)) {
            throw new RuntimeException('Unknown fieldName '. $this->endFieldName);
        }

        $timeStart = $values[$this->startFieldName];
        $timeEnd = $values[$this->endFieldName];

        if(!$timeStart instanceof \DateTime) {
            $timeStart = \DateTime::createFromFormat(DateConfig::FORMAT_TIME, $timeStart);
        }
        if(!$timeEnd instanceof \DateTime){
            $timeEnd = \DateTime::createFromFormat(DateConfig::FORMAT_TIME, $values[$this->endFieldName]);
        }

        $greaterThan = new GreaterThan(array(
            'min' => $timeStart,
            'format' => DateConfig::FORMAT_TIME
        ));

        if (!$greaterThan->isValid($timeEnd)) {
            $this->messages = $greaterThan->getMessages();

            return false;
        }

        return true;
    }
}