<?php

namespace Input\Validator;

use Zend\Filter\StringToLower as ZendStringToLower;

/**
 * Class StringToLower
 *
 * @package Input\Validator
 */
class StringToLower extends ZendStringToLower
{
    /**
     * Returns the input as a string
     *
     * @param string $value
     *
     * @return string
     */
    public function filter($value)
    {
        if(is_null($value)) {
            return $value;
        }

        return parent::filter($value);
   }
}
