<?php

namespace Input\Validator;

/**
 * Class to test if entity exists
 */
class ResourceExists extends EntityExists
{
    /**
     * Error constants
     */
    const ERROR_RESOURCE_NOT_ACTIVE = 'resourceNotActive';

    /**
     * @var array Message templates
     */
    protected $messageTemplates = array(
        self::ERROR_NO_ENTITY_FOUND => "No %entity% matching '%value%' was found",
        self::ERROR_RESOURCE_NOT_ACTIVE => "%entity% matching '%value%' is not active",
    );

    /**
     * @var string
     */
    protected $entity = 'resource';

    /**
     * {@inheritDoc}
     */
    public function isValid($value)
    {
        if (parent::isValid($value)) {
            return $this->isActive($value);
        }

        return false;
    }

    /**
     * Verify provided resource is currently active
     *
     * @param mixed $value
     *
     * @return bool
     */
    private function isActive($value)
    {
        /**
         * @var \Generic\Resource $resource
         */
        $match = $this->getMatch($value);

        if (!$match->isActive()) {
            $this->error(self::ERROR_RESOURCE_NOT_ACTIVE, $value);
            return false;
        }

        return true;
    }
}