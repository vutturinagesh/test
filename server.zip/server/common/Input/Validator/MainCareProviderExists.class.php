<?php

namespace Input\Validator;

/**
 * Class to test if MainCareProvider exists or is not set (empty)
 */
class MainCareProviderExists extends EmployeeExists
{
    /**
     * Override the check for maincareprovider.
     * 
     * It should be possible to remove the maincareprovider from an appointment
     * 
     * @param array $value an array of values passed by validator
     * @return bool if the validation has been successful
     * 
     * @uses \Input\Validator\EmployeeExists for underlying employee checks
     */
    public function isValid($value)
    {
        // check if every field passed for validation is empty
        $isEmpty = true;
        foreach ($this->fields as $field) {
            // check if the field exists and has an empty value. Zero (0) is considered not empty. 
            if (array_key_exists($field, $value) && $value[$field] !== '') {
                $isEmpty = false;
                break;
            }
        }
        if ($isEmpty) {
            // if everything is empty, this is valid
            return true;
        } else {
            // otherwise, return employee checks
            return parent::isValid($value);
        }
    }
}
