<?php

namespace Input\Validator;

use Zend\Filter\StringToUpper as ZendStringToUpper;

/**
 * Class StringToUpper
 *
 * @package Input\Validator
 */
class StringToUpper extends ZendStringToUpper
{
    /**
     * Returns the input as a string
     *
     * @param string $value
     *
     * @return string
     */
    public function filter($value)
    {
        if (is_null($value)) {
            return $value;
        }

        return parent::filter($value);
    }
}
