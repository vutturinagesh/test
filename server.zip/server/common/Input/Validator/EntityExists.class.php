<?php

namespace Input\Validator;

use Doctrine\ORM\EntityRepository;
use Zend\Validator\AbstractValidator;
use Zend\Stdlib\ArrayUtils;
use Zend\Validator\Exception;

/**
 * Class to test if entity exists
 */
class EntityExists extends AbstractValidator
{
    /**
     * Error constants
     */
    const ERROR_NO_ENTITY_FOUND = 'noEntityFound';

    /**
     * @var array Message templates
     */
    protected $messageTemplates = array(
        self::ERROR_NO_ENTITY_FOUND => "No %entity% matching '%value%' was found",
    );

    /**
     * @var array Variables available in message templates
     */
    protected $messageVariables = array(
        'value' => 'value',
        'entity' => 'entity'
    );

    /**
     * @var EntityRepository
     */
    protected $objectRepository;

    /**
     * Fields to be checked
     *
     * @var array
     */
    protected $fields;

    /**
     * @var string
     */
    protected $entity = 'entity';

    /**
     * @var array
     */
    protected $criteria = array();

    /**
     * Constructor
     *
     * @param array $options required keys are `object_repository`, which must be an instance of
     *                       Doctrine\ORM\EntityRepository, and `fields`, with either
     *                       a string or an array of strings representing the fields to be matched by the validator.
     *                       Optionally the name of the `entity` can be provided which is displayed in any error message
     *
     * @throws \Zend\Validator\Exception\InvalidArgumentException
     */
    public function __construct(array $options)
    {
        if (!isset($options['object_repository']) || !$options['object_repository'] instanceof EntityRepository) {
            if (!array_key_exists('object_repository', $options)) {
                $provided = 'nothing';
            } else {
                if (is_object($options['object_repository'])) {
                    $provided = get_class($options['object_repository']);
                } else {
                    $provided = getType($options['object_repository']);
                }
            }

            throw new Exception\InvalidArgumentException(
                sprintf(
                    'Option "object_repository" is required and must be an instance of'
                    . ' Doctrine\ORM\EntityRepository, %s given',
                    $provided
                )
            );
        }

        $this->setObjectRepository($options['object_repository']);

        if (!isset($options['fields'])) {
            throw new Exception\InvalidArgumentException(
                'Key `fields` must be provided and be a field or a list of fields to be used when searching for'
                . ' existing instances'
            );
        }

        $this->fields = $options['fields'];
        $this->validateFields();

        if(isset($options['criteria'])) {
            $this->criteria = $options['criteria'];
        }

        if (isset($options['entity'])) {
            $this->entity = $options['entity'];
        }

        parent::__construct($options);
    }

    /**
     * Set repository that is used to find entity
     *
     * @param EntityRepository $objectRepository
     *
     * @return $this
     */
    public function setObjectRepository(EntityRepository $objectRepository)
    {
        $this->objectRepository = $objectRepository;

        return $this;
    }

    /**
     * Get repository that is used to find entity
     *
     * @return EntityRepository
     */
    public function getObjectRepository()
    {
        return $this->objectRepository;
    }

    /**
     * Filters and validates the fields passed to the constructor
     *
     * @return array
     *
     * @throws \Zend\Validator\Exception\InvalidArgumentException
     */
    private function validateFields()
    {
        $fields = (array)$this->fields;

        if (empty($fields)) {
            throw new Exception\InvalidArgumentException('Provided fields list was empty!');
        }

        foreach ($fields as $key => $field) {
            if (!is_string($field)) {
                throw new Exception\InvalidArgumentException(
                    sprintf('Provided fields must be strings, %s provided for key %s', gettype($field), $key)
                );
            }
        }

        $this->fields = array_values($fields);
    }

    /**
     * Cleanup the value used to search for the entity
     *
     * @param string|array $value a field value or an array of field values if more fields have been
     *                            configured to be matched
     *
     * @return array
     *
     * @throws \Zend\Validator\Exception\RuntimeException
     */
    protected function cleanSearchValue($value)
    {
        $value = (array)$value;

        if (ArrayUtils::isHashTable($value)) {
            $matchedFieldsValues = array();

            foreach ($this->fields as $field) {
                if (!array_key_exists($field, $value)) {
                    throw new Exception\RuntimeException(
                        sprintf(
                            'Field "%s" was not provided, but was expected since the configured field lists needs'
                            . ' it for validation',
                            $field
                        )
                    );
                }

                $matchedFieldsValues[$field] = $value[$field];
            }
        } else {
            $matchedFieldsValues = @array_combine($this->fields, $value);

            if (false === $matchedFieldsValues) {
                throw new Exception\RuntimeException(
                    sprintf(
                        'Provided values count is %s, while expected number of fields to be matched is %s',
                        count($value),
                        count($this->fields)
                    )
                );
            }
        }

        return array_merge($this->criteria, $matchedFieldsValues);
    }

    /**
     * {@inheritDoc}
     */
    public function isValid($value)
    {
        if (empty($value)) {
            return true;
        }

        $value = $this->cleanSearchValue($value);
        $match = $this->getMatch($value);

        if (is_object($match)) {
            return true;

        }
        $this->error(self::ERROR_NO_ENTITY_FOUND, $value);

        return false;
    }

    /**
     * Get object matching criteria
     *
     * @param mixed $value
     *
     * @return object
     */
    protected function getMatch($value)
    {
        return $this->getObjectRepository()->findOneBy($value);
    }
}