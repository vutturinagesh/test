<?php

namespace Input\Validator;
use \Calendar\Appointment\Participation;
/**
 * Class to test if Participation exists or is not set (empty)
 */
class ParticipationExists extends EntityExists
{
    /**
     * Override the check for Participation.
     * 
     * It should be possible to remove the Participation from an appointment
     * 
     * @param array $value an array of values passed by validator
     * @return bool if the validation has been successful
     * 
     * @uses \Input\Validator\EntityExists for underlying checks
     */
    const ERROR_NOT_A_VALID_PATIENT_SYSTEM = "Not a valid patient system value.";

    private $allowedSystem = array(
        Participation::PATIENT_ONLY,
        Participation::PATIENT_SYSTEM,
        Participation::PATIENT_WITH_SYSTEM
    );

    public function isValid($value)
    {
        $isValidPatientSystem = false;
        foreach ($this->fields as $field) {
            if ($field == 'system'
                && array_key_exists($field, $value) 
                && in_array($value[$field], $this->allowedSystem)
                ){
                    $isValidPatientSystem = true;
                    break;
            } else {
                return parent::isValid($value);
                break;
            }
        }

        if ($isValidPatientSystem) {
            return true;
        } else {
            $this->error(self::ERROR_NOT_A_VALID_PATIENT_SYSTEM, $value);
            return false;
        }
    }
}
