<?php

namespace Input\Validator;

use Generic\ClinicService;
use Generic\Employee;
use Zend\Validator\AbstractValidator;
use Zend\Validator\Exception;

/**
 * Validates if provided clinic is accessible for current logged in employee
 */
class AccessibleClinic extends AbstractValidator
{
    /**
     * Error constants
     */
    const ERROR_NOT_ALLOWED = 'notAllowed';
    const ERROR_UNKNOWN_CLINIC = 'unknownClinic';

    /**
     * @var array Message templates
     */
    protected $messageTemplates = array(
        self::ERROR_NOT_ALLOWED => "Clinic with %value% is not allowed for %employee%",
        self::ERROR_UNKNOWN_CLINIC => "Clinic with %value% does not exist",
    );

    /**
     * @var array
     */
    protected $messageVariables = array(
        'employee' => 'employee'
    );

    /**
     * @var \Generic\Employee
     */
    private $currentEmployee;

    /**
     * Constructor
     *
     * @param array $options required key is `current_employee`, which must be an instance of
     *                       Generic\Employee.
     * @throws \Zend\Validator\Exception\InvalidArgumentException
     */
    public function __construct(array $options)
    {
        if (!isset($options['current_employee']) || !$options['current_employee'] instanceof Employee) {
            if (!array_key_exists('current_employee', $options)) {
                $provided = 'nothing';
            } else {
                if (is_object($options['current_employee'])) {
                    $provided = get_class($options['current_employee']);
                } else {
                    $provided = getType($options['current_employee']);
                }
            }

            throw new Exception\InvalidArgumentException(
                sprintf(
                    'Option "current_employee" is required and must be an instance of'
                    . ' Generic\Employee, %s given',
                    $provided
                )
            );
        }

        $this->currentEmployee = $options['current_employee'];
        $this->employee = $this->currentEmployee->getFullName();

        parent::__construct($options);
    }

    /**
     * {@inheritDoc}
     */
    public function isValid($value)
    {
        $clinicService = new ClinicService();
        $clinic = $clinicService->find($value['id']);

        if (!is_object($clinic)) {
            $this->error(self::ERROR_UNKNOWN_CLINIC, $value);
        }

        if ($this->currentEmployee->worksAt($clinic)) {
            return true;
        }

        $this->error(self::ERROR_NOT_ALLOWED, $value);

        return false;
    }
}