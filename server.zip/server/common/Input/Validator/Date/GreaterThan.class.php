<?php
/**
 *
 */

namespace Input\Validator\Date;

use DateTime;
use Config\Date as DateConfig;

class GreaterThan extends \Zend\Validator\GreaterThan
{
    /**
     * Validation failure message template definitions
     *
     * @var array
     */
    protected $messageTemplates = array(
        self::NOT_GREATER => "The input is not greater than %min%",
        self::NOT_GREATER_INCLUSIVE => "The input is not greater or equal than %min%",
    );

    /**
     * @var array
     */
    protected $messageVariables = array(
        'min' => 'minDate'
    );

    /**
     * @var string
     */
    protected $minDate;

    /**
     * Returns true if and only if $value is greater than min option
     *
     * @param  mixed $value
     * @return bool
     */
    public function isValid($value)
    {
        if ($this->getMin() instanceof DateTime) {
            $this->minDate = $this->min->format(DateConfig::FORMAT_DATE);
            $this->setMin($this->min->format('U'));
        }

        if ($value instanceof DateTime) {
            $value = $value->format('U');
        }

        return parent::isValid($value);
    }
}