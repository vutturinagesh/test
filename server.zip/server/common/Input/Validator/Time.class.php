<?php
/**
 *
 */

namespace Input\Validator;

use Zend\Validator\Date;
use Config\Date as DateConfig;

class Time extends Date
{
    /**
     * Optional format
     *
     * @var string|null
     */
    protected $format = DateConfig::FORMAT_TIME;

    /**
     * Validation failure message template definitions
     *
     * @var array
     */
    protected $messageTemplates = array(
        self::INVALID => "Invalid type given. String, integer, array or DateTime expected",
        self::INVALID_DATE => "The input does not appear to be a valid time",
        self::FALSEFORMAT => "The input does not fit the time format '%format%'",
    );
}