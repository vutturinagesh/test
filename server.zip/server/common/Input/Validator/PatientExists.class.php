<?php

namespace Input\Validator;

/**
 * Class to test if entity exists
 */
class PatientExists extends EntityExists
{
    /**
     * Error constants
     */
    const ERROR_PATIENT_NOT_ACTIVE = 'patientNotActive';
    const ERROR_PATIENT_DECEASED = 'patientDeceased';

    /**
     * @var array Message templates
     */
    protected $messageTemplates = array(
        self::ERROR_NO_ENTITY_FOUND => "No %entity% matching '%value%' was found",
        self::ERROR_PATIENT_NOT_ACTIVE => "%entity% matching '%value%' is not active",
        self::ERROR_PATIENT_DECEASED => "%entity% matching '%value%' is deceased",
    );

    /**
     * @var string
     */
    protected $entity = 'patient';

    /**
     * {@inheritDoc}
     */
    public function isValid($value)
    {
        if (parent::isValid($value)) {
            return $this->isActive($value);
        }

        return false;
    }

    /**
     * Verify provided resource is currently active
     *
     * @param mixed $value
     *
     * @return bool
     */
    private function isActive($value)
    {
        /**
         * @var \Generic\Resource $resource
         */
        $match = $this->getMatch($value);

        if ($match->isDeleted()) {
            $this->error(self::ERROR_PATIENT_NOT_ACTIVE, $value);
            return false;
        }

        return true;
    }
}