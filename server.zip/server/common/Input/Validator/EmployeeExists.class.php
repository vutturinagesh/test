<?php

namespace Input\Validator;

/**
 * Class to test if entity exists
 */
class EmployeeExists extends EntityExists
{
    /**
     * Error constants
     */
    const ERROR_EMPLOYEE_NOT_ACTIVE = 'employeeNotActive';

    /**
     * @var array Message templates
     */
    protected $messageTemplates = array(
        self::ERROR_NO_ENTITY_FOUND => "No %entity% matching '%value%' was found",
        self::ERROR_EMPLOYEE_NOT_ACTIVE => "%entity% matching '%value%' is not active",
    );

    /**
     * @var string
     */
    protected $entity = 'employee';

    /**
     * {@inheritDoc}
     */
    public function isValid($value)
    {
        if (parent::isValid($value)) {
            return $this->isActiveEmployee($value);
        }

        return false;
    }

    /**
     * Verify provided employee is currently active
     *
     * @param mixed $value
     *
     * @return bool
     */
    private function isActiveEmployee($value)
    {
        /**
         * @var \Generic\Employee $employee
         */
        $match = $this->getMatch($value);

        if (!$match->isActive()) {
            $this->error(self::ERROR_EMPLOYEE_NOT_ACTIVE, $value);
            return false;
        }

        return true;
    }
}