<?php

namespace Input;

use Zend\InputFilter\ArrayInput as ZendArrayInput;

/**
 * Class ArrayInput
 *
 * @package Input
 */
class ArrayInput extends ZendArrayInput
{

    /**
     * Custom method to be able to input null without getting an exception
     *
     * @param  array $value
     *
     * @return Input
     */
    public function setValue($value)
    {
        if (!is_array($value)) {
            return $this;
        }

        return parent::setValue($value);
    }
}
