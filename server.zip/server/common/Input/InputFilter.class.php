<?php

namespace Input;

use Input\Validator\Dependency\AbstractValidator;
use Interfaces\ToArrayInterface;
use Zend\InputFilter\Exception\RuntimeException;
use Zend\InputFilter\InputFilter as ZendInputFilter;

/**
 * Abstract inputFilter
 *
 * Adds functionality to bind an object to filter which is used to enable dependent validations where data is only
 * partially supplied.
 */
class InputFilter extends ZendInputFilter
{
    /**
     * @var object|null The bound object, Null if no object is bound
     */
    private $boundObject;

    /**
     * @var array|null List of bound object values, null if no object is bound
     */
    private $boundObjectValues;

    /**
     * @var AbstractValidator[] List of dependent validations
     */
    private $dependentValidations = array();

    /**
     * {@inheritDoc}
     */
    public function getValue($name)
    {
        $providedValue = parent::getValue($name);
        if (null !== $providedValue) {
            return $providedValue;
        }

        return $this->getObjectValue($name);
    }

    /**
     * Get value from bound object
     *
     * @param string $name Name of input to retrieve
     *
     * @return mixed
     */
    public function getObjectValue($name)
    {
        if ($this->boundObject) {
            if (!$this->boundObjectValues) {
                $this->boundObjectValues = $this->boundObject->toArray();
            }
            if (isset($this->boundObjectValues[$name])) {
                return $this->boundObjectValues[$name];
            }
        }

        return null;
    }

    /**
     * Bind object to input filter
     *
     * @param ToArrayInterface $object Object to be bound
     *
     * @return $this
     *
     * @throws RuntimeException
     */
    public function bind(ToArrayInterface $object)
    {
        if (!is_object($object)) {
            throw new RuntimeException('Value to be bound must be an object');
        }
        $this->boundObject = $object;

        return $this;
    }

    /**
     * {@inheritDoc}
     */
    public function isValid()
    {
        $isValid = parent::isValid();

        $validInputs = $this->getValidInput();

        foreach ($this->dependentValidations as $input => $dependentValidation) {
            if ($dependentValidation->canValidate($validInputs)) {
                if (!$dependentValidation->isValid($this)) {
                    $this->invalidInputs[$input] = $dependentValidation;
                    // TODO do we need to remove valid inputs on same $input
                    // TODO do we need to add validInput for $input if dependencies are valid

                    $isValid = false;
                }
            }
        }

        return $isValid;
    }

    /**
     * Attach a validation the depends on multiple input fields
     *
     * @param AbstractValidator $validator
     * @param string $registerInput The name of the input field failures should be registered on
     *
     * @return $this
     */
    public function attachDependencyValidation(AbstractValidator $validator, $registerInput)
    {
        $this->dependentValidations[$registerInput] = $validator;

        return $this;
    }

    protected function populate()
    {
        foreach (array_keys($this->inputs) as $name) {
            $input = $this->inputs[$name];

            if (!isset($this->data[$name])) {
                // No value; clear value in this input
                if ($input instanceof InputFilterInterface) {
                    $input->setData(array());
                    continue;
                }

                // Turned this off!
                // $input->setValue(null);
                continue;
            }

            $value = $this->data[$name];

            if ($input instanceof InputFilterInterface) {
                $input->setData($value);
                continue;
            }

            $input->setValue($value);
        }
    }
}
