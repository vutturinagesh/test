<?php

namespace Message;
/**
 * 
 *
 * @author eddy.de.boer
 */
class ExceptionHandler
{
    private static $nestingLevel = 0;

    const NESTING_LEVEL_TRESHOLD = 25;

    /**
     * Returns the message 
     * @param \Exception $e
     * @return string
     */
    public static function getMessage(\Exception $e) {
        if (++self::$nestingLevel > self::NESTING_LEVEL_TRESHOLD) {
            exit(1);
        }

        $message = $e->getMessage();
        if (  method_exists($e, "getPrevious")) {
            $previous = $e->getPrevious();
            if ($previous instanceof \Exception) {
                $message .= "\n" . $previous->getMessage();
            }
        }

        self::$nestingLevel--;

        return $message;
    }
}

