<?php

/**
 * List of possible messages send from the server
 * @IMPORTANT Preventing double entries:
 *      When adding new messages please set them in the correct order of code
 *      At the top of the array add the MG messages
 *      At The bottom add the M messages

 */

$messages = array(
    array(
        'code' => 'MEXC', //Used to show exceptions
        'lang' =>
            array(
                'en_uk' => '{*message*}',
                'nl' => '{*message*}',
            ),
    ),
    array(
        'code' => 'MG01',
        'lang' =>
            array(
                'en_uk' => 'The following fields are mandatory and missing: {*list_of_fields*}.',
                'nl' => 'De volgende velden zijn verplicht en ontbreken: {*list_of_fields*}.',
            ),
    ),
    array(
        'code' => 'MG02',
        'lang' =>
            array(
                'en_uk' => 'The following fields have unexpected format:
                    {*field_name*}, expected {*expected*}, actual {*actual*}.',
                'nl' => 'De volgende velden hebben verkeerde input:
                    {*field_name*} verwachte input {*expected*}, opgegeven {*actual*}',
            ),
    ),
    array(
        'code' => 'MG101',
        'lang' =>
            array(
                'en_uk' => '{*input*} is not a value possible for this field: {*field_name*}.',
                'nl' => '{*input*} is geen geldige waarde voor dit veld: {*field_name*}.',
            ),
    ),
    array(
        'code' => 'MG103',
        'lang' =>
            array(
                'en_uk' => 'No results were found with the provided input.',
                'nl' => 'Er zijn geen resultaten met deze zoekterm.',
            ),
    ),
    array(
        'code' => 'MG104',
        'lang' =>
            array(
                'en_uk' => '{*value*} has not been changed because optional field was left empty.',
                'nl' => '{*value*} is niet gewijzigd omdat deze optionele waarde leeg is gelaten.',
            ),
    ),
    array(
        'code' => 'MG105',
        'lang' =>
            array(
                'en_uk' => 'There is nothing to display.',
                'nl' => 'Er is niets om weer te geven.',
            ),
    ),
    array(
        'code' => 'MG106',
        'lang' =>
            array(
                'en_uk' => 'There are too many results to display. Please specify you search.',
                'nl' => 'Er zijn te veel resultaten om weer te geven. Gebruik meer zoektermen.',
            ),
    ),
    array(
        'code' => 'GV1',
        'lang' =>
            array(
                'en_uk' => 'The date must be a valid date (YYYY-MM-DD).',
                'nl' => 'De datum moet een geldige datum zijn (jjjj-mm-dd).',
            ),
    ),
    array(
        'code' => 'GV9',
        'lang' =>
            array(
                'en_uk' => 'Invalid input: {*object*} {*input*} does not exist.',
                'nl' => 'Ongeldige invoer: {*object*} {*input*} bestaat niet.',
            ),
        'params' =>
            array(
                0 => 'Object',
                1 => 'input',
            ),
    ),
    array(
        'code' => 'MG19',
        'lang' =>
            array(
                'en_uk' => 'Name should be between 1 - 255 characters.',
                'nl' => 'Naam moet tussen 1 - 255 tekens.',
            ),
    ),
    array(
        'code' => 'MG100',
        'lang' =>
            array(
                'en_uk' => '{*field_name*} cannot contain more than {*max_length*} characters.',
                'nl' => '{*field_name*} mag niet meer dan {*max_length*} tekens bevatten.',
            ),
    ),
    array(
        'code' => 'MG144',
        'lang' =>
            array(
                'en_uk' => '{*object*} must be an open {*input*}.',
                'nl' => '{*object*} moet een open {*input*}.',
            ),
    ),
    array(
        'code' => 'M003',
        'lang' =>
            array(
                'en_uk' => 'Previous treatment is not closed. Please close it before opening a new one.',
                'nl' => 'De vorige behandeling is nog niet gesloten.
                    Deze moet eerst gesloten zijn voordat een nieuwe geopend kan worden.',
            ),
    ),
    array(
        'code' => 'M008',
        'lang' =>
            array(
                'en_uk' => 'The performed date of the activity cannot be earlier than the start date of the treatment.',
                'nl' => 'De uitvoerdatum van de activiteit mag niet eerder zijn dan de startdatum van de behandeling.',
            ),
    ),
    array(
        'code' => 'EP-M21',
        'lang' =>
            array(
                'en_uk' => 'The end date must be on or later than the start date.',
                'nl' => 'De einddatum moet op of na de startdatum liggen.',
            ),
    ),
    array(
        'code' => 'EP-M26',
        'lang' =>
            array(
                'en_uk' => 'Within an episode, all treatments must be of the same treatment type.',
                'nl' => 'Binnen een zorgtraject moeten alle behandelingen van hetzelfde type zijn.',
            ),
    ),
    array(
        'code' => 'M010',
        'lang' =>
            array(
                'en_uk' => 'End date of the treatment must be equal to or later than the performance date of the last
                    performed activity.',
                'nl' => 'Einddatum van de behandeling moet gelijk of later zijn dan de uitvoerdatum van de laatst
                    uitgevoerde activiteit.',
            ),
    ),
    array(
        'code' => 'M011',
        'lang' =>
            array(
                'en_uk' => 'The episode cannot be closed: there are still open treatments.',
                'nl' => 'Het zorgtraject kan niet gesloten worden: er zijn nog openstaande behandelingen.',
            ),
    ),
    array(
        'code' => 'M015',
        'lang' =>
            array(
                'en_uk' => 'The end date of the episode must be on or later than the end date of the last
                    closed treatment.',
                'nl' => 'De einddatum van het zorgtraject moet op of later zijn dan de einddatum van de laatst
                    gesloten behandeling.',
            ),
    ),
    array(
        'code' => 'M017',
        'lang' =>
            array(
                'en_uk' => 'The treatment cannot be closed, because:',
                'nl' => 'De behandeling kan niet gesloten worden, omdat:',
            ),
    ),
    array(
        'code' => 'M022',
        'lang' =>
            array(
                'en_uk' => 'The episode cannot be closed yet',
                'nl' => 'Het zorgtraject mag nog niet gesloten worden.',
            ),
    ),
    array(
        'code' => 'M028',
        'lang' =>
            array(
                'en_uk' => 'Overlapping ICU trajectories are not allowed.',
                'nl' => 'Overlappende IC tracten zijn niet toegestaan.',
            ),
    ),
    array(
        'code' => 'M034',
        'lang' =>
            array(
                'en_uk' => 'The end date of the treatment cannot be in the future.',
                'nl' => 'De einddatum van de behandeling mag niet in de toekomst liggen.',
            ),
    ),
    array(
        'code' => 'M036',
        'lang' =>
            array(
                'en_uk' => 'The end date must be on or later than the start date.',
                'nl' => 'De einddatum moet op of na de startdatum liggen.',
            ),
    ),
    array(
        'code' => 'M039',
        'lang' =>
            array(
                'en_uk' => 'A treatment may be open for a maximum of 365 days.',
                'nl' => 'Een behandeling mag niet langer dan 365 dagen open staan.',
            ),
    ),
    array(
        'code' => 'M057',
        'lang' =>
            array(
                'en_uk' => 'The amount must be an integer between 1 and 9999.',
                'nl' => 'Het aantal moet een geheel getal zijn, tussen 1 en 9999.',
            ),
    ),
    array(
        'code' => 'M134',
        'lang' =>
            array(
                'en_uk' => 'The treatment is already financially processed.',
                'nl' => 'De behandeling is al financieel verwerkt.',
            ),
    ),
    array(
        'code' => 'M135',
        'lang' =>
            array(
                'en_uk' => 'The activity is financially processed.',
                'nl' => 'De activiteit is al financieel verwerkt.',
            ),
    ),
    array(
        'code' => 'M142',
        'lang' =>
            array(
                'en_uk' => 'The employee is not active on the start date of the treatment.',
                'nl' => 'De werknemer is niet actief op de startdatum van de behandeling.',
            ),
    ),
    array(
        'code' => 'M143',
        'lang' =>
            array(
                'en_uk' => 'The specialty of the employee is not the same as the specialty of the episode.',
                'nl' => 'Het specialisme van de medewerker komt niet overeen met die van het zorgtraject.',
            ),
    ),
    array(
        'code' => 'M144',
        'lang' =>
            array(
                'en_uk' => 'The performer is not active on the performed date of the activity.',
                'nl' => 'De uitvoerder is niet actief op de uitgevoerde datum van de activiteit.',
            ),
    ),
    array(
        'code' => 'M145',
        'lang' =>
            array(
                'en_uk' => 'The {*object*} is not active.',
                'nl' => 'De {*object*} is niet actief.',
            ),
    ),
    array(
        'code' => 'M146',
        'lang' =>
            array(
                'en_uk' => 'The treatment is not open. ',
                'nl' => 'De behandeling is niet open.',
            ),
    ),
    array(
        'code' => 'M147',
        'lang' =>
            array(
                'en_uk' => '{*object*} not valid on {*input*}.',
                'nl' => '{*object*} niet geldig op {*input*}.',
            ),
    ),
    array(
        'code' => 'M148',
        'lang' =>
            array(
                'en_uk' => 'The activity is not valid on the performance date.',
                'nl' => 'De activiteit is niet geldig op de uitvoerdatum.',
            ),
    ),
    array(
        'code' => 'M149',
        'lang' =>
            array(
                'en_uk' => 'This is a MHC DBC activity. It cannot be moved to an non-MHC DBC treatment.',
                'nl' => 'Dit is een GGZ DBC activiteit en kan niet naar een niet-GGZ DBC verplaatst worden.',
            ),
    ),
    array(
        'code' => 'M150',
        'lang' =>
            array(
                'en_uk' => 'The start date of the treatment cannot be prior to the start date of the episode.',
                'nl' => 'De startdatum van de behandeling mag niet voor de startdatum van het zorgtraject liggen.',
            ),
    ),
    array(
        'code' => 'M151',
        'lang' =>
            array(
                'en_uk' => 'The start date of the episode is after the start date of the first treatment in the
                    episode',
                'nl' => 'De startdatum van het zorgtraject ligt na de startdatum van de eerste behandeling in dit
                    zorgtraject',
            ),
    ),
    array(
        'code' => 'M152',
        'lang' =>
            array(
                'en_uk' => 'The selected episode belongs to another patient.',
                'nl' => 'De geselecteerde episode is van een andere patiÃ«nt.',
            ),
    ),
    array(
        'code' => 'M153',
        'lang' =>
            array(
                'en_uk' => 'The episode contains one or more treatments',
                'nl' => 'Het zorgtraject bevat een of meerdere behandelingen',
            ),
    ),
    array(
        'code' => 'M154',
        'lang' =>
            array(
                'en_uk' => 'Result: activity: {*activity_id*}, uitvoerdatum:{*performed_date*}, uitvoerder:
                    {*performer_id*}, succes:{*success*}, reden voor mislukken: {*reason_fail*}.',
                'nl' => 'Resultaat: activiteit: {*activity_id*}, performed date: {*performed_date*}, performer:
                    {*performer_id*}, success:{*success*}, reason for failure: {*reason_fail*}.',
            ),
    ),
    array(
        'code' => 'M155',
        'lang' =>
            array(
                'en_uk' => 'The treatment {*name*} is open.',
                'nl' => 'De behandeling {*name*} is open.',
            ),
    ),
    array(
        'code' => 'M156',
        'lang' =>
            array(
                'en_uk' => 'The treatment is not closed.',
                'nl' => 'De behandeling is niet gesloten.',
            ),
    ),
    array(
        'code' => 'M157',
        'lang' =>
            array(
                'en_uk' => 'The episode is not open.',
                'nl' => 'Het zorgtraject is niet open.',
            ),
    ),
    array(
        'code' => 'M159',
        'lang' =>
            array(
                'en_uk' => 'The end date of the episode cannot be in the future.',
                'nl' => 'De einddatum van het zorgtraject mag niet in de toekomst liggen.',
            ),
    ),
    array(
        'code' => 'M160',
        'lang' =>
            array(
                'en_uk' => 'The episode is already open.',
                'nl' => 'Het zorgtraject is al open. ',
            ),
    ),
    array(
        'code' => 'M161',
        'lang' =>
            array(
                'en_uk' => 'The episode contains treatments that are not cancelled.',
                'nl' => 'Het zorgtraject bevat nog niet-geannuleerde behandelingen.',
            ),
    ),
    array(
        'code' => 'M162',
        'lang' =>
            array(
                'en_uk' => 'The care type is not valid in combination with specialist or start date. Possible causes: the care type is not defined for the specialty of the treatment or the start date of the treatment is outside the validity range of the care type.',
                'nl' => 'Het zorgtype is niet valide in combinatie met de specialist of startdatum. Mogelijke oorzaken: het zorgtype is niet gedefinieerd voor het specialisme van de behandeling of de startdatum van de behandeling ligt niet in de geldigheidstermijn van het zorgtype.',
            ),
    ),
    array(
        'code' => 'M163',
        'lang' =>
            array(
                'en_uk' => 'The care request is not valid in combination with specialist or start date. Possible causes: the care request is not defined for the specialty of the treatment or the start date of the treatment is outside the validity range of the care request.',
                'nl' => 'De zorgvraag is niet valide in combinatie met de specialist of startdatum. Mogelijke oorzaken: de zorgvraag is niet gedefinieerd voor het specialisme van de behandeling of de startdatum van de behandeling ligt niet in de geldigheidstermijn van de zorgvraag.',
            ),
    ),
    array(
        'code' => 'M164',
        'lang' =>
            array(
                'en_uk' => 'The diagnose is not valid in combination with specialist or start date. Possible causes: the diagnose is not defined for the specialty of the treatment or the start date of the treatment is outside the validity range of the diagnose.',
                'nl' => 'De diagnose is niet valide in combinatie met de specialist of startdatum. Mogelijke oorzaken: de diagnose is niet gedefinieerd voor het specialisme van de behandeling of de startdatum van de behandeling ligt niet in de geldigheidstermijn van de diagnose.',
            ),
    ),
    array(
        'code' => 'M165',
        'lang' =>
            array(
                'en_uk' => 'The treatment code is not valid. Possible causes: the treatment code is not defined for the
                    specialty of the treatment or the start date of the treatment is outside the validity range of the
                    treatment code.',
                'nl' => 'De behandelas is niet valide. Mogelijke oorzaken: de behandelas is niet gedefinieerd voor het
                    specialisme van de behandeling of de startdatum van de behandeling ligt niet in de
                    geldigheidstermijn van de behandelas.',
            ),
    ),
    array(
        'code' => 'M166',
        'lang' =>
            array(
                'en_uk' => 'The status of treatment is either open or closed.',
                'nl' => 'De status van de behandeling is open of gesloten.',
            ),
    ),
    array(
        'code' => 'M167',
        'lang' =>
            array(
                'en_uk' => 'A dialysis DBC treatment may be open for a maximum of 7 days.',
                'nl' => 'Een dialyse DBC behandeling mag niet langer dan 7 dagen open staan.',
            ),
    ),
    array(
        'code' => 'M168',
        'lang' =>
            array(
                'en_uk' => 'A chronic DBC treatment may be open for a maximum of 30 days.',
                'nl' => 'Een chronische DBC behandeling mag niet langer dan 30 dagen open staan.',
            ),
    ),
    array(
        'code' => 'M169',
        'lang' =>
            array(
                'en_uk' => 'There is not enough information to validate the treatment axis',
                'nl' => 'Er is niet voldoende informatie om de behandelas te valideren',
            ),
    ),
    array(
        'code' => 'M170',
        'lang' =>
            array(
                'en_uk' => 'The connection with the behandeling_dbc table is not correct for this treatment',
                'nl' => 'De relatie met de behandeling_dbc tabel is niet correct voor deze behandeling',
            ),
    ),
    array(
        'code' => 'M171',
        'lang' =>
            array(
                'en_uk' => 'The treatment axis cannot be validated for this is not a pre-DOT treatment',
                'nl' => 'De behandelas kan niet gevalideerd worden want dit is geen pre-DOT behandeling',
            ),
    ),
    array(
        'code' => 'M195',
        'lang' =>
            array(
                'en_uk' => 'When a specialist or specialism is chosen there should also be an institution',
                'nl' => 'Wanneer een specialist of specialisme is gekozen moet ook een instelling geselecteerd worden',
            ),
    ),
    array(
        'code' => 'M196',
        'lang' =>
            array(
                'en_uk' => 'When an institution has been chosen there should also be a specialist or specialism',
                'nl' => 'Wanneer een instelling is gekozen moet ook een specialist of specialisme geselecteerd worden',
            ),
    ),
    array(
        'code' => 'M205',
        'lang' =>
            array(
                'en_uk' => 'For this treatmenttype, only one treatment may be present in the episode because each treatment should have its own referrer and this is registered on episode level.',
                'nl' => 'Voor dit behandeltype mag er maar één behandeling in het zorgtraject voorkomen omdat elke behandeling een eigen doorverwijzer nodig heeft en dit op zorgtrajectniveau wordt geregistreerd.',
            ),
    ),
    array(
        'code' => 'M206',
        'lang' =>
            array(
                'en_uk' => 'It is not possible to add a Basic MHC treatment to an episode that has treatments with another treatment type.',
                'nl' => 'Het is niet mogelijk om een Basis GGZ behandeling toe te voegen aan een zorgtraject met behandelingen van een ander type.',
            ),
    ),
    array(
        'code' => 'M500',
        'lang' =>
            array(
                'en_uk' => 'The MHC diagnose is not selectable. Select a diagnose on a lower level.',
                'nl' => 'De GGZ diagnose is niet selecteerbaar. Kies een diagnose op een lager niveau.',
            ),
    ),
    array(
        'code' => 'MG102',
        'lang' =>
            array(
                'en_uk' => 'At least one of the following fields must be filled out
                    {*field_name_1*}, {*field_name_2*}.',
                'nl' => 'Minstens één van de volgende velden moet worden ingevuld
                    {*field_name_1*}, {*field_name_2*}.',
            ),
    ),
    array(
        'code' => 'EMPM004',
        'lang' =>
            array(
                'en_uk' => 'The employee is not an attending physician.',
                'nl' => 'De medewerker is geen behandelend arts.',
            ),
    ),
    array(
        'code' => 'M501',
        'lang' =>
            array(
                'en_uk' => 'The MHC care type is not selectable. Select a care type on a lower level.',
                'nl' => 'Het GGZ zorgtype is niet selecteerbaar. Kies een zorgtype op een lager niveau.',
            ),
    ),
    array(
        'code' => 'M502',
        'lang' =>
            array(
                'en_uk' => 'This treatment is not registered for this patient.',
                'nl' => 'Dit behandeling is niet geregistreerd voor deze patient.',
            ),
    ),
    array(
        'code' => 'M503',
        'lang' =>
            array(
                'en_uk' => 'Specialist2 cannot be equal to the specialist of the treatment',
                'nl' => 'Specialist2 kan niet hetzelfde zijn als de specialist van de behandeling',
            ),
    ),
    array(
        'code' => 'M504',
        'lang' =>
            array(
                'en_uk' => 'The primary diagnose must be registered on an Axis I or II diagnose.',
                'nl' => 'De primaire diagnose kan alleen op As I of II worden geregistreerd.',
            ),
    ),
    array(
        'code' => 'M505',
        'lang' =>
            array(
                'en_uk' => 'The episode contains closed treatments, the primary diagnose cannot be changed.',
                'nl' => 'Het zorgtraject bevat gesloten subtrajecten, de primaire diagnose kan niet gewijzigd worden.',
            ),
    ),
    array(
        'code' => 'M506',
        'lang' =>
            array(
                'en_uk' => 'The PM diagnose must contain four digits.',
                'nl' => 'De PM diagnose moet 4 cijfers bevatten.',
            ),
    ),
    array(
        'code' => 'M507',
        'lang' =>
            array(
                'en_uk' => 'The day activity is not selectable. Select a day activity on a lower level.',
                'nl' => 'De dag activiteit is niet selecteerbaar. Selecteer een dag activiteit op een lager niveau.',
            ),
    ),
    array(
        'code' => 'M508',
        'lang' =>
            array(
                'en_uk' => 'The day activity is not valid on the date of the activity.',
                'nl' => 'De dag activiteit is niet geldig op de datum van de activiteit.',
            ),
    ),
    array(
        'code' => 'M509',
        'lang' =>
            array(
                'en_uk' => 'The end time of an activity must be later than the start time of the activity.',
                'nl' => 'De eindtijd van een activiteit moet later dan de begintijd van de activiteit.',
            ),
    ),
    array(
        'code' => 'M510',
        'lang' =>
            array(
                'en_uk' => 'The system cannot deduct the DOT referrer code.',
                'nl' => 'Het systeem kan de DOT verwijscode niet afleiden.',
            ),
    ),
    array(
        'code' => 'M511',
        'lang' =>
            array(
                'en_uk' => 'The {*input*} is not selectable. Select a {*input*} on a lower level.',
                'nl' => 'Het {*input*} is niet selecteerbaar. Kies een {*input*} op een lager niveau.',
            ),
    ),
    array(
        'code' => 'M512',
        'lang' =>
            array(
                'en_uk' => 'The end date of an day of stay must be later then the start date.',
                'nl' => 'De einddatum van een verblijfsdag moet later zijn dan de startdatum',
            ),
    ),
    array(
        'code' => 'M513',
        'lang' =>
            array(
                'en_uk' => 'The {*input*} must not be selectable. Select a {*input*} on a higher level.',
                'nl' => 'Het {*input*} moet niet selecteerbaar zijn. Kies een {*input*} op een hoger niveau.',
            ),
    ),
    array(
        'code' => 'M514',
        'lang' =>
            array(
                'en_uk' => 'The day of stay activity is not a level 2 activity, which is required.',
                'nl' => 'De verblijfsdag is geen niveau 2 activiteit wat wel vereist is.',
            ),
    ),
    array(
        'code' => 'M515',
        'lang' =>
            array(
                'en_uk' => 'This tax group is not related to the chosen activity.',
                'nl' => 'Deze tariefgroep is niet gerelateerd aan de gekozen activiteit.',
            ),
    ),
    array(
        'code' => 'M516',
        'lang' =>
            array(
                'en_uk' => 'This treatment {*id*} is not {*type*} treatment.',
                'nl' => 'Deze behandeling {*id*} is geen {*type*} behandeling.',
            ),
        'params' =>
            array(
                0 => 'Object',
                1 => 'input',
            ),
    ),
    array(
        'code' => 'M520',
        'lang' =>
            array(
                'en_uk' => 'The activity cannot be edited if it is not performed.',
                'nl' => 'De activiteit kan niet aangepast worden als deze niet is uitgevoerd.',
            ),
    ),
    array(
        'code' => 'M522',
        'lang' =>
            array(
                'en_uk' => 'This is not a PM treatment.',
                'nl' => 'Dit is geen PM behandeling.',
            ),
    ),
    array(
        'code' => 'M523',
        'lang' =>
            array(
                'en_uk' => 'Diagnosis {*id*} already exists for this treatment.',
                'nl' => 'Deze diagnose {*id*} bestaat al voor deze behandeling.',
            ),
    ),
    array(
        'code' => 'M525',
        'lang' =>
            array(
                'en_uk' => 'This diagnose cannot be set as primary.',
                'nl' => 'Deze diagnose kan niet als primair worden gezet.',
            ),
    ),
    array(
        'code' => 'M526',
        'lang' =>
            array(
                'en_uk' => 'This cannot be a referring treatment for this episode.',
                'nl' => 'Dit kan geen verwijzende behandeling zijn voor dit zorgtraject.',
            ),
    ),
    array(
        'code' => 'M527',
        'lang' =>
            array(
                'en_uk' => 'The treatment does not have the correct caretype.',
                'nl' => 'De behandeling heeft niet het juiste zorgtype.',
            ),
    ),
    array(
        'code' => 'M1010',
        'lang' =>
            array(
                'en_uk' => 'Not valid Integer.',
                'nl' => 'Niet geldig Integer.',
            ),
    ),
    array(
        'code' => 'M1010SS',
        'lang' =>
            array(
                'en_uk' => 'Not valid String.',
                'nl' => 'Not valid String.',
            ),
    ),
    array(
        'code' => 'EMPM100',
        'lang' =>
            array(
                'en_uk' => 'The employee does not have a specialism registered.',
                'nl' => 'De medewerker heeft geen specialisme geregistreerd.',
            ),
    ),
    array(
        'code' => 'EMPM101',
        'lang' =>
            array(
                'en_uk' => 'You do not have extended financial rights and therefore you cannot perform this action.',
                'nl' => 'U heeft geen uitgebreide financiële rechten en daarom kunt u deze actie niet uitvoeren.',
            ),
    ),
    array(
        'code' => 'EMPM102',
        'lang' =>
            array(
                'en_uk' => 'You are not authorized to perform this action',
                'nl' => 'U heeft geen rechten om deze actie uit te voeren.',
            ),
    ),
    array(
        'code' => 'M528',
        'lang' =>
            array(
                'en_uk' => 'Result of grouper:{*result*}',
                'nl' => 'Resultaat van de grouper:{*result*}',
            ),
    ),
    array(
        'code' => 'EMPM005',
        'lang' =>
            array(
                'en_uk' => 'The employee does not work for the selected clinic.',
                'nl' => 'De medewerker werkt niet voor de opgegeven kliniek.',
            ),
    ),
    array(
        'code' => 'M521',
        'lang' =>
            array(
                'en_uk' => 'It is not possible to create a follow-up treatment.',
                'nl' => 'Het is niet mogelijk om een vervolgbehandeling te starten.',
            ),
    ),
    array(
        'code' => 'M524',
        'lang' =>
            array(
                'en_uk' => 'There is no primary diagnose for this episode.',
                'nl' => 'Er is geen primaire diagnose voor dit zorgtraject.',
            ),
    ),
    array(
        'code' => 'AC-M1',
        'lang' =>
            array(
                'en_uk' => 'The entered postal code does not exist or could not be found.',
                'nl' => 'De opgegeven postcode bestaat niet of kon niet worden gevonden.',
            ),
    ),
    array(
        'code' => 'PRM01',
        'lang' =>
            array(
                'en_uk' => 'The {*field_name*} cannot be in the future.',
                'nl' => 'De {*field_name*} kan niet in de toekomst liggen.',
            ),
    ),
    array(
        'code' => 'PRM05',
        'lang' =>
            array(
                'en_uk' => 'This BSN is already registrered for another patient.
                    Double registration is not allowed.',
                'nl' => 'Dit BSN is al geregistreerd voor bij een andere patient.
                    Dubbele registratie is niet toegestaan.',
            ),
    ),
    array(
        'code' => 'SA1',
        'lang' =>
            array(
                'en_uk' => 'The information was saved.',
                'nl' => 'De gegevens zijn opgeslagen.',
            ),
    ),
    array(
        'code' => 'SA2',
        'lang' =>
            array(
                'en_uk' => 'The information was not saved.',
                'nl' => 'The information was not saved.',
            ),
    ),
    array(
        'code' => 'AC1',
        'lang' =>
            array(
                'en_uk' => 'The action was successful.',
                'nl' => 'De actie is geslaagd.',
            ),
    ),
    array(
        'code' => 'AC2',
        'lang' =>
            array(
                'en_uk' => 'The action was not successful.',
                'nl' => 'De actie is niet geslaagd.',
            ),
    ),
    array(
        'code' => 'AC-M3',
        'lang' =>
            array(
                'en_uk' => 'Document is in circulation.',
                'nl' => 'Document is in omloop.',
            ),
    ),
    array(
        'code' => 'AC-M4',
        'lang' =>
            array(
                'en_uk' => 'Document is not in circulation .',
                'nl' => 'Document is niet in omloop.',
            ),
    ),
    array(
        'code' => 'AC-M5',
        'lang' =>
            array(
                'en_uk' => 'A problem had occurred and is handled by SBV-Z. Try again later.',
                'nl' => 'Er is een fout opgetreden en deze is in behandeling genomen door de SBV-Z.' . ' ' .
                    'Probeer het later opnieuw.',
            ),
    ),
    array(
        'code' => 'AC-M2',
        'lang' =>
            array(
                'en_uk' => 'No result. The external party does not respond,
                    or the certificate does not work correctly.',
                'nl' => 'Geen resultaat. De externe partij geeft geen respons,
                    of het certificaat werkt niet correct.',
            ),
    ),
    array(
        'code' => 'AC-M6',
        'lang' =>
            array(
                'en_uk' => 'Certificate is not available; possibly no key found or wrong password.',
                'nl' => 'Het certificaat is niet beschikbaar; mogelijk geen sleutel gevonden of verkeerd wachtwoord.',
            ),
    ),
    array(
        'code' => 'MG107',
        'lang' =>
            array(
                'en_uk' => '{*field_name*} has to contain exactly {*length*} characters.',
                'nl' => '{*field_name*} moet exact {*length*} karakters zijn.',
            ),
    ),
    array(
        'code' => 'AC-M7',
        'lang' =>
            array(
                'en_uk' => 'BSN is verified.',
                'nl' => 'BSN is geverifieerd.',
            ),
    ),
    array(
        'code' => 'AC-M8',
        'lang' =>
            array(
                'en_uk' => 'BSN did not lead to one person.',
                'nl' => 'BSN heeft niet tot één persoon geleid.',
            ),
    ),
    array(
        'code' => 'AC-M9',
        'lang' =>
            array(
                'en_uk' => 'Number is not a BSN.',
                'nl' => 'Nummer is geen BSN.',
            ),
    ),
    array(
        'code' => 'AC-M10',
        'lang' =>
            array(
                'en_uk' => 'BSN is verified, but with different data.',
                'nl' => 'BSN is geverifieerd, maar met afwijkende gegevens.',
            ),
    ),
    array(
        'code' => 'PR-M23',
        'lang' =>
            array(
                'en_uk' => 'Some patient data could not be retrieved because the patient is under 18. Please manually fill in the required data.',
                'nl' => 'Bepaalde patiëntgegevens konden niet worden opgehaald omdat de patient jonger is dan 18. U kunt de benodigde gegevens handmatig aanvullen.',
            ),
    ),
    array(
        'code' => 'PA-V3',
        'lang' =>
            array(
                'en_uk' => 'Start date must be prior to enddate',
                'nl' => 'Einddatum moet na de startdatum liggen.'
            )
    ),
    array(
        'code' => 'PR-M6',
        'lang' =>
            array(
                'en_uk' => 'The selected careprovider is not a valid general practitioner.',
                'nl' => 'De gekozen zorgverlener is geen geldige huisarts.',
            ),
    ),
    array(
        'code' => 'PR-M7',
        'lang' =>
            array(
                'en_uk' => 'The selected practice is not a valid practice.',
                'nl' => 'De gekozen praktijk is geen geldige praktijk.',
            ),
    ),
    array(
        'code' => 'TR-M2',
        'lang' =>
            array(
                'en_uk' => 'The performance date of the activity cannot be earlier than the start date of the treatment.',
                'nl' => 'De uitvoerdatum van de activiteit mag niet eerder zijn dan de startdatum van de behandeling.',
            ),
    ),
    array(
        'code' => 'TR-M1',
        'lang' =>
            array(
                'en_uk' => 'The treatment is not open.',
                'nl' => 'De behandeling is niet open.',
            ),
    ),
    array(
        'code' => 'TR-M10',
        'lang' =>
            array(
                'en_uk' => 'It is not possible to change the start date after an add-on has been invoiced. If you want to change the start date, you will have to credit the add-on first.',
                'nl' => 'Het is niet mogelijk de startdatum te wijzigen nadat een add-on is gefactureerd. Wanneer u de startdatum wilt aanpassen, zult u eerst de add-on moeten crediteren.',
            ),
    ),
     array(
        'code' => 'TR-M14',
        'lang' =>
            array(
                'en_uk' => 'Previous treatment is not closed. Please close it before opening a new one.',
                'nl' => 'De vorige behandeling is nog niet gesloten. Deze moet eerst gesloten zijn voordat een nieuwe geopend kan worden.',
            ),
    ),
    array(
        'code' => 'TR-M9',
        'lang' =>
            array(
                'en_uk' => 'The employee is not active on the start date of the treatment.',
                'nl' => 'De werknemer is niet actief op de startdatum van de behandeling.',
            ),
    ),
    array(
        'code' => 'TR-M11',
        'lang' =>
            array(
                'en_uk' => 'The employee is not an attending physician.',
                'nl' => 'De medewerker is geen behandelend arts.',
            ),
    ),
    array(
        'code' => 'TR-M12',
        'lang' =>
            array(
                'en_uk' => 'The specialty of the employee is not the same as the specialty of the episode.',
                'nl' => 'Het specialisme van de medewerker komt niet overeen met die van de zorgtraject.',
            ),
    ),
    array(
        'code' => 'TR-M13',
        'lang' =>
            array(
                'en_uk' => 'Co-specialist cannot be equal to the specialist of the treatment.',
                'nl' => 'Medebehandelaar kan niet hetzelfde zijn als de specialist van de behandeling.',
            ),
    ),
    array(
        'code' => 'TR-M15',
        'lang' =>
            array(
                'en_uk' => 'The start date of the treatment must be one day later than the end date of the previous closed treatment.',
                'nl' => 'De startdatum van de behandeling moet één dag later zijn dan de dag waarop de voorgaande behandeling gesloten is.',
            ),
    ),
    array(
        'code' => 'TR-M6',
        'lang' =>
            array(
                'en_uk' => 'The care type is not valid in combination with specialist or start date. Possible causes: the care type is not defined for the specialty of the treatment or the start date of the treatment is outside the validity range of the care type.',
                'nl' => 'Het zorgtype is niet valide in combinatie met de specialist of startdatum. Mogelijke oorzaken: het zorgtype is niet gedefinieerd voor het specialisme van de behandeling of de startdatum van de behandeling ligt niet in de geldigheidstermijn van het zorgtype.',
            ),
    ),
    array(
        'code' => 'TR-M7',
        'lang' =>
            array(
                'en_uk' => 'The care request is not valid in combination with specialist or start date. Possible causes: the care request is not defined for the specialty of the treatment or the start date of the treatment is outside the validity range of the care request.',
                'nl' => 'De zorgvraag is niet valide in combinatie met de specialist of startdatum. Mogelijke oorzaken: de zorgvraag is niet gedefinieerd voor het specialisme van de behandeling of de startdatum van de behandeling ligt niet in de geldigheidstermijn van de zorgvraag.',
            ),
    ),
    array(
        'code' => 'TR-M8',
        'lang' =>
            array(
                'en_uk' => 'The diagnose is not valid in combination with specialist or start date. Possible causes: the diagnose is not defined for the specialty of the treatment or the start date of the treatment is outside the validity range of the diagnose.',
                'nl' => 'De diagnose is niet valide in combinatie met de specialist of startdatum. Mogelijke oorzaken: de diagnose is niet gedefinieerd voor het specialisme van de behandeling of de startdatum van de behandeling ligt niet in de geldigheidstermijn van de diagnose.',
            ),
    ),
    array(
        'code' => 'TR-M14',
        'lang' =>
            array(
                'en_uk' => 'Previous treatment is not closed. Please close it before opening a new one.',
                'nl' => 'De vorige behandeling is nog niet gesloten. Deze moet eerst gesloten zijn voordat een nieuwe geopend kan worden.',
            ),
    ),
    array(
        'code' => 'TR-M22',
        'lang' =>
            array(
                'en_uk' => 'Only one activity per treatment can have a medical ground registered.',
                'nl' => 'Per behandeling kan maar één activiteit een medische indicatie hebben.',
            ),
    ),
    array(
        'code' => 'TR-M25',
        'lang' =>
            array(
                'en_uk' => 'End date of the treatment must be equal to or later than the performance date of the last
                    performed activity.',
                'nl' => 'Einddatum van de behandeling moet gelijk of later zijn dan de uitvoerdatum van de laatst
                    uitgevoerde activiteit.',
            ),
    ),
    array(
        'code' => 'TR-M34',
        'lang' =>
            array(
                'en_uk' => 'The end date of the treatment cannot be in the future.',
                'nl' => 'De einddatum van de behandeling mag niet in de toekomst liggen.',
            ),
    ),
    array(
        'code' => 'EM-M1',
        'lang' =>
            array(
                'en_uk' => 'The employee does not have a specialty registered.',
                'nl' => 'De medewerker heeft geen specialisme geregistreerd.',
            ),
    ),
    array(
        'code' => 'EM-M2',
        'lang' =>
            array(
                'en_uk' => 'The employee does not work for the selected clinic.',
                'nl' => 'De medewerker werkt niet voor de opgegeven kliniek.',
            ),
    ),
    array(
        'code' => 'ACT-M1',
        'lang' =>
            array(
                'en_uk' => 'The activity is financially processed.',
                'nl' => 'De activiteit is financieel verwerkt.',
            ),
    ),
    array(
        'code' => 'ACT-M2',
        'lang' =>
            array(
                'en_uk' => 'The activity is not valid on the performance date.',
                'nl' => 'De activiteit is niet geldig op de uitvoerdatum.',
            ),
    ),
    array(
        'code' => 'ACT-M3',
        'lang' =>
            array(
                'en_uk' => 'The activity is not active.',
                'nl' => 'De verrichting is niet actief.',
            ),
    ),
    array(
        'code' => 'ACT-M4',
        'lang' =>
            array(
                'en_uk' => 'The performer is not active on the performance date of the activity.',
                'nl' => 'De medewerker is uit dienst op de uitvoerdatum van de zorgactiviteit.',
            ),
    ),
    array(
        'code' => 'ACT-M5',
        'lang' =>
            array(
                'en_uk' => 'The activity is not of correct treatment type.',
                'nl' => 'De activiteit is niet van het juiste behandeltype.',
            ),
    ),
    array(
        'code' => 'ACT-M6',
        'lang' =>
            array(
                'en_uk' => 'This appointment cannot be linked to this activity because the patient is not the same.',
                'nl' => 'Deze afspraak kan niet aan de activiteit gekoppeld worden omdat de patiënt niet overeen komt.',
            ),
    ),
    array(
        'code' => 'ACT-M7',
        'lang' =>
            array(
                'en_uk' => 'This appointment cannot be linked to this activity because the performance dat is prior to the startdate of the treatment.',
                'nl' => 'Deze afspraak kan niet aan de activiteit gekoppeld worden omdat de uitvoerdatum voor de startdatum van de behandeling ligt.',
            ),
    ),
    array(
        'code' => 'ACT-M8',
        'lang' =>
        array(
            'en_uk' => 'This appointment cannot be linked to this activity because the specialist is not the same.',
            'nl' => 'Deze afspraak kan niet aan de activiteit gekoppeld worden omdat de specialist niet overeen komt.',
        ),
    ),
    array(
        'code' => 'ACT-M999',
        'lang' =>
            array(
                'en_uk' => 'Not a valid functioncode for WLZ.',
                'nl' => 'Geen geldige functioncode for WLZ.',
            ),
    ),
    array(
        'code' => 'ACT-M9',
        'lang' =>
        array(
            'en_uk' => 'It is not possible to edit the field performer because an appointment is linked to this activity.',
            'nl' => 'Het is niet mogelijk om de specialist te wijzigen omdat een afspraak aan deze activiteit is gekoppeld.',
        ),
    ),
    array(
        'code' => 'ACT-M10',
        'lang' =>
        array(
            'en_uk' => 'It is not possible to edit the field performance date because an appointment is linked to this activity.',
            'nl' => 'Het is niet mogelijk om de uitvoerdatum te wijzigen omdat een afspraak aan deze activiteit is gekoppeld.',
        ),
    ),
    array(
        'code' => 'ACT-M11',
        'lang' =>
        array(
            'en_uk' => 'The minimum required amount for this activity is {*minimum*}.',
            'nl' => 'Het vereiste minimum aantal voor deze activiteit is {*minimum*}.',
        ),
    ),
    array(
        'code' => 'ACT-M12',
        'lang' =>
        array(
            'en_uk' => 'Please note; by changing the execution date of this activity the unit of the amount changes. Please check your registration.',
            'nl' => 'Let op: Door het wijzigen van de uitvoerdatum van deze activiteit wijzigt de eenheid van de toegediende hoeveelheid. Controleer uw registratie.',
        ),
    ),
    array(
        'code' => 'ACT-M13',
        'lang' =>
        array(
            'en_uk' => 'The following activities are not valid on the performance date: {*codelist*}',
            'nl' => 'De volgende activiteiten zijn niet geldig op de uitvoerdatum: {*codelist*}',
        ),
    ),
    array(
        'code' => 'ACT-M17',
        'lang' =>
        array(
            'en_uk' => 'The activity with insurance approval has not been performed within the validity period of the approval: {*activity_code*} {*activity_name*} {*date_performed*}',
            'nl' => 'De gemachtigde activiteit is niet uitgevoerd binnen de geldigheidsduur van de machtiging: {*activity_code*} {*activity_name*} {*date_performed*}',
        )
    ),
    array(
        'code' => 'AC-M11',
        'lang' =>
            array(
                'en_uk' => 'The BSN does not lead to insurance details.',
                'nl' => 'De combinatie van BSN en geboortedatum leidt niet tot verzekeringsgegevens.',
            ),
    ),
    array(
        'code' => 'AC-M12',
        'lang' =>
            array(
                'en_uk' => 'The combination of BSN and date of birth does not lead to insurance details.',
                'nl' => 'De combinatie van BSN en geboortedatum leidt niet tot verzekeringsgegevens.',
            ),
    ),
    array(
        'code' => 'AC-M13',
        'lang' =>
            array(
                'en_uk' => 'No insurancedetails were found because there is a double active insurance.',
                'nl' => 'Er zijn geen verzekeringsgegevens ontvangen omdat er sprake is van een dubbele actieve
                verzekering.',
            ),
    ),
    array(
        'code' => 'MG18',
        'lang' =>
            array(
                'en_uk' => 'Id is not active.',
                'nl' => 'Id is not active.',
            ),
    ),
    array(
        'code' => 'PR-M14',
        'lang' =>
            array(
                'en_uk' => 'The selected person does not work for the selected organization.',
                'nl' => 'De gekozen persoon werkt niet voor de gekozen organisatie*.',
            ),
    ),
    array(
        'code' => 'AC-M14',
        'lang' =>
            array(
                'en_uk' => 'No insurances were found.',
                'nl' => 'Er zijn geen verzekeringen gevonden.',
            ),
    ),
    array(
        'code' => 'AC-M15',
        'lang' =>
            array(
                'en_uk' => 'Insurancedetails are retrieved.',
                'nl' => 'Verzekeringsgegevens zijn bijgewerkt.',
            ),
    ),
    array(
        'code' => 'AC-M16',
        'lang' =>
            array(
                'en_uk' => 'No active insurances were found.',
                'nl' => 'Er zijn geen actieve verzekeringen gevonden.',
            ),
    ),
    array(
        'code' => 'PR-M9',
        'lang' =>
            array(
                'en_uk' => 'Insurance details are changed manually.',
                'nl' => 'Verzekeringsgegevens zijn handmatig gewijzigd.',
            ),
    ),
    array(
        'code' => 'EP-M5',
        'lang' =>
            array(
                'en_uk' => 'The referrer organization is not active.',
                'nl' => 'De verwijsorganisatie is niet actief.',
            ),
    ),
    array(
        'code' => 'EP-M6',
        'lang' =>
            array(
                'en_uk' => 'The referrer person is not active.',
                'nl' => 'De verwijzende persoon is niet actief.',
            ),
    ),
    array(
        'code' => 'PR-M15',
        'lang' =>
            array(
                'en_uk' => 'The selected organization does not have the selected organization type.',
                'nl' => 'De gekozen organisatie is niet van het gekozen organisatie type.',
            ),
    ),
    array(
        'code' => 'PR-M16',
        'lang' =>
            array(
                'en_uk' => 'The selected package is not an option for this insurance company.',
                'nl' => 'Het gekozen pakket is geen optie bij deze verzekeringsmaatschappij.',
            ),
    ),
    array(
        'code' => 'PR-M17',
        'lang' =>
            array(
                'en_uk' => 'The selected person does not have the selected type.',
                'nl' => 'De gekozen persoon is niet van het gekozen type.',
            ),
    ),
    array(
        'code' => 'PR-M18',
        'lang' =>
            array(
                'en_uk' => 'BSN is verified manually.',
                'nl' => 'BSN is handmatig geverifieerd.',
            ),
    ),
    array(
        'code' => 'PR-M19',
        'lang' =>
            array(
                'en_uk' => 'The patient could not be deleted.',
                'nl' => 'De patiënt kan niet verwijderd worden.',
            ),
    ),
    array(
        'code' => 'AC-M17',
        'lang' =>
            array(
                'en_uk' => 'BAG service is not reachable Try again later or register the address manually.',
                'nl' => 'BAG service is niet bereikbaar. Probeer het later nog eens of registreer het adres handmatig.',
            ),
    ),
    array(
        'code' => 'ACT-M31',
        'lang' =>
            array(
                'en_uk' => 'The end time of the activity should be after the start time.',
                'nl' => 'De eindtijd van de activiteit moet na de starttijd liggen.',
            ),
    ),
    array(
        'code' => 'TR-M3',
        'lang' =>
            array(
                'en_uk' => 'The amount must be an integer between 1 and 9999.',
                'nl' => 'Het aantal moet een geheel getal zijn, tussen 1 en 9999.',
            )
    ),
    array(
        'code' => 'TR-M6',
        'lang' =>
            array(
                'en_uk' => 'The care type is not valid. Possible causes: the care type is not defined for the
                        specialty of the treatment or the start date of the treatment is outside the validity range of the
                        care type.',
                'nl' => 'Het zorgtype is niet valide. Mogelijke oorzaken: het zorgtype is niet gedefinieerd voor het
                        specialisme van de behandeling of de startdatum van de behandeling ligt niet in de
                        geldigheidstermijn van het zorgtype.',
            ),
    ),
    array(
        'code' => 'TR-M7',
        'lang' =>
            array(
                'en_uk' => 'The care request is not valid. Possible causes: the care request is not defined for the
                        specialty of the treatment or the start date of the treatment is outside the validity range of the
                        care request.',
                'nl' => 'De zorgvraag is niet valide. Mogelijke oorzaken: de zorgvraag is niet gedefinieerd voor het
                        specialisme van de behandeling of de startdatum van de behandeling ligt niet in de
                        geldigheidstermijn van de zorgvraag.',
            ),
    ),
    array(
        'code' => 'TR-M8',
        'lang' =>
        array(
            'en_uk' => 'The diagnose is not valid. Possible causes: the diagnose is not defined for the specialty
                        of the treatment or the start date of the treatment is outside the validity range of the diagnose.',
            'nl' => 'De diagnose is niet valide. Mogelijke oorzaken: de diagnose is niet gedefinieerd voor het
                        specialisme van de behandeling of de startdatum van de behandeling ligt niet in de
                        geldigheidstermijn van de diagnose.',
        ),
    ),
    array(
        'code' => 'EP-M1',
        'lang' =>
            array(
                'en_uk' => 'The episode is not open.',
                'nl' => 'Het zorgtraject is niet open.',
            ),
    ),
    array(
        'code' => 'EP-M13',
        'lang' =>
            array(
                'en_uk' => 'This cannot be a referring treatment for this episode.',
                'nl' => 'De verwijzende behandeling kan niet in hetzelfde zorgtraject vastgelegd zijn.',
            ),
    ),
    array(
        'code' => 'EP-M14',
        'lang' =>
            array(
                'en_uk' => 'The referring treatment must have a start date on or before the episode that needs a referring treatment.',
                'nl' => 'De verwijzende behandeling dient een startdatum te hebben op of voor het zorgtraject waarin de verwijzende behandeling wordt vastgelegd.',
            ),
    ),
    array(
        'code' => 'EP-M15',
        'lang' =>
            array(
                'en_uk' => 'This treatment is not registered for this patient.',
                'nl' => 'Dit behandeling is niet geregistreerd voor deze patient.',
            ),
    ),
    array(
        'code' => 'EP-M7',
        'lang' =>
            array(
                'en_uk' => 'For this care type, a referral to another episode is not allowed.',
                'nl' => 'Er mag voor dit zorgtype geen verwijzing naar een ander zorgtraject zijn.',
            ),
    ),
    array(
        'code' => 'EP-M8',
        'lang' =>
            array(
                'en_uk' => 'For this care type a reference to a regular episode is obligatory. The period of the regular episode must enclose the duration of this episode completely.',
                'nl' => 'Voor dit zorgtype dient verwezen te worden naar een regulier zorgtraject, waarvan de periode de duur van dit zorgtraject compleet omvat.',
            ),
    ),
    array(
        'code' => 'EP-M26',
        'lang' =>
            array(
                'en_uk' => 'Within an episode, all treatments must be of the same type.',
                'nl' => 'Binnen een zorgtraject moeten alle behandelingen van hetzelfde type zijn.',
            ),
    ),
    array(
        'code' => 'EP-M27',
        'lang' =>
            array(
                'en_uk' => 'The circuit code is not valid on the start date of the treatment.',
                'nl' => 'De circuitcode is niet geldig op de startdatum van de behandeling.',
            ),
    ),
    array(
        'code' => 'EP-M28',
        'lang' =>
            array(
                'en_uk' => 'The circuit code is not valid for the clinic of the treatment.',
                'nl' => 'De circuitcode is niet geldig voor de kliniek van de behandeling.',
            ),
    ),
    array(
        'code' => 'PR-M20',
        'lang' =>
            array(
                'en_uk' => 'These locations must be registered for this patient because there are future appointments or open treatments: {*input*}',
                'nl' => 'De volgende locaties moeten geregistreerd worden voor deze patiënt omdat er afspraken in de toekomst zijn of open behandelingen: {*input*}',
            ),
    ),
    array(
        'code' => 'EP-M9',
        'lang' =>
            array(
                'en_uk' => 'Mandatory DOT code referrer missing',
                'nl' => 'Er ontbreekt verplichte verwijsinformatie: DOT verwijscode.',
            ),
    ),
    array(
        'code' => 'EP-M10',
        'lang' =>
            array(
                'en_uk' => 'The registered Code referrer (DOT) expects the following referral information: - AGB code of the referrer.',
                'nl' => 'De opgegeven verwijscode (DOT) verwacht de volgende verwijsinformatie: AGB-code van de verwijzer',
            ),
    ),
    array(
        'code' => 'EP-M11',
        'lang' =>
            array(
                'en_uk' => 'The registered Code referrer (DOT) expects the following referral information: - AGB code of the specialty of the referrer.',
                'nl' => 'De opgegeven verwijscode (DOT) verwacht de volgende verwijsinformatie: AGB-code van het specialisme van de verwijzer',
            ),
    ),
    array(
        'code' => 'EP-M12',
        'lang' =>
            array(
                'en_uk' => 'The registered Code referrer (DOT) expects the following referral information: - AGB code of the referrer, and - AGB code of the specialty of the referrer.',
                'nl' => 'De opgegeven verwijscode (DOT) verwacht de volgende verwijsinformatie: - AGB-code van de verwijzer, en -	AGB-code van het specialisme van de verwijzer',
            ),
    ),
    array(
        'code' => 'UR4',
        'lang' =>
            array(
                'en_uk' => 'Patient could not be found for given patient id (in the URL)',
                'nl' => 'Patiënt kon niet worden gevonden voor de opgegeven patiënt id (in de URL)',
            ),
    ),
    array(
        'code' => 'SY-M1',
        'lang' =>
            array(
                'en_uk' => 'The start date of the episode is updated with new start date of the first treatment in the episode.',
                'nl' => 'De startdatum van het zorgtraject is bijgewerkt met de nieuwe startdatum van de eerste behandeling in dit zorgtraject.',
            ),
    ),
    array(
        'code' => 'PR-M21',
        'lang' =>
            array(
                'en_uk' => 'The start date should be on 01-01-2015 or later.',
                'nl' => 'De startdatum moet op 01-01-2015 of later zijn.',
            ),
    ),
    array(
        'code' => 'TR-M16',
        'lang' =>
            array(
                'en_uk' => 'The ICD-10 code is not valid in combination with specialist or start date. Possible causes: the ICD-10 code is not defined for the specialty of the treatment or the start date of the treatment is outside the validity range of the ICD-10 code.',
                'nl' => 'De ICD-10 code is niet valide in combinatie met de specialist of startdatum. Mogelijke oorzaken: de ICD-10 code is niet gedefinieerd voor het specialisme van de behandeling of de startdatum van de behandeling ligt niet in de geldigheidstermijn van de ICD-10 code.',
            ),
    ),
    array(
        'code' => 'TR-M17',
        'lang' =>
            array(
                'en_uk' => 'The treatment is not a valid somatic DBC treatment.',
                'nl' => 'De behandeling is geen geldige somatische DBC behandeling.',
            ),
    ),
    array(
        'code' => 'TR-M18',
        'lang' =>
            array(
                'en_uk' => 'The expected end date must be on or later than the start date.',
                'nl' => 'De verwachte einddatum moet op of na de startdatum liggen.',
            ),
    ),
    array(
        'code' => 'TR-M19',
        'lang' =>
            array(
                'en_uk' => 'For this treatmenttype, only one treatment may be present in the episode because each treatment should have its own referrer and this is registered on episode level.',
                'nl' => 'Voor dit behandeltype mag er maar één behandeling in het zorgtraject voorkomen omdat elke behandeling een eigen doorverwijzer nodig heeft en dit op zorgtrajectniveau wordt geregistreerd.',
            ),
    ),
    array(
        'code' => 'TR-M20',
        'lang' =>
            array(
                'en_uk' => 'It is not possible to add a Basic MHC treatment to an episode that has treatments with another treatment type.',
                'nl' => 'Het is niet mogelijk om een Basis GGZ behandeling toe te voegen aan een zorgtraject met behandelingen van een ander type.',
            ),
    ),
    array (
        'code'    => 'TR-M21',
        'lang' =>
        array(
            'en_uk' => 'The start date of a basic MHC treatment must be after 31-12-2013',
            'nl' => 'De startdatum van een Basis GGZ behandeling moet na 31-12-2013 liggen. Met ingang van 01-01-2014 kunnen er Basis GGZ behandelingen geregistreerd worden'
        ),
    ),
    array (
        'code'    => 'TR-M23',
        'lang' =>
        array(
            'en_uk' => 'Only one activity per treatment can have an insurance approval registered.',
            'nl' => 'Per behandeling kan maar één activiteit een machtiging hebben.'
        ),
    ),
    array(
        'code'    => 'EP-M17',
        'lang' =>
        array(
            'en_uk' => 'The referring episode already refers to another overlapping treatment with care type 13 for this specialty.',
            'nl' => 'Het verwijzende zorgtraject verwijst naar een overlappend intercollegiaal consult voor dit specialisme.'
        ),
    ),
    array (
        'code'    => 'EP-M16',
        'lang' =>
        array(
            'en_uk' => 'For this care type a reference to a clinical treatment is obligatory.',
            'nl' => 'Voor dit zorgtype dient te worden verwezen naar een klinisch traject.'
        ),
    ),
    array (
        'code'    => 'TR-M27',
        'lang' =>
        array(
            'en_uk' => 'From this treatment is referred to a care type 51 treatment that is already closed. The end date of this treatment must be on or later than the end date of the care type 51 treatment.',
            'nl' => 'Vanuit deze behandeling wordt verwezen naar een zorgtype 51 behandeling die al gesloten is. De einddatum van deze behandeling moet op of na de einddatum van de zorgtype 51 behandeling ligge.'
        ),
    ),
    array (
        'code'    => 'TR-M26',
        'lang' =>
        array(
            'en_uk' => 'The date performed of the following  activity/activities is before the treatment startdate: {*codelist*}.',
            'nl' => 'De uitvoerdatum van de volgende activiteit/activiteiten ligt voor de startdatum van de behandeling: {*codelist*}.'
        ),
    ),
    array (
        'code'    => 'MG21',
        'lang' =>
            array(
                'en_uk' => 'An unexpected error occured. Please contact the servicedesk so the problem can be investigated.',
                'nl' => 'Er heeft zich een onverwacht probleem voorgedaan. Neem contact op met de servicedesk zodat het probleem onderzocht kan worden.'
            ),
    ),
    array(
        'code' => 'UR3',
        'lang' =>
            array(
                'en_uk' => 'You are not allowed to view this data of this patient.',
                'nl' => 'U hebt geen rechten om deze gegevens van deze patiënt te zien',
            )
    ),
    array(
        'code' => 'EP-M21',
        'lang' =>
            array(
                'en_uk' => 'The end date must be on or later than the start date.',
                'nl' => 'De einddatum moet op of na de startdatum liggen.',
            )
    ),
    array(
        'code' => 'GM-M03',
        'lang' =>
            array(
                'en_uk' => 'The patient is not linked to the selected clinic.',
                'nl' => 'De patiënt is niet geregistreerd bij de opgegeven kliniek.',
            )
    ),
    array(
        'code' => 'TR-M40',
        'lang' =>
            array(
                'en_uk' => 'There are parallel G-MHC/GB-MHC treatments.',
                'nl' => 'Er zijn parallelle G-GGZ/GB-GGZ behandelingen.',
            ),
    ),
    array(
        'code' => 'TR-M41',
        'lang' =>
            array(
                'en_uk' => 'The care type is not valid for this treatment. ',
                'nl' => 'Het zorgtype is niet valide voor deze behandeling',
            )
    ),
    array(
        'code' => 'TR-M42',
        'lang' =>
            array(
                'en_uk' => 'The care type is not valid on the start date of the treatment.',
                'nl' => 'Dit zorgtype is niet geldig op de startdatum van de behandeling.',
            ),
    ),
    array(
        'code' => 'TR-M50',
        'lang' =>
            array(
                'en_uk' => 'The expected performance is not valid on the start date of the treatment.',
                'nl' => 'De verwachte prestatie is niet geldig op de startdatum van de behandeling.',
            )
    ),
    array(
        'code' => 'TR-M51',
        'lang' =>
            array(
                'en_uk' => 'The delivered performance is not valid on the start date of the treatment.',
                'nl' => 'De geleverde prestatie is niet geldig op de startdatum van de behandeling.',
            ),
    ),
    array(
        'code' => 'ACT-M27',
        'lang' =>
            array(
                'en_uk' => 'This activity is already present on the performance date.',
                'nl' => 'Deze activiteit is al aanwezig op de uitvoerdatum.',
            ),
    ),
);
