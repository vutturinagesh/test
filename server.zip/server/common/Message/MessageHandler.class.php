<?php

namespace Message;

use Actinidium\API\Response\Meta;

class MessageHandler
{

    const
        BLOCKING = 0,
        WARNING = 1,
        NOTICE = 2,
        CONFIRMATION = 3;

    private
        $buffer = array(),
        $messages,
        $blocking = false,
        $levelDescriptions;

    public function __construct()
    {
        $this->load('Messages.php');
        $this->levelDescriptions = array(
            self::BLOCKING => 'error',
            self::WARNING => 'warning',
            self::NOTICE => 'info',
            self::CONFIRMATION => 'success'
        );
    }

    /**
     * @param $code
     * @param array $params
     * @return mixed|string
     * @throws \Exception
     */
    public function getOne($code, $params=array())
    {
        $rawMessage = $this->getRawMessage($code);
        if (empty($rawMessage)) {
            return array(
                'code' => $code,
                'params' => $params,
                'message' => 'Something went wrong, but the provided message code that should explain it ('.$code.') is unknown.'
            );
        }

        $message = $rawMessage;
        if (!empty($params) && is_array($params)) {
            $pattern = array();
            $replace = array();
            foreach ($params as $name => $value) {
                $pattern[] = '/\{\*' .$name. '\*\}/';
                $replace[] = $value;
            }
            $message = preg_replace($pattern, $replace, $rawMessage);
        }

        // Returned the complete message array
        return array(
            'code' => $code,
            'params' => $params,
            'raw' => $rawMessage,
            'message' => $message
        );
    }

    /**
     * adds a message, which will result in adding
     * - code
     * - params
     * - the raw message
     * - the message with the parameters filled in
     *
     * @param string $code like 'GV9'
     * @param int $level 0,1,2,3 (0=blocking,1=warning,2=notice,3=confirmation)
     * @param array $params like array('Object' => 'Episode', 'input'=> 99999)
     * @throws \Exception if $code is not present in the message list
     * @return boolean
     */
    public function add($code, $level, $params = array())
    {
        if ($level === self::BLOCKING) {
            $this->blocking = true;
        }

        $messageArray = $this->getOne($code, $params);

        $this->buffer[$this->levelDescriptions[$level]][] = $messageArray;
        return $messageArray;
    }

    /**
     * returns the array with all the messages
     * @return array
     */
    public function get()
    {
        foreach ($this->levelDescriptions as $key => $desc) {
            if (!isset($this->buffer[$desc])) {
                $this->buffer[$desc] = array();
            }
        }
        return $this->buffer;
    }

    /**
     * if we encountered a blocking error message
     * @return boolean
     */
    public function hasBlocking()
    {
        return (bool)$this->blocking;
    }

    /**
     * Cleans the buffer
     */
    public function clean()
    {
        $this->buffer = array();
    }

    /**
     * load the messages
     * @param type $messagesFilename
     * @return void
     */
    protected function load($messagesFilename)
    {
        require ($messagesFilename);
        $this->messages = $messages;
    }

    /**
     * returns the raw message with code $code
     * @param string $code
     * @return string
     */
    protected function getRawMessage($code)
    {
        if (!empty($this->messages) && is_array($this->messages)) {
            foreach ($this->messages as $message) {
                if ($message['code'] == $code) {
                    return $message['lang'][\Session\SessionHandler::getLanguage()];
                }
            }
        }
        return '';
    }
}
