<?php

namespace Session;

/**
 * Wraps the $_SESSION so we do not have to ask the session variable
 *
 * @author eddy.de.boer
 * @copyright (c) 2012, Medicore B.V
 * @package Session
 */
class SessionHandler
{

    const
        DEFAULT_LANGUAGE_IDENTIFIER = 'taal',
        LANGUAGE = 'taal',
        LANG_NL = 'nl',
        LANG_EN_UK = 'en_uk';

    /**
     * returns the value of $_SESSION[$key]
     * @param string $key
     * @return string;
     */
    public static function getValue($key)
    {
        if ( isset($_SESSION[$key]) ) {
            return $_SESSION[$key];
        }
        return "";
    }

    /**
     * getter
     * @return string
     */
    public static function getDefaultLanguage()
    {
        if ( isset($_SESSION[self::DEFAULT_LANGUAGE_IDENTIFIER]) ) {
            return $_SESSION[self::DEFAULT_LANGUAGE_IDENTIFIER];
        }
        return self::LANG_NL;
    }

    /**
     * getter
     * @return string
     */
    public static function getLanguage()
    {
        if ( isset($_SESSION[self::LANGUAGE]) ) {
            return $_SESSION[self::LANGUAGE];
        }
        return self::LANG_NL;
    }

    /**
     * setter
     * @param string $lang
     * @return void
     */
    public static function setDefaultLanguage($lang)
    {
        $_SESSION[self::DEFAULT_LANGUAGE_IDENTIFIER] = $lang;
    }

    /**
     * setter
     * @param string $lang
     * @return void
     */
    public static function setLanguage($lang)
    {
        $_SESSION[self::LANGUAGE] = $lang;
    }

}
