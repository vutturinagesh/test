<?php

namespace Session;

use Legacy\Gateway;
use Response\Error;

/**
 * Secure session class.
 *
 * PHP 5.4 comes with a new feature called session handler classes, which are extending the native SessionHandler class.
 * When registered as save handler, these classes can override the session methods, intercept them or filter them by
 * calling the parent class methods which ultimately wrap the internal PHP session handlers.
 *
 * Since we are currently running PHP 5.3, we can't intercept calls to session_start() or session_destroy(). This
 * session class wraps these two functions to enhance security. To use it, we need to replace the function calls
 * everywhere by SecureSession::start() and SecureSession::destroy() respectively.
 */
final class SecureSession
{
    /**
     * Start new or resume existing session.
     *
     * @return boolean
     */
    public static function start()
    {
        if (($result = session_start()) === true) {
            static::verifyUserAgent();
        }

        return $result;
    }

    /**
     * Verify browser user agent.
     */
    private static function verifyUserAgent()
    {
        if (static::checkIgnoreUserAgent()) {
            return;
        } elseif (!isset($_SESSION[__CLASS__ . '.userAgent'])) {
            $_SESSION[__CLASS__ . '.userAgent'] = static::getUserAgent();
        } elseif ($_SESSION[__CLASS__ . '.userAgent'] !== static::getUserAgent()) {
            static::exitUnauthorized();
        }
    }

    /**
     * Check if we need to ignore the browser user agent.
     *
     * @return boolean
     */
    private static function checkIgnoreUserAgent()
    {
        return (static::isCliRequest() || static::isGatewayRequest());
    }

    /**
     * Check if CLI-request.
     *
     * @return boolean
     */
    private static function isCliRequest()
    {
        return (php_sapi_name() === 'cli');
    }

    /**
     * Check if gateway-request.
     *
     * @return boolean
     */
    private static function isGatewayRequest()
    {
        return (strpos(static::getUserAgent(), Gateway::USER_AGENT_STRING) === 0);
    }

    /**
     * Get browser user agent.
     *
     * @return string
     */
    private static function getUserAgent()
    {
        return isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
    }

    /**
     * Exit with an "unauthorized" status header.
     */
    private static function exitUnauthorized()
    {
        static::removeSessionCookie();
        Error::unauthorized();
    }

    /**
     * Destroys all data registered to a session.
     *
     * @return boolean
     */
    public static function destroy()
    {
        if (($result = session_destroy()) === true) {
            static::removeSessionCookie();
        }

        return $result;
    }

    /**
     * Remove session cookie.
     */
    private static function removeSessionCookie()
    {
        if (ini_get('session.use_cookies')) {
            $cookieParams = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $cookieParams['path'], $cookieParams['domain'],
                $cookieParams['secure'], $cookieParams['httponly']
            );
        }
    }
}
