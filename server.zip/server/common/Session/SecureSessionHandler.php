<?php

namespace Session;

use Legacy\Gateway;
use Response\Error;
use SessionHandler;

/**
 * Secure session handler.
 *
 * SecureSessionHandler is a special class that exposes the current internal PHP session save handler by inheritance.
 * It contains methods which wrap the internal session save handler callbacks. This class will wrap whatever internal
 * save handler is set as defined by the session.save_handler configuration directive.
 *
 * Please note the callback methods of this class are designed to be called internally by PHP and are not meant to be
 * called from user-space code. The return values are equally processed internally by PHP. For more information on the
 * session workflow, please refer session_set_save_handler().
 */
class SecureSessionHandler extends SessionHandler
{
    /**
     * Initialize session.
     *
     * Create new session, or re-initialize existing session. Called internally by PHP when a session starts either
     * automatically or when session_start() is invoked.
     *
     * @param string $savePath    The path where to store/retrieve the session.
     * @param string $sessionName The session name.
     *
     * @return boolean
     */
    public function open($savePath, $sessionName)
    {
        if (($result = parent::open($savePath, $sessionName)) === true) {
            $this->verifyUserAgent();
        }

        return $result;
    }

    /**
     * Verify browser user agent.
     */
    private function verifyUserAgent()
    {
        if ($this->checkIgnoreUserAgent()) {
            return;
        } elseif (!isset($_SESSION[__CLASS__ . '.userAgent'])) {
            $_SESSION[__CLASS__ . '.userAgent'] = $this->getUserAgent();
        } elseif ($_SESSION[__CLASS__ . '.userAgent'] !== $this->getUserAgent()) {
            $this->exitUnauthorized();
        }
    }

    /**
     * Check if we need to ignore the browser user agent.
     *
     * @return boolean
     */
    private function checkIgnoreUserAgent()
    {
        return ($this->isCliRequest() || $this->isGatewayRequest());
    }

    /**
     * Check if CLI-request.
     *
     * @return boolean
     */
    private function isCliRequest()
    {
        return (php_sapi_name() === 'cli');
    }

    /**
     * Check if gateway-request.
     *
     * @return boolean
     */
    private function isGatewayRequest()
    {
        return (strpos($this->getUserAgent(), Gateway::USER_AGENT_STRING) === 0);
    }

    /**
     * Get browser user agent.
     *
     * @return string
     */
    private function getUserAgent()
    {
        return isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
    }

    /**
     * Exit with an "unauthorized" status header.
     */
    private function exitUnauthorized()
    {
        $this->removeSessionCookie();
        Error::unauthorized();
    }

    /**
     * Destroy a session.
     *
     * Destroys a session. Called by session_regenerate_id() (with $destroy = TRUE), session_destroy() and when
     * session_decode() fails.
     *
     * @param string $sessionId The session ID being destroyed.
     *
     * @return boolean
     */
    public function destroy($sessionId)
    {
        if (($result = parent::destroy($sessionId)) === true) {
            $this->removeSessionCookie();
        }

        return $result;
    }

    /**
     * Remove session cookie.
     */
    private function removeSessionCookie()
    {
        if (ini_get('session.use_cookies')) {
            $cookieParams = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $cookieParams['path'], $cookieParams['domain'],
                $cookieParams['secure'], $cookieParams['httponly']
            );
        }
    }
}
