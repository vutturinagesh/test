<?php

namespace Controller\Address\BAG;

use Actinidium\API\MetaBaseController;
use Actinidium\API\Response\Meta;
use Patient\Patient;
use Patient\PatientService;
use Actinidium\API\RestBaseController;

/**
 * PatientRestController
 *
 * Callable via /api/Address-BAG-SearchAddress
 */
class SearchAddressController extends \Controller\AbstractController
{
    /**
     * Holds the external service to call the legacy code 1.1
     *
     * @var \Patient\ExternalService
     */
    protected $externalService;

    /**
     * Hold the patient validation service object.
     *
     * @var \Patient\Field\ValidationService
     */
    protected $validationService;

    /**
     * Get the external service object on demand.
     *
     * @return \Patient\ExternalService
     */
    private function getExternalService()
    {
        if (!($this->externalService instanceof \Patient\ExternalService)) {
            $this->externalService = new \Patient\ExternalService();
        }
        return $this->externalService;

    }

    /**
     * Get the validation service object on demand.
     *
     * @return \Patient\Field\ValidationService
     */
    private function getValidationService()
    {
        if (!($this->validationService instanceof \Patient\Field\ValidationService)) {
            $this->validationService = new \Patient\Field\ValidationService();
        }

        return $this->validationService;
    }

    /**
     * Get action.
     *
     * @see \Actinidium\API\RestBaseController::getAction()
     *
     * @param int $id
     *
     * @return void
     */
    public function getAction($id)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * List action.
     *
     * @see \Actinidium\API\RestBaseController::getListAction()
     *
     * @return array $address
     */
    public function getListAction()
    {
        $address = null;
        $addressData = array();
        $query = $this->getRequest()->query;

        $addressData['physicalPostCode'] = $query->get('physicalPostCode');
        $addressData['physicalHouseNumber'] = $query->get('physicalHouseNumber');

        $this->validateMandatoryFields($addressData);
        if (!$this->hasError()) {
            $this->validateFields(array('physicalPostCode' => $addressData['physicalPostCode']));
        }

        $errors = array();
        if (!$this->hasError()) {
            $address = $this->getExternalService()->searchAddress(
                $addressData['physicalPostCode'],
                $addressData['physicalHouseNumber']
            );

            $errors = $this->getExternalService()->getErrors();

            if (count($errors > 0)) {
                $this->addErrorsToMeta($errors);
            }
        }

        if($address !== null ){
            if (array_key_exists('status', $address) && $address['status'] == 1) {
                $this->getMeta()->setCount(1);
            }
        }
        return $address;
    }

    /**
     * Create action.
     *
     * @see \Actinidium\API\RestBaseController::createAction()
     *
     * @param array $data
     *
     * @return void
     */
    public function createAction($data)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * Delete action.
     *
     * @see \Actinidium\API\RestBaseController::deleteAction()
     *
     * @param int $id
     *
     * @return void
     */
    public function deleteAction($id)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * Delete list action.
     *
     * @see \Actinidium\API\RestBaseController::deleteListAction()
     *
     * @return void
     */
    public function deleteListAction()
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * Update action.
     *
     * @see \Actinidium\API\RestBaseController::updateAction()
     *
     * @param int   $id
     * @param array $data
     *
     * @return void
     */
    public function updateAction($id, $data)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }


    /**
     * Function to collect and execute the mandatory fields for the actions
     *
     * @param array $addressData
     */
    private function validateMandatoryFields(array $addressData)
    {
        $validationService = $this->getValidationService();
        $mandatoryValidation = $validationService->validateMandatoryBAGAddressFields($addressData);

        if (!empty($mandatoryValidation)) {
            $this->addErrorsToMeta($mandatoryValidation);
        }
    }

    /**
     * Function to validate the contents of the fields.
     *
     * @param array $addressData
     */
    private function validateFields(array $addressData)
    {
        $validationService = $this->getValidationService();
        foreach ($addressData as $field => $value) {
            $validators = array();

            $validators = $validationService->getValidationsByField($field, $value, array(
                'physicalCountry' =>
                    array('id' => \Person\Address::DEFAULT_COUNTRY)
            ));
            $this->executeValidators($validators);
        }
    }
}
