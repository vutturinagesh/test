<?php

namespace Controller;

use Actinidium\API\Response\Meta;
use Generic\Message\MetaMessage;

/**
 * Validation result.
 */
class ValidationResult
{
    /**
     * @var integer
     */
    const ERROR = 0;

    /**
     * @var integer
     */
    const WARNING = 1;

    /**
     * @var integer
     */
    const INFO = 2;

    /**
     * @var integer
     */
    const SUCCESS = 3;

    /**
     * Adds validations results to Meta object.
     *
     * @param array              $results
     * @param AbstractController $controller
     */
    public static function addToMeta(array $results = array(), AbstractController $controller)
    {
        if (empty($results)) {
            return;
        }
        static::arrayWalkRecursive($results, 'static::addToMetaCallback', $controller);
    }

    /**
     * Add to meta callback.
     *
     * @param mixed                          $value
     * @param string                         $key
     * @param \Controller\AbstractController $controller
     */
    private static function addToMetaCallback($value, $key, AbstractController $controller)
    {
        if ($value instanceof MetaMessage) {
            static::addMetaMessageToMeta($value, $controller);
        } elseif (is_array($value) && isset($value['level'])) {
            static::addMessageHandlerMessageArrayToMeta($value, $controller);
        }
    }

    /**
     * Adds a translated message to Meta.
     *
     * Can handle the result arrays from both \Event\Handler::dispatchEvent() (new event system) and
     * \Generic\Validation\EventHandler::run() (old event system).
     *
     * Difference with static::addToMeta is that it does not use the MessageHandler, the messages are in the
     * translated xliff files.
     *
     * @param \Controller\AbstractController $controller
     * @param array                          $results
     * @param array                          $extraParams
     * @param string                         $domain
     */
    public static function addMessages(
        AbstractController $controller,
        array $results = array(),
        array $extraParams = array(),
        $domain = null
    ) {
        if (empty($results)) {
            return;
        }
        static::arrayWalkRecursive($results, 'static::addMessagesCallback', array($controller, $extraParams, $domain));
    }

    /**
     * Add messages callback.
     *
     * @param mixed $value
     * @param string $key
     * @param array $data
     */
    private static function addMessagesCallback($value, $key, array $data)
    {
        $controller = $data[0];
        $extraParams = $data[1];
        $domain = $data[2];

        if ($value instanceof MetaMessage) {
            static::addMetaMessageToMeta($value, $controller, $extraParams, $domain);
        } elseif (is_array($value) && isset($value['level'])) {
            static::addMessageArrayToMeta($value, $controller, $extraParams, $domain);
        }
    }

    /**
     * Add MetaMessage to Meta.
     *
     * @param \Generic\Message\MetaMessage   $metaMessage
     * @param \Controller\AbstractController $controller
     * @param array                          $extraParams
     * @param string                         $domain
     */
    private static function addMetaMessageToMeta(
        MetaMessage $metaMessage,
        AbstractController $controller,
        array $extraParams = array(),
        $domain = null
    ) {
        $type = $metaMessage->getStatus();
        $message = $metaMessage->getMessage();
        $params = $metaMessage->getParams();
        $messageCode = $metaMessage->getCode();
        $hint = $metaMessage->getHint();

        $params = array_merge($params, $extraParams);
        static::addTranslatedToMeta($type, $message, $params, $messageCode, $hint, $controller, $domain);
    }

    /**
     * Add MessageHandler message array to Meta.
     *
     * @param array                          $messageArray
     * @param \Controller\AbstractController $controller
     */
    private static function addMessageHandlerMessageArrayToMeta(array $messageArray, AbstractController $controller)
    {
        $status = static::convertErrorLevel($messageArray['level']);
        $code = isset($messageArray['message']) ? $messageArray['message'] : '';
        $params = isset($messageArray['params']) ? $messageArray['params'] : array();
        $controller->addMessage($status, $code, $params);
    }

    /**
     * Add message array to Meta.
     *
     * @param array                          $messageArray
     * @param \Controller\AbstractController $controller
     * @param array                          $extraParams
     * @param string                         $domain
     */
    private static function addMessageArrayToMeta(
        array $messageArray,
        AbstractController $controller,
        array $extraParams = array(),
        $domain = null
    ) {
        $type = static::convertErrorLevel($messageArray['level']);
        $message = isset($messageArray['message']) ? $messageArray['message'] : '';
        $params = isset($messageArray['params']) ? $messageArray['params'] : array();
        $messageCode = isset($messageArray['code']) ? $messageArray['code'] : null;
        $hint = isset($messageArray['hint']) ? $messageArray['hint'] : null;

        $params = array_merge($params, $extraParams);
        static::addTranslatedToMeta($type, $message, $params, $messageCode, $hint, $controller, $domain);
    }

    /**
     * Add translated to Meta.
     *
     * @param string                         $type
     * @param string                         $message
     * @param array                          $params
     * @param string                         $messageCode
     * @param string                         $hint
     * @param \Controller\AbstractController $controller
     * @param string                         $domain
     */
    private static function addTranslatedToMeta(
        $type,
        $message,
        array $params,
        $messageCode,
        $hint,
        AbstractController $controller,
        $domain = null
    ) {
        $message = $controller->getTranslator()->trans($message, $params, $domain);
        if (!empty($hint)) {
            $hint = $controller->getTranslator()->trans('HINT-' . $hint, $params, $domain);
        }
        $controller->getMeta()->addMessage($type, $message, $messageCode, $hint);
    }

    /**
     * Convert error level.
     *
     * The level we are getting from the backend is an integer, but Meta needs a string.
     *
     * @param integer $level
     *
     * @return string
     */
    public static function convertErrorLevel($level)
    {
        $metaLevel = Meta::STATUS_ERROR;
        if ($level == static::ERROR) {
            $metaLevel = Meta::STATUS_ERROR;
        } elseif ($level == static::WARNING) {
            $metaLevel = Meta::STATUS_WARNING;
        } elseif ($level == static::INFO) {
            $metaLevel = Meta::STATUS_INFO;
        } elseif ($level == static::SUCCESS) {
            $metaLevel = Meta::STATUS_SUCCESS;
        }

        return $metaLevel;
    }

    /**
     * Checks if validationResults contains errors.
     *
     * Can handle the result arrays from both \Event\Handler::dispatchEvent() (new event system) and
     * \Generic\Validation\EventHandler::run() (old event system).
     *
     * @param array $results
     *
     * @return boolean
     */
    public static function containsErrors(array $results)
    {
        $error = static::ERROR;
        $containsErrors = false;
        array_walk_recursive(
            $results,
            function ($value, $key) use (&$containsErrors, $error) {
                if ($value instanceof MetaMessage && $value->isError()) {
                    $containsErrors = true;
                } elseif ($key === 'level' && $value == $error) {
                    $containsErrors = true;
                }
            }
        );

        return $containsErrors;
    }

    /**
     * Array walk recursive.
     *
     * Apply a user function recursively to every member of an array.
     *
     * This version will pass any value to the callback function, even when the key holds an array. The native version
     * `array_walk_recursive` will only pass values that are not arrays.
     *
     * @param array    $array
     * @param callable $callback
     * @param mixed    $userdata
     */
    private static function arrayWalkRecursive(array $array, /*callable*/ $callback, $userdata = null)
    {
        foreach ($array as $key => $value) {
            if (in_array($key, array('params', 'eventListener'), true)) {
                continue;
            }
            call_user_func($callback, $value, $key, $userdata);
            if (is_array($value)) {
                static::arrayWalkRecursive($value, $callback, $userdata);
            }
        }
    }
}
