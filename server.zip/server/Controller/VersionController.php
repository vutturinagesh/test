<?php

namespace Controller;

use Actinidium\API\RestBaseController;
use System\SmsReleaseService;
use Generic\CustomerService;
use Actinidium\API\Response\CachedJsonResponse;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/version",
 *     basePath="/api/v2"
 * )
 */
class VersionController extends RestBaseController
{
    /**
     * Get resource by id
     *
     * @param int $id
     * @return null
     */
    public function getAction($id)
    {
        $this->getMeta()->addMessage(Meta::STATUS_ERROR, 'Not implemented');

        return null;
    }

    /**
     * Create new resource
     *
     * @param array $data
     * @return null
     */
    public function createAction($data)
    {
        $this->getMeta()->addMessage(Meta::STATUS_ERROR, 'Not implemented');

        return null;
    }

    /**
     * Update resource
     *
     * @param int $id
     * @param array $data
     * @return null
     */
    public function updateAction($id, $data)
    {
        $this->getMeta()->addMessage(Meta::STATUS_ERROR, 'Not implemented');

        return null;
    }

    /**
     * Delete resource
     *
     * @param int $id
     * @return null
     */
    public function deleteAction($id)
    {
        $this->getMeta()->addMessage(Meta::STATUS_ERROR, 'Not implemented');

        return null;
    }

    /**
     * Delete multiple resources
     *
     * @return null
     */
    public function deleteListAction()
    {
        $this->getMeta()->addMessage(Meta::STATUS_ERROR, 'Not implemented');

        return null;
    }

    /**
     * @SWG\Api(
     *   path="/version",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Find version by criteria",
     *           notes="Returns version",
     *       )
     * )
     *
     * @return CachedJsonResponse
     */
    public function getListAction()
    {
        $response = new CachedJsonResponse();

        $smsReleaseService = $this->getSMSReleaseService();
        $release = $smsReleaseService->getRelease();

        if ($release) {
            $revision = $release->getRevision();
            $revisionDate = $release->getUpdateTime()->format('Y-m-d H:i:s');
        } else {
            $revisionTime = new \DateTime();
            $revision = strtotime($revisionTime->format('Y-m-d H:i:s'));
            $revisionDate = '0000-00-00 00:00';
        }

        $customerService = $this->getCustomerService();
        $version = $customerService->getCustomer()->getVersion();

        $this->setSessionForRevision($revision, $revisionDate, $version);

        $data = array(
            'revision' => $revision,
            'revision_date' => $revisionDate,
            'version' => $version
        );
        $response->setData(array('data' => $data));

        return $response;
    }

    /**
     * Function to return SMSReleaseService
     *
     * @return \System\SmsReleaseService()
     */
    protected function getSMSReleaseService()
    {
       return new \System\SmsReleaseService();
    }
    
    /**
     * Function to return CustomerService
     *
     * @return \Generic\CustomerService()
     */
    protected function getCustomerService()
    {
        return new \Generic\CustomerService();
    }
    
    /**
     * Set session variables for revision data
     *
     * @param int $revision
     * @param string $revisionDate Date as Y-m-d
     * @param string $version
     */
    private function setSessionForRevision($revision, $revisionDate, $version)
    {
        $_SESSION['settings']['revision'] = $revision;
        $_SESSION['settings']['revision_date'] = $revisionDate;
        $_SESSION['settings']['version'] = $version;
    }
}
