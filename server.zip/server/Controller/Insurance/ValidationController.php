<?php
namespace Controller\Insurance;

use Actinidium\API\Response\Meta as Meta;
use Controller\AbstractController as AbstractController;
use \Insurance\Validation\Service as ValidationService;
use \Insurance\Validation\Exception\EmptyInput as EmptyException;
use \Message\MessageHandler as MessageHandler;

/**
 * Validation Controller
*/
class ValidationController extends AbstractController
{
    /**
     * Holds object of \Insurance\Validation\Service.
     *
     * @var \Insurance\Validation\Service
     */
    protected $validationService;

    /**
     * Get the validation service object on demand.
     *
     * @return \Insurance\Validation\Service
     */
    private function getValidationService()
    {
        if (!($this->validationService instanceof ValidationService)) {
            $this->validationService = new ValidationService();
        }
        return $this->validationService;
    }

    /**
     * Get action for validating insurances.
     *
     * @param integer $id
     *
     * @todo Need to implement
     */
    public function getAction($id)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * Get list action for validation.
     *
     * @todo Need to implement
     */
    public function getListAction()
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * Create action.
     *
     * @param array $data
     */
    public function createAction($data)
    {
        if (!array_key_exists('insurances', $data) || count($data['insurances']) === 0) {
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->add(
                    'MG-XXX',
                    MessageHandler::BLOCKING
                )
            );
        }

        if ($this->hasError() === false) {
            try {
                $insurances = $data['insurances'];
                $this->processRequestValidation($insurances);

                if ($this->hasError() === false) {
                    $validationService = $this->getValidationService();
                    $validatedInsurances = $validationService->validateInsurances($insurances);

                    $this->getMeta()->addMessage(
                        Meta::STATUS_SUCCESS,
                        $this->messageHandler->add(
                            'MG-XXXX',
                            MessageHandler::CONFIRMATION
                        )
                    );

                    $this->getMeta()->setCount(count($validatedInsurances));

                    return $validatedInsurances;
                } else {
                    $this->getMeta()->setCount(0);
                }
            } catch (EmptyException $e) {
                $this->getMeta()->addMessage(
                    Meta::STATUS_ERROR,
                    $this->messageHandler->add(
                        'MG-XXX',
                        MessageHandler::BLOCKING
                    )
                );
                $this->getMeta()->setCount(0);
            } catch (\Exception $e) {
                var_dump($e);
            }
        }
    }

    /**
     * Function to process the field validations.
     *
     * @param array $data
     */
    private function processRequestValidation(array $data = array())
    {
        $insuranceValidationService = $this->getValidationService();

        foreach ($data as $insurance) {
            // Validate top level insurance input
            $mandatoryInsuranceFields = $insuranceValidationService->collectMandatoryFields($insurance);
            $this->processMandatoryFields($mandatoryInsuranceFields, $insurance);
        }
    }

    /**
     * Validate the insurances.
     *
     * @param integer $id
     * @param array   $data
     *
     * @return void
     *
     * @todo Need to implement
     */
    public function updateAction($id, $data)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * Delete action.
     *
     * @param integer $id
     *
     * @return void
     *
     * @todo Need to implement
     */
    public function deleteAction($id)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * Delete list action.
     *
     * @return void
     *
     * @todo Need to implement
     */
    public function deleteListAction()
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }
}
