<?php
namespace Controller\Insurance;

use Actinidium\API\Response\Meta;
use Controller\AbstractController;

/**
 * Company Controller
 *
 * @package Insurance
 */
class CompanyController extends AbstractController
{
    /**
     * Holds object of  CompanyService.
     *
     * @var \Insurance\CompanyService
     */
    protected $companyService;

    /**
     * Get the validation service object on demand.
     *
     * @return \Patient\PatientService
     */
    private function getValidationService()
    {
        if (!($this->validationService instanceof \Insurance\Company\ValidationService)) {
            $this->validationService = new \Insurance\Company\ValidationService();
        }
        return $this->validationService;
    }

    /**
     * Function to process the validation for the posted data on a passed service.
     *
     * @param array                                $data
     * @param \Insurance\Company\ValidationService $validationService
     * @param array                                $mandatoryFields
     */
    private function processValidators(
        array $data,
        \Insurance\Company\ValidationService $validationService,
        array $mandatoryFields = array()
    ) {
        foreach ($data as $field => $value) {
            if ($this->requiresValidation($field, $value, $mandatoryFields) === true) {
                $validators = $validationService->getValidationsByField($field, $value, $data);
                $this->executeValidators($validators);
            }
        }
    }

    /**
     * Get the Emr type service object on demand.
     *
     * @return \Insurance\CompanyService
     */
    private function getCompanyService()
    {
        if (!($this->companyService instanceof \Insurance\CompanyService)) {
            $this->companyService = new \Insurance\CompanyService();
        }
        return $this->companyService;
    }

    /**
     * Get action for insurance company.
     *
     * @param integer $id
     *
     * @return void
     *
     * @todo Need to implement
     */
    public function getAction($id)
    {
        try {
            // find companies by id
            $result = $this->getCompanyService()->getById($id);
            if (count($result) == 0) {
                $this->getMeta()->addMessage(META::STATUS_ERROR, "No Records Found");
            } else {
                //Count will always be one for the id
                $this->getMeta()->setCount(1);
                return $result;
            }
        } catch (\Exception $e) {
            $this->getMeta()->addMessage(META::STATUS_ERROR, $e->getMessage());
        }
    }

    /**
     * Get list action for companies.
     *
     * This function handles the following request parameters:
     *  searchValue, can be UZOVI number, or company name string
     *  validityDate, date between start date and end date of insurance
     *  coverageType, can be 'basis' or 'aanvullend'
     *
     * @return array Selected companies with packages.
     */
    public function getListAction()
    {
        $validationService = $this->getValidationService();
        $fieldsToValidate = array();

        $requestData = $this->getRequestData();
        $fieldsToValidate = $this->collectFieldsToValidate($requestData);

        $this->processMandatoryFields(array_keys($fieldsToValidate), $fieldsToValidate);
        if ($this->hasError() === false) {
            // Add request values to validation
            $this->processValidators($fieldsToValidate, $validationService);

            if ($this->hasError() === false) {
                $data = array();
                try {
                    $data = $this->getCompanyService()->getBySearchCriteria($fieldsToValidate);
                } catch (\Exception $e) {
                    $this->getMeta()->addMessage(META::STATUS_ERROR, $e->getMessage());
                }

                $this->getMeta()->setCount(count($data));
                return $data;
            }
        }
    }

    /**
     * Create action for company.
     *
     * @param array $data
     *
     * @return void
     *
     * @todo Need to implement
     */
    public function createAction($data)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * Update action for company.
     *
     * @param integer $id
     * @param array   $data
     *
     * @return void
     *
     * @todo Need to implement
     */
    public function updateAction($id, $data)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * Delete action for company.
     *
     * @param integer $id
     *
     * @return void
     *
     * @todo Need to implement
     */
    public function deleteAction($id)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * Delete list action for company.
     *
     * @return void
     *
     * @todo Need to implement
     */
    public function deleteListAction()
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * Function to collect the passed parameters from the request.
     *
     * @return array
     */
    private function getRequestData()
    {
        $requestData = array();
        $query = $this->getRequest()->query;

        $keys = $query->keys();
        foreach ($keys as $incoming) {
            $requestData[$incoming] = $query->get($incoming);
        }

        return $requestData;
    }

    /**
     * Function to decide which of the fields passed to the controller need to be validated.
     *
     * @param array $requestData
     *
     * @return array
     */
    private function collectFieldsToValidate(array $requestData = array())
    {
        $fieldsToValidate = array();

        if (array_key_exists('searchValue', $requestData)) {
            $searchParameter = $this->evaluateSearchValue($requestData['searchValue']);
            $fieldsToValidate = array_merge($searchParameter, $fieldsToValidate);
        }

        if (array_key_exists('validityDate', $requestData)) {
            $fieldsToValidate['validityDate'] = $requestData['validityDate'];
        }

        if (array_key_exists('coverageType', $requestData)) {
            $fieldsToValidate['coverageType'] = $requestData['coverageType'];
        }
        return $fieldsToValidate;
    }

    /**
     * Function to decide if we should search for a name or a uzovi by checking if the parameter is an int or string.
     *
     * @param string | int $searchValue
     *
     * @return array
     */
    private function evaluateSearchValue($searchValue)
    {
        $searchParameter = array();

        //if the value is numeric we want to search for an uzovi
        if (is_numeric($searchValue)) {
            $searchParameter['uzovi'] = (int) $searchValue;;
        } else {
            $searchParameter['name'] = $searchValue;
        }

        return $searchParameter;
    }
}
