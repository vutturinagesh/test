<?php

namespace Controller;

use Medical\EpisodeService;
use Medical\Episode;
use System\MHC\ReferrerCodeService;
use System\MHC\YouthReferrerCodeService;
use System\MHC\ReferrerCode;
use Actinidium\API\Response\Meta;

class MHCReferrerCodeHelper
{
    /**
     * @var AbstractController
     */
    private $controller;

    /**
     * @var EpisodeService
     */
    private $episodeService;

    public function __construct(AbstractController $controller)
    {
        $this->controller = $controller;
    }

    /**
     * Validate MHC Referrer cpde
     *
     * @param array $data
     *
     * @return MhcReferrerCode|null
     */
    public function validateMHCReferrerCode(array $data)
    {
        $MHCReferrerCode = null;

        $MHCReferrerCode = $this->controller->createEntity(
            $data['MHCReferrerCode']['id'],
            "MHCReferrerCode",
            new ReferrerCodeService($this->getEntityManager()->getRepository('System\MHC\ReferrerCode')),
            'System\MHC\ReferrerCode'
        );
        return $MHCReferrerCode;
    }

    /**
     * Get Entity Manager.
     *
     * @param $identity
     *
     * @return \Doctrine\ORM\EntityManager|\ORM\false
     */
    private function getEntityManager($identity = \ORM\Provider::DEFAULT_ID)
    {
        return \ORM\Provider::getInstance()->getEntityManager($identity);
    }

    /**
     * Validate MHC youth Referrer code.
     *
     * @param array $data
     *
     * @return MhcYouthReferrerCode|null
     */
    public function validateMHCYouthReferrerCode(array $data)
    {
        $MHCYouthReferrerCode = null;

        $MHCYouthReferrerCode = $this->controller->createEntity(
            $data['MHCReferrerCode']['id'],
            "MHCYouthReferrerCode",
            new YouthReferrerCodeService($this->getEntityManager()->getRepository('System\MHC\YouthReferrerCode')),
            'System\MHC\YouthReferrerCode'
        );

        return $MHCYouthReferrerCode;
    }
}