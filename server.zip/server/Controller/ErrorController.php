<?php

namespace Controller;

use Actinidium\API\Exception\ApiNotFoundException;
use Actinidium\API\Exception\UnauthorizedException;
use Actinidium\API\MetaBaseController;
use Actinidium\API\AnonymousAccessInterface;

/**
 * Error Controller for all invalid paths
 */
class ErrorController extends MetaBaseController implements AnonymousAccessInterface
{
    /**
     * @return bool
     */
    public function anonymousAccessAllowed()
    {
        return true;
    }

    /**
     * Default action
     *
     * @throws \Actinidium\API\Exception\ApiNotFoundException
     */
    public function indexAction()
    {
        throw new ApiNotFoundException();
    }

    /**
     * Default action
     *
     * @throws \Actinidium\API\Exception\UnauthorizedException
     */
    public function unauthorizedAction()
    {
        throw new UnauthorizedException();
    }
}
