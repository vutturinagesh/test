<?php

namespace Controller;

use Generic\SpecialismService;
use Medical\TreatmentService;
use Medical\ActivitySearchService;
use Message\MessageHandler;

/**
 * @SWG\Resource(
 *     apiVersion="1.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/activity",
 *     basePath="/api"
 * )
 */
class ActivityController extends AbstractController
{
    /**
     * @var \Generic\SpecialismService
     */
    private $specialismService;

    /**
     * @var \Medical\ActivitySearchService
     */
    private $activitySearchService;

    /**
     * Constructor.
     *
     * @param \Generic\SpecialismService|null     $specialismService
     * @param \Medical\ActivitySearchService|null $activitySearchService
     */
    public function __construct(
        SpecialismService $specialismService = null,
        ActivitySearchService $activitySearchService = null
    ) {
        parent::__construct();

        if (null === $specialismService) {
            $specialismService = $this->get('medicore.generic.specialism_service');
        }

        if (null === $activitySearchService) {
            $activitySearchService = $this->get('medicore.medical.activity_search_service');
        }

        $this->specialismService = $specialismService;
        $this->activitySearchService = $activitySearchService;
    }

    /**
     * @SWG\Api(
     *   path="/activity",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Find MHC or Somatic activities on partial and full strings.",
     *           notes="Returns found MHC or SOM activities.",
     *           @SWG\Parameter(name="searchString", type="string", required=true, paramType="query"),
     *           @SWG\Parameter(name="treatment-type", type="string", required=true, paramType="query"),
     *           @SWG\Parameter(name="date", type="string", format="YYYY-MM-DD", required=true, paramType="query"),
     *           @SWG\Parameter(name="offset", type="integer", required=false, paramType="query"),
     *           @SWG\Parameter(name="itemsPerPage", type="integer", required=false, paramType="query"),
     *           @SWG\Parameter(name="specialtyId", type="integer", required=false, paramType="query")
     *       )
     * )
     *
     * @return array
     */
    public function getListAction()
    {
        $data = array();
        $query = $this->getRequest()->query;
        $specialism = null;

        if ($query->has('specialtyId')) {
            $specialism = $this->createEntity(
                $query->get('specialtyId'),
                "specialtyId",
                $this->specialismService,
                "Generic\\Specialism"
            );
        }

        $criteria = $this->activitySearchService->getCriteriaFromRequest($this->getRequest());
        $criteria->setSpecialism($specialism);

        if ($this->isModelValid($criteria)) {
            list($totalAmount, $results) = $this->activitySearchService->search($criteria);
        }

        if (!$this->getMeta()->hasError()) {
            $data = array_map(function ($activity) {
                return $activity->toListArray();
            }, $results);

            $offset = ($criteria->getPage() - 1) * $criteria->getLimit();
            $this->addPagination($offset, $criteria->getLimit(), $totalAmount);
        }

        $this->getMeta()->setCount($totalAmount);

        return $data;
    }
}
