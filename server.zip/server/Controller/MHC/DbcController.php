<?php
/**
 * Created by Treatment Registration Rebuild.
 * User: eddy.de.boer
 * Date: 8-7-13
 * 
 */

namespace Controller\MHC;

use Actinidium\API\RestBaseController;
use Actinidium\API\Response\Meta;
use Medical\MHC\Dbc;
use Medical\MHC\DbcService;
use Medical\Treatment;
use Medical\TreatmentService;
use Symfony\Component\HttpFoundation\ParameterBag;
use Encoding\Utf8;
use Controller\AbstractController;


class DbcController extends AbstractController
{
    private $model;
    private $treatmentModel;
    private $treatment;

    /**
     * @return DbcController
     */
    public function __construct()
    {
        parent::__construct();
        $this->model = new DbcService();

    }

    public function getAction($id)
    {
        $this->data = array();
        $query = $this->getRequest()->query;
        $this->validateTreatment($id);
        $this->validateAction($query);
        if (!$this->getMeta()->hasError()) {
            $this->getProductGroup($id);
        }

        Utf8::convert($this->data, 'iso88591');

        return $this->data;
    }

    public function getListAction()
    {
        $this->getMeta()->addMessage(Meta::STATUS_ERROR, __CLASS__."#".__FUNCTION__."() Not yet implemented.");
    }

    public function createAction($data)
    {
        $this->getMeta()->addMessage(Meta::STATUS_ERROR, __CLASS__."#".__FUNCTION__."() Not yet implemented.");
    }

    public function updateAction($id, $data)
    {
        $this->getMeta()->addMessage(Meta::STATUS_ERROR, __CLASS__."#".__FUNCTION__."() Not yet implemented.");
    }

    public function deleteAction($id)
    {
        $this->getMeta()->addMessage(Meta::STATUS_ERROR, __CLASS__."#".__FUNCTION__."() Not yet implemented.");
    }

    public function deleteListAction()
    {
        $this->getMeta()->addMessage(Meta::STATUS_ERROR, __CLASS__."#".__FUNCTION__."() Not yet implemented.");
    }

    /**
     * @return DbcService
     */
    public function getModel()
    {
        if ($this->model) {
            return $this->model;
        }
        $this->model = new DbcService();
        return $this->model;
    }

    /**
     * @param DbcService $model
     */
    public function setModel(DbcService $model)
    {
        if ($model instanceof DbcService) {
            $this->model = $model;
        }
    }

    /**
     * @return \Medical\TreatmentService
     */
    public function getTreatmentModel()
    {
        if ($this->treatmentModel) {
            return $this->treatmentModel;
        }
        $this->treatmentModel = new TreatmentService();
        return $this->treatmentModel;
    }

    /**
     * @param \Medical\TreatmentService $model
     */
    public function setTreatmentModel(TreatmentService $model)
    {
        if ($model instanceof TreatmentService) {
            $this->treatmentModel = $model;
        }
    }

    /**
     * Needed for PHPUnit
     * @param Treatment $treatment
     */
    public function setTreatment(Treatment $treatment)
    {
        if ($treatment instanceof Treatment) {
            $this->treatment = $treatment;
        }
    }

    /**
     * @param Dbc $dbc
     */
    public function setDbc(Dbc $dbc)
    {
        if ($dbc instanceof Dbc) {
            $this->dbc = $dbc;
        }
    }

    /**
     * @param $id
     */
    protected function validateTreatment($id)
    {
        $this->getTreatmentById($id);
    }

    /**
     * @param ParameterBag $query
     */
    protected function validateAction(ParameterBag $query)
    {
        if ($query->has("action")) {
            if ($this->isRequired($query->get("action"), "action")) {
                if (strtolower("productgroup") !== strtolower($query->get("action"))) {
                    $this->getMeta()->addMessage(
                        Meta::STATUS_ERROR,
                        $this->messageHandler->add(
                            'MG101',
                            \Message\MessageHandler::BLOCKING,
                            array('field_name' => "action", 'input' => $query->get("action"))
                        )
                    );
                }
            }
        }
    }


    /**
     * Calls the decision tree for determining the Product Group
     * @param $id
     * @return mixed
     * @return array
     */
    protected function getProductGroup($id)
    {
        $treatment = $this->getTreatmentById($id);
        if ($treatment) {
            $dbc = $this->getDbcByTreatment($treatment);
        }
        if (!$this->getMeta()->hasError()) {
            $this->data = $this->getModel()->getProductGroup($dbc);
        }
        return $this->data;
    }

    /**
     * @param $id
     * @return Treatment
     */
    protected function getTreatmentById($id)
    {
        if (!$this->treatment) {
            $this->treatment = $this->createEntity($id, "id", $this->getTreatmentModel(), "Medical\\Treatment");
        }
        return $this->treatment;
    }

    /**
     * @param Treatment $treatment
     * @return \Medical\MHC\Dbc
     */
    protected function getDbcByTreatment(Treatment $treatment)
    {
        if (!$this->dbc) {
            $this->dbc = $treatment->getDbcMhc();
            if (!$this->dbc) {
                $this->getMeta()->addMessage(
                    Meta::STATUS_ERROR,
                    $this->messageHandler->add(
                        'GV9',
                        \Message\MessageHandler::BLOCKING,
                        array('object' => "Medical\\MHC\\Dbc", 'input' => $treatment->getId())
                    )
                );
            }
        }
        return $this->dbc;
    }




}