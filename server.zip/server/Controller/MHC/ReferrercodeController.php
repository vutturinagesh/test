<?php

namespace Controller\MHC;

use Actinidium\API\Response\Meta;
use Controller\AbstractController;
use Actinidium\API\MetaBaseController;
use Medical\Episode;
use System\MHC\ReferrerCodeService;
use Medical\EpisodeService;
use System\MHC\YouthReferrerCodeService;

/**
 * Class ReferrercodeController
 */
class ReferrercodeController extends AbstractController
{
    const YOUNG = 18;

    /**
     * @var ReferrerCodeService
     */
    private $referrerCodeService;

    /**
     * @var YouthReferrerCodeService
     */
    private $youthReferrerCodeService;

    /**
     * @var EpisodeService
     */
    private $episodeService;

    /**
     * Will return all referrer codes.
     *
     * @return array
     */
    public function getListAction()
    {
        $this->data = array();
        $query = $this->getRequest()->query;

        if ($query->has('episodeId')) {
            $referrerCodes = $this->findByEpisode($query->get("episodeId"));
        } else {
            $referrerCodes = $this->getReferrerCodeService(false)->findAll();
        }

        foreach ($referrerCodes as $referrerCode) {
            $this->data[] = $referrerCode->toListArray();
        }

        $this->getMeta()->setCount(count($this->data));

        return $this->data;
    }

    /**
     * Will fetch all referrer codes valid on episode start date.
     *
     * @param $episodeId
     *
     * @return array
     */
    private function findByEpisode($episodeId)
    {
        $referrerCodes = array();
        $episode = $this->createEntity($episodeId, "patientId", $this->getEpisodeService(), "Medical\\Episode");
        if (!$this->getMeta()->hasError()) {
            $criteria = array();
            $criteria['date'] = $episode->getStartDate();
            $referrerCodes = $this->getReferrerCodeService($this->isPatientYoung($episode))->findAllByCriteria($criteria);
        }

        return $referrerCodes;
    }

    /**
     * Will check it episode start date is greater or equal to 01-01-2015
     * and patient age should be less than 18 on episode startdate.
     *
     * @param Episode $episode
     *
     * @return bool
     */
    private function isPatientYoung(Episode $episode)
    {
        $patientAge = $episode->getPatient()->getBirthDate();

        if (!$this->getMeta()->hasError()) {
            if (($episode->getStartDate() >= new \DateTime("2015-01-01"))
                && (\Generic\DiffDate::diffInYears($patientAge, $episode->getStartDate())) < self::YOUNG
            ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Factory method for getting the referrer code service.
     *
     * @param bool $isPatientYoung Based on the age of the patient, use the
     *
     * @return ReferrerCodeService
     */
    private function getReferrerCodeService($isPatientYoung)
    {
        if (!$this->referrerCodeService) {
            if ($isPatientYoung) {
                $this->referrerCodeService = new YouthReferrerCodeService();
            } else {
                $this->referrerCodeService = new ReferrerCodeService();
            }
        }

        return $this->referrerCodeService;
    }

    private function getEntityManager($identity = \ORM\Provider::DEFAULT_ID)
    {
        return \ORM\Provider::getInstance()->getEntityManager($identity);
    }

    /**
     * Factory method for getting the EpisodeService.
     *
     * @return EpisodeService
     */
    private function getEpisodeService()
    {
        if (!$this->episodeService) {
            $this->episodeService = new EpisodeService();
        }

        return $this->episodeService;
    }
}
