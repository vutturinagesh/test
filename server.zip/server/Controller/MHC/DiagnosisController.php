<?php
namespace Controller\MHC;

use Actinidium\API\Response\Meta;
use Controller\AbstractController;
use Generic\CustomerSettingsService;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use System\MHC\DiagnoseService;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/system",
 *     basePath="/api/v2"
 * )
 */
class DiagnosisController extends AbstractController
{
    /**
     * @var \System\MHC\DiagnoseService
     */
    private $systemMhcDiagnoseService;

    /**
     * @var \DateTime
     */
    private $systemDate;

    /**
     * Constants for axis values.
     */
    const ERROR_NO_AXIS = "NoAxis";
    const ERROR_WRONG_AXIS = "WrongAxis";

    /**
     * Construct the controller and the service.
     *
     * @param \System\MHC\DiagnoseService $systemMhcDiagnoseService
     */
    public function __construct(DiagnoseService $systemMhcDiagnoseService = null)
    {
        parent::__construct();
        if (null === $systemMhcDiagnoseService) {
            /** @var \System\MHC\DiagnoseService model */
            $systemMhcDiagnoseService = $this->get('medicore.system.diagnose_mhc_service');
        }
        $this->systemMhcDiagnoseService = $systemMhcDiagnoseService;
    }

    /**
     * @SWG\Api(
     *     path="/system/diagnosis/mhc",
     *     @SWG\Operation(
     *         method="GET",
     *         summary="Find MHC Diagnosis for a certain axis.",
     *         notes="Returns MHC Diagnosis",
     *         @SWG\Parameter(
     *             name="action",
     *             description="Call a specific action in the controller",
     *             type="string",
     *             paramType="query",
     *             enum="['tree']",
     *             required=true
     *         ),
     *         @SWG\Parameter(
     *             name="axis",
     *             description="The DSM IV axis on which the diagnosis is applied",
     *             type="integer",
     *             paramType="query",
     *             enum="['1','2','3','4','5']",
     *             required=true
     *         ),
     *         @SWG\Parameter(
     *             name="date",
     *             description="A date on which the diagnosis has to be active",
     *             type="string(format YYYY-MM-DD)",
     *             paramType="query",
     *             required=false
     *         )
     *     )
     * )
     *
     * Get a list of all the diagnosis records in the table for an axis.
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function getListAction()
    {
        $response = new JsonResponse();
        if ($this->getRequest()->query->has('search')) {
            $data = $this->searchDiagnosis();
            $this->getMeta()->setCount(count($data));

            $response->setData(array('data' => $data));
            return $response;
        }

        $action = $this->getRequestedAction();
        switch ($action) {
            case 'tree':
                $data = $this->showDiagnoseTree();
                break;
            case 'default':
                $axis = $this->getValidAxis();
                $date = $this->getValidDate();
                if (!$this->getMeta()->hasError()) {
                    $defaultDiagnosis = $this->systemMhcDiagnoseService->getDefaultDiagnoseByAxis($axis, $date);
                    if (null !== $defaultDiagnosis[0]) {
                        $data = $defaultDiagnosis[0]->toListArray(false);
                    }
                }
                break;
            default:
                $params = array(
                    'field_name' => 'action',
                    'expected' => 'tree, default',
                    'actual' => $action
                );
                $this->getMeta()->addMessage(
                    Meta::STATUS_ERROR,
                    $this->messageHandler->getOne('MG02', $params)
                );
                break;
        }

        $this->getMeta()->setCount(count($data));
        $response->setData(array('data' => $data));

        return $response;
    }

    /**
     * Search Diagnosis.
     *
     * @return array|bool
     */
    private function searchDiagnosis()
    {
        $query = $this->getRequest()->query;

        $criteria = array();
        $criteria['searchString'] = $this->validateSearchString();
        $criteria['axis'] = $this->getValidAxis();
        if ($query->has('date')) {
            if (!$this->isRequired($query->get('date'), 'date')) {
                $criteria['date'] = $this->getValidDate();
            }
        }

        $criteria['date'] = $this->getValidDate();
        $criteria['selectable'] = true;

        $data = array();
        if (!$this->getMeta()->hasError()) {
            $diagnoses = $this->systemMhcDiagnoseService->searchAllBy($criteria);

            if (empty($diagnoses)) {
                $this->addMessage(
                    Meta::STATUS_INFO,
                    "MG103"
                );

                return false;
            }

            return array_map(
                function ($diagnosis) {
                    return $diagnosis->toListArray();
                },
                $data
            );

        }

        return false;
    }

    /**
     * Validate the searchstring.
     *
     * @return bool|string
     */
    private function validateSearchString()
    {
        $query = $this->getRequest()->query;
        $searchString = $query->get('search');
        if (!$this->isRequired($searchString, 'search')) {
            return false;
        }

        return $searchString;
    }

    /**
     * Show the list of system diagnoses in a tree.
     *
     * @return array
     */
    private function showDiagnoseTree()
    {
        $axis = $this->getValidAxis();
        $date = $this->getValidDate();

        if (!$this->getMeta()->hasError()) {
            return $this->systemMhcDiagnoseService->showDiagnoseTreeFor($axis, $date);
        }

        return array();
    }

    /**
     * Check if the posted Axis is valid.
     *
     * @return  int|boolean
     */
    private function getValidAxis()
    {
        $axis = $this->getRequestedAxis();

        if (!$axis) {
            $this->setError(self::ERROR_NO_AXIS);
            return false;
        }

        if (!$this->systemMhcDiagnoseService->validateAxis($axis)) {
            $this->setError(self::ERROR_WRONG_AXIS);
            return false;
        }

        return $axis;
    }

    /**
     * Retrieve the data to validate the searchresults against and check if it is valid.
     *
     * If no date is provided, return current system date.
     *
     * @return  \DateTime|false
     */
    private function getValidDate()
    {
        $date = $this->getRequestedDate();
        if (!$date) {
            return CustomerSettingsService::getSystemDate();
        }

        return $this->validateDate($date, "date");
    }

    /**
     * Set an error message to the Meta.
     *
     * @param string $errorCode
     */
    protected function setError($errorCode)
    {
        switch ($errorCode) {
            case self::ERROR_NO_AXIS:
                $this->addMessage(Meta::STATUS_ERROR, "MG01", array('list_of_fields' => "axis"));
                break;
            case self::ERROR_WRONG_AXIS:
                $this->addMessage(
                    Meta::STATUS_ERROR,
                    "GV9",
                    array('object' => "axis", 'input' => $this->getRequestedAxis())
                );
                break;
        }
    }

    /**
     * Return the action parameter from the Request.
     *
     * @return string|null
     */
    protected function getRequestedAction()
    {
        return $this->getRequest()->query->get('action', null);
    }

    /**
     * Return the axis parameter from the Request.
     *
     * @return  int|bool
     */
    protected function getRequestedAxis()
    {
        return $this->getRequest()->query->get('axis', false);
    }

    /**
     * Return the date parameter from the request.
     *
     * @return  string|bool
     */
    protected function getRequestedDate()
    {
        return $this->getRequest()->query->get('date', false);
    }
}
