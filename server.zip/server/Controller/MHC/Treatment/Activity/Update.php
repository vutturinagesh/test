<?php

namespace Controller\MHC\Treatment\Activity;

use Controller\AbstractController;
use Medical\MHC\TreatmentActivity;
use Medical\MHC\TreatmentActivityService;
use Security\Sanitizer;
use Actinidium\API\Response\Meta;

/**
 * Class Update
 *      All the update method about treatment Activity should go in here
 *
 * @package Controller\MHC\Treatment\Activity
 */
class Update
{
    /**
     * @var \Medical\MHC\TreatmentActivityService
     */
    private $model;

    /* @var \Medical\MHC\TreatmentActivity\EditService */
    private $updateModel;

    /**
     * @var \Controller\AbstractController
     */
    private $parentController;

    /**
     * @var array
     */
    private $data = array();

    /*
     * @var bool
     */
    private $performed;

    /**
     * @var \Medical\Treatment
     */
    private $treatment;
    private $activity;
    private $treatmentActivity;
    private $performer;
    private $minutes;
    private $performedDate;


    /**
     * constructor
     */
    public function __construct(AbstractController $controller)
    {
        $this->parentController = $controller;
        $this->getTreatmentActivityModel();
    }

    /**
     * setParentController
     *      set the parent Controller
     *
     * @param       \Controller\AbstractController $controller
     */
    public function setParentController(AbstractController &$controller)
    {
        $this->parentController = $controller;
       
    }

    private function setTreatment(\Medical\Treatment $treatment)
    {
        $this->treatment = $treatment;
    }

    /**
     * @return \Controller\AbstractController
     */
    public function getParentController()
    {
        return $this->parentController;
    }

    /**
     * getTreatmentActivityModel
     *      Get an object of treatment Activity
     *
     * @return      \Medical\MHC\TreatmentActivityService
     */
    protected function getTreatmentActivityModel()
    {
        if (!$this->model) {
            $this->model = $this->parentController->getModel();
        }
         
        return $this->model;
    }

    /**
     * @param TreatmentActivityService $model
     */
    public function setTreatmentActivityModel(TreatmentActivityService $model)
    {
        $this->model = $model;
    }

    /**
     * getAction
     *      get the current action for the update from the query
     *
     * @return      String
     */
    private function getAction()
    {
        $query  = $this->parentController->getRequest()->query;
        $action = $query->has('action') ? $query->get('action') : 'update';

        return $action;
    }

    /**
     * Run
     *      The entry point to run the update action
     *
     * @param   int     $id
     * @param   Array   $data
     * @return  Array
     * @throws \Exception
     */
    public function run($id, $data)
    {
        $this->data = array();
        $treatmentActivity = null;
        $action = $this->getAction();
        
        if ($id) {
            $treatmentActivity  = $this->getTreatmentActivityObject($id);
        }

        if (strtolower($action) == "linkctgtoactivity") {
            if (array_key_exists("activityId", $data) && (!empty( $data['activityId']))) {
                $this->getCTGActivityObject($data['activityId']);
            } elseif (empty( $data['activityId']) && !array_key_exists("activityId", $data)) {
                $this->getCTGActivityObject($data['activityId']);
            }
        }
        $this->callMethodToUpdate($action, $treatmentActivity, $data);

        if ($treatmentActivity) {
            $errors = $this->getUpdateModel()->isValidForUpdate($treatmentActivity);
            if (!empty($errors)) {
                foreach ($errors as $code) {
                    $this->getParentController()->addMessage(Meta::STATUS_ERROR, $code);
                }
            }
        }

        if ($this->getParentController()->getMeta()->hasError()) {
            return $this->data;
        }

        if ($treatmentActivity && !$this->parentController->getMeta()->hasError()) {
            $this->data = $treatmentActivity->toListArray();
        }
        return $this->data;
    }

    /**
     * @return TreatmentActivity\EditService
     */
    protected function getUpdateModel()
    {
        if (!$this->updateModel) {
            $this->updateModel = new \Medical\MHC\TreatmentActivity\EditService();
        }
        return $this->updateModel;
    }

    /**
     * @param TreatmentActivity\EditService $updateModel
     */
    public function setUpdateModel(\Medical\MHC\TreatmentActivity\EditService $updateModel)
    {
        $this->updateModel = $updateModel;
    }


    /**
     * @param TreatmentActivity $treatmentActivity
     */
    protected function validateTreatmentIsOpen(TreatmentActivity $treatmentActivity)
    {
        return $this->parentController->validateTreatmentIsOpen($treatmentActivity);
    }

    /**
     * @param int $phaseId
     */
    protected function getPhaseObject($phaseId)
    {
        $this->parentController->getPhaseObject($phaseId);
    }

    /**
     * @param int $phaseId
     */
    protected function getCTGActivityObject($activityId)
    {
        $this->parentController->getCTGActivityObject($activityId);
    }

    /**
     * getTreatmentActivityObject
     *      Get the treatment activity object based on the id
     * @param       int $id
     * @return      /Medical/MHC/TreatmentActivity
     */
    protected function getTreatmentActivityObject($id)
    {
        return $this->parentController->getTreatmentActivityObject($id);
    }

    /**
     * callMethodToUpdate
     *      call the Proper method to update
     * @param       String $action
     * @param       \Medical\MHC\TreatmentActivity | null $treatmentActivity
     * @param       Array $data
     */
    private function callMethodToUpdate($action, $treatmentActivity, array $data)
    {
        switch ($action) {
            case 'execute':
                $this->execute($treatmentActivity, $data);
                break;
            case 'updatePhase':
                $result = $this->updatePhase($data);
                if ($result) {
                    $this->data = $result;
                }
                break;
            case 'moveActivities':
                $result = $this->moveActivities($data);
                if ($result) {
                    $this->data = $result;
                }
                break;
            case 'linkCTGtoActivity':
                $this->linkCTGtoActivity($treatmentActivity, $data);
                break;
            case 'update' :
                $this->update($treatmentActivity, $data);
                break;
            default:
                $this->validateAction($action);
                break;
        }
    }

    /**
     * Update
     *  Edit MHC Treatment Activity
     * @param $treatmentActivity
     * @param $data
     *
     * @return bool
     */
    protected function update($treatmentActivity, $data)
    {

        $result = false;

        $this->treatmentActivity = $treatmentActivity;
        $editParams['treatmentActivity'] = $this->treatmentActivity;
        if (array_key_exists('treatmentId', $data)) {
            $this->treatment = $this->parentController->getTreatment($data['treatmentId']);
            $editParams['treatment'] = $this->treatment;
        }

        if (array_key_exists('activityId', $data)) {
            $this->activity = $this->parentController->getActivity($data['activityId']);
            $editParams['activity'] = $this->activity;
        }

        if (array_key_exists('performedDate', $data)) {
            $this->performedDate = $this->parentController->validateDate($data['performedDate'], 'performedDate');
            $editParams['performedDate'] = $this->performedDate;
            if (!$this->parentController->getMeta()->hasError()) {
                $treatment = $treatmentActivity->getTreatment();
                $this->parentController->validatePerformedDateForTreatment($treatment, $this->performedDate);

            }
        }

        if (array_key_exists('performerId', $data)) {
            $this->performer = $this->parentController->validateSpecialist($data['performerId']);
            $editParams['performer'] = $this->performer;
        }

        if (array_key_exists('performed', $data)) {
            $this->performed = $this->parentController->validateBoolean($data["performed"], "performed");
            $editParams['performed'] = $this->performed;
        }

        $this->minutes = $this->parentController->getMinutes($data);
        if( !empty($this->minutes)) {
            $editParams['minutes'] = $this->minutes;
        }

        if ($this->treatment && !$this->parentController->getMeta()->hasError()) {
            $this->parentController->setPerformedDate($treatmentActivity->getPerformedDate());
            $this->setTreatment($this->treatment);
            $this->validateMHCTreatmentActivityForMove($treatmentActivity);
        }
        if ($this->performer || $this->performedDate) {
            try {
                $performer = $this->performer ? $this->performer : $this->treatmentActivity->getSpecialist();
                $performedDate = $this->performedDate ? $this->performedDate : $this->treatmentActivity->getPerformanceDate();
            } catch (\Exception $e) {}

            if ($performer && $performedDate) {
                $this->parentController->setSpecialist($performer);
                $this->parentController->setExecutionDate($performedDate);
                $this->parentController->checkPerformerValidity();
            }

        }

        if (!$this->parentController->getMeta()->hasError()) {
            $result = $this->model->edit($editParams);
        }

        return $result;
    }

    /**
     * Prepare array for Update
     *
     * @return array
     */
    private function prepareParametersForUpdate()
    {
        $data = array();

        $data['treatmentActivity'] = $this->treatmentActivity;
        $data['treatment'] = $this->treatment;
        $data['activity'] = $this->activity;
        $data['performedDate'] = $this->performedDate;
        $data['performed'] = $this->performed;
        $data['performer'] = $this->performer;
        $data['minutes'] = $this->minutes;

        return $data;

    }

    /**
     * moveActivities
     *      move one or more activities to another treatment
     *
     * @param array $data
     *
     * @return bool
     */

    protected function moveActivities($data)
    {
        $result = array();
        $this->treatment = $this->parentController->getTreatment($data['treatmentId']);
        $treatmentActivityIds = $data['id'];

        $this->validateActivities($treatmentActivityIds);

        if (!$this->parentController->getMeta()->hasError()) {
            foreach ($treatmentActivityIds as $id) {
                $moved = $this->moveActivity($id);
                $result[$id] = ($moved == true)
                    ? $this->getTreatmentActivityObject($id)->toArray()
                    : $moved;
            }
            $this->parentController->getMeta()->setCount(count($treatmentActivityIds));
        }
        return $result;
    }

    private function validateActivities($treatmentActivityIds)
    {
        foreach ($treatmentActivityIds as $treatmentActivityId) {
            $this->getTreatmentActivityObject($treatmentActivityId);
        }
    }

    /**
     * moveActivity
     *      Validate and move a single activity
     *
     * @param $id
     *
     * @return bool
     */
    protected function moveActivity($id)
    {
        $treatmentActivity = $this->getTreatmentActivityObject($id);
        $this->validateMHCTreatmentActivityForMove($treatmentActivity);

        if (!$this->parentController->getMeta()->hasError()) {
            return $this->model->move($treatmentActivity, $this->treatment);
        }

        return false;
    }

    /**
     * validateMHCTreatmentActivityForMove
     *      Validates the other treatment to move
     * @param \Medical\MHC\TreatmentActivity $treatmentActivity
     *
     * @return bool
     */
    protected function validateMHCTreatmentActivityForMove(\Medical\MHC\TreatmentActivity $treatmentActivity)
    {
        $validateObject = new \Validation\ValidateMHCTreatmentActivityForMove();
        $validateObject->setMHCTreatmentActivity($treatmentActivity);
        $validateObject->setNewTreatment($this->treatment);
        $errors = $validateObject->validate();

        if ($errors !==  true) {
            foreach ($errors as $error => $value) {
                switch ($error) {
                    case 'isCancelledOrProcessed':
                        $this->parentController->getMeta()->addMessage(
                            Meta::STATUS_ERROR,
                            $this->parentController->getMessageHandler()->getOne(
                                'M146',
                                array(
                                    'object' => 'TreatmentActivity',
                                    'input' => $treatmentActivity->getId()
                                )
                            )
                        );
                        $this->parentController->getMeta()->addMessage(
                            Meta::STATUS_ERROR,
                            $this->parentController->getMessageHandler()->getOne(
                                'M134',
                                array(
                                    'object' => 'TreatmentActivity',
                                    'input' => $treatmentActivity->getId()
                                )
                            )
                        );
                        break;
                    case 'notOpenedOnPerformedDate':
                        $this->parentController->getMeta()->addMessage(
                            Meta::STATUS_ERROR,
                            $this->parentController->getMessageHandler()->getOne(
                                'M008',
                                array(
                                    'object' => 'TreatmentActivity',
                                    'input' => $treatmentActivity->getId()
                                )
                            )
                        );
                        break;
                    case 'notSameType':
                        $this->parentController->getMeta()->addMessage(
                            Meta::STATUS_ERROR,
                            $this->parentController->getMessageHandler()->getOne(
                                'M149',
                                array(
                                    'object' => 'TreatmentActivity',
                                    'input' => $treatmentActivity->getId()
                                )
                            )
                        );
                        break;
                    default:
                        break;
                }
            }
        }
        return $errors;
    }

    /**
     * updatePhase
     * @param array $data
     * @return bool | Array
     */
    public function updatePhase($data)
    {
        $result = array();
        $phaseEntity = $this->parentController->getPhaseObject($data['phaseId']);

        if (!$this->parentController->getMeta()->hasError()) {
            if (empty($data['id'])) {
                $this->parentController->addMessage(
                    Meta::STATUS_ERROR,
                    'MG01',
                    array('list_of_fields' => 'id[]')
                );
            } else {
                $treatmentActivityIds = $data['id'];
                if (!empty($treatmentActivityIds)) {
                    foreach ($treatmentActivityIds as $id) {
                        $moved = $this->moveToPhase($id, $phaseEntity);
                        $result[$id] = ($moved == true)
                            ? $this->getTreatmentActivityObject($id)->toArray()
                            : $moved;
                    }
                    $this->parentController->getMeta()->setCount(count($treatmentActivityIds));
                }
            }
            return $result;
        }
        return false;
    }

    /**
     *
     * @param int $id treatment activity id
     * @param \Medical\Activity\Phase $phase
     * @return boolean
     */
    private function moveToPhase($id, \Medical\Activity\Phase $phase)
    {
        $treatmentActivity = $this->getTreatmentActivityObject($id);

        if ($treatmentActivity instanceof \Medical\MHC\TreatmentActivity) {
            return $this->getTreatmentActivityModel()->updatePhase($treatmentActivity, $phase);
        }
        return false;
    }

    /**
     * linkCTGtoActivity
     *      Add a CTG to an activity
     *
     * @param \Medical\MHC\TreatmentActivity $treatmentActivity
     * @param $data
     *
     * @return bool
     */
    public function linkCTGtoActivity(\Medical\MHC\TreatmentActivity $treatmentActivity, $data)
    {
        $result = false;
        $ctgActivityEntity = null;

        if (array_key_exists("activityId", $data) && (!empty($data['activityId']))) {
            $ctgActivityEntity = $this->parentController->getCTGActivityObject($data['activityId']);
        }
        if (!$this->parentController->getMeta()->hasError()) {
            $result = $this->model->linkCTGtoActivity($treatmentActivity, $ctgActivityEntity);
        }
        return $result;
    }

    /**
     * execute
     *      Execute an activity
     *
     * @param   \Medical\MHC\TreatmentActivity $treatmentActivity
     * @param   Array   $data
     */
    protected function execute($treatmentActivity, $data)
    {
        $performed = Sanitizer::boolean($data['performed']);
        $this->model->executedMHC($treatmentActivity, $performed);
    }

    /**
     * Validates default action
     *
     * @param $value
     */
    private function validateAction($value)
    {
        if ($this->parentController->isRequired($value, 'action')) {
            $this->parentController->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->parentController->getMessageHandler()->add(
                    'MG101',
                    \Message\MessageHandler::BLOCKING,
                    array(
                        'input' => $value,
                        'field_name' => "action",
                    )
                )
            );
        }
    }
}
