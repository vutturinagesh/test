<?php
/**
 * Created by dev.
 * User: hank.kam
 * Date: 14-8-13
 * 
 */

namespace Controller\MHC\Treatment\Activity\OtherProduct;

use Actinidium\API\Response\Meta;
use Medical\MHC\OtherProductActivityService;
use Medical\Treatment;
use Medical\MHC\TreatmentActivity;
use Medical\MHC\TreatmentActivityService;
use Medical\MHC\TreatmentOtherProductActivityService;
use Medical\MHC\OtherProductActivity;
use Generic\Specialism;
use Generic\Employee;

class Create
{
    /**
     * @var OtherProductActivity
     */
    private $model;

    /**
     * @var TreatmentOtherProductActivityService;
     */
    private $treatmentOtherProductActivityModel;

    /**
     * @var \Controller\AbstractController
     */
    private $parentController;

    /***
     * @var Treatment
     */
    private $treatment;

    /**
     * @var OtherProductActivity
     */
    private $otherProductActivity;

    /**
     * @var \Generic\Employee
     */
    private $specialist;

    /**
     * @var \Generic\EmployeeService
     */
    private $employeeModel;

    /**
     * @var \DateTime
     */
    private $date;

    /**
     * @var array
     */
    private $data = array();

    /**
     * constructor
     */
    public function __construct(\Controller\AbstractController $controller)
    {
        $this->parentController = $controller;
        $this->model = $this->getModel();
        $this->treatmentOtherProductActivityModel = $this->getTreatmentOtherProductActivityModel();
    }

    /**
     * @param array $data
     * @return array
     */
    public function run($data)
    {
        $this->data = array();
        $this->createObjects($data);
        if (!$this->parentController->getMeta()->hasError()) {
            $this->data = $this->save();
        }
        return $this->data;
    }

    /**
     * @param array $data
     */
    protected function createObjects($data)
    {
        $this->data = array();
        $this->createTreatmentObject($data['treatmentId']);

        $this->createDateObject($data['date']);
        $this->createDayActivityObject($data['otherProductActivityId']);
        $this->validateOtherProductIsValidOnDate();

        $this->createSpecialistObject($data['specialistId']);

        $this->validateSpecialistOnDate();

        $this->validateSpecialistSpecialty();
    }

    /**
     * Validate otherProduct is valid on date
     */
    private function validateOtherProductIsValidOnDate()
    {
        if ($this->otherProductActivity instanceof otherProductActivity && $this->date instanceof \DateTime) {
            if ((!($this->date >= $this->otherProductActivity->getStartDate()) &&
                    ($this->date <= $this->otherProductActivity->getEnddate())
                )
                || ($this->date >= $this->otherProductActivity->getStartDate() &&
                    !($this->date <= $this->otherProductActivity->getEnddate()))
            ) {
                    $this->parentController->getMeta()->addMessage(
                        Meta::STATUS_ERROR,
                        $this->parentController->getMessageHandler()->getOne(
                            "M147",
                            array(
                                "object" => "OtherProductActivity",
                                "input" => $this->date->format(\Date\Format::DATE)
                            )
                        )
                    );
            }
        }
    }

    /**
     * Validate specialist on date
     */
    private function validateSpecialistOnDate()
    {
        if ($this->date instanceof \DateTime && $this->specialist instanceof Employee) {
            if (!$this->employeeModel->validateSpecialistActiveOnDate($this->specialist, $this->date)) {
                $this->parentController->getMeta()->addMessage(
                    Meta::STATUS_ERROR,
                    $this->parentController->getMessageHandler()->getOne("M144")
                );
            }
        }
    }

    /**
     * Validate the specialty of the specialist
     */
    private function validateSpecialistSpecialty()
    {
        if ($this->specialist instanceof Employee) {
            $specialty = $this->specialist->getSpecialism();
            if (!$specialty instanceof Specialism) {
                $this->parentController->getMeta()->addMessage(
                    Meta::STATUS_ERROR,
                    $this->parentController->getMessageHandler()->getOne("EMPM100")
                );
            }
        }
    }

    /**
     * @param integer $otherProductActivityId
     */
    private function createDayActivityObject($otherProductActivityId)
    {
        $this->otherProductActivity = $this->parentController->createEntity(
            $otherProductActivityId,
            "otherProductActivityId",
            $this->getModel(),
            "Medical\\MHC\\OtherProductActivity"
        );
    }

    /**
     * @param integer $specialistId
     */
    private function createSpecialistObject($specialistId)
    {
        $this->specialist = null;
        $this->employeeModel = new \Generic\EmployeeService();
        if (mb_strlen($specialistId)) {
            $this->specialist = $this->parentController->createEntity(
                $specialistId,
                "specialistId",
                $this->employeeModel,
                "Generic\\Employee"
            );
        } else {
            if ($this->treatment) {
                $this->specialist = $this->employeeModel->getDefaultPerformer($this->treatment);
            }
        }
    }

    /**
     * @param string $dateString
     */
    private function createDateObject($dateString)
    {
        $this->date = $this->parentController->validateDate($dateString, "date");
    }

    /**
     * @return array
     */
    protected function save()
    {
        $treatmentActivity = $this->treatmentOtherProductActivityModel->create(
            $this->treatment,
            $this->date,
            $this->otherProductActivity,
            $this->specialist
        );
        return $treatmentActivity->toArray();
    }

    /**
     * @param int $treatmentId
     */
    private function createTreatmentObject($treatmentId)
    {
        $this->treatment = $this->parentController->getTreatment($treatmentId);
    }

    /**
     * @return TreatmentOtherProductActivityService TreatmentDayActivityService
     */
    protected function getTreatmentOtherProductActivityModel()
    {
        if (!$this->treatmentOtherProductActivityModel) {
            $this->treatmentOtherProductActivityModel = new TreatmentOtherProductActivityService();
        }
        return $this->treatmentOtherProductActivityModel;
    }

    /**
     * @return OtherProductActivityService
     */
    protected function getModel()
    {
        if (!$this->model) {
            $this->model = new OtherProductActivityService();
        }
        return $this->model;
    }
}
