<?php
/**
 * Created by Treatment Registration Rebuild.
 * User: eddy.de.boer
 * Date: 15-7-13

 */

namespace Controller\MHC\Treatment\Activity;


use Actinidium\API\Response\Meta;
use Controller\AbstractController;
use Medical\MHC\TreatmentOtherProductActivity;
use Medical\MHC\TreatmentOtherProductActivityService;
use Medical\Treatment;
use Medical\TreatmentService;
use Symfony\Component\HttpFoundation\Request;

class OtherProductController extends AbstractController
{

    private $treatment;
    private $treatmentModel;
    private $model;
    private $orderBy;
    private $treatmentActivities;

    /** @var  TreatmentOtherProductActivity */
    private $treatmentOtherProductActivity;

    /**
     * @param int $id
     * @return array
     */
    public function getAction($id)
    {
        $treatmentActivity = $this->getTreatmentOtherProductActivityObject($id);
        if (!$this->getMeta()->hasError()) {
            return $treatmentActivity->toArray();
        }
        return null;
    }

    /**
     * @return array
     */
    public function getListAction()
    {
        $this->data = array();
        $query = $this->getRequest()->query;
        if ($query->has("treatmentId")) {
            $this->getTreatment($query->get("treatmentId"));
            if (!$this->getMeta()->hasError()) {
                $treatmentActivities = $this->findTreatmentActivitiesByTreatment(
                    $this->getTreatment($query->get("treatmentId"))
                );
            }
        } else {
            $treatmentActivities = $this->findTreatmentActivities();
        }
        if (!empty($treatmentActivities)) {
            $this->data = $this->prepareListForGUI($treatmentActivities);
            $this->getMeta()->setCount(count($this->data));
        }
        return $this->data;
    }

    /**
     * @param mixed $id
     * @return array
     */
    public function deleteAction($id)
    {
        $treatmentActivity = $this->getTreatmentOtherProductActivityObject($id);

        if ($treatmentActivity) {
            $this->delete($treatmentActivity);
        }

        return $this->data;
    }

    /**
     * @return array
     */
    public function deleteListAction()
    {
        $this->data = array();
        $request = $this->getRequest()->request;
        $ids = $request->get("id");

        if (isset($ids) && !empty($ids)) {
            foreach ($ids as $id) {
                $this->deleteAction($id);
            }
        } else {
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne("MG01", array('list_of_fields' => 'ids'))
            );
        }

        return $this->data;
    }

    /**
     * @param array $data
     * @return aray
     */
    public function createAction($data)
    {
        $this->data = array();
        $createController = $this->getNewCreateController();
        $this->data = $createController->run($data);
        return $this->data;
    }

    /**
     * @param TreatmentOtherProductActivity $treatmentActivity
     */
    protected function delete(TreatmentOtherProductActivity $treatmentActivity)
    {
        try {
            $this->getModel()->delete($treatmentActivity);
        } catch (\Exception $e) {
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, $e->getMessage());
        }
    }

    /**
     * @param TreatmentOtherProductActivityService $model
     */
    public function setModel(TreatmentOtherProductActivityService $model)
    {
        $this->model = $model;
    }

    /**
     * @param $treatmentId
     * @return Treatment
     */
    public function getTreatment($treatmentId)
    {
        if (!$this->treatment) {
            $this->treatment = $this->createEntity(
                $treatmentId,
                "treatmentId",
                $this->getTreatmentModel(),
                "Medical\\Treatment"
            );
        }
        return $this->treatment;
    }

    /**
     * @param \Medical\Treatment $treatment
     * @param Treatment $treatment
     */
    public function setTreatment(Treatment $treatment)
    {
        if ($treatment instanceof Treatment) {
            $this->treatment = $treatment;
        }
    }

    /**
     * @return TreatmentService
     */
    public function getTreatmentModel()
    {
        if (!$this->treatmentModel) {
            $this->treatmentModel = new TreatmentService();
        }
        return $this->treatmentModel;
    }

    /**
     * format: array($key => "ASC|DESC");
     * @param array $orderBy
     * @param array $orderBy
     */
    public function setOrderBy(array $orderBy)
    {
        $this->orderBy = $orderBy;
    }

    /**
     * @return array
     */
    public function getOrderBy()
    {
        if (empty($orderBy)) {
            $this->orderBy = array("id" => "DESC");
        }
        return $this->orderBy;
    }

    public function setTreatmentActivities(array $treatmentActivities)
    {
        if (!empty($treatmentActivities)) {
            foreach ($treatmentActivities as $treatmentActivity) {
                if ($treatmentActivity instanceof TreatmentOtherProductActivity) {
                    $this->treatmentActivities[] = $treatmentActivity;
                }
            }
        }
    }

    /**
     * Returns TreatmentOtherProductActivities filtered by $treatment
     * @param Treatment $treatment
     * @return array
     */
    protected function findTreatmentActivitiesByTreatment(Treatment $treatment)
    {
        $criteria = array('treatment' => $treatment);
        return $this->findTreatmentActivitiesFromModelByCriteria($criteria);
    }

    /**
     * Returns all TreatmentOtherProductActivities
     * @return array
     */
    protected function findTreatmentActivities()
    {
        $criteria = array();
        return $this->findTreatmentActivitiesFromModelByCriteria($criteria);
    }

    /**
     * @param $criteria
     * @return array
     */
    protected function findTreatmentActivitiesFromModelByCriteria($criteria)
    {
        if (empty($this->treatmentActivities)) {
            $this->treatmentActivities = $this->getModel()->findAllByCriteria($criteria, $this->getOrderBy());
        }
        return $this->treatmentActivities;
    }

    /**
     * @return TreatmentOtherProductActivityService
     */
    protected function getModel()
    {
        if (!$this->model) {
            $this->model = new \Medical\MHC\TreatmentOtherProductActivityService();
        }
        return $this->model;
    }

    /**
     * @return \Controller\MHC\Treatment\Activity\OtherProduct\Create
     */
    private function getNewCreateController()
    {
        return  new \Controller\MHC\Treatment\Activity\OtherProduct\Create($this);
    }


    /**
     * @param array $treatmentActivities
     * @internal param \Medical\Treatment $treatment
     * @return mixed
     */
    protected function prepareListForGUI(array $treatmentActivities)
    {
        $data = array();
        if (!empty($treatmentActivities)) {
            foreach ($treatmentActivities as $treatmentActivity) {
                /** @var $treatmentActivity TreatmentOtherProductActivity */
                if ($treatmentActivity instanceof TreatmentOtherProductActivity) {
                    $data[] = $treatmentActivity->toListArray();
                }
            }
        }
        return $data;
    }

    /**
     * Creates one if it did not exist already. If it did not succeed, returns null.
     * @param $id
     * @return TreatmentOtherProductActivity
     */
    protected function getTreatmentOtherProductActivityObject($id)
    {
        return $this->createEntity($id, "id", $this->getModel(), "Medical\\MHC\\TreatmentOtherProductActivity");
    }
}
