<?php

namespace Controller\MHC\Treatment;

use Actinidium\API\Response\Meta;
use Controller\AbstractController;
use Generic\Authorizer;
use Medical\Treatment;
use Medical\TreatmentService as TreatmentService;
use Medical\Validations\ValidateTrv1;
use Medical\MHC\Diagnose as MhcDiagnose;
use Medical\MHC\DiagnoseService;
use Security\Sanitizer;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use System\MHC\Diagnose as SystemDiagnose;
use System\MHC\DiagnoseService as SystemDiagnoseService;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/treatment",
 *     basePath="/api/v2"
 * )
 */
class DiagnosisController extends AbstractController
{
    /**
     * @var \Medical\MHC\DiagnoseService 
     */
    private $diagnoseService;

    /**
     * @var \Medical\Treatment
     */
    private $treatment;

    /**
     * @var \Medical\TreatmentService
     */
    private $treatmentService;

    /**
     * @var \System\MHC\DiagnoseService
     */
    private $systemDiagnosisService;
    
    /**
     * @var \System\MHC\Diagnose
     */
    private $systemDiagnosis;
    
    /**
     * @var \Medical\MHC\Diagnose
     */
    private $diagnosis;

    /**
     * @var \Generic\Authorizer
     */
    private $authorizer;

    /**
     * Instantiate the controller with all its dependencies.
     *
     * If some are not injected fetch them from the container.
     *
     * @param \Medical\TreatmentService    $treatmentService
     * @param \System\MHC\DiagnoseService  $systemDiagnosisService
     * @param \Medical\MHC\DiagnoseService $diagnoseService
     * @param \Generic\Authorizer          $authorizer
     */
    public function __construct(
        TreatmentService $treatmentService = null,
        SystemDiagnoseService $systemDiagnosisService = null,
        DiagnoseService $diagnoseService = null,
        Authorizer $authorizer = null
    ) {
        parent::__construct();

        if (null === $treatmentService) {
            $treatmentService = $this->get('medicore.medical.treatment_service');
        }

        if (null === $systemDiagnosisService) {
            $systemDiagnosisService = $this->get('medicore.system.diagnose_mhc_service');
        }

        if (null === $diagnoseService) {
            $diagnoseService = $this->get('medicore.medical.treatment.mhc.diagnose_service');
        }

        if (null === $authorizer) {
            $this->authorizer = $this->get('medicore.generic.authorizer');
        }

        $this->treatmentService = $treatmentService;
        $this->systemDiagnosisService = $systemDiagnosisService;
        $this->diagnoseService = $diagnoseService;
    }

    /**
     *  Validates the input and calls the service to create the Diagnosis.
     *
     * @SWG\Api(
     *   path="/medical/treatment/diagnosis/mhc",
     *   description="Create a diagnose from the passed data.",
     *       @SWG\Operation(
     *           method="POST",
     *           summary="Create a diagnose from the passed data.",
     *           notes="If errors occur error messages will be send to the frontend for each error found.",
     *           @SWG\Parameter(
     *               name="body",
     *               description="Diagnose object, see toArray as reference.",
     *               required=true,
     *               type="\Medical\MHC\Diagnose",
     *               paramType="body",
     *               allowMultiple=false
     *           )
     *       )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function createAction(Request $request)
    {
        $response = new JsonResponse();

        $data = json_decode($request->getContent(), true);
        $this->treatment = $this->validateTreatment($data["treatmentId"]);
        $this->checkUserTreatmentAccessMode($this->treatment);
        $this->systemDiagnosis = $this->validateSystemDiagnose($data["diagnosisId"]);

        if (!$this->hasError()) {
            $this->validateRequestData($data);

            if (null !== $this->treatment && null !== $this->systemDiagnosis) {
                $this->checkTreatmentIsOpen($this->treatment);
                $errors = $this->diagnoseService->validateDiagnosis($this->systemDiagnosis, $this->treatment);
                if (!empty($errors)) {
                    foreach ($errors as $error) {
                        $params = array();
                        if (array_key_exists('params', $error)) {
                            $params = $error['params'];
                        }
                        $this->addMessage($error["status"], $error["code"], $params);
                    }
                }
            }
        }

        if ($this->hasError()) {
            $response->setData(array("data" => $data));
            return $response;
        }

        if ($this->diagnoseService->isDiagnoseDuplicate($this->treatment, $this->systemDiagnosis)) {
            $this->addMessage(Meta::STATUS_ERROR, 'M523', array("id" => $this->systemDiagnosis->getId()));

            $response->setData(array("data" => $data));
            return $response;
        }

        $treatmentDiagnosis = $this->diagnoseService->create(
            array(
                "treatment"  => $this->treatment,
                "diagnose"   => $this->systemDiagnosis,
                "symptomsOf" => $this->getSymptomsOf($data),
                "remark"     => isset($data['remark']) ? $data['remark'] : '',
                "axis"       => $this->systemDiagnosis->getAxis()
            )
        );

        if ($treatmentDiagnosis instanceof MhcDiagnose) {
            $data = $treatmentDiagnosis->toArray();
        }

        $response->setData(array('data' => $data));
        return $response;
    }

    /**
     * Get a list of all the diagnosis records for a certain treatment
     *
     * @SWG\Api(
     *   path="/medical/treatment/diagnosis/mhc",
     *   description="Retrieve all the diagnosis object for a MHC treatment",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Retrieve all the diagnosis objects for a MHC Treatment.",
     *           notes="Excludes the primary diagnose!",
     *           @SWG\Parameter(
     *              name="treatmentId",
     *              description="The id of the treatment for which to fetch the diagnosis",
     *              type="integer",
     *              paramType="query",
     *              required=true
     *           )
     *       )
     * )
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function getListAction()
    {
        $data = array();
        $query = $this->getRequest()->query;

        if ($query->has('treatmentId')) {
            $treatment = $this->validateTreatment($query->get('treatmentId'));

            $this->checkUserTreatmentAccessMode($treatment, false);

            if (!$this->getMeta()->hasError()) {
                $diagnoses = $this->treatmentService->viewMHCDiagnose($treatment);

                $data = $this->prepareMHCDiagnoseForGUI($diagnoses);
                $this->getMeta()->setCount(count($data));
            }
        }

        $response = new JsonResponse();
        $response->setData(array('data' => $data));

        return $response;
    }

    /**
     * Deletes a diagnose from axis and add geen diagnose if it is last one.
     *
     * @SWG\Api(
     *   path="/medical/treatment/diagnosis/mhc",
     *   description="Delete the diagnose with the passed id from its axis.",
     *       @SWG\Operation(
     *           method="DELETE",
     *           summary="Delete the diagnose with the passed id from its axis.",
     *           notes="If all the diagnosis are deleted, the default diagnose will be added.",
     *           @SWG\Parameter(
     *              name="id",
     *              description="The id of the diagnose to delete from the treatment",
     *              type="integer",
     *              paramType="query",
     *              required=true
     *           )
     *       )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function deleteAction(Request $request)
    {
        $id = $request->query->get('id');
        $data = json_decode($request->getContent(), true);

        $treatmentDiagnose = $this->createEntity($id, "id", $this->diagnoseService, "Medical\\MHC\\Diagnose");

        if (!$this->getMeta()->hasError()) {
            $treatment = $treatmentDiagnose->getMainTreatment();
            $this->checkUserTreatmentAccessMode($treatment);
            $this->validateTreatmentIsOpen($treatment);
        }

        if (!$this->getMeta()->hasError()) {
            $result = $this->diagnoseService->delete($treatmentDiagnose);

            if ($result) {
                $this->getMeta()->setCount(1);
                $data = array($id => true);
            }
        }

        $response = new JsonResponse();
        $response->setData(array('data' => $data));

        return $response;
    }

    /**
     * Update the diagnose with the passed id, use the passed data as update values.
     *
     * @SWG\Api(
     *   path="/medical/treatment/diagnosis/mhc",
     *   description="Update the diagnose with the passed id with the data in the request.",
     *       @SWG\Operation(
     *           method="PUT",
     *           summary="Update the diagnose with the passed id with the data in the request.",
     *           notes="",
     *           @SWG\Parameter(
     *              name="id",
     *              description="The id of the diagnose to update",
     *              type="integer",
     *              paramType="query",
     *              required=true
     *           ),
     *           @SWG\Parameter(
     *               name="body",
     *               description="Updated Diagnose object, see toArray as reference.",
     *               required=true,
     *               type="\Medical\MHC\Diagnose",
     *               paramType="body",
     *               allowMultiple=false
     *           )
     *       )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function updateAction(Request $request)
    {
        $result = array();
        $query = $this->getRequest()->query;
        $id = $query->get('id');
        $data = json_decode($request->getContent(), true);

        $this->diagnosis = $this->validateDiagnose($id);

        if ($this->diagnosis instanceof MhcDiagnose) {
            $treatment = $this->diagnosis->getMainTreatment();
            $this->checkUserTreatmentAccessMode($treatment);
        }

        if (!$this->getMeta()->hasError()) {
            if (!$query->has('action')) {
                $result = $this->edit($id, $data);
            }
        }

        $response = new JsonResponse();
        $response->setData(array("data" => $result));

        return $response;
    }

    /**
     * Validate if the treatment is open.
     *
     * @param Treatment $treatment
     */
    protected function validateTreatmentIsOpen(Treatment $treatment)
    {
        if (! $this->treatmentService->isTreatmentOpen($treatment)) {
            $this->addMessage(Meta::STATUS_ERROR, 'M146', array("id" => $treatment->getId()));
        }
    }

    /**
     * Edit the Diagnoses for the MHC treatment.
     *
     * @param  string $id
     * @param  array  $data
     *
     * @return array
     */
    public function edit($id, array $data)
    {
        $this->diagnosis = $this->validateDiagnose($id);

        $params = array();
        if ($this->diagnosis instanceof MhcDiagnose) {
            $this->checkTreatmentIsOpen($this->diagnosis->getMainTreatment());
            $this->systemDiagnosis = $this->diagnosis->getSystemDiagnose();
            $params = $this->validateRequestData($data);
        }

        if (!$this->getMeta()->hasError()) {
            $result = $this->diagnoseService->edit($this->diagnosis, $params);
            if ($result) {
                $data = $this->diagnosis->toArray();
            }
        }

        return $data;
    }

    /**
     * Validate the data which is passed to the controller.
     *
     * @param array $data
     *
     * @return array
     */
    protected function validateRequestData(array $data = array())
    {
        $params = array();
        if (array_key_exists('diagnose', $data)  &&
            array_key_exists('id', $data['diagnose']) &&
            $this->systemDiagnosis->getId() !== $data['diagnose']['id']) {
            $params['diagnose'] = $this->validateSystemDiagnose($data['diagnose']['id']);
        }

        if (isset($data['date'])) {
            $params['date'] = $this->validateDiagnosisDate($data['date']);
        }

        if (isset($data['symptomsOf'])) {
            $params['symptomsOf'] = $this->validateSymptomsOf($this->systemDiagnosis, $data['symptomsOf']);
        }

        if (isset($data['remark'])) {
            $params['remark'] = $this->validateRemark($data['remark']);
        }

        return $params;
    }

    /**
     * Checks whether the user has write/access premissions for the treatment.
     *
     * @param \Medical\Treatment $treatment
     * @param boolean            $writeAccess
     */
    protected function checkUserTreatmentAccessMode(Treatment $treatment, $writeAccess = true)
    {
        if (!$this->hasError()) {
            if ($writeAccess) {
                $allowed = $this->authorizer->isTreatmentWritable($treatment);
            } else {
                $allowed = $this->authorizer->isTreatmentAccessable($treatment);
            }

            if (!$allowed) {
                $this->getMeta()->addMessage(
                    Meta::STATUS_ERROR,
                    $this->messageHandler->getOne('UR3')
                );
            }
        }
    }

    /**
     * Validate the passed diagnose.
     *
     * @param integer id
     *
     * @return \Medical\MHC\Diagnose|null
     */
    protected function validateDiagnose($id)
    {
        return $this->createEntity($id, "id", $this->diagnoseService, "Medical\\MHC\\Diagnose");
    }

    /**
     * Validate the id of the passed system diagnose.
     *
     * @param integer id
     *
     * @return \System\MHC\Diagnose|null
     */
    protected function validateSystemDiagnose($id)
    {
        return $this->createEntity($id, "id", $this->systemDiagnosisService, "System\\MHC\\Diagnose");
    }

    /**
     * Validate if the treatment is still open.
     * 
     * @param \Medical\Treatment $treatment
     */
    protected function checkTreatmentIsOpen(Treatment $treatment)
    {
        $validator = new ValidateTrv1();
        $validator->getProperties()->setTreatment($treatment);

        if (!$validator->validate()) {
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne('M146')
            );
        }
    }

    /**
     * Validate the remark field.
     *
     * @param string $remark
     * @param int    $limit
     *
     * @access private Access lowered due to unit testing.
     *
     * @return null|string
     */
    protected function validateRemark($remark, $limit = 255)
    {
        if (!Sanitizer::isStringLengthIsValid($remark, $limit)) {
            $params = array(
                'field_name' => "remark",
                'expected' => "Maximum of ".$limit." characters",
                'actual' => $remark,
                'max_length' => $limit
            );

            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne('MG100', $params)
            );
        } else {
              return $remark;
        }
    }

    /**
     * Validate the input for the symptoms of field.
     *
     * @param \System\MHC\Diagnose $diagnose
     * @param boolean              $symptomsOf
     *
     * @access private Access lowered due to unit testing.
     *
     * @return boolean
     */
    protected function validateSymptomsOf(SystemDiagnose $diagnose, $symptomsOf)
    {
        if (!Sanitizer::isBoolean($symptomsOf)) {
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne(
                    'MG101',
                    array('field_name' => "symptomsOf", 'input' => $symptomsOf)
                )
            );
        } else {
            $symptomsOf = Sanitizer::boolean($symptomsOf);
            if ($diagnose) {
                return $diagnose->getValidSymptomsOf($symptomsOf);
            }
        }
    }

    /**
     * Validate if the diagnose date passed is actually a valid date.
     *
     * @param string $date
     *
     * @access private Access lowered due to unit testing.
     *
     * @return \DateTime|null
     */
    protected function validateDiagnosisDate($date)
    {
        return $this->validateDate($date, "date");
    }

    /**
     * Get the symptomsOff flag from the data and validate if it is valid.
     *
     * @param array $data
     *
     * @return bool
     */
    protected function getSymptomsOf(array $data)
    {
        if (!array_key_exists("symptomsOf", $data)) {
            return false;
        }

        $symptomsOf = Sanitizer::boolean($data["symptomsOf"]);
        if ($symptomsOf) {
            $symptomsOf = $this->systemDiagnosis->getValidSymptomsOf($this->systemDiagnosis, $symptomsOf);
        }

        return $symptomsOf;
    }

    /**
     * Validate if the treatmentId passed to this function is an existing treatment.
     *
     * @param string $treatmentId
     *
     * @return \Medical\Treatment|null
     */
    protected function validateTreatment($treatmentId)
    {
        return $this->createEntity($treatmentId, "id", $this->treatmentService, "Medical\\Treatment");
    }

    /**
     * Hydrate the found diagnosis objects to an array.
     *
     * @param array $diagnoses
     *
     * @return array
     */
    private function prepareMHCDiagnoseForGUI(array $diagnoses)
    {
        $data = array();

        $data['axisI']   = $this->prepareAxisForGUI($diagnoses['axisI']);
        $data['axisII']  = $this->prepareAxisForGUI($diagnoses['axisII']);
        $data['axisIII'] = $this->prepareAxisForGUI($diagnoses['axisIII']);
        $data['axisIV']  = $this->prepareAxisForGUI($diagnoses['axisIV']);
        $data['axisV']   = $this->prepareAxisForGUI($diagnoses['axisV']);

        return $data;
    }

    /**
     * Hydrate a single axis with al its diagnosis objects to an array.
     *
     * @param array $axisDiagnoses
     *
     * @return array
     */
    protected function prepareAxisForGUI(array $axisDiagnoses)
    {
        $diagnoseArray = array();
        foreach ($axisDiagnoses as $axisDiagnose) {
            $diagnoseArray[] = $axisDiagnose->toListArray();
        }

        return $diagnoseArray;
    }
}
