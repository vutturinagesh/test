<?php

namespace Controller;

use Actinidium\API\Response\Meta;
use Controller\Treatment\Create;
use Controller\Treatment\Update;
use Date\Format as DateFormat;
use DateTime;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\EntityNotFoundException;
use Generic\Authorizer;
use Generic\ClosureReason\ClosureReasonServiceFactory;
use Generic\Employee;
use Generic\EmployeeService;
use HL7\ObserverService;
use Medical\Activity\Phase;
use Medical\Episode;
use Medical\EpisodeService;
use Medical\InterfaceTreatmentActivity;
use Medical\MHC\Basic\Activity\CreateService as BasicMhcActivityCreateService;
use Medical\MHC\Basic\IdToComponentTransformer;
use Medical\MHC\DiagnoseService as MhcDiagnoseService;
use Medical\MHC\DayOfStay\Activity\FindService;
use Medical\Treatment;
use Medical\Treatment\ApplyProfileService;
use Medical\TreatmentActivityPhase;
use Medical\TreatmentService;
use Patient\PatientService;
use Generic\Clinic;
use Generic\ClinicService;
use Generic\IdToClinicTransformer;
use Symfony\Component\Translation\Translator;
use System\Dbc\Characterization;
use System\Dbc\CharacterizationService;

/**
 * @SWG\Resource(
 *     apiVersion="1.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/treatment",
 *     basePath="/api"
 * )
 */
class TreatmentController extends AbstractController
{
    /**
     * @var \Medical\EpisodeService
     */
    private $episodeService;

    /**
     * @var \Medical\TreatmentService
     */
    private $treatmentService;

    /**
     * @var \HL7\ObserverService
     */
    private $observerService;

    /**
     * @var \Generic\Authorizer
     */
    private $authorizer;

    /**
     * @var \Controller\Treatment\Update
     */
    private $updateHelper;

    /**
     * @var \Controller\Treatment\Create
     */
    private $createHelper;

    /**
     * @var Generic\EmployeeService
     */
    private $employeeService;

    /**
     * @var \Generic\PatientService $patientService
     */
    private $patientService;

    /**
     * @var \Generic\IdToClinicTransformer $idToClinicTransformer
     */
    private $idToClinicTransformer;

    /**
     * @var \Generic\ClosureReason\ClosureReasonServiceFactory
     */
    private $closureReasonServiceFactory;

    /** @var  \Medical\MHC\Basic\IdToComponentTransformer */
    private $idToComponentTransformer;

    /** @var \Medical\MHC\Basic\Activity\CreateService */
    private $basicMhcActivityCreateService;

    /** @var \Medical\MHC\DiagnoseService */
    private $mhcDiagnoseService;

    /** @var \Medical\Treatment\ApplyProfileService */
    private $applyProfileService;

    /** @var \Medical\MHC\DayOfStay\Activity\FindService */
    private $dayOfStayFindService;

    /**
     * Constructor.
     *
     * @param \Patient\PatientService                            $patientService
     * @param \Medical\EpisodeService                            $episodeService
     * @param \Medical\TreatmentService                          $treatmentService
     * @param \HL7\ObserverService                               $observerService
     * @param \Generic\Authorizer                                $authorizer
     * @param \Generic\EmployeeService                           $employeeService
     * @param \Symfony\Component\Translation\Translator          $translator
     * @param \Generic\ClosureReason\ClosureReasonServiceFactory $closureReasonServiceFactory
     * @param \Medical\MHC\Basic\IdToComponentTransformer        $idToComponentTransformer
     * @param \Medical\MHC\Basic\Activity\CreateService          $basicMhcActivityCreateService
     * @param \Medical\MHC\DiagnoseService                       $mhcDiagnoseService
     * @param \Medical\Treatment\ApplyProfileService             $applyProfileService
     * @param \Medical\MHC\DayOfStay\Activity\FindService        $dayOfStayFindService
     * @param \Generic\IdToClinicTransformer                     $idToClinicTransformer
     */
    public function __construct(
        PatientService $patientService = null,
        EpisodeService $episodeService = null,
        TreatmentService $treatmentService = null,
        ObserverService $observerService = null,
        Authorizer $authorizer = null,
        EmployeeService $employeeService = null,
        Translator $translator = null,
        ClosureReasonServiceFactory $closureReasonServiceFactory = null,
        IdToComponentTransformer $idToComponentTransformer = null,
        BasicMhcActivityCreateService $basicMhcActivityCreateService = null,
        MhcDiagnoseService $mhcDiagnoseService = null,
        ApplyProfileService $applyProfileService = null,
        FindService $dayOfStayFindService = null,
        IdToClinicTransformer $idToClinicTransformer = null
    ) {
        parent::__construct();

        $this->patientService = $patientService;
        $this->episodeService = $episodeService;
        $this->treatmentService = $treatmentService;
        $this->observerService = $observerService;
        $this->authorizer = $authorizer;
        $this->employeeService = $employeeService;
        $this->translator = $translator;
        $this->closureReasonServiceFactory = $closureReasonServiceFactory;
        $this->idToComponentTransformer = $idToComponentTransformer;
        $this->basicMhcActivityCreateService = $basicMhcActivityCreateService;
        $this->mhcDiagnoseService = $mhcDiagnoseService;
        $this->applyProfileService = $applyProfileService;
        $this->dayOfStayFindService = $dayOfStayFindService;
        $this->idToClinicTransformer = $idToClinicTransformer;
        $this->legacyInitDependencies();
        $this->initHelpers();
    }

    /**
     * @return \Medical\TreatmentService
     */
    public function getTreatmentService()
    {
        return $this->treatmentService;
    }

    /**
     * Legacy initialize dependencies.
     */
    private function legacyInitDependencies()
    {
        if (!$this->patientService) {
            $this->patientService = $this->get('medicore.patient.patient_service');
        }

        if (!$this->episodeService) {
            $this->episodeService = $this->get('medicore.medical.episode_service');
        }

        if (!$this->idToClinicTransformer) {
            $this->idToClinicTransformer = $this->get('medicore.generic.id_to_clinic_transformer');
        }

        if (!$this->treatmentService) {
            $this->treatmentService = $this->get('medicore.medical.treatment_service');
        }

        if (!$this->observerService) {
            $this->observerService = $this->get('medicore.hl7.observer_service');
        }

        if (!$this->authorizer) {
            $this->authorizer = $this->get('medicore.generic.authorizer');
        }

        if (!$this->employeeService) {
            $this->employeeService = $this->get('medicore.generic.employee_service');
        }

        if (!$this->translator) {
            $this->translator = $this->get('medicore.translation.default');
        }

        if (!$this->idToComponentTransformer) {
            $this->idToComponentTransformer = $this->get('medicore.medical.basic.id_to_component_transformer');
        }

        if (!$this->basicMhcActivityCreateService) {
            $this->basicMhcActivityCreateService = $this->get('medicore.medical.basic.activity.create_service');
        }

        if (!$this->mhcDiagnoseService) {
            $this->mhcDiagnoseService = $this->get('medicore.medical.treatment.mhc.diagnose_service');
        }

        if (!$this->applyProfileService) {
            $this->applyProfileService = $this->get('medicore.medical.treatment.apply_profile_service');
        }

        if (!$this->dayOfStayFindService) {
            $this->dayOfStayFindService = $this->get('medicore.medical.mhc.day_of_stay.activity.find_service');
        }

        if (!$this->closureReasonServiceFactory) {
            $this->closureReasonServiceFactory = $this
                ->get('medicore.generic.closure_reason.closure_reason_service_factory');
        }
    }

    /**
     * @return \Medical\Treatment\ApplyProfileService
     */
    public function getApplyProfileService()
    {
        return $this->applyProfileService;
    }

    /**
     * @return \Medical\MHC\Basic\Activity\CreateService
     */
    public function getBasicMhcCreateService()
    {
        return $this->basicMhcActivityCreateService;
    }

    /**
     * @return \Medical\MHC\Basic\IdToComponentTransformer
     */
    public function getIdToComponentTransformer()
    {
        return $this->idToComponentTransformer;
    }

    /**
     * @return \Medical\MHC\DiagnoseService
     */
    public function getMhcDiagnoseService()
    {
        return $this->mhcDiagnoseService;
    }

    /**
     * Initialize helpers.
     *
     * @access private Lowered accessibility due to unit testing
     */
    protected function initHelpers()
    {
        $this->updateHelper = new Update($this);
        $this->createHelper = new Create($this);
    }

    /**
     * Get the basic closure reason transformer.
     *
     * @return \System\MHC\Basic\IdToClosureReasonTransformer
     */
    public function getIdToBasicClosureReasonTransformer()
    {
        return $this->get('medicore.system.mhc.basic.id_to_closure_reason_transformer');
    }

    /**
     * @SWG\Api(
     *   path="/treatment",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Returns a list of treatments.",
     *           @SWG\Parameter(name="episodeId", type="integer", required=false, paramType="query"),
     *           @SWG\Parameter(name="patientId", type="integer", required=false, paramType="query"),
     *           @SWG\Parameter(name="clinicId", type="integer", required=false, paramType="query"),
     *           @SWG\Parameter(name="status", type="string", required=false, paramType="query"),
     *           @SWG\Parameter(name="applyProfile", type="boolean", required=false, paramType="query"),
     *       )
     * )
     *
     * @return array
     */
    public function getListAction()
    {
        $data = array();
        $query = $this->getRequest()->query;
        $treatments = array();

        if ($query->has('episodeId')) {
            $episode = $this->createEntity(
                $query->get('episodeId'),
                'episodeId',
                $this->episodeService,
                'Medical\Episode'
            );
        }

        if ($query->has('patientId')) {
            $patient = $this->createEntity(
                $query->get('patientId'),
                'patientId',
                $this->patientService,
                '\Patient\Patient'
            );
        }

        if ($query->has('clinicId')) {
            try {
                $clinic = $this->idToClinicTransformer->transform($query->get('clinicId'));
            } catch (TransformationFailedException $e) {
                $this->addInvalidInputMessageToMeta('clinicId', $query->get('clinicId'));
                return false;
            }
        }

        if (!$this->getMeta()->hasError()) {

            if ($query->has('clinicId') && $query->has('patientId') && $query->has('status')) {
                $noElp = false;
                if ($query->has('applyProfile')) {
                    $noElp = true;
                }
                $treatments = $this->treatmentService->findTreatmentsBy($clinic, $patient, $query->get('status'), $noElp);

                if (!empty($treatments)) {
                    if (is_array($treatments)) {
                        $treatments = new ArrayCollection($treatments);
                    }
                    if ($query->has('applyProfile')) {
                        $treatments = $this->filterTreatmentsToApplyProfile($treatments);
                    } else {
                        $treatments = $this->authorizer->filterTreatments($treatments);
                    }
                }
            } elseif ($query->has('patientId')) {
                $treatments = $this->treatmentService->findNotCancelledByPatient($patient);
                if (!empty($treatments)) {
                    if (is_array($treatments)) {
                        $treatments = new ArrayCollection($treatments);
                    }
                    $treatments = $this->authorizer->filterTreatments($treatments);
                }
            } elseif ($query->has('status')) {
                $treatments = $this->treatmentService->getTreatmentsByEpisodeAndStatus($episode, $query->get('status'));
            } else {
                if (!empty($episode)) {
                    $treatments = $episode->getTreatments();
                    $treatments = $this->authorizer->filterTreatments($treatments);
                }
            }
            if (!empty($treatments)) {
                $data = $this->prepareTreatmentsForGUI($treatments);
            }
        }
        $this->getMeta()->setCount(count($data));

        return $data;
    }

    /**
     * Prepare treatments data for GUI.
     *
     * @param array $treatments
     *
     * @return array
     */
    private function prepareTreatmentsForGUI($treatments)
    {
        $data = array();
        foreach ($treatments as $treatment) {
            $data[] = $this->getTreatmentReturnData($treatment);
        }

        return $data;
    }

    /**
     * @SWG\Api(
     *   path="/treatment",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Fetch a treatment.",
     *           @SWG\Parameter(name="id", type="string", required=true, paramType="query"),
     *       )
     * )
     *
     * @param integer $id
     *
     * @return array
     */
    public function getAction($id)
    {
        $data = array();
        $treatment = $this->createEntity(
            $id,
            'id',
            $this->treatmentService,
            "Medical\\Treatment"
        );

        if (null !== $treatment && !$this->authorizer->isTreatmentAccessable($treatment)) {

            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne('UR3')
            );
            return $data;
        }

        if (!$this->getMeta()->hasError()) {
            $data = $this->getTreatmentReturnData($treatment);
            $data = $this->updateCareRequestForTreatment($treatment, $data);

            $this->executeViewValidations($treatment);
        }

        return $data;
    }

    /**
     * Interprets the Treatment as an array with all desired data.
     *
     * @param \Medical\Treatment $treatment
     *
     * @return array
     */
    private function getTreatmentReturnData(Treatment $treatment)
    {
        $data = array(
            'id'                   => $treatment->getId(),
            'episodeId'            => $treatment->getEpisode()->getId(),
            'patientId'            => $treatment->getEpisode()->getPatient()->getId(),
            'name'                 => $treatment->getName(),
            'startDate'            => $treatment->getStartDate()->format(DateFormat::DATE),
            'endDate'              => ($treatment->getEndDate() instanceof DateTime)
                ? $treatment->getEndDate()->format(DateFormat::DATE)
                : null,
            'expectedEndDate'      => ($treatment->getExpectedEndDate() instanceof DateTime)
                ? $treatment->getExpectedEndDate()->format(DateFormat::DATE)
                : null,
            'status'               => $treatment->getTreatmentStatus(),
            'medicallyEnded'       => $treatment->isMedicallyEnded(),
            'medicallyEndedDate'   => ($treatment->getMedicallyEndedDate() instanceof DateTime)
                ? $treatment->getMedicallyEndedDate()->format(DateFormat::DATE)
                : null,
            'secondStatus'         => $treatment->getSecondStatus(),
            'notInvoiceable'       => !$treatment->isInvoiceable(),
            'financiallyProcessed' => $treatment->isFinanciallyProcessed(),
            'type'                 => $treatment->getTreatmentTypeWithCareType(),
            'dbcCareType'          => $treatment->getDbcCareType(),
            'dbcCode'              => $treatment->getDbcAxes(),
            'application'          => $treatment->getApplication(),
            'expectedCareProduct'  => $treatment->getExpectedCareProduct()
                ? $treatment->getExpectedCareProduct()->toListArray()
                : null,
            'closureReason'        => $treatment->canHaveClosureReason()
                ? $this->getClosureReasonArray($treatment)
                : null,
            'specialist'           => $treatment->getSpecialistList(),
            'clinic'               => $treatment->getClinic()->toListArray(),
            'profile'              => $treatment->getProfileList(),
            'indication'           => $treatment->getPMIndicationList(),
            'phases'               => $this->getPhasesList($treatment),
            'circuitCode'          => $treatment->getCircuitCodeList(),
            'existingPatient'      => $treatment->getExistingPatient(),
            'secondSpecialist'     => $treatment->getSecondSpecialistList(),
            'remark'               => $treatment->getRemark(),
            'initialTreatment'     => $this->treatmentService->isInitialTreatment($treatment),
        );

        if (null !== $treatment->getMhc() && null !== $treatment->getMhc()->getTreatmentPhaseSpecialist()) {
            $data['treatmentPhaseSpecialist'] = $treatment->getMhc()->getTreatmentPhaseSpecialist()->toListArray();
        }

        $data['initialTreatment'] = $this->treatmentService->isInitialTreatment($treatment);

        if (null !== $treatment->getBasicMhc()) {
            $data = array_merge($data, $treatment->getBasicMhc()->toArray());
        }

        return $data;
    }

    /**
     * Get closure reason array.
     *
     * In 1.10 code the closure reason can be 0. Because of this we need this try catch block to catch the
     * EntityNotFound Exception this will cause.
     * 
     * @param \Medical\Treatment $treatment
     *
     * @return array|null
     *
     * @access private Lowered accessibility due to unit testing
     */
    protected function getClosureReasonArray(Treatment $treatment)
    {
        $closureReason = $this
            ->closureReasonServiceFactory
            ->getByTreatment($treatment)
            ->getClosureReason($treatment);

        try {
            return ($closureReason)
                ? $closureReason->toListArray()
                : null;
        } catch (EntityNotFoundException $e) {
            return null;
        }
    }

    /**
     * Get a list of all the phases of the Treatment.
     *
     * @param \Medical\Treatment $treatment
     *
     * @return array
     */
    private function getPhasesList(Treatment $treatment)
    {
        $data = array();

        // Get the activities with out phase
        $data[] = $this->getPhaseDataForTreatment($treatment, null);

        // ... and the custom phases
        $phases = $treatment->getPhases();

        if (!empty($phases)) {
            foreach ($phases as $phase) {
                $data[] = $this->getPhaseDataForTreatment($treatment, $phase);
            }
        }
        if ($treatment->isMhcDbc() || $treatment->isBasicMhc()) {
            $data = $this->treatmentService->sortPhasesBasedOnActivityType($data);
        }

        return $data;
    }

    /**
     * Get all desired info from a phase.
     *
     * @param \Medical\Treatment $treatment
     * @param \Medical\TreatmentActivityPhase $treatmentActivityPhase
     *
     * @return array
     */
    private function getPhaseDataForTreatment(
        Treatment $treatment,
        TreatmentActivityPhase $treatmentActivityPhase = null
    ) {
        $data = array();
        $phase = $treatmentActivityPhase ? $treatmentActivityPhase->getPhase() : null;

        if ($treatment->isSomatic()) {
            $data = $this->getPhaseDataForTreatmentSomatic($treatment, $treatmentActivityPhase);
        } else {
            if ($treatment->isMhcCtg() || (null !== $phase && Phase::CTG_ACTIVITIES_TYPE === $phase->getType())) {
                $data = $this->getDataForCtgPhase($treatment, $treatmentActivityPhase);
            } elseif ($treatment->isMhcDbc() && (null !== $phase && Phase::SPECIAL_ACTIVITIES_TYPE === $phase->getType())) {
                $data = $this->getDataForSpecialPhase($treatment, $treatmentActivityPhase);
            } elseif ($treatment->isMhcDbc() && (null !== $phase && Phase::DAYCARE_ACTIVITIES_TYPE === $phase->getType())) {
                $data = $this->getDataForDayCarePhase($treatment, $treatmentActivityPhase);
            } elseif ($treatment->isMhcDbc() && (null !== $phase && Phase::DAY_OF_STAY_ACTIVITIES_TYPE === $phase->getType())) {
                $data = $this->getDataForDayOfStayPhase($treatment, $treatmentActivityPhase);
            } elseif ($treatment->isMhcDbc() || $treatment->isMhcElp()) {
                $data = $this->getPhaseDataForTreatmentMhcDbc($treatment, $treatmentActivityPhase);
            } elseif ($treatment->isBasicMhc()) {
                $data = $this->getDataForBasicPhase($treatment, $treatmentActivityPhase);
            }
        }

        return array_merge(
            array(
                'id'                            => $treatmentActivityPhase ? $treatmentActivityPhase->getId() : null,
                'systemId'                      => $phase ? $phase->getId() : null,
                'activityType'                  => $this->getPhaseActivityType($treatment, $phase),
                'name'                          => $phase ? $phase->getName() : 'no phase',
                'count'                         => 0,
                'hasActivityWithMedicalGrounds' => false,
                'hasActivityWithAuthorizations' => false,
                'activityTimeTotals'            => array(),
            ),
            $data
        );
    }

    /**
     * Return the type of activities this phase contains. If the type of the phase is 'default'
     * we map it to the default activity type for that treatment, e.g.: default for mhc dbc is timewriting.
     *
     * @param \Medical\Treatment $treatment
     * @param \Medical\Activity\Phase $phase
     *
     * @return string
     */
    public function getPhaseActivityType(Treatment $treatment, Phase $phase = null)
    {
        if (null === $phase) {
            if ($treatment->isMhcCtg()) {
                $type = Phase::CTG_ACTIVITIES_TYPE;
            } else {
                $type = Phase::DEFAULT_ACTIVITIES_TYPE;
            }
        } else {
            $type = $phase->getType();
        }

        if (Phase::DEFAULT_ACTIVITIES_TYPE === $type) {
            if ($treatment->isBasicMhc() || $treatment->isMhcDbc() || $treatment->isMhcElp()) {
                return InterfaceTreatmentActivity::TYPE_TIMEWRITING;
            }
            if ($treatment->isMhcCtg()) {
                return InterfaceTreatmentActivity::TYPE_CTG;
            }
            if ($treatment->isSomatic()) {
                if ($treatment->isTypeAwbz()) {
                    return InterfaceTreatmentActivity::TYPE_AWBZ;
                }
                return InterfaceTreatmentActivity::TYPE_SOM;
            }
        }
        return $type;
    }

    /**
     * Get all desired info from a phase (somatic).
     *
     * @param \Medical\Treatment $treatment
     * @param \Medical\TreatmentActivityPhase $treatmentActivityPhase
     *
     * @return array
     */
    private function getPhaseDataForTreatmentSomatic(
        Treatment $treatment,
        TreatmentActivityPhase $treatmentActivityPhase = null
    ) {
        $treatmentActivityService = $this->get('medicore.medical.treatment_activity_service');

        $phase = $treatmentActivityPhase ? $treatmentActivityPhase->getPhase() : null;
        $treatmentActivities = $treatmentActivityService->findByPhase($treatment, $phase);

        return array(
            'count'                         => count($treatmentActivities),
            'hasActivityWithMedicalGrounds' => $this->hasClaimForSomaticActivities($treatmentActivities),
            'hasActivityWithAuthorizations' => $this->hasAuthorizationForSomaticActivities($treatmentActivities),
        );
    }

    /**
     * Get all desired info from a phase (MHC DBC).
     *
     * @param \Medical\Treatment $treatment
     * @param \Medical\TreatmentActivityPhase $treatmentActivityPhase
     *
     * @return array
     */
    private function getPhaseDataForTreatmentMhcDbc(
        Treatment $treatment,
        TreatmentActivityPhase $treatmentActivityPhase = null
    ) {
        $treatmentActivityService = $this->get('medicore.medical.mhc.treatment.activity.get_service');

        $phase = $treatmentActivityPhase ? $treatmentActivityPhase->getPhase() : null;
        $treatmentActivities = $treatmentActivityService->findByPhase($treatment, $phase);

        return array(
            'count'              => count($treatmentActivities),
            'activityTimeTotals' => $this->getActivityTimeTotals($treatmentActivities),
        );
    }

    /**
     * Get all desired info from a phase (MHC DBC).
     *
     * @param \Medical\Treatment $treatment
     * @param \Medical\TreatmentActivityPhase $treatmentActivityPhase
     *
     * @return array
     */
    private function getDataForCtgPhase(
        Treatment $treatment,
        TreatmentActivityPhase $treatmentActivityPhase = null
    ) {
        $treatmentActivityService = $this->get('medicore.medical.mhc.ctg.activity.find_service');

        $phase = $treatmentActivityPhase ? $treatmentActivityPhase->getPhase() : null;
        $treatmentActivities = $treatmentActivityService->findByPhase($treatment, $phase);

        return array(
            'count'              => count($treatmentActivities),
            'activityTimeTotals' => $this->getActivityTimeTotals(array()),
        );
    }

    /**
     * Get all desired info from the daycare phase.
     *
     * @param \Medical\Treatment                    $treatment
     * @param \Medical\TreatmentActivityPhase|null  $treatmentActivityPhase
     *
     * @return array
     */
    private function getDataForDayCarePhase(
        Treatment $treatment,
        TreatmentActivityPhase $treatmentActivityPhase = null
    ) {
        $treatmentActivityService = $this->get('medicore.medical.mhc.day_care.activity.find_service');

        $phase = $treatmentActivityPhase ? $treatmentActivityPhase->getPhase() : null;
        $treatmentActivities = $treatmentActivityService->findByPhase($treatment, $phase);

        return array(
            'count'              => count($treatmentActivities),
            'activityTimeTotals' => $this->getActivityTimeTotals(array()),
        );
    }

    /**
     * Get all desired info from the special activities phase.
     *
     * @param \Medical\Treatment                    $treatment
     * @param \Medical\TreatmentActivityPhase|null  $treatmentActivityPhase
     *
     * @return array
     */
    private function getDataForSpecialPhase(
        Treatment $treatment,
        TreatmentActivityPhase $treatmentActivityPhase = null
    ) {
        $treatmentActivityService = $this->get('medicore.medical.mhc.special.activity.find_service');

        $phase = $treatmentActivityPhase ? $treatmentActivityPhase->getPhase() : null;
        $treatmentActivities = $treatmentActivityService->findByPhase($treatment, $phase);

        return array(
            'count'              => count($treatmentActivities),
            'activityTimeTotals' => $this->getActivityTimeTotals(array()),
        );
    }

    /**
     * Get all desired info from a phase (MHC Basic).
     *
     * @param \Medical\Treatment              $treatment
     * @param \Medical\TreatmentActivityPhase $treatmentActivityPhase
     *
     * @return array
     */
    private function getDataForBasicPhase(
        Treatment $treatment,
        TreatmentActivityPhase $treatmentActivityPhase = null
    ) {
        $treatmentActivityService = $this->get('medicore.medical.mhc.basic.activity.find_service');

        $phase = $treatmentActivityPhase ? $treatmentActivityPhase->getPhase() : null;
        $treatmentActivities = $treatmentActivityService->findByPhase($treatment, $phase);

        return array(
            'count'              => count($treatmentActivities),
            'activityTimeTotals' => $this->getActivityTimeTotals($treatmentActivities),
        );
    }

    /**
     * Get all required data from the day of stay phase.
     *
     * @param \Medical\Treatment                    $treatment
     * @param \Medical\TreatmentActivityPhase|null  $treatmentActivityPhase
     *
     * @return array
     */
    private function getDataForDayOfStayPhase(
        Treatment $treatment,
        TreatmentActivityPhase $treatmentActivityPhase = null
    ) {
        $phase = $treatmentActivityPhase ? $treatmentActivityPhase->getPhase() : null;
        $treatmentActivities = $this->dayOfStayFindService->findByPhase($treatment, $phase);

        return array(
            'count'              => count($treatmentActivities),
            'activityTimeTotals' => $this->getActivityTimeTotals(array()),
        );
    }

    /**
     * Check whether any activity is has the claim.
     *
     * @param array \Medical\TreatmentActivity[]
     *
     * @return boolean
     */
    private function hasClaimForSomaticActivities(array $treatmentActivities)
    {
        foreach ($treatmentActivities as $treatmentActivity) {
            if (null !== $treatmentActivity->getClaim()) {
                return true;
            }
        }

        return false;
    }

    /**
     * Check whether any activity is has the authorization for the claim.
     *
     * @param array \Medical\TreatmentActivity[]
     *
     * @return boolean
     */
    private function hasAuthorizationForSomaticActivities(array $treatmentActivities)
    {
        foreach ($treatmentActivities as $treatmentActivity) {
            if (null !== $treatmentActivity->hasAuthorization()) {
                return true;
            }
        }

        return false;
    }

    /**
     * Get activity time totals from the list of treatment activities.
     *
     * @param array \Medical\MHC\TreatmentActivity[]
     *
     * @return array
     *
     * @access private Lowered accessibility due to unit testing
     */
    protected function getActivityTimeTotals(array $treatmentActivities)
    {
        $directTime = 0;
        $indirectTime = 0;
        $travelTime = 0;

        foreach ($treatmentActivities as $treatmentActivity) {
            if ($treatmentActivity->isPerformed()) {
                $directTime   += $treatmentActivity->getDirectTime();
                $indirectTime += $treatmentActivity->getInDirectTime();
                $travelTime   += $treatmentActivity->getTravelTime();
            }
        }

        return array(
            'directTime'   => $directTime,
            'indirectTime' => $indirectTime,
            'travelTime'   => $travelTime,
        );
    }

    /**
     * Function to check if the careRequest should be disabled for a treatment.
     *
     * We need to evaluate if the care type supports any care requests. If none are supported for we set the
     * value for careRequest to false in the response body.
     *
     * @param \Medical\Treatment $treatment
     * @param array              $data
     *
     * @return array
     */
    private function updateCareRequestForTreatment(Treatment $treatment, array $data)
    {
        $searchParams = array(
            'validOn' => $treatment->getDtStart(),
            'specialty' => $treatment->getSpecialist()->getSpecialism(),
            'code' => Characterization::CARE_REQUEST_AXIS,
            'removeInactive' => true
        );

        //check the characterization service which care requests are present for the treatment.
        $characterizationService = new CharacterizationService();
        $careRequests = $characterizationService->findAllBy($searchParams);
        //if we get less than 1 carerequest we can disable it.
        $isCareRequestRequired = true;
        if (count($careRequests) < 1) {
            $isCareRequestRequired = false;
        }

        $data['dbcCode']['isCareRequestRequired'] = $isCareRequestRequired;

        return $data;
    }

    /**
     * @param array $data
     *
     * @return array
     */
    public function createAction($data)
    {
        $response = array();

        $this->createEntity(
            $data['episodeId'],
            'id',
            $this->episodeService,
            "Medical\\Episode"
        );

        $treatment = $this->createHelper->run($data);

        if (!$this->hasError()) {
            $response = $this->getTreatmentReturnData($treatment);
            $this->observerService->notify('Treatment_Create', $treatment);
        }

        return $response;
    }

    /**
     * @SWG\Api(
     *   path="/treatment",
     *       @SWG\Operation(
     *           method="PUT",
     *           summary="Update a treatment",
     *           @SWG\Parameter(name="id", type="integer", paramType="query", required=true),
     *           @SWG\Parameter(
     *               name="body",
     *               description="Updated treatment object, see toArray as reference.",
     *               required=true,
     *               type="\Medical\Treatment",
     *               paramType="body",
     *               allowMultiple=false
     *           )
     *       )
     * )
     *
     * @param integer $id The entity identifier.
     * @param array $data Array representation of the treatment object. Yes you have to give the complete object.
     *
     * @return array The updated array representation of the Treatment object.
     */
    public function updateAction($id, $data)
    {
        $this->data = array();
        $treatment = $this->createEntity(
            $id,
            'id',
            $this->treatmentService,
            "Medical\\Treatment"
        );

        if (null !== $treatment) {
            if (!$this->authorizer->isTreatmentWritable($treatment)) {
                $this->getMeta()->addMessage(
                    Meta::STATUS_ERROR,
                    $this->messageHandler->getOne('UR3')
                );

                return $this->data;
            }
            $treatment = $this->updateHelper->update($treatment, $data);
        }

        if (!$this->hasError()) {
            $this->data = $this->getTreatmentReturnData($treatment);
        }
        return $this->data;
    }

    /**
     * Returns filtered treatments if apply profile is accessible for the logged in employee.
     *
     * @param array $treatments
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    private function filterTreatmentsToApplyProfile($treatments)
    {
        if ($treatments->isEmpty()) {
            return $treatments;
        }
        $authorizer = $this->authorizer;
        $treatments = $treatments->filter(
            function (Treatment $treatment) use ($authorizer) {
                return $authorizer->isApplyProfileAccessable($treatment);
            }
        );

        return new ArrayCollection(array_values($treatments->toArray()));
    }

    /**
     * Validate icd10 for somatic treatments.
     *
     * @param \Medical\Treatment $treatment
     */
    private function executeViewValidations(Treatment $treatment)
    {
        if ($treatment->getDbcSomatic()) {
            $this->treatmentService->executeTreatmentViewEvent($treatment);

            ValidationResult::addMessages(
                $this,
                $this->treatmentService->getValidationMessages()
            );
        }
    }
}
