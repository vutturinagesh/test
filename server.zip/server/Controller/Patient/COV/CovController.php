<?php

namespace Controller\Patient\COV;

use Actinidium\API\Response\Meta;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Generic\EmployeeService;
use Patient\PatientService;
use Patient\InsuranceService;
use Patient\External\Cov\ValidationService;
use Person\PersonService;
use Medical\Treatment\TypeService as TreatmentTypeService;
use Medicore\Component\CovCheck\Service\CovRequestService;
use Medicore\Component\CovCheck\Model\CovRequest;
use Monolog\Logger;
use Monolog\Handler\StreamHandler;
use Controller\AbstractController;
use Exception;
use DateTime;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/patient",
 *     basePath="/api/v2"
 * )
 */
class CovController extends AbstractController
{
    /**
     * Holds the error message for: when no COV check is allowed (isRequestValid()) and no BSN has been supplied.
     *
     * @var string
     */
    const NO_COV_ALLOWED_AND_NO_BSN_ERROR = 'PR-M23';

    /**
     * Holds the log file location for the COV match process.
     */
    const DEFAULT_COV_LOG_LOCATION = '/var/www/logs/covcheck.%s.log';

    /**
     * Holds the default log name for the COV process.
     */
    const DEFAULT_LOG_NAME = 'CovCheck';

    /** @var \Patient\PatientService */
    private $patientService;

    /** @var \Patient\External\Cov\ValidationService */
    private $validationService;

    /** @var \Generic\EmployeeService */
    private $employeeService;

    /** @var \Patient\InsuranceService */
    private $insuranceService;

    /** @var \Medicore\Component\CovCheck\Service\CovRequestService */
    private $covRequestService;

    /** @var \Medical\Treatment\TypeService */
    private $treatmentTypeService;

    /** @var \Person\PersonService */
    private $personService;

    /**
     * Instantiate the controller and create new services if they are not injected.
     *
     * @param \Patient\PatientService                                $patientService
     * @param \Patient\External\Cov\ValidationService                $validationService
     * @param \Generic\EmployeeService                               $employeeService
     * @param \Medicore\Component\CovCheck\Service\CovRequestService $covRequestService
     * @param \Patient\InsuranceService                              $insuranceService
     * @param \Medical\Treatment\TypeService                         $treatmentTypeService
     * @param \Person\PersonService                                  $personService
     */
    public function __construct(
        PatientService $patientService,
        ValidationService $validationService,
        EmployeeService $employeeService,
        CovRequestService $covRequestService,
        InsuranceService $insuranceService,
        TreatmentTypeService $treatmentTypeService,
        PersonService $personService
    ) {
        parent::__construct();

        $this->patientService = $patientService;
        $this->validationService = $validationService;
        $this->employeeService = $employeeService;
        $this->covRequestService = $covRequestService;
        $this->insuranceService = $insuranceService;
        $this->treatmentTypeService = $treatmentTypeService;
        $this->personService = $personService;
    }

    /**
     * Action to do a single request to COV.
     *
     * @SWG\Api(
     *     path="/patient-cov-check",
     *     description="Do a COV check for the patient.",
     *     @SWG\Operation(
     *         method="GET",
     *         summary="Do a COV check for the patient.",
     *         notes="The update can be done by using a BSN & date of birth OR a bsn and an address.",
     *         @SWG\Parameter(name="dateOfBirth", type="string", format="date", required=false, paramType="query"),
     *         @SWG\Parameter(name="bsnValue", type="integer", required=false, paramType="query"),
     *         @SWG\Parameter(name="physicalPostCode", type="string", required=false, paramType="query"),
     *         @SWG\Parameter(name="physicalHouseNumber", type="integer", required=false, paramType="query"),
     *     )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function getListAction(Request $request)
    {
        $data = array();

        $covData = $this->createPostData($request);
        $covRequest = $this->createCovRequest($covData);

        if ($covRequest->isDummyBsn()) {
            $this->getMeta()->addMessage(Meta::STATUS_SUCCESS, '');
        }

        if ($this->isRequestValid($covData, $covRequest)) {
            try {
                $this->initializeLogging();
                $data = $this->covRequestService->getInsurancesRestResponse($covRequest);
                $this->processMessages($data['messages']);

            } catch (\Exception $e) {
                $this->getMeta()->addMessage(Meta::STATUS_ERROR, $e->getMessage());
            }
        } else {
            if ($covRequest->hasBsnNumber()) {
                $data = $this->covRequestService->generateResultset();
            } else {
                $data = $this->covRequestService->generateResultset(false, self::NO_COV_ALLOWED_AND_NO_BSN_ERROR);
            }
            $this->processMessages($data['messages']);
        }

        $response = new JsonResponse();
        $response->setData(array('data' => $data));

        return $response;
    }

    /**
     * Private function to get all the posted data.
     *
     * @param \Symfony\Component\HttpFoundation\Request
     *
     * @return array
     */
    private function createPostData(Request $request)
    {
        $query = $request->query;

        $covData = array(
            'bsnValue' => $query->get('bsnValue'),
            'dateOfBirth' => $query->get('dateOfBirth'),
            'physicalPostCode' => $query->get('physicalPostCode'),
            'physicalHouseNumber' => $query->get('physicalHouseNumber'),
            'physicalHouseNumberSuffix' => $query->get('physicalHouseNumberSuffix')
        );

        if ($query->has('patientId')) {
            $covData['patientId'] = $query->get('patientId');
        }

        return $covData;
    }

    /**
     * Function to add messages to the meta.
     *
     * @param array $messages
     */
    private function processMessages(array $messages)
    {
        foreach ($messages as $message) {

            if ($message['status'] === true) {
                $type = Meta::STATUS_SUCCESS;
            } else {
                $type = Meta::STATUS_ERROR;
            }

            $this->logger->debug(
                sprintf(
                    '[COV Batch] Message status "%s", code "%s"',
                    $type,
                    $message['cov']['code']
                )
            );

            $this->getMeta()->addMessage($type, $message);
        }
    }

    /**
     * Create COV object.
     *
     * @param array $covData
     *
     * @return \Medicore\Component\CovCheck\Model\CovRequest
     */
    private function createCovRequest(array $covData)
    {
        $covRequest = new CovRequest();
        $covRequest
            ->setBsnNumber($covData['bsnValue'])
            ->setBirthDate(new DateTime($covData['dateOfBirth']))
            ->setPostalCode($covData['physicalPostCode'])
            ->setHouseNumber($covData['physicalHouseNumber'])
            ->setHouseNumberSuffix($covData['physicalHouseNumberSuffix']);
        return $covRequest;
    }

    /**
     * Validate the request both syntax and allowance by checking all the values and running all the validations.
     *
     * @param array                                         $covData
     * @param \Medicore\Component\CovCheck\Model\CovRequest $covRequest
     *
     * @return boolean
     */
    private function isRequestValid(array $covData, CovRequest $covRequest)
    {
        $patient = $this->getPatient($covData, $covRequest);
        $isLinkedToSomaticClinics = false;
        if (null !== $patient) {
            $isLinkedToSomaticClinics = $this->patientService->isLinkedToSomaticClinics($patient);
        }

        if ($this->personService->isJuvenile($covRequest->getBirthDate()) &&
            $this->treatmentTypeService->hasMhcTreatmentTypes() &&
            !$isLinkedToSomaticClinics) {
            return false;
        }

        if ($covRequest->hasBsnNumber()) {
            $mandatoryFields = $this->validationService->getMandatoryFields('searchpath1');
        } else {
            $mandatoryFields = $this->validationService->getMandatoryFields('searchpath3');
        }

        $this->processMandatoryFields($mandatoryFields, $covData);

        if (!$this->hasError()) {
            $this->validateCovParameters($covData, $mandatoryFields);

            if (!$this->hasError()) {
                return true;
            }
        }

        return false;
    }

    /**
     * Initialize logging support.
     */
    private function initializeLogging()
    {
        if ($this->employeeService->getCurrentEmployee()->isSupportAccount()) {
            $logLevel = Logger::DEBUG;
        } else {
            $logLevel = Logger::WARNING;
        }

        $logger = new Logger(self::DEFAULT_LOG_NAME);
        $logger->pushHandler(new StreamHandler(sprintf(self::DEFAULT_COV_LOG_LOCATION, DBNAME), $logLevel));
    }

    /**
     * Function to validate the parameters.
     *
     * @param array $data
     * @param array $mandatoryFields
     */
    private function validateCovParameters(array $data, array $mandatoryFields)
    {
        foreach ($data as $field => $value) {

            if ($this->requiresValidation($field, $value, $mandatoryFields) === true) {
                $validators = $this->validationService->getValidationsByField($field, $value, $data);

                $this->executeValidators($validators);
            }
        }
    }

    /**
     * Try to get the patient given in the cov api call.
     *
     * @param array                                         $covData
     * @param \Medicore\Component\CovCheck\Model\CovRequest $covRequest
     *
     * @return \Patient\Patient
     */
    private function getPatient(array $covData, CovRequest $covRequest)
    {
        $patient = null;
        $givenBsn = $covRequest->getBsnNumber();

        if (array_key_exists('patientId', $covData)) {
            $patient = $this->patientService->findById($covData['patientId']);
        } elseif (!empty($givenBsn)) {
            $patientCollection = $this->patientService->findBy(
                array(
                    'bsn' => $givenBsn,
                    'deleted' => 'nee',
                )
            );
            $patient = array_shift($patientCollection);
        }

        return $patient;
    }

    /**
     * Do a single request to COV, perform the insurance algorithm and save the result with the patient.
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return array
     */
    private function refresh(Request $request)
    {
        $data = array();
        $data['insurances'] = array();
        $currentDateTime = new DateTime();

        $covData = $this->createPostData($request);
        $covRequest = $this->createCovRequest($covData);

        if ($covRequest->isDummyBsn()) {
            $this->getMeta()->addMessage(Meta::STATUS_SUCCESS, '');
        }

        if ($this->isRequestValid($covData, $covRequest)) {
            try {
                $this->initializeLogging();
                $data = $this->covRequestService->getInsurancesRestResponse($covRequest);
                $this->processMessages($data['messages']);

                if ($data['status'] === true) {

                    $patient = $this->getPatient($covData, $covRequest);
                    if (null === $patient) {
                        return array();
                    }
                    $patientInsurances = $patient->insurancesToArray();

                    $insuranceData = array();
                    if (count($data['insurances']) > 0) {
                        $insuranceData = array_merge($data['insurances'], $patientInsurances);
                    }

                    $this->insuranceService->filterAndSetInsurances($patient, $insuranceData);
                    $patient->setCovCheckDate($currentDateTime);
                    $patient->setCovCheckCodeByMessageCode($data['messages']['cov']['code']);

                    $this->patientService->save($patient);

                    $data['insurances'] = $patient->insurancesToArray();
                }
            } catch (Exception $e) {
                $this->getMeta()->addMessage(Meta::STATUS_ERROR, $e->getMessage());
            }
        }

        return $data;
    }

    /**
     * Action to do a single request to COV, perform the insurance algorithm and save the result with the patient.
     *
     * @SWG\Api(
     *     path="/patient-cov-refresh",
     *     description="Do a COV check, perform matching algorithm and store the result for the patient.",
     *     @SWG\Operation(
     *         method="GET",
     *         summary="Do a COV check, perform matching algorithm and store the result for the patient.",
     *         notes="The update can be done by using a BSN & date of birth OR a bsn and an address.",
     *         @SWG\Parameter(name="dateOfBirth", type="string", format="date", required=false, paramType="query"),
     *         @SWG\Parameter(name="bsnValue", type="integer", required=false, paramType="query"),
     *         @SWG\Parameter(name="physicalPostCode", type="string", required=false, paramType="query"),
     *         @SWG\Parameter(name="physicalHouseNumber", type="integer", required=false, paramType="query"),
     *     )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse|array
     */
    public function refreshAction(Request $request)
    {
        $response = new JsonResponse();
        $response->setData(array('data' => $this->refresh($request)));
        return $response;
    }

    /**
     * Action to do a batch request for a set of patients.
     *
     * @SWG\Api(
     *     path="/patient-cov-batch",
     *     description="Do a batch COV check, perform matching algorithm and store the result for a given set of patients.",
     *     @SWG\Operation(
     *         method="PUT",
     *         notes="Input a set of id's in the payload."
     *     )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function batchAction(Request $request)
    {
        $response = new JsonResponse();

        $patients = json_decode($request->getContent(), true);
        if (empty($patients)) {
            $response->setData(array('data' => 0));
            return $response;
        }

        $resultCounter = 0;
        foreach($patients as $patient) {
            $this->setMeta(new Meta());

            $newRequest = new Request(
                array(
                    'patientId' => $patient['patientId'],
                    'bsnValue' => $patient['bsnValue'],
                    'dateOfBirth' => $patient['dateOfBirth'],
                    'physicalPostCode' => $patient['physicalPostCode'],
                    'physicalHouseNumber' => $patient['physicalHouseNumber'],
                    'physicalHouseNumberSuffix' => $patient['physicalHouseNumberSuffix']
                )
            );

            $result = $this->refresh($newRequest);
            if (array_key_exists('insurances', $result) && !empty($result['insurances'])) {
                $resultCounter++;
            }

            $em = $this->get('doctrine.orm.entity_manager');
            $em->clear();
        }

        $response->setData(array('data' => $resultCounter));
        return $response;
    }
}
