<?php
/**
 * MCIS
 *
 * Patient form controller
 *
 * @package Patient
 */
namespace Controller\Patient;

use Actinidium\API\Response\Meta;
use Actinidium\API\RestBaseController;
use Controller\EMR\EMRInterface;

/**
 * form Controller
 *
 * @package patient
 */
class EMRFormController extends RestBaseController implements EMRInterface
{

    /**
     * Holds the form service object
     *
     * @var \EMR\Form\FormService
     */
    private $formService;

    /**
     * Get the form service object on demand
     *
     * @return \EMR\Form\FormService
     */
    public function getFormService()
    {
        if (!($this->formService instanceof \EMR\Form\FormService)) {
            $this->formService = new \EMR\Form\FormService();
        }

        return $this->formService;
    }

    /**
     * Set the form service - This is used in phpunit when we want to set the mock object
     *
     * @param \EMR\Form\FormService $formService
     */
    public function setFormService(\EMR\Form\FormService $formService)
    {
        if (!($this->formService instanceof \EMR\Form\FormService)) {
            $this->formService = $formService;
        }
    }

    /**
     * Get action for form
     *
     * @param integer $id
     *
     * @return void
     *
     * @todo Need to implement
     */
    public function getAction($id)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * Get list action for form
     *
     * @return array
     */
    public function getListAction()
    {
        $query = $this->getRequest()->query;
        $patientId = $query->get('patientId');
        $formId = $query->get('formId');
        $typeId = $query->get('typeId');

        try {
            $result = $this->getFormService()->getForm($patientId, $formId, $typeId);
            if (count($result) == 0) {
                $this->getMeta()->addMessage(META::STATUS_ERROR, "No Records Found");
            } else {
                $this->getMeta()->setCount(count($result));
                return $result;
            }
        } catch (\Exception $e) {
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, $e->getMessage());
        }
    }

    /**
     * create action for form
     *
     * @param array $data
     *
     * @return void
     *
     * @todo Need to implement
     */
    public function createAction($data)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * update action for status
     *
     * @param integer $id
     * @param array $data
     *
     * @return void
     *
     * @todo Need to implement
     */
    public function updateAction($id, $data)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * delete action for status
     *
     * @param integer $id
     *
     * @return void
     *
     * @todo Need to implement
     */
    public function deleteAction($id)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * delete list action for status
     *
     * @return void
     *
     * @todo Need to implement
     */
    public function deleteListAction()
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }
}
