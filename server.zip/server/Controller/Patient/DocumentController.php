<?php

namespace Controller\Patient;

use Actinidium\API\Response\Meta;
use Actinidium\API\Response\NonCachedJsonResponse;
use Controller\AbstractController;
use Exception;
use Patient\DocumentService;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/patient-documents",
 *     basePath="/api/v2"
 * )
 */
class DocumentController extends AbstractController
{
    /** @var \Patient\DocumentService */
    private $documentService;

    /**
     * @param \Patient\DocumentService $documentService
     */
    public function __construct(DocumentService $documentService)
    {
        parent::__construct();

        $this->documentService = $documentService;
    }

    /**
     * @SWG\Api(
     *     path="/patient/{patientId}/document",
     *     @SWG\Operation(
     *         method="GET",
     *         summary="Returns a list of documents belonging to a patient.",
     *         @SWG\Parameter(name="patientId", type="integer", required=true, description="Patient ID", paramType="path"),
     *     )
     * )
     * 
     * @param int $patientId
     *
     * @return \Actinidium\API\Response\NonCachedJsonResponse
     */
    public function getListAction($patientId)
    {
        $response = new NonCachedJsonResponse();
        $data = array();

        $document = $this->documentService->getSearchByRequest($patientId);
        if ($this->isModelValid($document, array('get'))) {
            $data = $this->documentService->getAllByPatient($document->getPatient());
        }
        $response->setData(array('data' => $data));

        return $response;
    }

    /**
     * @SWG\Api(
     *     path="/patient/{caregiverId}/document",
     *     @SWG\Operation(
     *         method="POST",
     *         summary="Create a document for a patient.",
     *         notes="Upload a document trough base64 encoded string, Saved for a patient. 'caregiverId' is appointment.external_id and will be converted to a patient.",
     *         @SWG\Parameter(
     *             name="caregiverId",
     *             type="integer",
     *             required=true,
     *             description="External ID in table appointment, converted to the patient of the appointment",
     *             paramType="path"
     *         ),
     *         @SWG\Parameter(
     *             name="body",
     *             description="Document input.",
     *             required=true,
     *             type="\Patient\Document",
     *             paramType="body",
     *             allowMultiple=false
     *         )
     *     )
     * )
     *
     * @return \Actinidium\API\Response\NonCachedJsonResponse
     */
    public function createAction($caregiverId)
    {
        $response = new NonCachedJsonResponse();
        $documentData = array();

        $document = $this->documentService->createByRequest($this->getRequest(), $caregiverId);
        if ($this->isModelValid($document, array('create'))) {
            try {
                $documentData = $this->documentService->extractDocument($document);
            } catch (Exception $e) {
                $this->getMeta()->addMessage(Meta::STATUS_ERROR, $e->getMessage());
            }
        }

        $response->setData($documentData);

        return $response;
    }
}
