<?php

namespace Controller\Patient\Referrer;

use Symfony\Component\HttpFoundation\JsonResponse;
use Actinidium\API\RestBaseController;
use Patient\RelatedOrganizationService;
use Generic\Referrer\OrganizationService;
use Generic\Referrer\IndividualService;
use ORM\Provider;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/patient",
 *     basePath="/api/v2"
 * )
 */
class ReasonController extends RestBaseController
{
    /** @var RelatedOrganizationService */
    private $relatedOrganizationService;

    /**
     * @param RelatedOrganizationService $relatedOrganizationService
     */
    public function __construct(RelatedOrganizationService $relatedOrganizationService)
    {
        $this->relatedOrganizationService = $relatedOrganizationService;
    }

    /**
     * @SWG\Api(
     *     path="/patient/referrer/reason",
     *     @SWG\Operation(
     *         summary="Find referrer reasons for related organizations.",
     *         method="GET"
     *     )
     * )
     *
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function getListAction()
    {
        $response = new JsonResponse();
        $response->setPublic();
        $response->setMaxAge(14400);
        $response->headers->addCacheControlDirective('must-revalidate', true);

        $reasons = $this->relatedOrganizationService->getReasons();
        $data = array();

        foreach ($reasons as $reason) {
            $data[] = $reason->toArray();
        }

        $this->getMeta()->setCount(count($data));

        $response->setData(array('data' => $data));

        return $response;
    }

}
