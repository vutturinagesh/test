<?php
/**
 * MCIS
 * 
 * @author Prasanth Pillai <prasanth.pillai@medicore.nl>
 * @package Patient
 * 
 */
namespace Controller\Patient;

use Actinidium\API\MetaBaseController;
use Actinidium\API\Response\Meta;
use Generic\Patient;
use Generic\PatientService;
use Actinidium\API\RestBaseController;

/**
 * PatientRestController
 *
 * Callable via /api/patient-display/
 */
class DisplayController extends RestBaseController
{

    /**
     * @var \Patient\FieldService
     */
    protected $fieldService;
    
    
    /**
     * Get the field service object on demand
     * 
     * @return \Patient\FieldService
     */
    private function getFieldService()
    {
        if ($this->fieldService instanceof  \Patient\FieldService) {
            $this->fieldService = new \Patient\FieldService();
        }

        return $this->fieldService;
    }
    
    /**
     * Get the Field object by passing the id
     * Callable via /api/patient-display/?id=<id>
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::getAction()
     */
    public function getAction($id)
    {
        $field = $this->getFieldService()->findById($id);
        if ($field) {
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, "Field with identity '$id' does not exist");
        }
        return $field;
    }
    
    /**
     * Get all the fields along with validation for patient registration
     * Callable via /api/patientdisplay/
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::getListAction()
     */
    public function getListAction()
    {
        return $this->getFieldService()->getAll();
    }
    
    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::createAction()
     */
    public function createAction($data)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }
    
    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::deleteAction()
     */
    public function deleteAction($id)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }
    
    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::deleteListAction()
     */
    public function deleteListAction()
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }
    
    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::updateAction()
     */
    public function updateAction($id, $data)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }
}
