<?php
/**
 * MCIS
 *
 * Patient Status controller
 *
 * @package Patient
 */
namespace Controller\Patient;

use Actinidium\API\Response\Meta;
use Actinidium\API\RestBaseController;

/**
 * Status Controller
 *
 * @package patient
 */
class StatusController extends RestBaseController
{

    /**
     * Holds the status service object
     *
     * @var \Generic\Patient\StatusService
     */
    protected $statusService;

    /**
     * Get the status service object on demand
     *
     * @return \Generic\Patient\StatusService
     */
    private function getStatusService()
    {
        if (!($this->statusService instanceof \Generic\Patient\StatusService)) {
            $this->statusService = new \Generic\Patient\StatusService();
        }

        return $this->statusService;
    }

    /**
     * Set the status service - Thsi us used in php unit when we want to set the mcok object
     *
     * @param \Generic\Patient\StatusService $status
     */
    public function setStatusService(\Generic\Patient\StatusService $status)
    {
        if (!($this->statusService instanceof \Generic\Patient\StatusService)) {
            $this->statusService = $status;
        }
    }

    /**
     * Get action for status
     *
     * @param integer $id
     *
     * @return void
     *
     * @todo Need to implement
     */
    public function getAction($id)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * Get list action for status
     *
     * @return array
     */
    public function getListAction()
    {
        try {
            $result = $this->getStatusService()->getStatus();
            if (count($result) == 0) {
                $this->getMeta()->addMessage(META::STATUS_ERROR, "No Records Found");
            } else {
                $this->getMeta()->setCount(count($result));
                return $result;
            }
        } catch (\Exception $e) {
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, $e->getMessage());
        }
    }

    /**
     * create action for status
     *
     * @param array $data
     *
     * @return void
     *
     * @todo Need to implement
     */
    public function createAction($data)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * update action for status
     *
     * @param integer $id
     * @param array $data
     *
     * @return void
     *
     * @todo Need to implement
     */
    public function updateAction($id, $data)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * delete action for status
     *
     * @param integer $id
     *
     * @return void
     *
     * @todo Need to implement
     */
    public function deleteAction($id)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * delete list action for status
     *
     * @return void
     *
     * @todo Need to implement
     */
    public function deleteListAction()
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }
}
