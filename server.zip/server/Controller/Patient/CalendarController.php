<?php

namespace Controller\Patient;

use Patient\PatientService;
use Actinidium\API\Response\Meta;
use Generic\EmployeeService;
use Calendar\AppointmentService;
use Calendar\AppointmentSearchCriteria;
use Actinidium\API\RestBaseController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use DateTime;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/patient",
 *     basePath="/api/v2"
 * )
 */
class CalendarController extends RestBaseController
{
    /**
     * Returns appointments that belong to the given Employee and are attached to the given patient.
     *
     * @SWG\Api(
     *   path="/patient-calendar",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Returns appointments that belong to the given Employee and are attached to the given patient.",
     *           @SWG\Parameter(name="patientId", type="integer", required=true, paramType="query"),
     *           @SWG\Parameter(name="employeeId", type="integer", required=false, paramType="query"),
     *           @SWG\Parameter(
     *               name="start_date",
     *               type="string",
     *               required=false,
     *               description="All appointments planned from the startdate given.",
     *               paramType="query"
     *           )
     *       )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function getAction(Request $request)
    {
        $response = new JsonResponse();
        $response->setPublic();
        $response->setMaxAge(300);
        $response->headers->addCacheControlDirective('must-revalidate', true);

        $criteria = new AppointmentSearchCriteria();
        $patientService = new PatientService();
        $patientId = $request->query->get('patientId');
        $patient = $patientService->find($patientId);

        if (null === $patient) {
            $this
                ->getMeta()
                ->addMessage(
                    Meta::STATUS_ERROR,
                    $this->get('medicore.message.message_handler')->getOne('GV9', array('object' => 'patient', 'input' => $patientId))
                );

            return $response;
        }

        $appointmentService = new AppointmentService();
        $startDate = $request->query->get('startDate', null);

        $criteria->setPatient($patient);
        $criteria->setStartDate($startDate !== null ? new DateTime($startDate) : null);

        if (null !== ($employeeId = $request->query->get('employeeId', null))) {
            $employeeService = new EmployeeService();
            $employee = $employeeService->findOneById($employeeId);

            if (null === $employee) {
                $this
                    ->getMeta()
                    ->addMessage(
                        Meta::STATUS_ERROR,
                        $this->get('medicore.message.message_handler')->getOne('GV9', array('object' => 'employee', 'input' => $employeeId))
                    );

                return $response;
            }

            $criteria->setEmployee($employee);
        }

        $appointments = $appointmentService->getAppointments($criteria);

        return $this->createRestResponseFromAppointments($appointments, $response);
    }

    /**
     * Transform appointments obtained to a REST response.
     *
     * @param array                                          $appointments
     * @param \Symfony\Component\HttpFoundation\JsonResponse $response
     *
     * @return \Symfony\Component\HttpFoundation\Response
     */
    private function createRestResponseFromAppointments(array $appointments, JsonResponse $response)
    {
        $data = array();

        foreach ($appointments as $appointment) {
            $hasAppointmentType = (null !== $appointment->getAppointmentType());
            $hasMainCareProvider = (null !== $appointment->getMainCareProvider());

            $data[] = array(
                'id'               => $appointment->getId(),
                'date'             => $appointment->getDtEnd()->format('Y-m-d'),
                'timeStart'        => $appointment->getDtStart()->format('H:i'),
                'timeEnd'          => $appointment->getDtEnd()->format('H:i'),
                'clinic'           => $appointment->getClinic() ? $appointment->getClinic()->toListArray() : null,
                'appointmentType'  => $hasAppointmentType ? $appointment->getAppointmentType()->toListArray() : null,
                'mainCareProvider' => $hasMainCareProvider ? $appointment->getMainCareProvider()->toListArray() : null,
                'status'           => $appointment->getStatus() ? $appointment->getStatus()->toListArray() : null,
                'note'             => $appointment->getNotes(),
            );
        }

        $this->getMeta()->setCount(count($data));

        $response->setData(array('data' => $data));

        return $response;
    }
}

