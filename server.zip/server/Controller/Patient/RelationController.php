<?php
/**
 * MCIS
 *
 * @author surendra.yallabandi<surendra.yallabandi@medicore.nl>
 *
 * @package Patient
 */

namespace Controller\Patient;

use Actinidium\API\MetaBaseController;
use Actinidium\API\Response\Meta;
use Generic\Patient;
use Generic\PatientService;
use Actinidium\API\RestBaseController;

/**
 * Relation
 *
 * Callable via /api/Patient-Relation
 */
class RelationController extends RestBaseController
{

    protected $relationService;


    /**
     * Get the Relation Service object on demand
     *
     * @return \Patient\RelationService
     */
    private function getRelationService()
    {
        if (!($this->relationService instanceof \Patient\RelationService)) {
            $this->relationService = new \Patient\RelationService();
        }

        return $this->relationService;
    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::getAction()
     */
    public function getAction($id)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::getListAction()
     */
    public function getListAction()
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::createAction()
     */
    public function createAction($data)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");

    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::deleteAction()
     */
    public function deleteAction($id)
    {
        $requestData = $this->getRequest()->query;

        $id = $requestData->get('id');

        try {
            $result = $this->getRelationService()->delete($id);
            return $result;
        } catch (\Patient\Generic\PatRegException $e) {
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, $e->getMessage());
        } catch (\Exception $e) {
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, $e->getMessage());
        }

    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::deleteListAction()
     */
    public function deleteListAction()
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");

    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::updateAction()
     */
    public function updateAction($id, $data)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }
}
