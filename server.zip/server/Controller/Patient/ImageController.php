<?php

namespace Controller\Patient;

use Actinidium\API\MetaBaseController;
use Actinidium\API\Response\Meta;
use Generic\Patient;
use Generic\PatientService;
use Actinidium\API\RestBaseController;
use Actinidium\API\Response;
use Patient\ImageService as ImageService;
use Patient\Generic\PatRegException as PatRegException;

/**
 * ImageController.
 *
 * Callable via /api/patient-image/
 */
class ImageController extends RestBaseController
{
    /**
     * Holds Image Service object
     *
     * @var \Patient\ImageService
     */
    protected $imageService;

    /**
     * Get the image service object on demand.
     *
     * @return ImageService
     */
    private function getImageService()
    {
        if (!($this->imageService instanceof ImageService)) {
            $this->imageService = new ImageService;
        }

        return $this->imageService;
    }

    /**
     * Get photo.
     *
     * @see \Actinidium\API\RestBaseController::getAction()
     */
    public function getAction($id)
    {
        try {
            $default = $this->getRequest()->query->get('default', false);
            $file = $this->getImageService()->getPhoto($id, $default);
            $this->setResponseType(Response::FILE);
            return $file;
        } catch (PatRegException $e) {
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, $e->getMessage());
        } catch (\Exception $e) {
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, $e->getMessage());
        }


    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::getListAction()
     */
    public function getListAction()
    {
        $patientId = $this->getRequest('patientId');
        try {
            $this->getImageService()->findByPatient(array('patient' => $patientId));
        } catch (PatRegException $e) {
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, $e->getMessage());
        }
    }

    /**
     * Upload patient image
     *
     * @see \Actinidium\API\RestBaseController::createAction()
     */
    public function createAction($data)
    {
        $id = $data['id'];
        $data = $this->getRequest()->get('imageData');

        try {
            return $this->getImageService()->setProfileImage($id, $data);
        } catch (PatRegException $e) {
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, $e->getMessage());
        } catch (\Exception $e) {
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, $e->getMessage());
        }

    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::deleteAction()
     */
    public function deleteAction($id)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::deleteListAction()
     */
    public function deleteListAction()
    {

        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     *(non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::updateAction()
     */
    public function updateAction($id, $data)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * Set the image service - This is used in phpunit when we want to set the mock object.
     *
     * @param ImageService $imageService
     */
    public function setImageService(ImageService $imageService)
    {
        if (!($this->imageService instanceof ImageService)) {
            $this->imageService = $imageService;
        }
    }
}
