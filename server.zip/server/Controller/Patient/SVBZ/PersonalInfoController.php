<?php
/**
 * MCIS
 *
 * @author surendra yallabandi<surendra.yallabandi@medicore.nl>
 *
 * @package Patient\SVBZ
 */

namespace Controller\Patient\SVBZ;

use Actinidium\API\MetaBaseController;
use Actinidium\API\Response\Meta;
use Patient\Patient;
use Patient\PatientService;
use Controller\AbstractController;

/**
 * PatientRestController
 *
 * Callable via /api/Patient-SVBZ-PersonalInfo
 */
class PersonalInfoController extends AbstractController
{

    /**
     * Holds the external service to call the legacy code 1.1
     *
     * @var \Patient\External\Sbvz\PersonalInfoService
     */
    protected $externalService;

    /**
     * Holds the validation service to validate input
     *
     * @var \Patient\External\Sbvz\ValidationService
     */
    private $validationService;

    /**
     * Dummy BSN value for testing purpose.
     */
    const DUMMY_BSN_FOR_TESTING = '123456782';

    /**
     * Get the external service object on demand
     *
     * @return \Patient\External\Sbvz\PersonalInfoService
     */
    private function getExternalService()
    {
        if (!$this->externalService instanceof \Patient\External\Sbvz\PersonalInfoService) {
            $this->externalService = new \Patient\External\Sbvz\PersonalInfoService();
        }
        return $this->externalService;

    }

    /**
     * Get the validation service object on demand.
     *
     * @return \Patient\External\Sbvz\ValidationService
     */
    private function getValidationService()
    {
        if (!$this->validationService instanceof \Patient\External\Sbvz\ValidationService) {
            $this->validationService = new \Patient\External\Sbvz\ValidationService();
        }

        return $this->validationService;
    }


    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::getAction()
     */
    public function getAction($id)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::getListAction()
     */
    public function getListAction()
    {
        //Hard coded as one sine form the old code in MCIS it always sends one
        //Refer - old/module_classes/svbzconnectivity/bsnwidcheck.js
        //this.id =1 has been hard-coded
        $id = $this->getRequest()->query->get('id', '1');
        $postData = $this->getPostData();
        if (array_key_exists('bsnValue', $postData)
            && $postData['bsnValue'] == self::DUMMY_BSN_FOR_TESTING) {

            return $this->getMeta()->addMessage(Meta::STATUS_SUCCESS, '');
        }
        $this->validatePostData($postData);

        if (!$this->hasError()) {
            try {
                $externalService = $this->getExternalService();
                $result = $externalService->bsnPersonInfo($postData);

                if ($externalService->hasErrors()) {
                    $this->addErrorsToMeta($externalService->getErrors());
                }

                if ($externalService->hasMessages()) {
                    $this->addMessagesToMeta($externalService->getMessages());
                }

                if (!$this->getMeta()->hasError() && !$externalService->hasErrors()) {
                    $this->getMeta()->setCount(1);
                }
                return $result;
            } catch (\Patient\Generic\PatRegException $e) {
                $this->getMeta()->addMessage(Meta::STATUS_ERROR, $e->getMessage());
            } catch (\Exception $e) {
                $this->getMeta()->addMessage(Meta::STATUS_ERROR, $e->getMessage());
            }
        }
    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::createAction()
     */
    public function createAction($data)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::deleteAction()
     */
    public function deleteAction($id)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::deleteListAction()
     */
    public function deleteListAction()
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::updateAction()
     */
    public function updateAction($id, $data)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * Function to get the posted data from the request.
     *
     * @return array
     */
    private function getPostData()
    {
        $query = $this->getRequest()->query;

        $bsn = $query->get('bsnValue');
        $postData = array(
            'bsnValue' => $bsn,
            'id' => 1
        );

        return $postData;
    }

    /**
     * Function to validate the posted data.
     *
     * Any failures will be added to the Meta.
     *
     * @param array $postData
     */
    private function validatePostData(array $postData)
    {
        $validationService = new \Patient\External\Sbvz\ValidationService();
        $mandatoryFields = $validationService->getMandatoryFields('personInfo');

        $this->processMandatoryFields($mandatoryFields, $postData);
        if ($this->hasError() === false) {
            $this->validateSbvzParameters($postData, $mandatoryFields);
        }
    }

    /**
     * Function to validate the parameters.
     *
     * @param array $data
     * @param array $mandatoryFields
     */
    private function validateSbvzParameters($data, $mandatoryFields)
    {
        $validationService = new \Patient\External\Cov\ValidationService();

        foreach ($data as $field => $value) {

            if ($this->requiresValidation($field, $value, $mandatoryFields) === true) {
                $validators = array();

                $validators = $validationService->getValidationsByField($field, $value, $data);

                $this->executeValidators($validators);
            }
        }

    }
}
