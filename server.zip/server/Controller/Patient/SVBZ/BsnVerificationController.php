<?php
/**
 * MCIS
 *
 * @author surendra yallabandi<surendra.yallabandi@medicore.nl>
 *
 * @package Patient\SVBZ
 */

namespace Controller\Patient\SVBZ;

use Actinidium\API\MetaBaseController;
use Actinidium\API\Response\Meta;
use Controller\AbstractController;
use Security\Sanitizer;

/**
 * PatientRestController
 *
 * Callable via /api/Patient-SVBZ-BsnVerification
 */
class BsnVerificationController extends AbstractController
{
    /**
     * Holds the external service to call the legacy code 1.1
     *
     * @var \Patient\ExternalService
     */
    protected $externalService;

    /**
     * Get the external service object on demand
     *
     * @return \Patient\ExternalService
     */
    private function getExternalService()
    {
        if (!($this->externalService instanceof \Patient\ExternalService)) {
            $this->externalService = new \Patient\ExternalService();
        }
        return $this->externalService;

    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::getAction()
     */
    public function getAction($id)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::getListAction()
     */
    public function getListAction()
    {
        $query = $this->getRequest()->query;

        $bsn = $query->get('bsnValue');
        $sex = $query->get('gender');
        //Last Name is to be sent
        $name = $query->get('name');
        $dateOfBirth = $query->get('dateOfBirth');
        //Hard coded as one sine form the old code in MCIS it always sends one
        //Refer - old/module_classes/svbzconnectivity/bsnwidcheck.js
        //this.id =1 has been hard-coded
        $id = $query->get('id', '1');

        $manuallyVerifyBsn = Sanitizer::boolean($query->get('manual'));

        //dummy bsn for testing purposes
        if ($bsn == 999999999) {
            $this->getMeta()->addMessage(
                Meta::STATUS_SUCCESS,
                $this->messageHandler->getOne('AC-M7', null)
            );
            $this->getMeta()->setCount(1);
            return array("result" => "G");
        }

        try {
            $params = array();
            $externalService =  $this->getExternalService();
            $params = $externalService->bsnCheckData($bsn, $sex, $name, $dateOfBirth, $id);
            $this->validateValues($bsn, $sex, $name, $dateOfBirth);

            if (!$this->hasError()) {
                $result = $externalService->getBsnCheckInfo($params);
            }

            if ($externalService->hasErrors() && $manuallyVerifyBsn !== true) {
                $this->addErrorsToMeta($externalService->getErrors());
                return $result;
            }

            if ($externalService->bsnCanBeVerifiedManually === true && $manuallyVerifyBsn === true) {
                // BSN is verified manually
                $result = $externalService->bsnVerifiedManually();
            }

            $this->addErrorsToMeta($externalService->getMessages());
            $this->getMeta()->setCount(1);

            return $result;
        } catch (\Patient\Generic\PatRegException $e) {
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, $e->getMessage());
        } catch (\Exception $e) {
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, $e->getMessage());
        }
    }

    /**
     * Function to validate the values that are passed to the API.
     *
     * @param string $bsn
     * @param string $sex; On of the following: male, female
     * @param string $name
     * @param $dateOfBirth
     *
     * @return void;
     */
    public function validateValues($bsn, $sex, $name, $dateOfBirth)
    {
        $this->validateBSN($bsn, 'BSN');
        $this->validatePredefinedValue('gender', $sex, array('male', 'female'));
        $this->validatePastDate($dateOfBirth, 'dateOfBirth');
        $this->validateString($name, 'name');

    }
    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::createAction()
     */
    public function createAction($data)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::deleteAction()
     */
    public function deleteAction($id)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::deleteListAction()
     */
    public function deleteListAction()
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::updateAction()
     */
    public function updateAction($id, $data)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }
}
