<?php

namespace Controller\Patient\SVBZ;

use Controller\AbstractController;
use Actinidium\API\MetaBaseController;
use Actinidium\API\Response\Meta;
use Patient\Patient;
use Patient\PatientService;

/**
 * WID Verification Controller.
 *
 * Callable via /api/Patient-SVBZ-WidVerification
 */
class WidVerificationController extends AbstractController
{

    /**
     * Holds the external service to call the legacy code 1.1.
     *
     * @var \Patient\ExternalService
     */
    protected $externalService;

    /**
     * Get the external service object on demand.
     *
     * @return \Patient\ExternalService
     */
    private function getExternalService()
    {
        if (!($this->externalService instanceof \Patient\ExternalService)) {
            $this->externalService = new \Patient\ExternalService();
        }
        return $this->externalService;

    }

    /**
     * WID Verification Controller for get Action.
     *
     * @see \Actinidium\API\RestBaseController::getAction()
     */
    public function getAction($id)
    {

    }

    /**
     * WID Verifiction List controller Action.
     *
     * @see \Actinidium\API\RestBaseController::getListAction()
     *
     * @return null | array
     */
    public function getListAction()
    {
        $query = $this->getRequest()->query;
        $documentVerificationData = array();

        $documentVerificationData['bsn'] = $query->get('bsnValue');
        $documentVerificationData['documentType'] = $query->get('widtype');
        $documentVerificationData['documentNumber'] = $query->get('widnumber');
        $validationService = new \Patient\Field\ValidationService();
        //Mandatory fields and Document Format validation
        $errors =  $validationService->validateWidVerificationFields($documentVerificationData);
        if (count($errors)) {
            $this->addErrorsToMeta($errors);
        }
        //BSN validation
        if (!empty($documentVerificationData['bsn'])) {
            //Handle BSN validation seperately and validateBSN errors will be add to Meta.
            $this->validateBSN($documentVerificationData['bsn'], 'bsnValue');
        }

        if ($this->hasError()) {
            return;
        }

        //Hard coded as one sine form the old code in MCIS it always sends one
        //Refer - old/module_classes/svbzconnectivity/bsnwidcheck.js
        //this.id =1 has been hard-coded
        $id = $query->get('id', '1');
        $externalService = $this->getExternalService();
        try {
            $widParams = $externalService->widCheckData(
                $documentVerificationData['bsn'],
                $documentVerificationData['documentType'],
                $documentVerificationData['documentNumber'],
                $id
            );
            $returnData = $externalService->getWidCheck($widParams);
            $errors = $this->getExternalService()->getErrors();
            if ($errors) {
                $this->addErrorsToMeta($errors);
            }

            if ($returnData['status'] && $returnData['result'] == 'G') {
                $this->getMeta()->setCount(1);
                $this->getMeta()->addMessage(
                    Meta::STATUS_SUCCESS,
                    $this->messageHandler->add(
                        'AC-M3',
                        \Message\MessageHandler::CONFIRMATION
                    )
                );
            }

            return $returnData;
        } catch (\Exception $e) {
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, $e->getMessage());
        }
    }

    /**
     * WID Verification Controller for Create Action.
     *
     * @see \Actinidium\API\RestBaseController::createAction()
     */
    public function createAction($data)
    {
    }

    /**
     * WID Verification Controller for Delete Action.
     *
     * @see \Actinidium\API\RestBaseController::deleteAction()
     */
    public function deleteAction($id)
    {
    }

    /**
     * WID Verification Controller for Delete List Action.
     *
     * @see \Actinidium\API\RestBaseController::deleteListAction()
     */
    public function deleteListAction()
    {
    }

    /**
     * WID Verification Controller for Update Action.
     *
     * @see \Actinidium\API\RestBaseController::updateAction()
     */
    public function updateAction($id, $data)
    {
    }
}
