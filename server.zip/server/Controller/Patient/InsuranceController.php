<?php

namespace Controller\Patient;

use Patient\InsuranceService;
use Medicore\Component\PatientInsurance\Service\BlenderService;
use Patient\PatientService;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Actinidium\API\RestBaseController;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/patient-insurance",
 *     basePath="/api/v2"
 * )
 */
class InsuranceController extends RestBaseController
{
    /** @var PatientService */
    private $patientService;

    /** @var InsuranceService */
    private $insuranceService;

    /** @var BlenderService */
    private $blenderService;

    /**
     * @param PatientService $patientService
     * @param InsuranceService $insuranceService
     * @param BlenderService $blenderService
     */
    public function __construct(
        PatientService $patientService,
        InsuranceService $insuranceService,
        BlenderService $blenderService
    ) {
        $this->patientService = $patientService;
        $this->insuranceService = $insuranceService;
        $this->blenderService = $blenderService;
    }

    /**
     * @SWG\Api(
     *   path="/patient-insurance?patientId={patientId}",
     *   @SWG\Operation(
     *       method="PUT",
     *       summary="Validate set of patient insurances, run business rules, return blended patient insurance set",
     *       notes="Returns a set of patient insurances",
     *       @SWG\Parameter(name="patientId", type="integer", required=true),
     *       @SWG\Parameter(
     *           name="body",
     *           description="Patient Insurance set. See \Patient\Insurance toArray() as reference.",
     *           required=true,
     *           type="\Patient\Insurance",
     *           paramType="body",
     *           allowMultiple=true
     *       )
     *   )
     * )
     *
     * This action is used to validate and blend the Patient Insurances. This action is not used to do saving actions
     * on the database. With this action, the insurances will be validated, blended and returned.
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function updateAction(Request $request)
    {
        $patientService = $this->patientService;
        $insuranceService = $this->insuranceService;
        $blenderService = $this->blenderService;

        $patientId = $request->query->get('patientId');
        $data = json_decode($request->getContent(), true);
        $insuranceData = $data['insurances'];
        $insurances = array();

        if (count($insuranceData) > 0) {
            $patient = $patientService->find($patientId);
            $insurances = $insuranceService->createInsuranceCollection($patient, $insuranceData);
        }

        $result = $blenderService->applyBusinessRules($insurances);

        $response = new JsonResponse();
        $response->setPublic();
        $response->setMaxAge(300);
        $response->headers->addCacheControlDirective('must-revalidate', true);
        $response->setData(array('data' => $result));

        return $response;
    }
}
