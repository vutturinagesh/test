<?php

namespace Controller;

use Actinidium\API\Response\Meta;
use Actinidium\API\Response\NonCachedJsonResponse;
use Controller\ValidationResult;
use Doctrine\Common\Collections\ArrayCollection;
use Exception;
use Generic\Authorizer;
use Generic\Customer;
use Generic\CustomerService;
use Generic\Employee;
use Generic\EmployeeService;
use Generic\Patient;
use Generic\PatientService;
use Generic\Specialism;
use Generic\SpecialismService;
use Generic\SystemInstitutionService;
use Generic\SystemProviderService;
use Generic\Validation\EventHandler;
use Medical\Episode;
use Medical\EpisodeService;
use Medical\Treatment;
use Medical\TreatmentService;
use Message\MessageHandler;
use Security\Sanitizer;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Validation\DotValidationResult;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/episode",
 *     basePath="/api/v2"
 * )
 */
class EpisodeController extends AbstractController
{
    const ACTION_EDIT = 'edit';

    /**
     * @var \Generic\PatientService
     */
    private $patientService;

    /**
     * @var \Generic\SpecialismService
     */
    private $specialtyModel;

    /**
     * @var \Medical\EpisodeService
     */
    private $episodeService;

    /**
     * @var \Generic\Authorizer
     */
    private $authorizer;

    /**
     * @var \Medical\TreatmentService
     */
    private $treatmentService;

    /**
     * Constructor.
     *
     * @param \Medical\EpisodeService   $episodeService
     * @param \Generic\Authorizer       $authorizer
     * @param \Generic\PatientService   $patientService
     * @param \Medical\TreatmentService $treatmentService
     */
    public function __construct(
        EpisodeService $episodeService = null,
        Authorizer $authorizer = null,
        PatientService $patientService = null,
        TreatmentService $treatmentService = null
    ) {
        parent::__construct();

        if (null === $episodeService) {
            $episodeService = $this->get('medicore.medical.episode_service');
        }

        if (null === $authorizer) {
            $authorizer = $this->get('medicore.generic.authorizer');
        }

        if (null === $patientService) {
            $patientService = $this->get('medicore.generic.patient_service');
        }

        if (null === $treatmentService) {
            $treatmentService = $this->get('medicore.medical.treatment_service');
        }

        $this->episodeService = $episodeService;
        $this->authorizer = $authorizer;
        $this->patientService = $patientService;
        $this->treatmentService = $treatmentService;
    }

    /**
     * @SWG\Api(
     *   path="/episode/list",
     *   @SWG\Operation(
     *      method="GET",
     *      summary="Returns a list of episodes for patient.",
     *      @SWG\Parameter(
     *          name="patientId",
     *          type="integer",
     *          required=false,
     *          description="The episode id",
     *          paramType="query"
     *      )
     *   )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function getListAction(Request $request)
    {
        $response = new NonCachedJsonResponse();

        $patient = $this->patientService->find($request->get('patientId'));

        if (null === $patient) {
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne('GV9')
            );

            return $response;
        }

        $episodes = $this->episodeService->findAllOrderBy(
            array('patient' => $patient),
            array("startDate" => "DESC"),
            false
        );

        $authorizer = $this->authorizer;

        array_walk(
            $episodes,
            function (Episode $episode) use ($authorizer) {
                $treatments = $authorizer->filterTreatments($episode->getTreatments());

                $treatments = $treatments->filter(
                    function (Treatment $treatment) {
                        return !$treatment->isCancelled();
                    }
                );

                $episode->setAmountNonCancelledTreatments(count($treatments));
            }
        );

        $episodes = $authorizer->filterEpisodes(new ArrayCollection($episodes));

        $numberOfNonCancelledEpisodes = count(
            $episodes->filter(
                function (Episode $episode) {
                    return !$episode->isCancelled();
                }
            )
        );

        $treatmentService = $this->treatmentService;
        $data = array_filter(
            array_map(
                function (Episode $episode) use ($treatmentService) {
                    $episodeArray = $episode->toArray();
                    $episodeArray['numberOfOpenTreatments'] =
                        (int)$treatmentService->getNumberOfOpenTreatments($episode);
                    return $episodeArray;
                },
                $episodes->toArray()
            )
        );

        $this->getMeta()->setCount($numberOfNonCancelledEpisodes);

        $response->setData(array('data' => $data));

        return $response;
    }

    /**
     * @SWG\Api(
     *  path="/episode",
     *  @SWG\Operation(
     *      summary = "Get a single episode details.",
     *      method  = "GET",
     *      type    = "Episode",
     *      @SWG\Parameter(
     *          name      = "id",
     *          type      = "integer",
     *          paramType = "query",
     *          required  = true
     *      )
     *   )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function getAction(Request $request)
    {
        $response = new JsonResponse();

        $requestParameters = $request->query->all();

        $episode = $this->validateId($requestParameters['id']);

        if (!$this->getMeta()->hasError()) {
            if (!$this->authorizer->isEpisodeAccessible($episode)) {
                return $response;
            }

            $treatments = $this->authorizer->filterTreatments($episode->getTreatments());
            $treatments = $treatments->filter(function(Treatment $treatment) {
                return !$treatment->isCancelled();
            });

            $episode->setAmountNonCancelledTreatments(count($treatments));

            if (!$this->getMeta()->hasError()) {
                $response->setData(array('data' => $episode->toArray()));
            }
        }

        return $response;
    }

    /**
     * @SWG\Api(
     *  path="/episode",
     *  @SWG\Operation(
     *      summary="Create an Episode.",
     *      method="POST",
     *      @SWG\Parameter(
     *          name="patientId",
     *          description="Id of the patient.",
     *          required=true,
     *          type="integer",
     *          paramType="body"
     *      ),
     *      @SWG\Parameter(
     *           name="startDate",
     *          description="Date of episode start.",
     *          required=true,
     *          type="string",
     *          paramType="body"
     *      ),
     *      @SWG\Parameter(
     *          name="specialtyId",
     *          description="Id of the speciality.",
     *          required=true,
     *          type="integer",
     *          paramType="body"
     *      ),
     *      @SWG\Parameter(
     *          name="name",
     *          description="Name of the episode, Mandatory for MHC, Optional for somatic.",
     *          required=false,
     *          type="string",
     *          paramType="body"
     *      )
     *   )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function createAction(Request $request)
    {
        $response = new JsonResponse();
        $data = json_decode($request->getContent(), true);

        $patient = $this->validatePatientId($data['patientId']);
        $startDate = $this->validateDate($data['startDate'], "startDate");
        $specialty = $this->validateSpecialtyId($data['specialtyId'], $startDate);

        if ($this->isSomatic()) {
            $name = $this->validateAndPrepareDefaultName($data, $patient, $specialty);
        } else {
            $name = $this->validateName($data['name']);
        }

        if (!$this->getMeta()->hasError()) {
            $episode = $this->episodeService->create(
                $patient,
                $name,
                $startDate,
                $specialty
            );

            $validationResults = $this->episodeService->getMeta();
            DotValidationResult::addMessagesToMeta($validationResults, $this->getMeta());

            if ($episode) {
                $response->setData(array('data' => $episode->toArray()));
            }
        }

        return $response;
    }

    /**
     * Validate a patient ID, return patient object.
     *
     * @param int $patientId
     *
     * @return \Generic\Patient|null
     */
    public function validatePatientId($patientId)
    {
        $patient = $this->createEntity($patientId, "patientId", $this->patientService, "Generic\\Patient");

        return $patient;
    }

    /**
     * Validates specialty.
     *
     * @param int       $specialtyId
     * @param \dateTime $startDate
     *
     * @return \Generic\Specialism|null
     */
    public function validateSpecialtyId($specialtyId, $startDate)
    {
        $specialtyModel = $this->getSpecialtyModel();
        $specialty = $this->createEntity($specialtyId, "specialtyId", $specialtyModel, "Generic\\Specialism");

        // validate specialty
        if (!is_Null($startDate) && !is_Null($specialty)) {


            if (!($specialty->getStartDate() <= $startDate && $specialty->getEndDate() >= $startDate)) {
                $code = 'M147';
                $params = array('object' => 'Specialty', 'input' => $startDate);
                $this->getMeta()->addMessage(
                    Meta::STATUS_ERROR,
                    $this->messageHandler->getOne($code, $params)
                );
            }
        }

        return $specialty;
    }

    /**
     * So that we can mock this in our phpunit.
     *
     * @return \Generic\SpecialismService
     */
    protected function getSpecialtyModel()
    {
        if (!$this->specialtyModel) {
            $this->specialtyModel = new SpecialismService();
        }

        return $this->specialtyModel;
    }

    /**
     * @SWG\Api(
     *  @SWG\Operation(
     *  summary="Update Episode.",
     *      method="PUT",
     *      type="Episode",
     *      @SWG\Parameter(
     *          name="id",
     *          description="Id of the episode.",
     *          required=true,
     *          type="integer",
     *          paramType="body"
     *      ),
     *      @SWG\Parameter(
     *          name="startDate",
     *          description="Date of episode start.",
     *          required=true,
     *          type="string",
     *          paramType="body"
     *      ),
     *      @SWG\Parameter(
     *          name="specialtyId",
     *          description="Id of the speciality.",
     *          required=true,
     *          type="integer",
     *          paramType="body"
     *      ),
     *      @SWG\Parameter(
     *          name="name",
     *          description="Name of the episode",
     *          required=true,
     *          type="string",
     *          paramType="body"
     *      ),
     *      @SWG\Parameter(
     *          name="status",
     *          description="Used to update the status of episode to cancel/close/reopen.",
     *          required=false,
     *          type="string",
     *          enum="['cancel','close','reopen']",
     *          paramType="body"
     *      )
     *   )
     * )
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function updateAction(Request $request)
    {
        $response = new JsonResponse();
        $data = json_decode($request->getContent(), true);
        
        $action = $request->get('action');
        $episode = $this->validateId($data['id']);

        if ($this->hasError()) {
            return $response;
        }

        if (!$this->authorizer->isEpisodeAccessible($episode)) {
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne('UR3')
            );

            return $response;
        }

        if (array_key_exists("status", $data)) {
            $action = $data['status'];
        }

        switch ($action) {
            case 'externalReferrerGp':
                $return = $this->editExternalReferrerGp(
                    $episode,
                    $data['careInstitutionId'],
                    $data['careProviderId'],
                    $data['referrerDate'],
                    $data['emergencyRoom']
                );
                break;
            case 'cancel':
                $return = $this->cancel($episode);
                break;
            case 'reopen':
                $return = $this->reopen($episode);
                break;
            case 'close':
                $return = $this->close($episode, $data['endDate']);
                break;
            default:
                $return = $this->edit($episode, $data);
                break;
        }

        $response->setData(array('data' => $return));
        return $response;
    }

    /**
     * Check if episode is writable or not.
     *
     * @param \Medical\Episode $episode
     *
     * @return boolean
     */
    public function isEpisodeWritable(Episode $episode)
    {
        $customerService = new CustomerService();
        if ($customerService->getCareType() == Customer::CARETYPE_SOMATIC) {
            $treatments = $episode->getTreatments();

            $employeeModel = new EmployeeService();
            $currentEmployee = $employeeModel->getCurrentEmployee();

            if (count($treatments) == 0) {
                if ($currentEmployee->isSupportAccount() || $currentEmployee->isAttendingPhysician()) {
                    return true;
                } else {
                    return false;
                }
            }

            $employeeAuthorizer = $this->authorizer;
            foreach ($treatments as $treatment) {
                if ($employeeAuthorizer->hasValidAccess(
                    $treatment->getSpecialist(),
                    Authorizer::ACCESS_WRITE
                )
                ) {
                    return true;
                }
            }

        } else {
            // For MHC
            return true;
        }

        return false;
    }

    /**
     * Edit the episode.
     *
     * @param \Medical\Episode $episode
     * @param array            $data
     *
     * @return array
     */
    public function edit(Episode $episode, array $data)
    {
        $return = array();
        $params = array();
        $startDate = null;

        $validationEvents = array();

        if (array_key_exists('startDate', $data)) {
            $startDate = $this->validateStartDate($data['startDate']);
            $validationEvents[] = EventHandler::EVENT_EP_E2_1;
        } else {
            if ($episode) {
                $startDate = $episode->getStartDate();
            }
        }
        $params['startDate'] = $startDate;
        if (array_key_exists('name', $data)) {
            $params['name'] = $this->validateName($data['name']);
        }
        if (array_key_exists('specialtyId', $data)) {
            $specialty = $this->validateSpecialty($data['specialtyId']);
            if (!$this->getMeta()->hasError()) {
                $params['specialty'] = $this->validateSpecialtyIsValidOnDate($startDate, $specialty);
            }
        }

        $params['privacy'] = Sanitizer::boolean($data['privacy']);

        if (!$this->getMeta()->hasError()) {
            $result = $this->episodeService->edit($episode, $params, $validationEvents);
            $validationResults = $this->episodeService->getMeta();
            DotValidationResult::addMessagesToMeta($validationResults, $this->getMeta());
            $errors = $this->episodeService->getErrors();
            if (!empty($errors)) {
                ValidationResult::addToMeta($errors, $this);
            }

            if ($result) {
                $return = $episode->toArray();
            }
        }

        return $return;
    }

    /**
     * Validates start date.
     *
     * @param string $startDate
     *
     * @return \DateTime|null
     */
    private function validateStartDate($startDate)
    {
        return $this->validateDate($startDate, "startDate");
    }

    /**
     * Validates name of the episode.
     *
     * @param string $name
     *
     * @return string
     */
    private function validateName($name)
    {
        if ($this->isRequired($name, "name")) {
            return $this->validateStringLength($name, "name");
        }
    }

    /**
     * Validate if name provided or create new name.
     *
     * @param array                    $data
     * @param \Generic\Patient|null    $patient
     * @param \Generic\Specialism|null $specialty
     *
     * @return string
     */
    private function validateAndPrepareDefaultName($data, Patient $patient = null, Specialism $specialty = null)
    {
        if (array_key_exists('name', $data)) {
            return $this->validateName($data['name'], "name");
        } elseif (($patient instanceof Patient) && ($specialty instanceof Specialism)) {
            return $this->episodeService->getDefaultName($patient, $specialty);
        }
    }

    /**
     * Validate specialty.
     *
     * @param integer $specialtyId
     *
     * @return \Generic\Specialism $specialty
     */
    private function validateSpecialty($specialtyId)
    {
        $specialtyModel = $this->getSpecialtyModel();

        return $this->createEntity($specialtyId, "specialtyId", $specialtyModel, "Generic\\Specialism");
    }

    /**
     * Validate speciality on given date.
     *
     * @param \DateTime           $startDate
     * @param \Generic\Specialism $specialty
     *
     * @return \Generic\Specialism
     */
    private function validateSpecialtyIsValidOnDate(\DateTime $startDate, Specialism $specialty)
    {
        if (!($specialty->getStartDate() <= $startDate && $specialty->getEndDate() >= $startDate)) {
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne(
                    'M147',
                    array('object' => 'Specialty', 'input' => $startDate->format(Date::FORMAT_DATE),)
                )
            );
        }

        return $specialty;
    }

    /**
     * Cancel the episode.
     *
     * @param \Medical\Episode $episode
     *
     * @return array
     */
    private function cancel(Episode $episode)
    {
        $return = array();

        if ($episode) {
            $errors = $this->episodeService->cancelValidation($episode);

            if (!empty($errors)) {
                $this->addErrorsToMeta($errors);
            } else {
                $result = $this->episodeService->cancel($episode);
                if ($result) {
                    $return = $episode->toArray();
                }
            }
        }

        return $return;
    }

    /**
     * Reopen a cancelled/closed episode.
     *
     * @param \Medical\Episode $episode
     *
     * @return array
     */
    private function reopen(Episode $episode)
    {
        $return = array();

        if (!empty($episode)) {
            $errors = $this->episodeService->reopenValidation($episode);
        }
        if (!empty($errors)) {
            foreach ($errors as $error) {
                $this->getMeta()->addMessage(
                    $error['type'],
                    $this->messageHandler->getOne($error['id'], $error['params'])
                );
            }
        }
        if (!$this->getMeta()->hasError()) {
            $result = $this->episodeService->reopen($episode);
            if ($result) {
                $return = $episode->toArray();
            }
        }

        return $return;
    }

    /**
     * Close the episode.
     *
     * @param \Medical\Episode $episode
     * @param string           $endDate
     *
     * @return array
     */
    private function close(Episode $episode, $endDate)
    {
        $return = array();

        $endDateObj = $this->validateDate($endDate, "endDate");
        if ($episode && !empty($endDateObj)) {

            $errors = $this->episodeService->closeValidation($episode, $endDateObj);
            if (!empty($errors)) {
                foreach ($errors as $error) {
                    $this->getMeta()->addMessage(
                        $error['type'],
                        $this->messageHandler->getOne($error['id'], $error['params'])
                    );
                }
            }
        }
        if (!$this->getMeta()->hasError()) {
            $this->episodeService->close($episode, $endDateObj);
            $errors = $this->episodeService->getErrors();
            if (!empty($errors)) {
                foreach ($errors as $error) {
                    $this->getMeta()->addMessage(
                        Meta::STATUS_ERROR,
                        $this->messageHandler->getOne($error['message'])
                    );
                }
            } else {
                $return = $episode->toArray();
            }
        }

        return $return;
    }

    /**
     * Sets dot referrer cod for episode.
     *
     * @param \Medical\Episode $episode
     *
     * @return array
     */
    public function setDOTReferrerCodeAutomatic(Episode $episode)
    {
        $return = array();
        if (!$this->getMeta()->hasError()) {
            $result = $this->episodeService->setDOTReferrerCodeAutomatic($episode);
            if (is_array($result)) {
                $this->getMeta()->addMessage(Meta::STATUS_ERROR, $this->messageHandler->getOne($result['id']));
                $result = array();
            } else {
                if ($result) {
                    $return = $episode->getDOTReferrerCodeData();
                }
            }
        }

        return $return;
    }

    /**
     * Validates care institution.
     *
     * @param int $careInstitutionId
     *
     * @return \Generic\SystemInstitution
     */
    public function validateSystemInstitutionId($careInstitutionId)
    {
        $systemCareInstitutionModel = new SystemInstitutionService();
        $systemCareInstitutionEntity = $this->createEntity(
            $careInstitutionId,
            "careInstitutionId",
            $systemCareInstitutionModel,
            "Generic\\SystemInstitution"
        );

        return $systemCareInstitutionEntity;
    }

    /**
     * call this like: /api/editExternalReferrerGp
     *
     * @param \Medical\Episode $episode
     * @param integer          $careInstitutionId
     * @param integer          $careProviderId
     * @param string           $date
     * @param bool             $emergencyRoom
     *
     * @return array
     */
    private function editExternalReferrerGp(
        Episode $episode,
        $careInstitutionId,
        $careProviderId,
        $date,
        $emergencyRoom
    ) {
        $return = array();
        $careInstitution = $this->validateSystemInstitutionId($careInstitutionId);

        if (!empty($careProviderId)) {
            $careProvider = $this->validateCareProviderId($careProviderId);
        }
        if (!empty($date)) {
            $dateObj = $this->validateDate($date);
        }
        if (!empty($emergencyRoom)) {
            $validateEmergencyRoom = $this->validateEmergencyRoom($emergencyRoom);
            $emergencyRoom = ($emergencyRoom == 'true') ? 1 : 0;
        }

        if (!$this->getMeta()->hasError()) {
            $result = $this->episodeService->editExternalReferrerGp(
                $episode,
                $careInstitution,
                $careProvider,
                $dateObj,
                $emergencyRoom
            );

            if ($result) {
                $return = $episode->toArray();
            }
        }

        return $return;
    }

    /**
     * Make sure that the systemCareProviderId id is valid.
     *
     * @param integer $careproviderId
     *
     * @return \Generic\systemCareProvider
     */
    public function validateCareProviderId($careproviderId)
    {
        $systemCareProviderModel = new SystemProviderService();
        $systemCareProviderEntity = $this->createEntity(
            $careproviderId,
            "careproviderId",
            $systemCareProviderModel,
            "Generic\\SystemProvider"
        );

        return $systemCareProviderEntity;
    }

    /**
     * Validates episode id.
     *
     * @param integer $id
     *
     * @return \Medical\Episode $episode|bool
     */
    protected function validateId($id)
    {
        $episode = $this->createEntity(
            $id,
            'id',
            $this->episodeService,
            "Medical\\Episode"
        );

        return $episode;
    }

    /**
     * Validates emergency room.
     *
     * @param bool $emergencyRoom
     *
     * @return bool
     */
    private function validateEmergencyRoom($emergencyRoom)
    {
        if (is_string($emergencyRoom)) {
            if (!Sanitizer::isBoolean($emergencyRoom)) {
                $this->getMeta()->addMessage(
                    Meta::STATUS_ERROR,
                    $this->messageHandler->getOne(
                        'MG101',
                        MessageHandler::BLOCKING,
                        array(
                            'field_name' => 'emergencyRoom',
                            'input' => $emergencyRoom
                        )
                    )
                );

            } else {
                $emergencyRoom = Sanitizer::boolean($emergencyRoom);
            }
        }

        return $emergencyRoom;
    }
}
