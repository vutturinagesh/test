<?php

namespace Controller;

use Communication\LetterService;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/letter",
 *     basePath="/api/v2"
 * )
 */
class LetterController extends AbstractController
{
    /** @var string */
    const SEARCH_DEFAULT_LABEL = 'default';

    /** @var \Communication\LetterService */
    private $letterService;

    /**
     * @param \Communication\LetterService $letterService
     */
    public function __construct(LetterService $letterService) {
        parent::__construct();

        $this->letterService = $letterService;
    }

    /**
     * @SWG\Api(
     *     path="/letter",
     *     @SWG\Operation(
     *         method="GET",
     *         summary="Get a list of letters and labels.",
     *         notes="Get all letters, or the default, by setting parameter 'type=default'.",
     *         @SWG\Parameter(name="type", type="string", description="'default' for the default label.", required=false, paramType="query"),
     *     )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function getListAction(Request $request)
    {
        if ($request->query->has('type')) {
            if ($request->query->get('type') == static::SEARCH_DEFAULT_LABEL) {
                $letters = $this->letterService->getDefaultLetter();
            } else {
                $this->addInvalidInputMessageToMeta('type', $request->query->get('type'));
            }
        } else {
            $letters = $this->letterService->findAll();
        }

        $response = new JsonResponse();
        $response->setData(array('data' => $this->letterService->normalize($letters)));

        return $response;
    }
}
