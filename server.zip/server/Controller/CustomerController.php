<?php
namespace Controller;

use Actinidium\API\MetaBaseController;
use Actinidium\API\AnonymousAccessInterface;
use Actinidium\API\Response\Meta;
use Generic\Customer;
use Generic\CustomerService;

/**
 *
 * Callable via /api/customer
 */
class CustomerController extends MetaBaseController implements AnonymousAccessInterface
{

    const CARETYPE_MHC = 'mhc';
    const CARETYPE_SOM = 'som';

    /**
     * Check if anonymous access is allowed
     *
     * @return bool
     */
    public function anonymousAccessAllowed()
    {
        return true;
    }

    /**
     * @return null
     */
    public function envAction()
    {
        $service = new CustomerService();
        if ($service->getCareType() == Customer::CARETYPE_MHC) {
            $this->data['careType'] = self::CARETYPE_MHC;
        } else {
            $this->data['careType'] = self::CARETYPE_SOM ;
        }
        return $this->data;
    }

}