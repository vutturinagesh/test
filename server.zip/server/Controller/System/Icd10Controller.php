<?php

namespace Controller\System;

use Controller\AbstractController;
use DateTime;
use Medical\IdToTreatmentTransformer;
use Response\PaginationAdaptor;
use Symfony\Component\HttpFoundation\JsonResponse;
use System\Icd10Service;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/system",
 *     basePath="/api/v2"
 * )
 */
class Icd10Controller extends AbstractController
{
    /**
     * @var \System\Icd10Service
     */
    private $systemIcd10Service;

    /**
     * @var \Medical\IdToTreatmentTransformer;
     */
    private $idToTreatmentTransformer;

    /**
     * Constructor.
     *
     * @param \System\Icd10Service              $systemIcd10Service
     * @param \Medical\IdToTreatmentTransformer $IdToTreatmentTransformer
     */
    public function __construct(
        Icd10Service             $systemIcd10Service,
        IdToTreatmentTransformer $idToTreatmentTransformer
    ) {
        $this->systemIcd10Service       = $systemIcd10Service;
        $this->idToTreatmentTransformer = $idToTreatmentTransformer;
    }

    /**
     * @SWG\Api(
     *     path="/system-icd10",
     *     @SWG\Operation(
     *         method="GET",
     *         summary="Find ICD10 codesby criteria",
     *         notes="If the search param is set, we only want to use that. No filtering is be done.
     *                If search is not set we will use the treatment startdate, treatment specialism and if set the
     *                thesaurus term as filter criteria.",
     *         @SWG\Parameter(name="treatmentId", type="integer", required=false, paramType="query"),
     *         @SWG\Parameter(name="search", type="string", required=false, paramType="query"),
     *         @SWG\Parameter(name="termId", type="integer", required=false, paramType="query"),
     *         @SWG\Parameter(name="startDate", type="string", format="date", required=false, paramType="query"),
     *     )
     * )
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function getListAction()
    {
        $response = new JsonResponse();

        $criteria = array();
        $this->data = array();
        $order = array('code' => 'ASC');

        $query = $this->getRequest()->query;

        if ($query->has('search')) {
            $criteria['search'] = $query->get('search');
        } else {
            if ($query->has('treatmentId')) {
                try {
                    $treatment = $this->idToTreatmentTransformer->transform($query->get('treatmentId'));
                } catch (TransformationFailedException $e) {
                    $this->addInvalidInputMessageToMeta('treatmentId', $query->get('treatmentId'));
                }

                if (!$this->getMeta()->hasError()) {
                    $criteria['specialism'] = $treatment->getSpecialist()->getSpecialism();
                    $criteria['startDate'] = $treatment->getDtStart();
                }
            }

            if ($query->has('termId')) {
                $criteria['termId'] = $query->get('termId');
                $criteria['primaryDiagnosis'] = true;

                if (!array_key_exists('startDate', $criteria)) {
                    $criteria['startDate'] = new DateTime();
                }

                $order = array('order' => 'ASC');
            }
        }

        $page = $this->processPage();
        $limit = $this->processLimit();

        if (!$this->getMeta()->hasError()) {
            $icd10s  = $this->systemIcd10Service->findAllBy($criteria, $order, $page, $limit);
            $this->data = $this->prepareIcd10ForGui($icd10s);
        }

        $this->getMeta()->setCount(count($this->data));
        $this->addPaginationMeta($page, $limit);

        $response->setData(array('data' => $this->data));

        return $response;
    }

    /**
     * Prepare the icd10 for gui.
     *
     * @param array $icd10s
     *
     * @return array
     */
    private function prepareIcd10ForGui(array $icd10s)
    {
        return array_map(function ($icd10) {
            return $icd10->toListArray();
        }, $icd10s);
    }
}
