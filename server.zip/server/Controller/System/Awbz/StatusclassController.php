<?php

namespace Controller\System\Awbz;

use Controller\AbstractController;
use Actinidium\API\Response\CachedJsonResponse;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/system",
 *     basePath="/api/v2"
 * )
 */
class StatusclassController extends AbstractController
{
    /**
     * @var \System\Awbz\FunctioncodeService
     */
    private $findStatusClassService;

    /**
     * @SWG\Api(
     *   path="/system-awbz-statusclass",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Find statusclass by criteria",
     *           notes="Returns statusclass",
     *           @SWG\Parameter(name="search", type="string", required=false, paramType="query"),
     *       )
     * )
     *
     * @return CachedJsonResponse
     */
    public function getListAction()
    {
        $response = new CachedJsonResponse();

        $data = array();
        if ($this->getRequest()->query->has('search') && mb_strlen($this->getRequest()->query->get('search'))) {
            $entities = $this->getFindStatusClassService()->search($this->getRequest()->get('search'), false);
        } else {
            $entities = $this->getFindStatusClassService()->findAll();
        }
        if (!empty($entities)) {
            foreach ($entities as $entity) {
                $data[] = $entity->toArray();
            }
        }
        $response->setData(array('data' => $data));
        return $response;
    }

    private function getFindStatusClassService()
    {
        if (!$this->findStatusClassService) {
            $this->findStatusClassService = new \System\Awbz\FindStatusClassService();
        }
        return $this->findStatusClassService;
    }
}
