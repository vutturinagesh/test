<?php
namespace Controller\System\Awbz;

use Actinidium\API\Response\Meta;
use Controller\AbstractController;
use System\Awbz\ZtwTypeService;
use Actinidium\API\Response\CachedJsonResponse;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/system",
 *     basePath="/api/v2"
 * )
 */
class ZtwtypeController extends AbstractController
{
    /**
     * @var \System\Awbz\ZtwTypeService
     */
    private $service;

    /**
     * @SWG\Api(
     *   path="/system-awbz-ztwtypes",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Find ztwtypes",
     *           notes="Returns ztwtypes",
     *       )
     * )
     *
     * @return CachedJsonResponse
     */
    public function getListAction()
    {
        $response = new CachedJsonResponse();

        $this->data = array();
        $ztwTypes = $this->getService()->findAll();

        if (!empty($ztwTypes)) {
            foreach ($ztwTypes as $ztwType) {
                $this->data[] = $ztwType->toArray();
            }
            $response->setData(array('data' => $this->data));
        }

        return $response;
    }

    /**
     * @return \System\Awbz\ZtwTypeService
     */
    private function getService()
    {
        if (!$this->service) {
            $this->service = new ZtwTypeService();
        }
        return $this->service;
    }
}
