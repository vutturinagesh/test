<?php

namespace Controller\System\Awbz;

use Calendar\Roster\Cache;
use Controller\AbstractController;
use Actinidium\API\Response\CachedJsonResponse;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/system",
 *     basePath="/api/v2"
 * )
 */
class FunctioncodeController extends AbstractController
{
    /**
     * @var \System\Awbz\FunctioncodeService
     */
    private $service;

    /**
     * @SWG\Api(
     *   path="/system-awbz-functioncode",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Find function codes",
     *           notes="Returns function codes",
     *       )
     * )
     *
     * @return CachedJsonResponse
     */
    public function getListAction()
    {
        $response = new CachedJsonResponse();

        $data = array();
        $functioncodes = $this->getService()->findAll();
        if (!empty($functioncodes)) {
            foreach ($functioncodes as $functioncode) {
                $data[] = $functioncode->toArray();
            }
            $response->setData(array('data' => $data));

        }
        return $response;
    }

    private function getService()
    {
        if (!$this->service) {
            $this->service = new \System\Awbz\FunctioncodeService();
        }
        return $this->service;
    }
}
