<?php

namespace Controller\System\Awbz;

use Actinidium\API\Response\Meta;
use Controller\AbstractController;
use System\Awbz\UnitService;
use Symfony\Component\HttpFoundation\JsonResponse;
use Actinidium\API\Response\CachedJsonResponse;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/system",
 *     basePath="/api/v2"
 * )
 */
class UnitController extends AbstractController
{
    /**
     * @var \System\Awbz\Unit
     */
    private $service;

    /**
     * @SWG\Api(
     *   path="/system-awbz-unit",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Find time frames",
     *           notes="Returns time frames",
     *       )
     * )
     *
     * @return CachedJsonResponse
     */
    public function getListAction()
    {
        $response = new CachedJsonResponse();

        $this->data = array();
        $units = $this->getService()->findAll();

        if (!empty($units)) {
            foreach ($units as $unit) {
                $this->data[] = $unit->toArray();
            }
            $response->setData(array('data' => $this->data));
        }
        return $response;
    }

    /**
     * @return \System\Awbz\UnitService
     */
    private function getService()
    {
        if (!$this->service) {
            $this->service = new UnitService();
        }
        return $this->service;
    }
}
