<?php

namespace Controller\System\Awbz;

use Controller\AbstractController;
use Actinidium\API\Response\CachedJsonResponse;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/system",
 *     basePath="/api/v2"
 * )
 */
class DeliverystatusController extends AbstractController
{
    /**
     * @var \System\Awbz\DeliveryStatusService
     */
    private $service;

    /**
     * @SWG\Api(
     *   path="/system-awbz-deliverystatus",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Find delivery status",
     *           notes="Returns delivery status",
     *       )
     * )
     *
     * @return CachedJsonResponse
     */
    public function getListAction()
    {
        $response = new CachedJsonResponse();

        $data = array();
        $deliveryStatus = $this->getService()->findAll();

        if (!empty($deliveryStatus)) {
            foreach ($deliveryStatus as $deliveryStatus) {
                $data[] = $deliveryStatus->toArray();
            }
            $response->setData(array('data' => $data));
        }

        return $response;
    }

    private function getService()
    {
        if (!$this->service) {
            $this->service = new \System\Awbz\DeliverystatusService();
        }
        return $this->service;
    }
}
