<?php
namespace Controller\System\Awbz;

use Actinidium\API\Response\Meta;
use Controller\AbstractController;
use System\Awbz\FrequencyService;
use Actinidium\API\Response\CachedJsonResponse;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/system",
 *     basePath="/api/v2"
 * )
 */
class FrequencyController extends AbstractController
{
    /**
     * @var \System\Awbz\Frequency
     */
    private $service;

    /**
     * @SWG\Api(
     *   path="/system-awbz-frequency",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Find time frames",
     *           notes="Returns time frames",
     *       )
     * )
     *
     * @return CachedJsonResponse
     */
    public function getListAction()
    {
        $response = new CachedJsonResponse();

        $this->data = array();
        $frequencies = $this->getService()->findAll();

        if (!empty($frequencies)) {
            foreach ($frequencies as $frequency) {
                $this->data[] = $frequency->toArray();
            }
            $response->setData(array('data' => $this->data));
        }

        return $response;
    }

    /**
     * @return \System\Awbz\FrequencyService
     */
    private function getService()
    {
        if (!$this->service) {
            $this->service = new FrequencyService();
        }
        return $this->service;
    }
}
