<?php
namespace Controller\System;

use Actinidium\API\Response\Meta;
use Controller\AbstractController;
use System\RelationTypeService as RelationTypeService;
use System\RelationType as RelationType;
use Actinidium\API\Response\CachedJsonResponse;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/system",
 *     basePath="/api/v2"
 * )
 */
class RelationTypeController extends AbstractController
{
    /**
     * Holds the relation type service.
     *
     * @var \System\RelationTypeService
     */
    protected $relationTypeService;

    /**
     * Get the relation type service object on demand.
     *
     * @return \System\RelationTypeService
     */
    private function getRelationTypeService()
    {
        if (!($this->relationTypeService instanceof RelationTypeService)) {
            $this->relationTypeService = new RelationTypeService();
        }
        return $this->relationTypeService;
    }

    /**
     * @see \Actinidium\API\RestBaseController::getAction()
     */
    public function getAction($id)
    {
        $result = array();
        $relationType = $this->getRelationTypeService()->getRelationType($id);

        if ($relationType instanceof RelationType) {
            $this->getMeta()->setCount(1);
            return $this->extractRelationGenderType($relationType, $result);
        }

        $this->getMeta()->setCount(0);
        return $result;
    }

    /**
     * @SWG\Api(
     *   path="/system-relationType",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Find relation type by criteria",
     *           notes="Returns relation type",
     *           @SWG\Parameter(name="relationTypeId", type="integer", required=false, paramType="query"),
     *       )
     * )
     *
     * @return CachedJsonResponse
     */
    public function getListAction()
    {
        $response = new CachedJsonResponse();

        $query = $this->getRequest()->query;
        if ($query->has('relationTypeId')) {
            // Get single result. For GUI support, 'id' can not be used.
            $data = $this->getAction($query->get('relationTypeId'));
            $response->setData(array('data' => $data));
        } else {
            // Get list result
            $result = array();
            $relationTypes = $this->getRelationTypeService()->getAllRelationTypes();

            foreach ($relationTypes as $relationType) {
                if ($relationType instanceof RelationType) {
                    $result = $this->extractRelationGenderType($relationType, $result);
                }
            }

            if (count($result) == 0) {
                $this->getMeta()->addMessage(META::STATUS_ERROR, "No Records Found");
                return $response;
            }
            $response->setData(array('data' => $result));
        }
        return $response;
    }

    /**
     * Process relationtype resultset into separate array items.
     *
     * @param \System\RelationType $relationType
     * @param array $result
     *
     * @return array
     */
    private function extractRelationGenderType(RelationType $relationType, array $result) {
        $genderRelationTypes = $relationType->toListArray();
        foreach($genderRelationTypes as $relationGenderType) {
            array_push($result, $relationGenderType);
        }
        return $result;
    }
}
