<?php

namespace Controller\System;

use Actinidium\API\Response\Meta;
use Controller\AbstractController;
use System\MunicipalityService;
use Actinidium\API\Response\CachedJsonResponse;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/system",
 *     basePath="/api/v2"
 * )
 */
class MunicipalityController extends AbstractController
{
    /**
     * @var MunicipalityService
     */
    private $municipalityService;

    /**
     * Retrieve the Municipality Service.
     *
     * @return \System\MunicipalityService
     */
    private function getMunicipalityService()
    {
        if (!$this->municipalityService instanceof MunicipalityService) {
            $this->municipalityService = new MunicipalityService();
        }

        return $this->municipalityService;
    }

    /**
     * @SWG\Api(
     *   path="/system-municipality",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Find municipality",
     *           notes="Returns municipality",
     *       )
     * )
     *
     * @return CachedJsonResponse
     */
    public function getListAction()
    {
        $response = new CachedJsonResponse();

        $this->data = array();
        $criteria = $this->processRequestData();

        if (!$this->getMeta()->hasError()) {
            $municipalityService = $this->getMunicipalityService();
            $this->data = $municipalityService->findAllBy($criteria);
            $response->setData(array('data' => $this->data));
        }

        return $response;
    }

    /**
     * Process the data passed to the controller.
     *
     * @return array
     */
    private function processRequestData()
    {
        $request = $this->getRequest()->query;

        $criteria = array();

        if ($request->has('postcode')) {
            $criteria['postcode'] = $request->get('postcode');
        }

        if ($request->has('startdate')) {
            $criteria['searchDate'] = $request->get('startdate');
        }

        return $criteria;
    }
}
