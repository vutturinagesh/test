<?php

namespace Controller\System;

use Actinidium\API\Response\Meta;
use Message\MessageHandler;
use Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use System\CareInstitution;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/system",
 *     basePath="/api/v2"
 * )
 */
class InstitutionController extends AbstractController
{
    /**
     * @SWG\Api(
     *   path="/system-institution",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Find institutions by criteria",
     *           @SWG\Parameter(name="search", type="string", required=false, paramType="query"),
     *           @SWG\Parameter(name="code", type="string", required=false, paramType="query"),
     *           @SWG\Parameter(name="date", type="string(format DD-MM-YYYY)", required=false, paramType="query"),
     *           @SWG\Parameter(name="careProviderTypeId", type="string", required=false, paramType="query"),
     *           @SWG\Parameter(name="careProviderId", type="string", required=false, paramType="query"),
     *           @SWG\Parameter(name="offset", type="integer", required=false, paramType="query", defaultValue=0),
     *           @SWG\Parameter(name="itemsPerPage", type="integer", required=false, paramType="query", defaultValue=30),
     *       )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function getListAction(Request $request)
    {
        $data = array();
        $response = $this->defaultResponse();
        $careInstitutionService = $this->get('medicore.system.care_institution_service');
        $search = $careInstitutionService->getCareInstitutionSearchByRequest($request);
        $isSearchValid = $this->isModelValid($search);

        if ($isSearchValid) {
            list ($data, $totalCount) = $careInstitutionService->search($search);

            $this->addPagination(
                $search->getOffset(),
                (count($data) > $search->getLimitPerPage()) ? count($data) : $search->getLimitPerPage(),
                $totalCount
            );

            if (null !== $data) {
                $data = array_map(function(CareInstitution $item) {
                    return $item->toListArray();
                }, $data);
            }
        }

        if ($isSearchValid && 0 === count($data)) {
            $this->getMeta()->addMessage(
                Meta::STATUS_INFO,
                $this->get('medicore.message.message_handler')->getOne('MG103')
            );
        }

        $response->setData(array('data' => $data));
        return $response;
    }
}
