<?php

namespace Controller\System;

use Controller\AbstractController;
use Generic\CustomerSettingsService;
use Actinidium\API\Response\CachedJsonResponse;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/system",
 *     basePath="/api/v2"
 * )
 */
class DateController extends AbstractController
{
    /**
     * @SWG\Api(
     *   path="/system-date",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Find system date",
     *           notes="Returns system date",
     *       )
     * )
     *
     * @return CachedJsonResponse
     */
    public function getListAction()
    {
        $response = new CachedJsonResponse();

        $systemDate = CustomerSettingsService::getSystemDate();

        $this->data = array("date" => $systemDate->format(\Date\Format::DATE));

        $response->setData(array('data' => $this->data));

        return $response;
    }
}
