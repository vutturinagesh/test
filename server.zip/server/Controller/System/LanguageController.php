<?php

namespace Controller\System;

use Actinidium\API\RestBaseController;
use Actinidium\API\Response\Meta;
use Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Generic\EmployeeService;
use Generic\UserService;
use Generic\User;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/system",
 *     basePath="/api/v2"
 * )
 */
class LanguageController extends AbstractController
{
    /**
     * @var \Generic\EmployeeService
     */
    private $employeeService;

    /**
     * @var \Generic\UserService
     */
    private $userService;

    /**
     * @param \Generic\EmployeeService $employeeService
     * @param \Generic\UserService $userService
     */
    public function __construct(
        EmployeeService $employeeService = null,
        UserService $userService = null
    ) {
        parent::__construct();
        if (null == $employeeService) {
            $employeeService = $this->get('medicore.generic.employee_service');
        }
        if (null == $userService) {
            $userService = $this->get('medicore.generic.user_service');
        }

        $this->employeeService = $employeeService;
        $this->userService = $userService;
    }

    /**
     * @SWG\Api(
     *   path="/system-language",
     *       @SWG\Operation(
     *           method="POST",
     *           summary="Set the default language of user.",
     *           @SWG\Parameters(
     *               @SWG\Parameter(
     *                   name="language",
     *                   type="string",
     *                   required=true,
     *                   description="Language sting to change",
     *                   paramType="body"
     *               )
     *          ),
     *       )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function createAction(Request $request)
    {
        $response = new JsonResponse();

        $data = json_decode($request->getContent(), true);
        $this->validateLanguage($data['language']);

        if (!$this->getMeta()->hasError()) {
            $result = $this->userService->changeLanguage($this->employeeService->getCurrentEmployee()->getUser(), $data['language']);

            if ($result) {
                $response->setData(array('data' => array('language' => $data['language'])));
                $_SESSION['settings']['language'] = $data['language'];
                $_SESSION['settings']['default_language'] = $data['language'];
            }
        }
        return $response;
    }

    /**
     * Validates input language string.
     *
     * @param string $language
     */
    private function validateLanguage($language)
    {
        if ($language != User::LANGUAGE_ENGLISH && $language != User::LANGUAGE_DUTCH) {
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne(
                    'MG101',
                    array('field_name' => "language", 'input' => $language)
                )
            );
        }
    }
}
