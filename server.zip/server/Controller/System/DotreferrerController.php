<?php

namespace Controller\System;

use Actinidium\API\Response\Meta;
use Controller\AbstractController;
use Actinidium\API\MetaBaseController;
use Medical\EpisodeService;
use Generic\Referrer\EpisodeReferrer;
use Generic\Referrer\ExternalService;
use Generic\Referrer\InternalService;
use Generic\Referrer\NoReferrerService;
use Generic\Referrer\GeneralPractitionerService;
use Generic\Referrer\OrganizationService;
use Generic\Referrer\IndividualService;
use System\CareInstitutionService;
use System\CareProviderService;
use Medical\TreatmentService;
use Generic\Referrer\NoReferrer;
use Generic\Referrer\External;
use Generic\Referrer\GeneralPractitioner;
use Generic\Referrer\Internal;
use Actinidium\API\Response\CachedJsonResponse;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/system",
 *     basePath="/api/v2"
 * )
 */
class DotreferrerController extends AbstractController
{
    /**
     * @var \System\DOTReferrerCodeService
     */
    private $model;

    /**
     * @var EpisodeService
     */
    private $episodeService;

    /**
     * @SWG\Api(
     *   path="/system-dotreferrer",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Find dot referrer",
     *           notes="Returns dot referrer",
     *           @SWG\Parameter(name="type", type="string", required=false, paramType="query"),
     *           @SWG\Parameter(name="episodeId", type="integer", required=false, paramType="query"),
     *       )
     * )
     *
     * @return CachedJsonResponse
     */
    public function getListAction()
    {
        $response = new CachedJsonResponse();

        $this->model = $this->getModel();
        $this->data = array();
        $request = $this->getRequest()->query;
        if ($request->has('type') && $request->has('episodeId')) {
            $this->deductByEpisodeReferrer();
        } elseif ($request->has('type')) {
            $this->searchByReferrerType($request->get('type'));
        } else {
            $this->data = $this->model->findAll();
        }
        $response->setData(array('data' => $this->data));

        return $response;
    }
    
    /**
     * Will deduct suggested DOT referrer code according to episode referrer.
     *
     * @return array
     */
    private function deductByEpisodeReferrer()
    {
        $request = $this->getRequest()->query;
        
        $episode = $this->createEntity(
            $request->get('episodeId'),
            'episodeId',
            $this->getEpisodeService(),
            '\Medical\Episode'
        );

        $referrerType = $this->validateType($request->get('type'));
        $emergencyRoom = $this->validateEmergencyRoom($request->get('emergencyRoom'));

        $episodeReferrer = $this->prepareEpisodeReferrerObject($referrerType, $emergencyRoom);

        if (!$this->getMeta()->hasError()) {
            $episode->setEpisodeReferrer($episodeReferrer);
            $result = $this->getEpisodeService()->deductDOTReferrerCodeByReferrer($episode);

            if (is_array($result)) {
                $this->getMeta()->addMessage(Meta::STATUS_ERROR, $this->messageHandler->getOne($result['id']));
            } elseif ($result) {
                $this->data = $result->toListArray();
            }
        }
    }
    
    /**
     * Factory method for getting the EpisodeService.
     *
     * @return EpisodeService
     */
    private function getEpisodeService()
    {
        if (!$this->episodeService) {
            $this->episodeService = new EpisodeService();
        }
        return $this->episodeService;
    }

    /**
     * searchByReferrerType
     *
     * @param String $referrerType
     *
     */
    protected function searchByReferrerType($referrerType)
    {
        if (!$referrerType) {
            $this->addMessage(Meta::STATUS_ERROR, "MG01", array('list_of_fields' => "type"));
        }else if ($this->validateReferrerType($referrerType)) {
            $this->data = $this->model->findByReferrerType($referrerType);
        } else {
            $this->addMessage(
                Meta::STATUS_ERROR,
                "GV9",
                array('object' => "type", 'input' => $referrerType)
            );
        }
    }

    /**
     * validateReferrerType
     *
     * @param String $referrerType
     * @return bool
     */
    private function validateReferrerType($referrerType)
    {
        return $this->model->validateReferrerType($referrerType);
    }


    /**
     * getModel
     *
     * @return \System\DOTReferrerCodeService
     */
    protected function getModel()
    {
        if (!$this->model) {
            $this->model = new \System\DOTReferrerCodeService();
        }

        return $this->model;
    }
    
    /**
    * Will prepare episode referrer object according to referrer data.
    *
    * @param $referrerType
    * @param $emergencyRoom
    *
    * @return EpisodeReferrer
    */
    private function prepareEpisodeReferrerObject($referrerType, $emergencyRoom)
    {
        $request = $this->getRequest()->query;

        $episodeReferrer = new EpisodeReferrer;
        $episodeReferrer->setEmergencyRoom($emergencyRoom);

        switch ($referrerType) {
            case EpisodeReferrer::EXTERNAL:
                $externalReferrer = $this->prepareExternalReferrerObject($request);
                if ($externalReferrer) {
                    $episodeReferrer->setExternalReferrer($externalReferrer);
                }
                break;
            case EpisodeReferrer::SYSTEM_EXTERNAL:
                $systemExternalReferrer = $this->prepareSystemExternalReferrerObject($request);
                if ($systemExternalReferrer) {
                    $episodeReferrer->setGeneralPractitioner($systemExternalReferrer);
                }
                break;
            case EpisodeReferrer::INTERNAL:
                $internalReferrer = $this->prepareInternalReferrerObject($request);
                if ($internalReferrer) {
                    $episodeReferrer->setInternalReferrer($internalReferrer);
                }
                break;
            case EpisodeReferrer::NO_REFERRER:
                $noReferrer = $this->prepareNoReferrerObject($request);
                if ($noReferrer) {
                    $episodeReferrer->setNoReferrer($noReferrer);
                }
                break;
        }
        return $episodeReferrer;
    }

    /**
     * Will return internal referrer object.
     *
     * @param $request
     *
     * @return bool|External
     */
    private function prepareExternalReferrerObject($request)
    {
        $data = array();

        $data['organization'] = $this->createEntity(
            $request->get('organizationId'),
            'organizationId',
            $this->get('medicore.generic.referrer.organization_service'),
            'Generic\Referrer\Organization'
        );

        if ($request->has('personId')) {
            $data['individual'] = $this->createEntity(
                $request->get('personId'),
                'personId',
                new IndividualService(),
                'Generic\Referrer\Individual'
            );
        }

        if ($this->hasError()) {
            return false;
        }

        $externalReferrerService = new ExternalService();

        return $externalReferrerService->createExternalReferrer($data);
    }

    /**
     * Will return system external referrer object.
     *
     * @param $request
     *
     * @return bool|GeneralPractitioner
     */
    private function prepareSystemExternalReferrerObject($request)
    {
        $careInstitution = null;
        $careProvider = null;

        $careInstitution = $this->createEntity(
            $request->get('organizationId'),
            'organizationId',
            new CareInstitutionService(),
            'System\CareInstitution'
        );

        $careProvider = $this->createEntity(
            $request->get('personId'),
            'personId',
            new CareProviderService(),
            '\System\CareProvider'
        );

        if ($this->hasError()) {
            return false;
        }

        $systemExternalReferrerService = new GeneralPractitionerService();
        return $systemExternalReferrerService->create($careInstitution, $careProvider);
    }

    /**
     * Will return internal referrer object.
     *
     * @param $request
     *
     * @return bool|Internal
     */
    private function prepareInternalReferrerObject($request)
    {
        $referringTreatment = $this->createEntity(
            $request->get('referringTreatmentId'),
            'referringTreatmentId',
            new TreatmentService(),
            '\Medical\Treatment'
        );

        if ($this->hasError()) {
            return false;
        }

        $data['referringTreatment'] = $referringTreatment;
        $data['referringEpisode'] = $referringTreatment->getEpisode();
        $data['specialist'] = $referringTreatment->getSpecialist();

        $internalService = new InternalService();
        return $internalService->createObject($data);
    }

    /**
     * Will prepare no referrer object.
     *
     * @return NoReferrer
     */
    private function prepareNoReferrerObject()
    {
        $noReferrerService = new NoReferrerService();
        return $noReferrerService->createNoReferrer();
    }

    /**
     * Validate emergency room.
	 *
     * @param bool $emergencyRoom
     *
     * @return bool
     */
    private function validateEmergencyRoom($emergencyRoom)
    {
        if (!\Security\Sanitizer::isBoolean($emergencyRoom)) {
            $this->addMessage(
                Meta::STATUS_ERROR,
                'MG101',
                array('field_name' => 'emergencyRoom', 'input' => $emergencyRoom)
            );
        } else {
            $emergencyRoom = \Security\Sanitizer::boolean($emergencyRoom);
        }
        return $emergencyRoom;
    }
    
    /**
     * Will validate type.
     *
     * @param string $type
     *
     * @return string
     */
    private function validateType($type)
    {
        if (!$type) {
            $this->addMessage(Meta::STATUS_ERROR, "MG01", array('list_of_fields' => "referrertype"));
        } elseif ($this->validateReferrerType($type)) {
            return $type;
        } else {
            $this->addMessage(
                Meta::STATUS_ERROR,
                "GV9",
                array('object' => "referrertype", 'input' => $type)
            );
        }
        return $type;
    }
}
