<?php

namespace Controller\System;

use Actinidium\API\Response\CachedJsonResponse;
use Controller\AbstractController;
use DateTime;
use Generic\SpecialismService;
use Medical\Treatment;
use System\Thesaurus\TermService;
use System\Thesaurus\TermSearchCriteria;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/system",
 *     basePath="/api/v2"
 * )
 */
class ThesaurusController extends AbstractController
{
    /**
     * @var \System\Thesaurus\TermService
     */
    private $termService;

    /**
     * @var \Generic\SpecialismService
     */
    private $specialismService;

    /**
     * Construct the controller and inject the dependencies.
     *
     * @param \System\Thesaurus\TermService $termService
     * @param \Generic\SpecialismService    $specialismService
     */
    public function __construct(
        TermService $termService,
        SpecialismService $specialismService
    ) {
        parent::__construct();

        $this->termService = $termService;
        $this->specialismService = $specialismService;
    }

    /**
     * @SWG\Api(
     *   path="/system-thesaurus",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Find thesaurus",
     *           notes="Returns thesaurus",
     *       )
     * )
     *
     * @return CachedJsonResponse
     */
    public function getListAction()
    {
        $response = new CachedJsonResponse();

        $criteria = $this->processRequestParameters();

        $data = array();
        if ($this->isModelValid($criteria, array('search')) && !$this->getMeta()->hasError()) {
            $terms = $this->termService->findAllBy($criteria);
            $data = array_map(
                function ($term) {
                    return $term->toListArray();
                },
                $terms
            );
        }

        $this->getMeta()->setCount(count($data));
        $response->setData(array('data' => $data));

        return $response;
    }

    /**
     * Check the request data and build an array with criteria objects from it.
     *
     * @return array
     */
    public function processRequestParameters()
    {
        $searchDate = null;
        $query = $this->getRequest()->query;

        $searchCriteria = new TermSearchCriteria();

        $specialty = $this->specialismService->find($query->get('specialty'));
        $searchCriteria->setSpecialty($specialty);

        $searchCriteria->setSearch($query->get('search', null));

        $date = $query->get('validOn', null);
        if (null === $date) {
            $searchDate = new DateTime();
        } else {
            $this->validateDate($date);
        }

        if (!$this->getMeta()->hasError()) {
            $searchDate = new DateTime($date);
        }

        $searchCriteria->setDate($searchDate);

        return $searchCriteria;
    }
}
