<?php

namespace Controller\System\Mhc;

use Controller\AbstractController;
use DateTime;
use Symfony\Component\HttpFoundation\JsonResponse;
use System\Mhc\GafService;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/system",
 *     basePath="/api/v2"
 * )
 *
 * System MHC GAF score collection controller.
 */
class GafController extends AbstractController
{
    /**
     * @var System\Mhc\GafService
     */
    private $gafService = null;

    /**
     * Instantiate the controller.
     *
     * Dependencies that are not injected are created.
     *
     * @param \System\Mhc\GafService $gafService
     */
    public function __construct(GafService $gafService = null)
    {
        parent::__construct();

        if (null === $gafService) {
            $gafService = $this->get('medicore.system.gaf_service');
        }

        $this->gafService = $gafService;
    }

    /**
     * Process the request date param and retrieve a DateTime object for further usage.
     *
     * @return \DateTime | false
     */
    private function processRequestDate()
    {
        $criteria = array();
        $request = $this->getRequest()->query;

        if ($request->has('date')) {
            $dateString = $request->get('date');
            $date = $this->validateDate($dateString);
        } else {
            $date = new DateTime();
        }

        return $date;
    }

    /**
     * @SWG\Api(
     *     path="/system/mhc/gaf",
     *     @SWG\Operation(
     *         method="GET",
     *         summary="Get a list with all the GAF scores.",
     *         notes="Returns both CGAS and GAF",
     *         @SWG\Parameter(
     *             name="date",
     *             description="A date on which the GAF/CGAS score has to be active",
     *             type="string(format YYYY-MM-DD)",
     *             paramType="query",
     *             required=false
     *         )
     *     )
     * )
     *
     * Get the list of GAF scores according to the passed criteria.
     *
     * @return JsonResponse
     */
    public function getListAction()
    {
        $reponse = new JsonResponse();
        $searchDate = $this->processRequestDate();
        $data = array();
        if (!$this->getMeta()->hasError()) {
            $data = $this->gafService->showDiagnoseTreeFor($searchDate);
        }

        $this->getMeta()->setCount(count($data));

        $reponse->setData(array('data' => $data));
        return $reponse;
    }
}