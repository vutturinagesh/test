<?php

namespace Controller\System\Mhc;

use Controller\AbstractController;
use DateTime;
use System\MHC\PerformanceService;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/system",
 *     basePath="/api/v2"
 * )
 *
 * System PrestationCode collection controller for Basic MHC.
 */
class PerformanceController extends AbstractController
{
    /**
     * @var \System\MHC\PerformanceService
     */
    private $performanceService;

    /**
     * Create the controller and Inject the dependancies.
     *
     * @param \System\MHC\PerformanceService|null $performanceService
     */
    public function __construct(PerformanceService $performanceService = null)
    {
        parent::__construct();

        if (null === $performanceService) {
            $performanceService = $this->get('medicore.system.mhc.performance_service');
        }

        $this->performanceService = $performanceService;
    }

    /**
     * @SWG\Api(
     *     path="/system/mhc/performance",
     *     @SWG\Operation(
     *         method="GET",
     *         summary="Get a list with all the Performances that can be registered for Basic MHC.",
     *         notes="Former known as 'basic prestation codes'.",
     *         @SWG\Parameter(
     *             name="date",
     *             type="string",
     *             format="YYYY-MM-DD",
     *             required=true,
     *             paramType="query"
     *         ),
     *     )
     * )
     *
     * List controller function for Basic MHC Performance.
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function getListAction(Request $request)
    {
        $critera = $this->processRequestValidation($request);

        $data = array();

        $this->getMeta()->setCount(0);
        if (!$this->hasError()) {
            $performanceCodes = $this->performanceService->findActivePerformanceCodesForDate($critera['date']);
            $data = array_map(
                function ($performanceCode) {
                    return $performanceCode->toListArray();
                },
                $performanceCodes
            );
            $this->getMeta()->setCount(count($performanceCodes));
        }

        $response = new JsonResponse();
        $response->setData(array("data" => $data));

        return $response;
    }

    /**
     * Function to process all the parameters send by the request.
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return array
     */
    public function processRequestValidation(Request $request)
    {
        $query = $request->query;

        $criteria = array();
        if ($query->has('date')) {
            $criteria['date'] = $this->validateDate($query->get('date'));
        } else {
            $criteria['date'] = new DateTime();
        }

        return $criteria;
    }
}
