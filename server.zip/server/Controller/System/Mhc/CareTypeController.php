<?php

namespace Controller\System\Mhc;

use Actinidium\API\Response\Meta;
use Controller\AbstractController;
use DateTime;
use Medical\TreatmentService;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use System\MHC\CareTypeService;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/system",
 *     basePath="/api/v2"
 * )
 *
 * Class CareType Controller.
 *
 * Access the systeemggzzorgtype (\System\MHC\CareType domain)
 */
class CareTypeController extends AbstractController
{
    /**
     * @var \System\MHC\CareTypeService
     */
    private $careTypeService = null;

    /**
     * @var \Medical\MHC\TreatmentService
     */
    private $treatmentService = null;

    /**
     * Instantiate the controller with all its dependencies.
     *
     * If some are not injected fetch them from the container.
     *
     * @param \Medical\TreatmentService   $treatmentService
     * @param \System\MHC\CareTypeService $careTypeService
     */
    public function __construct(
        TreatmentService $treatmentService = null,
        CareTypeService $careTypeService = null
    ) {
        parent::__construct();

        if (null === $treatmentService) {
            $treatmentService = $this->get('medicore.medical.treatment_service');
        }

        if (null === $careTypeService) {
            $careTypeService = $this->get('medicore.system.mhc.care_type_service');
        }

        $this->treatmentService = $treatmentService;
        $this->careTypeService = $careTypeService;
    }

    /**
     * @SWG\Api(
     *     path="/system/mhc/caretype",
     *     @SWG\Operation(
     *         method="GET",
     *         summary="Get a list with all the CareTypes.",
     *         notes="Only the CareTypes which are valid on a certain date (current date or date passed) and
     *                treatment type (initial or followup) are displayed.",
     *         @SWG\Parameter(
     *             name="date",
     *             description="A date on which the caretype has to be active",
     *             type="string(format YYYY-MM-DD)",
     *             paramType="query",
     *             required=false
     *         )
     *     )
     * )
     *
     * List controller function for care providers.
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function getListAction(Request $request)
    {
        $response = new JsonResponse();
        $criteria = $this->processRequestValidation($request);

        $data = array();
        if (!$this->hasError()) {
            $careTypes = $this->careTypeService->findAllBy($criteria, $this->getOrder(), false);
            $this->getMeta()->setCount(count($careTypes));
            if (0 === count($careTypes)) {
                $this->addMessage(Meta::STATUS_INFO, "MG103");
            } else {
                $data = array_map(
                    function ($careType) {
                        return $careType->toListArray();
                    },
                    $careTypes
                );
            }
        }

        $response->setData(array("data" => $data));

        return $response;
    }

    /**
     * Function to process all the parameters send by the request.
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return array|null
     */
    public function processRequestValidation(Request $request)
    {
        $criteria = array();
        $treatment = null;

        $query = $request->query;
        if ($query->has('treatmentId')) {
            $treatment = $this->createEntity(
                $query->get("treatmentId"),
                "treatmentId",
                $this->treatmentService,
                "Medical\Treatment"
            );
        }

        if (null !== $treatment && !$treatment->isCancelled()) {
            $initialTreatment = $this->treatmentService->isInitialTreatment($treatment);
            //if the initial treatment is not null. This is a followup.
            if ($initialTreatment === true) {
                $criteria['initialTreatment'] = $treatment;
            } else {
                $criteria['followUpTreatment'] = $treatment;
            }
        } else {
            $criteria['date'] = new DateTime();
        }

        return $criteria;
    }

    /**
     * Function to retrieve the order.
     *
     * Right now this is a preset order, once we make sorting available in the frontend this will be updated.
     *
     * @return array
     */
    private function getOrder()
    {
        return array("code" => "asc");
    }
}
