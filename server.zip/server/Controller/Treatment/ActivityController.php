<?php

namespace Controller\Treatment;

use Actinidium\API\Response\Meta;
use Actinidium\API\Response\NonCachedJsonResponse;
use Controller\AbstractController;
use Controller\Treatment\Activity\Create;
use Controller\Treatment\Activity\Update;
use Controller\ValidationResult;
use DateTime;
use Factory\TranslatorFactory;
use Generic\Authorizer;
use Generic\CustomerSettingsService;
use Generic\Employee;
use Generic\IdToEmployeeTransformer;
use Medical\Activity\IdToPhaseTransformer;
use Medical\Activity\Phase;
use Medical\Activity\PhaseService;
use Medical\Activity\StrategyFactory as ActivityStrategyFactory;
use Medical\Episode;
use Medical\IdToActivityTransformer;
use Medical\IdToTreatmentTransformer;
use Medical\InterfaceTreatmentActivity;
use Medical\MHC\Basic\Activity as BasicActivity;
use Medical\MHC\Basic\Component;
use Medical\MHC\Basic\IdToActivityTransformer as IdToBasicMhcActivityTransformer;
use Medical\MHC\Basic\IdToComponentTransformer;
use Medical\MHC\Ctg\Activity as CtgActivity;
use Medical\MHC\Ctg\IdToActivityTransformer as IdToCtgMhcActivityTransformer;
use Medical\MHC\TreatmentActivity as MhcTreatmentActivity;
use Medical\MHC\DayCare\Activity as DayCareActivity;
use Medical\Treatment;
use Medical\Treatment\Activity\EmrService;
use Medical\Treatment\Activity\Mover;
use Medical\Treatment\Factory as TreatmentFactory;
use Medical\Treatment\SystemDbcActivityService;
use Medical\TreatmentActivity;
use Medical\TreatmentActivityPhaseService;
use Medical\TreatmentService;
use Message\MessageHandler;
use Symfony\Component\Form\Exception\TransformationFailedException;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Translation\Translator;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/treatment-activity",
 *     basePath="/api/v2"
 * )
 */
class ActivityController extends AbstractController
{
    /**
     * @var \Medical\TreatmentService
     */
    private $treatmentService;

    /**
     * @var \Medical\Activity\PhaseService
     */
    private $phaseService;

    /**
     * @var \Generic\Authorizer
     */
    private $authorizer;

    /**
     * @var \Message\MessageHandler
     */
    protected $messageHandler;

    /**
     * @var \Medical\Activity\EmrService
     */
    private $emrService;

    /** @var \Medical\Treatment\SystemDbcActivityService */
    private $systemDbcActivityService;

    /** @var \Medical\MHC\Basic\IdToComponentTransformer */
    private $idToComponentTransformer;

    /** @var  \Medical\MHC\Basic\IdToActivityTransformer */
    private $idToBasicMhcActivityTransformer;

    /** @var  \Generic\IdToEmployeeTransformer */
    private $idToEmployeeTransformer;

    /**
     * @var \Medical\Activity\StrategyFactory
     */
    private $activityStrategyFactory;

    /**
     * @var \Medical\Activity\StrategyInterface
     */
    private $activityStrategy = null;

    /**
     * The CRUD services used in this controller. Default set to null, but filled when setStrategyByTreatment
     * is called. By doing this we removed ALL the dependencies to Treatment Activity services from here.
     *
     * Holds the service used to create Activity objects depending on the strategy.
     *
     * @var object
     */
    private $createService = null;

    /**
     * Holds the service used to fetch/search Activity objects depending on the strategy.
     *
     * @var object
     */
    private $readService = null;

    /**
     * Holds the service used to update Activity objects depending on the strategy.
     *
     * @var object
     */
    private $updateService = null;

    /**
     * Holds the service used to remove Activity objects depending on the strategy.
     *
     * @var object
     */
    private $deleteService = null;

    /**
     * Holds the transformer objects depending on the strategy.
     *
     * @var \Symfony\Component\Form\DataTransformerInterface
     */
    private $transformer = null;

    /** @var  \Medical\MHC\Ctg\Activity\UpdateService */
    private $ctgActivityUpdateService;

    /** @var  \Medical\MHC\Ctg\IdToActivityTransformer */
    private $idToCtgMhcActivityTransformer;

    /** @var  \Medical\IdToTreatmentTransformer */
    private $idToTreatmentTransformer;

    /** @var \Medical\IdToActivityTransformer */
    private $idToActivityTransformer;

    /** @var \Medical\Activity\IdToPhaseTransformer */
    private $idToPhaseTransformer;

    /**
     * @var \Medical\treatmentActivityPhaseService
     */
    private $treatmentActivityPhaseService;

    /**
     * Holds the service used to move Activity objects depending on the strategy.
     *
     * @var \Service\AbstractService
     */
    private $moverService = null;

    /**
     * Constructor.
     *
     * @param \Medical\TreatmentService                     $treatmentService
     * @param \Medical\Activity\PhaseService                $phaseService
     * @param \Generic\Authorizer                           $authorizer
     * @param \Message\MessageHandler                       $messageHandler
     * @param \Symfony\Component\Translation\Translator     $translator
     * @param \Medical\Treatment\Activity\EmrService        $emrService
     * @param \Medical\MHC\Basic\IdToComponentTransformer   $idToComponentTransformer
     * @param \Medical\MHC\Basic\IdToActivityTransformer    $idToBasicMhcActivityTransformer
     * @param \Generic\IdToEmployeeTransformer              $idToEmployeeTransformer
     * @param \Medical\treatmentActivityPhaseService        $treatmentActivityPhaseService
     * @param \Medical\Treatment\SystemDbcActivityService   $systemDbcActivityService
     * @param \Medical\Activity\StrategyFactory             $activityStrategyFactory
     * @param \Medical\IdToTreatmentTransformer             $idToTreatmentTransformer
     * @param \Medical\IdToActivityTransformer              $idToActivityTransformer
     * @param \Medical\MHC\Ctg\IdToActivityTransformer      $idToCtgMhcActivityTransformer
     * @param \Medical\Activity\IdToPhaseTransformer        $idToPhaseTransformer
     */
    public function __construct(
        TreatmentService                $treatmentService,
        PhaseService                    $phaseService,
        Authorizer                      $authorizer,
        MessageHandler                  $messageHandler,
        Translator                      $translator,
        EmrService                      $emrService,
        IdToComponentTransformer        $idToComponentTransformer,
        IdToBasicMhcActivityTransformer $idToBasicMhcActivityTransformer,
        IdToEmployeeTransformer         $idToEmployeeTransformer,
        TreatmentActivityPhaseService   $treatmentActivityPhaseService,
        SystemDbcActivityService        $systemDbcActivityService,
        ActivityStrategyFactory         $activityStrategyFactory,
        IdToTreatmentTransformer        $idToTreatmentTransformer,
        IdToActivityTransformer         $idToActivityTransformer,
        IdToCtgMhcActivityTransformer   $idToCtgMhcActivityTransformer,
        IdToPhaseTransformer            $idToPhaseTransformer
    ) {
        parent::__construct();

        $this->treatmentService                = $treatmentService;
        $this->phaseService                    = $phaseService;
        $this->authorizer                      = $authorizer;
        $this->messageHandler                  = $messageHandler;
        $this->translator                      = $translator;
        $this->emrService                      = $emrService;
        $this->idToComponentTransformer        =  $idToComponentTransformer;
        $this->idToBasicMhcActivityTransformer = $idToBasicMhcActivityTransformer;
        $this->idToEmployeeTransformer         = $idToEmployeeTransformer;
        $this->treatmentActivityPhaseService   = $treatmentActivityPhaseService;
        $this->systemDbcActivityService        = $systemDbcActivityService;
        $this->activityStrategyFactory         = $activityStrategyFactory;
        $this->idToTreatmentTransformer        = $idToTreatmentTransformer;
        $this->idToActivityTransformer         = $idToActivityTransformer;
        $this->idToCtgMhcActivityTransformer   = $idToCtgMhcActivityTransformer;
        $this->idToPhaseTransformer            = $idToPhaseTransformer;
    }

    /**
     * @SWG\Api(
     *   path="/treatment/activity",
     *   @SWG\Operation(
     *       method="GET",
     *       summary="Returns a list of treatment activities.",
     *       @SWG\Parameter(name="treatmentId", type="integer", required=true, description="The treatment id", paramType="query"),
     *       @SWG\Parameter(name="phaseId", type="integer", required=true, description="The treatment phase id", paramType="query")
     *   )
     * )
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function getListAction(Request $request)
    {
        $query = $request->query;

        $treatment = $this->treatmentService->find($query->get('treatmentId'));
        $phase = null;

        $response = new NonCachedJsonResponse();
        $response->setData(array('data' => array()));

        if ($query->has('phaseId') && is_numeric($query->get('phaseId'))) {
            $phase = $this->phaseService->find($query->get('phaseId'));

            if (null === $phase) {
                $this->addInvalidInputMessageToMeta('phaseId', $query->get('phaseId'));
                return $response;
            }
        }

        if (null === $treatment) {
            $this->addInvalidInputMessageToMeta('treatmentId', $query->get('treatmentId'));
            return $response;
        }

        if (!$this->authorizer->isTreatmentAccessable($treatment)) {
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne('UR3')
            );

            return $response;
        }

        $data = array();
        if (!$this->getMeta()->hasError()) {
            if (isset($phase)) {
                $this->selectStrategyByPhase($phase, $treatment);
            } else {
                $this->selectStrategyByTreatment($treatment);
            }

            $data = $this->getTreatmentActivitiesData($treatment, $phase);
        }

        $this->getMeta()->setCount(count($data));

        $response->setData(array("data" => $data));
        return $response;
    }

    /**
     * Retrieve the Strategy which belongs to the passed Phase so we can set the CRUD services.
     *
     * @param \Medical\Activity\Phase $phase
     * @param \Medical\Treatment      $treatment
     */
    private function selectStrategyByPhase(Phase $phase, Treatment $treatment)
    {
        $this->activityStrategy = $this->activityStrategyFactory->selectStrategyByPhase($phase, $treatment);
        $this->setServices();
    }

    /**
     * Retrieve the Strategy which belongs to the passed Treatment Object so we can set the CRUD services.
     *
     * @param \Medical\Treatment $treatment
     */
    private function selectStrategyByTreatment(Treatment $treatment)
    {
        $this->activityStrategy = $this->activityStrategyFactory->selectStrategyByTreatment($treatment);
        $this->setServices();
    }

    /**
     * Retrieve the Strategy which belongs to the passed Treatment Activity Object so we can set the CRUD services.
     *
     * @param \Medical\Treatment $treatment
     * @param string $type
     */
    private function selectStrategyByTreatmentActivityType(Treatment $treatment, $type)
    {
        $this->activityStrategy = $this->activityStrategyFactory->selectStrategyByActivityType($treatment, $type);
        $this->setServices();
    }

    /**
     * Set the services to the controller by fetching them from the selected Strategy.
     */
    private function setServices()
    {
        $this->readService = $this->activityStrategy->getReadService();
        $this->createService = $this->activityStrategy->getCreateService();
        $this->deleteService = $this->activityStrategy->getDeleteService();
        $this->updateService = $this->activityStrategy->getUpdateService();
        $this->transformer = $this->activityStrategy->getTransformer();
        $this->moverService = $this->activityStrategy->getMoverService();
    }

    /**
     * Get amount related data for a Treatment Activity.
     *
     * @param \Medical\TreatmentActivity $treatmentActivity
     *
     * @return array
     */
    public function getTreatmentActivityAmountData(TreatmentActivity $treatmentActivity)
    {
        if (!$treatmentActivity->getTreatment()->isSomatic()) {
            return array();
        }

        $performedDate = $treatmentActivity->getPerformedDate();
        if (null === $performedDate || $performedDate == '0000-00-00') {
            $performedDate = CustomerSettingsService::getSystemDate();
        }
        $systemDbcActivity = $this->systemDbcActivityService->findOneByCodeAndDate(
            $treatmentActivity->getActivityCode(),
            $performedDate
        );

        if (null === $systemDbcActivity) {
            return array();
        }

        return $treatmentActivity->getAmountData($systemDbcActivity);
    }

    /**
     * Get treatment activities data.
     *
     * @param \Medical\Treatment $treatment
     * @param \Medical\Activity\Phase $phase
     *
     * @return array
     *
     * @access private lowered accessibility due to unit testing
     */
    protected function getTreatmentActivitiesData(Treatment $treatment, Phase $phase = null)
    {
        $treatmentActivities = $this->readService->findByPhase($treatment, $phase);
        return $this->prepareForGui($treatmentActivities);
    }

    /**
     * Convert the objects into data arrays.
     *
     * @param array $treatmentActivities
     *
     * @return array
     */
    private function prepareForGui(array $treatmentActivities)
    {
        $emrService = $this->emrService;
        $systemDbcActivityService = $this->systemDbcActivityService;

        $self = $this;
        return array_map(
            function($treatmentActivity) use ($emrService, $systemDbcActivityService, $self) {
                $data = $treatmentActivity->toListArray();

                if ($treatmentActivity->getTreatment()->isSomatic()) {
                    $data = array_merge($data, $self->getTreatmentActivityAmountData($treatmentActivity));
                }

                $data['relatedForms'] = $emrService->hydrate($treatmentActivity);

                return $data;
            }, $treatmentActivities
        );

    }

    /**
     * @SWG\Api(
     *   path="/treatment/activity",
     *   @SWG\Operation(
     *       method="POST",
     *       summary="Create the MHC/Somatic activity based on the treatment type.",
     *       @SWG\Parameter(
     *           name="body",
     *           description="Create a MHC or SOM treatment activity.",
     *           required=true,
     *           type="\Medical\MHC\TreatmentActivity OR \Medical\TreatmentActivity.",
     *           paramType="body",
     *           allowMultiple=false
     *       )
     *   )
     * )
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function createAction(Request $request)
    {
        $data = json_decode($request->getContent(), true);
        $phase = null;
        $response = new JsonResponse();
        try {
            $treatment = $this->idToTreatmentTransformer->transform($data['treatmentId']);
        } catch (TransformationFailedException $e) {
            $this->addInvalidInputMessageToMeta('treatmentId', $data['treatmentId']);
            return $response;
        }

        $performedDate = $this->validateDate($data['performedDate']);

        if (!empty($data['phaseId'])) {
            try {
                $phase = $this->idToPhaseTransformer->transform($data['phaseId']);
            } catch(TransformationFailedException $e) {
                $this->addInvalidInputMessageToMeta('phaseId', $data['phaseId']);

                return $response;
            }
        }

        if (!$this->authorizer->isTreatmentAccessable($treatment)) {
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne('UR3')
            );

            return $response;
        }

        if ($data['type'] !== InterfaceTreatmentActivity::TYPE_CTG &&
            $data['type'] !== InterfaceTreatmentActivity::TYPE_TIMEWRITING &&
            $data['type'] !== InterfaceTreatmentActivity::TYPE_SOM &&
            $data['type'] !== InterfaceTreatmentActivity::TYPE_AWBZ &&
            $data['type'] !== InterfaceTreatmentActivity::TYPE_DAY_CARE &&
            $data['type'] !== InterfaceTreatmentActivity::TYPE_DAY_OF_STAY &&
            $data['type'] !== InterfaceTreatmentActivity::TYPE_SPECIAL
        ) {
            $this->addInvalidInputMessageToMeta('type', $data['type']);
            return $response;
        }

        $this->selectStrategyByTreatmentActivityType($treatment, $data['type']);

        if ($data['type'] == InterfaceTreatmentActivity::TYPE_CTG) {
            try {
                $activity = $this->idToActivityTransformer->transform($data['activityId']);
            } catch (TransformationFailedException $e) {
                $this->addInvalidInputMessageToMeta('activityId', $data['activityId']);

                return $response;
            }

            $ctgActivity = $this->createService->engage($treatment, $activity, $performedDate, $phase);
            if ($this->createService->hasValidationMessages()) {
                ValidationResult::addMessages($this, $this->createService->getValidationMessages());
            }
            if (ValidationResult::containsErrors($this->createService->getValidationMessages())) {
                return $response;
            }

            $response->setData(array("data" => $ctgActivity->toArray()));

            return $response;
        } elseif ($data['type'] === InterfaceTreatmentActivity::TYPE_DAY_CARE ||
                  $data['type'] === InterfaceTreatmentActivity::TYPE_DAY_OF_STAY ||
                  $data['type'] === InterfaceTreatmentActivity::TYPE_SPECIAL
        ) {
            $returnData = array();

            $dayActivity = $this->createService->set($treatment, $data);
            if ($this->isModelValid($dayActivity, array('create'))) {
                $this->createService->complete($dayActivity);
                $errors = $this->createService->getErrors();
                if (!ValidationResult::containsErrors($errors)) {
                    $returnData = $dayActivity->toListArray();
                }
                ValidationResult::addMessages($this, $errors);
            }
        } elseif ($treatment->isMhcDbc()) {
            $treatmentActivity = $this->createService->set($treatment, $data, new MhcTreatmentActivity());
            if ($this->isModelValid($treatmentActivity, array('create'))) {

                $this->createService->complete($treatmentActivity);

                $errors = $this->createService->getErrors();
                if (!ValidationResult::containsErrors($errors)) {
                    if (null !== $phase) {
                        $this->updateTreatmentPhases(array($phase), $treatment);
                    }

                    $returnData = $treatmentActivity->toArray();
                }

                // Make sure warnings are also included.
                if ($this->createService->hasErrors()) {
                    ValidationResult::addMessages($this, $errors);
                }
            }

            $response->setData(array("data" => $returnData));
            return $response;
        }

        if ($treatment->isBasicMhc()) {
            $this->isEntityIdEmpty($data['componentId'], 'componentId');
            $this->isEntityIdPositiveInteger($data['componentId'], 'componentId');
            try {
                $component = $this->idToComponentTransformer->transform($data['componentId']);
            } catch (TransformationFailedException $e) {
                $this->addMessage(
                    Meta::STATUS_ERROR,
                    'GV9',
                    array('object' => '\Medical\MHC\Basic\Component', 'input' => $data['componentId'])
                );
            }
            if (!$this->hasError()) {
                $returnData = $this->createBasicMhcActivity($treatment, $component, $performedDate, $phase);
                if (null !== $phase) {
                    $this->updateTreatmentPhases(array($phase), $treatment);
                }
                if ($this->createService->hasValidationMessages()) {
                    ValidationResult::addMessages(
                        $this,
                        $this->createService->getValidationMessages()
                    );
                }
                if (ValidationResult::containsErrors($this->createService->getValidationMessages())) {
                    return $response;
                }
            }
        }

        if ($treatment->isSomatic()) {
            $createController = new Create($this, $this->createService);

            $returnData =  $createController->run($data);
        }

        $response->setData(array("data" => $returnData));
        return $response;
    }

    /**
     * Calls the service to create a basic MHC Activity.
     *
     * @param \Medical\Treatment           $treatment
     * @param \Medical\MHC\Basic\Component $component
     * @param \DateTime                    $performedDate
     * @param \Medical\Activity\Phase      $phase
     *
     * @return array|null
     */
    private function createBasicMhcActivity(Treatment $treatment, Component $component, DateTime $performedDate, Phase $phase = null)
    {
        if ($basicActivity = $this->createService->engage($treatment, $component, $performedDate, $phase)) {
            return $basicActivity->toArray();
        }

        return null;
    }

    /**
     * @SWG\Api(
     *     path="/treatment/activity",
     *     @SWG\Operation(
     *         method="DELETE",
     *         summary="Delete one or more activities.",
     *         @SWG\Parameter(
     *             name="ids",
     *             description="Activity ids.",
     *             type="integer",
     *             paramType="query",
     *             required=true,
     *             allowMultiple=true
     *         ),
     *         @SWG\Parameter(
     *             name="type",
     *             description="Activity type.",
     *             type="string",
     *             paramType="query",
     *             required=true,
     *             allowMultiple=false
     *         ),
     *          @SWG\Parameter(
     *             name="treatmentId",
     *             description="Treatment id.",
     *             type="integer",
     *             paramType="query",
     *             required=true,
     *             allowMultiple=false
     *         )
     *     )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function deleteListAction(Request $request)
    {
        $response = new JsonResponse();
        $query = $request->query;
        $ids = $query->get("ids");

        $type = $query->get('type');
        $this->validateActivityType($type);

        $treatmentId = $query->get('treatmentId');

        try {
            $treatment = $this->idToTreatmentTransformer->transform($treatmentId);
        } catch (TransformationFailedException $e) {
            $this->addInvalidInputMessageToMeta('treatmentId', $treatmentId);
            return $response;
        }

        if (!isset($ids)) {
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne("MG01", array('list_of_fields' => 'ids'))
            );
        }

        if ($this->hasError()) {
            return $response;
        }

        $this->selectStrategyByTreatmentActivityType($treatment, $type);
        $activitiesAttachedWithEmrForm = array();
        foreach ($ids as $id) {
            if (null === $this->transformer) {
                $treatmentActivity = $this->readService->find($id);
            } else {
                try {
                    $treatmentActivity = $this->transformer->transform($id);
                } catch (TransformationFailedException $e) {
                    //will be handled if the treatmentActivity is empty
                }
            }

            if (empty($treatmentActivity)) {
                continue;
            }

            if (true === $this->emrService->hasUserForm($treatmentActivity)) {
                $activitiesAttachedWithEmrForm[] = $id;
            } else if($this->authorizer->isTreatmentAccessable($treatmentActivity->getTreatment())) {
                if ($treatmentActivity->getTreatment()->isSomatic()) {
                    $this->deleteService->delete($treatmentActivity);

                    $errors = $this->deleteService->getErrors();
                    if (!empty($errors)) {
                        ValidationResult::addToMeta($errors, $this);
                    }
                }

                if ($treatmentActivity->getTreatment()->isMHC() && !$this->deleteService->hasErrors()) {
                    $this->deleteService->complete($treatmentActivity);

                    if ($this->deleteService->hasErrors()) {
                        $errors = $this->deleteService->getErrors();
                        ValidationResult::addMessages(
                            $this,
                            $errors,
                            array(),
                            TranslatorFactory::TRANS_DOMAIN_MEDICAL_VALIDATIONS
                        );
                    }
                }

                if(!$this->hasError()) {
                    $this->cleanUpPhases($treatmentActivity);
                }
            }
        }

        if (count($activitiesAttachedWithEmrForm) > 0) {
            $errors[] = array('message' => 'ACT-M28', 'level' => ValidationResult::SUCCESS);
            ValidationResult::addMessages(
                $this,
                $errors,
                array('%codelist%' => implode(',', $activitiesAttachedWithEmrForm),
                ),
                TranslatorFactory::TRANS_DOMAIN_MEDICAL_VALIDATIONS
            );
        }

        return $response;
    }

    /**
     * @SWG\Api(
     *   path="/treatment/activity",
     *   @SWG\Operation(
     *       method="PUT",
     *       summary="Update the MHC/Somatic activity based on the treatment type.",
     *       @SWG\Parameter(name="id", type="integer", paramType="query", required=true),*
     *       @SWG\Parameter(
     *           name="body",
     *           description="Update a MHC or SOM treatment activity.",
     *           required=true,
     *           type="\Medical\MHC\TreatmentActivity OR \Medical\TreatmentActivity.",
     *           paramType="body",
     *           allowMultiple=false
     *       )
     *   )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function updateAction(Request $request)
    {
        $returnData = array();
        $data = json_decode($request->getContent(), true);
        $response = new NonCachedJsonResponse();
        $action = $request->query->get('action');
        $result = false;

        $response->setData(array('data' => array()));

        $id = $request->query->get('id');
        if (empty($id)) {
            $id = $data['id'];
        }

        $treatment = $this->treatmentService->find($data['treatmentId']);
        if (null == $treatment) {
            $this->addInvalidInputMessageToMeta('treatmentId', $data['treatmentId']);

            return $response;
        }

        if (!$this->authorizer->isTreatmentAccessable($treatment)) {
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne('UR3')
            );
        }

        $this->selectStrategyByTreatmentActivityType($treatment, $data['type']);

        if ($data['type'] == InterfaceTreatmentActivity::TYPE_DAY_CARE ||
            $data['type'] == InterfaceTreatmentActivity::TYPE_SPECIAL ||
            $data['type'] == InterfaceTreatmentActivity::TYPE_DAY_OF_STAY
        ) {
            // Begin, new controller structure for treatment activities.
            // The statement above is only to make sure no other types are impacted (yet).

            // Finding correct treatment activity trough read Service
            $treatmentActivity = $this->readService->find($id);
            if (null === $treatmentActivity) {
                // If not found, output default 'unknown id' message
                $this->addInvalidInputMessageToMeta('id', $id);

                return $response;
            }

            // Set fields-to-update on valid treatment activity
            $this->updateService->set($treatmentActivity, $data);
            // Validate updated model, when constraints are not matched, output message.
            if ($this->isModelValid($treatmentActivity, array('update'))) {
                // Model to update was valid. Complete update (event validation, saving, logging).
                $result = $this->updateService->complete();
            }

            if ($this->updateService->hasValidationMessages()) {
                ValidationResult::addMessages(
                    $this,
                    $this->updateService->getValidationMessages()
                );
            }

            if ($result) {
                $returnData = $treatmentActivity->toArray();
            }

            $response->setData(array("data" => $returnData));
            return $response;

        } else {

            /**
             * This stuff is about to be refactored to fit in the structure in the if clause.
             */

            if ($data['type'] == InterfaceTreatmentActivity::TYPE_CTG) {
                try {
                    $ctgMhcActivity = $this->idToCtgMhcActivityTransformer->transform($id);
                } catch (TransformationFailedException $e) {
                    $this->addInvalidInputMessageToMeta('id', $id);

                    return $response;
                }

                if (null !== $treatment && !$this->authorizer->isCtgTreatmentAccessable($treatment)) {
                    $this->getMeta()->addMessage(
                        Meta::STATUS_ERROR,
                        $this->messageHandler->getOne('UR3')
                    );

                    return $response;
                }

                $updatedCtgMhcActivity = clone $ctgMhcActivity;
                $originalCtgMhcActivity = clone $ctgMhcActivity;
                if (isset($data['performer']['id'])) {
                    $updatedCtgMhcActivity->setPerformer(
                        $this->idToEmployeeTransformer->transform($data['performer']['id'])
                    );
                }
                if (isset($data['performed'])) {
                    $data['performed'] = $this->validateBoolean($data['performed'], 'performed');
                    $updatedCtgMhcActivity->setPerformed($data['performed']);
                }

                $currentPerformedDate = $updatedCtgMhcActivity->getPerformedDate();
                if (array_key_exists('performedDate', $data) && $this->validateDateString($data['performedDate'])) {
                    $updatedCtgMhcActivity->setPerformedDate(date_create_from_format('Y-m-d', $data['performedDate']));
                } elseif (empty($currentPerformedDate)) {
                    $updatedCtgMhcActivity->setPerformedDate(CustomerSettingsService::getSystemDate());
                }

                if ($this->isModelValid($updatedCtgMhcActivity, array('update'))) {
                    $ctgMhcActivity = $this->updateService->engage($ctgMhcActivity, $updatedCtgMhcActivity, $data);

                    if ($this->updateService->hasValidationMessages()) {
                        ValidationResult::addMessages(
                            $this,
                            $this->updateService->getValidationMessages()
                        );
                    }
                    if (ValidationResult::containsErrors($this->updateService->getValidationMessages())) {
                        return $response;
                    }
                }
                $this->cleanUpPhases($originalCtgMhcActivity);
                $fakeArray = $this->prepareForGui(array($ctgMhcActivity));
                $response->setData(array("data" => $fakeArray[0]));

                return $response;
            } elseif ($treatment->isMhcDbc()) {
                $this->selectStrategyByTreatment($treatment);
                $treatmentActivity = $this->readService->getOneById($id);

                $newPerformedDate = $treatmentActivity->getPerformedDate() ?: CustomerSettingsService::getSystemDate();
                if (isset($data['performedDate']) && $this->validateDateString($data['performedDate'])) {
                    $newPerformedDate = new DateTime($data['performedDate']);
                }

                if (!$this->updateService->isValidOnPerformedDate($treatmentActivity, $newPerformedDate)) {
                    $treatmentActivity = $this->readService->updateWithValidActivityOnPerformedDate(
                        $treatmentActivity,
                        $newPerformedDate
                    );
                    $data['activityId'] = $treatmentActivity->getActivity()->getId();
                }

                if (null === $treatmentActivity) {
                    $this->addInvalidInputMessageToMeta('id', $id);

                    return $response;
                }

                $treatmentActivity = $this->updateService->set($treatment, $data, $treatmentActivity);
                if ($this->isModelValid($treatmentActivity, array('update'))) {
                    $this->updateService->complete($treatmentActivity);

                    $errors = $this->updateService->getErrors();
                    if (!ValidationResult::containsErrors($errors)) {
                        $oldTreatmentActivity = $this->updateService->getOldTreatmentActivity();
                        $this->cleanUpPhases($oldTreatmentActivity);

                        $fakeArray = $this->prepareForGui(array($treatmentActivity));
                        $returnData = $fakeArray[0];
                    }

                    if ($this->updateService->hasErrors()) {
                        ValidationResult::addMessages($this, $errors);
                    }
                }
                $response->setData(array("data" => $returnData));

                return $response;

            } elseif ($treatment->isBasicMhc()) {
                try {
                    $basicMhcActivity = $this->idToBasicMhcActivityTransformer->transform($id);
                } catch (TransformationFailedException $e) {
                    $this->addInvalidInputMessageToMeta('id', $id);
                    return $response;
                }

                if (null !== $treatment && !$this->authorizer->isBasicTreatmentComponentAccessable($treatment)) {

                    $this->getMeta()->addMessage(
                        Meta::STATUS_ERROR,
                        $this->messageHandler->getOne('UR3')
                    );

                    return $response;
                }
                $updatedBasicMhcActivity = clone $basicMhcActivity;

                if (isset($data['directTime'])) {
                    $updatedBasicMhcActivity->setDirectTime($data['directTime']);
                    $updatedBasicMhcActivity->setInDirectTime($data['indirectTime']);
                    $updatedBasicMhcActivity->setTravelTime($data['travelTime']);
                }

                if (isset($data['performer'])) {
                    $updatedBasicMhcActivity->setPerformer(
                        $this->idToEmployeeTransformer->transform($data['performer']['id'])
                    );
                }

                if (isset($data['performed'])) {
                    $updatedBasicMhcActivity->setPerformed($data['performed']);
                }

                if (empty($data['performedDate'])) {
                    $data['performedDate'] = $basicMhcActivity->getPerformedDate()->format('Y-m-d');
                }

                if ($this->validateDateString($data['performedDate'])) {
                    $updatedBasicMhcActivity->setPerformedDate(
                        date_create_from_format('Y-m-d', $data['performedDate'])
                    );
                } else {
                    //this then will throw a correct error because of the validators in the Activity class.
                    $updatedBasicMhcActivity->setPerformedDate(null);
                }

                if (isset($data['phase'])) {
                    if (!empty($data['phase']['id'])) {
                        $phase = $this->getPhaseObject($data['phase']['id']);
                    }
                }
                if ($this->isModelValid($updatedBasicMhcActivity, array('update'))) {
                    $oldTreatmentActivity = clone $basicMhcActivity;
                    $basicMhcActivity = $this->updateService->engage(
                        $basicMhcActivity,
                        $updatedBasicMhcActivity,
                        $data
                    );

                    $fakeArray = $this->prepareForGui(array($basicMhcActivity));
                    $returnData = $fakeArray[0];

                    if ($this->updateService->hasValidationMessages()) {
                        ValidationResult::addMessages(
                            $this,
                            $this->updateService->getValidationMessages()
                        );
                    }
                    if (ValidationResult::containsErrors($this->updateService->getValidationMessages())) {
                        $response->setData(array("data" => array()));

                        return $response;
                    }
                }

                $this->cleanUpPhases($oldTreatmentActivity);
                $response->setData(array("data" => $returnData));
                return $response;
            } elseif ($treatment->isSomatic()) {
                $treatmentActivity = $this->readService->getOneById($id);
                if (null === $treatmentActivity) {
                    $this->addInvalidInputMessageToMeta('id', $id);
                    
                    return $response;
                } elseif ($treatment->isSomatic()) {
                    if ($action == 'updatePhase') {
                        try {
                            $this->idToPhaseTransformer->transform($data['phaseId']);
                        } catch (TransformationFailedException $e) {
                            return $response;
                        }

                        $treatmentActivity = $this->readService->getOneById($id);
                        if (null === $treatmentActivity) {
                            $this->addInvalidInputMessageToMeta('id', $id);

                            return $response;
                        }
                    }

                    $updateController = new Update($this, $this->updateService);

                    $treatmentActivity = $updateController->run($id, $data);

                    $errors = $this->updateService->getRawMessages();
                    if (count($errors) > 0) {
                        $this->registerRawMessages();
                    }

                    $errors = $this->updateService->getErrors();
                    if (!empty($errors)) {
                        ValidationResult::addMessages($this, $errors);
                    }

                    if ($this->hasError() || null === $treatmentActivity) {
                        return $response;
                    }

                    $this->cleanUpPhaseByTreatment($treatmentActivity->getTreatment());

                    $returnData = array_merge(
                        $treatmentActivity->toArray(),
                        $this->getTreatmentActivityAmountData($treatmentActivity)
                    );
                    $response->setData(array("data" => $returnData));

                    return $response;
                }
            }
        }
    }

    /**
     * Remove the phase when there are no activities.
     *
     * @param \Medical\TreatmentActivity $treatmentActivity
     */
    private function cleanUpPhases($treatmentActivity)
    {
        if (null !== $treatmentActivity->getPhase() && $treatmentActivity->getPhaseName()) {
            $activitiesOnPhase = $this->readService->findByPhase(
                $treatmentActivity->getTreatment(),
                $treatmentActivity->getPhase()
            );
            if (empty($activitiesOnPhase) && null !== $treatmentActivity->getPhase()) {
                $this->treatmentActivityPhaseService->deleteByPhaseAndTreatment(
                    $treatmentActivity->getPhase(),
                    $treatmentActivity->getTreatment()
                );
            }
        }
    }

    /**
     * Clean up phases by given treatment.
     *
     * @param \Medical\Treatment $treatment
     */
    public function cleanUpPhaseByTreatment(Treatment $treatment)
    {
        $treatmentPhases = $this->treatmentActivityPhaseService->findByTreatment($treatment);
        /**
         * @var \Medical\TreatmentActivityPhase $phase
         */
        foreach ($treatmentPhases as $treatmentPhase) {
            $activitiesOnPhase = $this->readService->findByPhase(
                $treatment,
                $treatmentPhase->getPhase()
            );
            if (empty($activitiesOnPhase)) {
                $this->treatmentActivityPhaseService->deleteByPhaseAndTreatment(
                    $treatmentPhase->getPhase(),
                    $treatment
                );
            }
        }
    }

    /**
     *  @SWG\Api(
     *      path="/treatment/activity/move",
     *      @SWG\Operation(
     *          method="PUT",
     *          summary="Move the activities to the desired treatment",
     *          notes="Returns an array containing an array with activity ids that were moved successfully and one with
     *              ids that were not moved",
     *          @SWG\Parameter(
     *              name="Mover model",
     *              type="\Medical\Treatment\Activity\Mover",
     *              required=true,
     *              description="Mover model containing the desired data",
     *              paramType="body"
     *          )
     *      )
     *  )
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function moveAction(Request $request)
    {
        $allowedActivityTypes = array(
            InterfaceTreatmentActivity::TYPE_CTG,
            InterfaceTreatmentActivity::TYPE_TIMEWRITING,
            InterfaceTreatmentActivity::TYPE_DAY_CARE,
            InterfaceTreatmentActivity::TYPE_DAY_OF_STAY,
            InterfaceTreatmentActivity::TYPE_SPECIAL,
        );

        $allowedActivityTypesSomatic = array(
            InterfaceTreatmentActivity::TYPE_SOM,
            InterfaceTreatmentActivity::TYPE_AWBZ,
        );

        $response = new JsonResponse();

        // get the data from the request and validate it
        $data = json_decode($request->getContent(), true);

        if (!$this->validateMoveRequest($data)) {
            return $response;
        }

        $groupedActivities = $this->groupActivitiesByType($data['activities']);
        $mover = $this->processMoveRequest($data);

        $sourceTreatment = $this->createEntity(
            $mover->getSourceTreatmentId(),
            'sourceTreatmentId',
            $this->treatmentService,
            'Medical\Treatment'
        );

        $destinationTreatment = $this->createEntity(
            $mover->getDestinationTreatmentId(),
            'destinationTreatmentId',
            $this->treatmentService,
            'Medical\Treatment'
        );

        $moveResults = array(
            'succeeded' => array(),
            'failed'    => array(),
        );

        $succeededTotal = array();
        $failedTotal = array();
        $AllAffectedPhases = array();

        if (!$this->getMeta()->hasError()) {
            $mover->setDestinationTreatment($destinationTreatment);
            $mover->setSourceTreatment($sourceTreatment);
            $this->selectStrategyByTreatment($sourceTreatment);
            if ($sourceTreatment->isSomatic()) {
                foreach ($groupedActivities as $type => $activityIds) {
                    if (in_array($type, $allowedActivityTypesSomatic)) {
                        $mover->setActivityIds($activityIds);
                    }
                }
                $activities = $this->readService->findByIds($mover->getActivityIds());
                if (!empty($activities)) {
                    $moveResults = $this->readService->move(
                        $sourceTreatment,
                        $destinationTreatment,
                        $activities
                    );
                }
                $errorsArray = $this->readService->getErrors();
            } elseif ($this->moverService->isValid($sourceTreatment, $destinationTreatment)) {
                foreach ($groupedActivities as $type => $activityIds) {
                    if (in_array($type, $allowedActivityTypes)) {
                        $this->selectStrategyByTreatmentActivityType($sourceTreatment, $type);
                        $activities = $this->readService->getAllByIds($activityIds);
                        $results = $this->moverService->move($activities, $mover);
                        $AllAffectedPhases[] = $results['affectedPhases'];
                        $succeededTotal[] = $results['succeeded'];
                        $failedTotal[] = $results['failed'];
                    } else {
                        $failedTotal = array_merge($failedTotal, $activityIds);
                    }
                }
                $moveResults['succeeded'] = $this->formatResult($succeededTotal);
                $moveResults['failed'] = $this->formatResult($failedTotal);
                $formattedAffectedPhases = $this->formatResult($AllAffectedPhases);
                $errorsArray = $this->moverService->getErrors();

                if (count($formattedAffectedPhases) > 0) {
                    $this->clearTreatmentPhasesIfEmpty($formattedAffectedPhases, $sourceTreatment);
                    $this->updateTreatmentPhases($formattedAffectedPhases, $destinationTreatment);
                }
            } else {
                foreach ($groupedActivities as $activityIds) {
                    $errorsArray = $this->moverService->getErrors();
                    $moveResults['failed'] = array_merge($moveResults['failed'], $activityIds);
                }
            }

            if (!empty($errorsArray)) {
                ValidationResult::addMessages($this, $errorsArray, array(
                    '%codelist%' => implode(',', $moveResults['failed']),
                ));
            }

            $response->setData(
                array(
                    'data' => $moveResults,
                )
            );
        }

        return $response;
    }

    /**
     * Delete the treatment phases if they don't have any activity in it.
     *
     * @param array $affectedPhases
     * @param Treatment $sourceTreatment
     */
    private function clearTreatmentPhasesIfEmpty(array $affectedPhases, Treatment $sourceTreatment)
    {
        $processedPhases = array();

        foreach ($affectedPhases as $phase) {
            $this->selectStrategyByPhase($phase, $sourceTreatment);

            $activitiesOnPhase = $this->readService->findByPhase(
                $sourceTreatment,
                $phase
            );

            if (count($activitiesOnPhase) === 0 && $phase !== null &&
                !in_array($phase->getId(), $processedPhases)
            ) {
                $this->treatmentActivityPhaseService->deleteByPhaseAndTreatment(
                    $phase,
                    $sourceTreatment
                );
                $processedPhases[] = $phase->getId();
            }
        }
    }

    /**
     * Update the destination treatment with new phases(originated phases from source treatment) if not exists already.
     *
     * @param array              $affectedPhases
     * @param \Medical\Treatment $destinationTreatment
     */
    private function updateTreatmentPhases(array $affectedPhases, Treatment $destinationTreatment)
    {
        $treatmentActivityPhaseService = $this->treatmentActivityPhaseService;
        array_walk($affectedPhases, function ($phase) use ($destinationTreatment, $treatmentActivityPhaseService){
            if (null === $treatmentActivityPhaseService->findByPhaseAndTreatment($phase, $destinationTreatment)) {
                $treatmentActivityPhaseService->createPhaseForTreatment($phase, $destinationTreatment);
            }
        });
    }

    /**
     * Convert the multidimensional array into a simple array which will be accepted by GUI.
     *
     * @param array $result
     *
     * @return array
     */
    private function formatResult(array $result)
    {
        $formatted = array();

        array_walk_recursive($result,
            function ($value) use (&$formatted){
                $formatted[] = $value;
            }
        );

        return $formatted;
    }

    /**
     * Group the activities based on type.
     *
     * @param array $activities
     * @return array
     */
    private function groupActivitiesByType(array $activities)
    {
        $groupByType = array();
        foreach ($activities as $activity) {
             $groupByType[$activity['type']][] = $activity['id'];
        }

        return $groupByType;
    }

    /**
     * Process the request data and store it in the appropriate model.
     *
     * @param array $requestData
     *
     * @return Mover
     */
    private function processMoveRequest(array $requestData)
    {
        $mover = new Mover();
        $mover->setSourceTreatmentId($requestData['sourceTreatmentId']);
        $mover->setDestinationTreatmentId($requestData['destinationTreatmentId']);

        return $mover;
    }

    /**
     * Validate the request data of the move request.
     *
     * @param array $requestData
     *
     * @return bool
     */
    private function validateMoveRequest(array $requestData)
    {
        $validRequest = true;
        if (!isset($requestData['destinationTreatmentId'])) {
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne("MG01", array('list_of_fields' => 'destinationTreatmentId'))
            );
            $validRequest = false;
        }
        if (!isset($requestData['sourceTreatmentId'])) {
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne("MG01", array('list_of_fields' => 'sourceTreatmentId'))
            );
            $validRequest = false;
        }
        if (!isset($requestData['activities'])) {
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne("MG01", array('list_of_fields' => 'activities'))
            );
            $validRequest = false;
        }
        return $validRequest;
    }

    /**
     * getTreatmentActivityObject
     *      get the treatmentActivity Object if id exists
     *
     * @param   int $id
     * @return  \Medical\TreatmentActivity
     */
    public function getTreatmentActivityObject($id)
    {
        $treatmentActivity = $this->createEntity(
            $id,
            'id',
            $this->readService,
            "Medical\\TreatmentActivity"
        );

        return $treatmentActivity;
    }

    /**
     * getCostCenterObject
     *      get the CostCenter Object if id exists
     *
     * @param   int $id
     * @return  \System\CostCenter
     */
    public function getCostCenterObject($id, $paramName)
    {
        $costCenter = $this->createEntity(
            $id,
            $paramName,
            new \System\CostCenterService(),
            "System\\CostCenter"
        );
        return $costCenter;
    }

    /**
     * getActivityObject
     *      get the Activity Object if id exists
     * @param   int $id
     * @param string $fieldName
     * @return  \Medical\Activity
     */
    public function getActivityObject($id, $fieldName = "activity")
    {
        $activityService = new \Medical\ActivityService();
        $activity = $this->createEntity(
            $id,
            $fieldName,
            $activityService,
            "Medical\\Activity"
        );

        return $activity;
    }

    /**
     * getSpecialistObject
     *      get the specialist Object if id exists
     * @param   int $id
     * @param string $fieldName
     *
     * @return  \Generic\Employee
     */
    public function getSpecialistObject($id, $fieldName = "specialistId")
    {
        $employeeService = new \Generic\EmployeeService();

        $employee = $this->createEntity(
            $id,
            $fieldName,
            $employeeService,
            "Generic\\Employee"
        );

        return $employee;
    }

    /**
     * getSpecialismObject
     *      get the specialism Object if id exists
     * @param   int $id
     * @param string $fieldName
     *
     * @return  \Generic\Employee
     */
    public function getSpecialismObject($id, $fieldName = "specialistId")
    {
        $specialism = $this->createEntity(
            $id,
            $fieldName,
            new \Generic\SpecialismService(),
            "Generic\\Specialism"
        );

        return $specialism;
    }

    public function getAppointmentObject($id)
    {
        $appointmentModel = new \Calendar\AppointmentService();
        $appointment = $this->createEntity($id, "appointmentId", $appointmentModel, "Calendar\\Appointment");

        if ($appointment && $appointment instanceof \Calendar\Appointment) {
            return $appointment;
        }

        return null;
    }

    /**
     * Register raw messages in the controller meta property.
     */
    private function registerRawMessages()
    {
        $rawMessages = $this->readService->getRawMessages();
        foreach ($rawMessages as $rawMessage) {
            $this->getMeta()->addMessage($rawMessage['level'], $rawMessage['message']);
        }
    }

    /**
     * Returns a Phase object identified by $phaseId.
     *
     * @param integer  $phaseId
     *
     * @return \Medical\Activity\Phase
     */
    public function getPhaseObject($phaseId)
    {
        $phase = null;
        if (!empty($phaseId)) {
            try {
                $phase = $this->idToPhaseTransformer->transform($phaseId);
            } catch(TransformationFailedException $e) {
                $this->addInvalidInputMessageToMeta('phaseId', $phaseId);
            }
        }

        return $phase;
    }

    /**
     * Fetches as treatment.
     *
     * @param integer $id
     *
     * @return \Medical\Treatment
     */
    public function getTreatmentObject($id)
    {
        return $this->treatmentService->find($id);
    }

    /**
     * Validate the activity type by checking if it is filled AND exists in the list of types.
     *
     * @param string $activityType
     */
    private function validateActivityType($activityType)
    {
        $activityTypes = array(
            InterfaceTreatmentActivity::TYPE_SOM,
            InterfaceTreatmentActivity::TYPE_AWBZ,
            InterfaceTreatmentActivity::TYPE_CTG,
            InterfaceTreatmentActivity::TYPE_TIMEWRITING,
            InterfaceTreatmentActivity::TYPE_DAY_CARE,
            InterfaceTreatmentActivity::TYPE_DAY_OF_STAY,
            InterfaceTreatmentActivity::TYPE_SPECIAL,
        );

        if ($activityType == null || empty($activityType) ||
            !in_array($activityType, $activityTypes)) {
            $this->addInvalidInputMessageToMeta('type', $activityType);
        }
    }
}
