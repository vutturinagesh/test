<?php

namespace Controller\Treatment;

use Actinidium\API\Response\Meta;
use Controller\AbstractController;
use Generic\Authorizer;
use Medical\Treatment;
use Medical\TreatmentService;
use Medical\MHC\CareTypeService;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use System\MHC\CareTypeService as SystemCareTypeService;

/**
 * @SWG\Resource(
 *      apiVersion="2.0",
 *      swaggerVersion="1.2",
 *      resourcePath="/treatment",
 *      basePath="/api/v2"
 * )
 */
class CareTypeController extends AbstractController
{
    /**
     * @var \Medical\TreatmentService
     */
    private $treatmentService;

    /**
     * @var \System\MHC\CareTypeService
     */
    private $systemCareTypeService;

    /**
     * @var \Medical\MHC\CareTypeService
     */
    private $mhcCareTypeService;

    /**
     * @var \Generic\Authorizer
     */
    private $authorizer;


    /**
     * Instantiate the controller with all its dependencies.
     *
     * If some are not injected fetch them from the container.
     *
     * @param \Medical\TreatmentService    $treatmentService
     * @param \System\MHC\CareTypeService  $systemCareTypeService
     * @param \Medical\MHC\CareTypeService $mhcCareTypeService
     * @param \Generic\Authorizer          $authorizer
     */
    public function __construct(
        TreatmentService $treatmentService = null,
        SystemCareTypeService $systemCareTypeService = null,
        CareTypeService $mhcCareTypeService = null,
        Authorizer      $authorizer = null
    ) {
        parent::__construct();

        if (null === $treatmentService) {
            $treatmentService = $this->get('medicore.medical.treatment_service');
        }

        if (null === $systemCareTypeService) {
            $systemCareTypeService = $this->get('medicore.system.mhc.care_type_service');
        }

        if (null === $mhcCareTypeService) {
            $mhcCareTypeService = $this->get('medicore.medical.treatment.mhc.care_type_service');
        }

        if (null === $authorizer) {
            $authorizer = $this->get('medicore.generic.authorizer');
        }

        $this->treatmentService      = $treatmentService;
        $this->systemCareTypeService = $systemCareTypeService;
        $this->mhcCareTypeService    = $mhcCareTypeService;
        $this->authorizer            = $authorizer;
    }

    /**
     * @SWG\Api(
     *      path="/medical/treatment",
     *      @SWG\Operation(
     *          method="GET",
     *          summary="Get the CareType registered for the treatment.",
     *          notes="Only works for MHC DBC treatments",
     *          @SWG\Parameter(
     *              name="treatmentId",
     *              description="The id of the treatment for which to fetch the CareType",
     *              type="integer",
     *              paramType="query",
     *              required=true
     *          )
     *      )
     * )
     *
     * Get the CareType registered for the treatment.
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function getAction(Request $request)
    {
        $data = array();
        $query = $request->query;

        if ($query->has('treatmentId')) {
            $treatment = $this->validateTreatment($query->get('treatmentId'));

            if (!$this->hasError()) {
                if (!$this->authorizer->isTreatmentAccessable($treatment)) {
                    $this->getMeta()->addMessage(
                        Meta::STATUS_ERROR,
                        $this->messageHandler->getOne('UR3')
                    );
                }
            }
        } else {
            $this->getMeta()->setCount(0);
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne(
                    'MG01',
                    array('list_of_fields' => 'treatmentId')
                )
            );
        }

        if (!$this->hasError()) {
            $data = $treatment->getDbcCareType();
            $this->getMeta()->setCount(1);
        }

        $response = new JsonResponse();
        $response->setData(array('data' => $data));

        return $response;
    }

    /**
     * @SWG\Api(
     *      path="/medical/treatment",
     *      @SWG\Operation(
     *          method="PUT",
     *          summary="Update the CareType registered for the treatment.",
     *          notes="Only works for MHC DBC treatments",
     *          @SWG\Parameter(
     *              name="treatmentId",
     *              description="The id of the treatment for which to fetch the CareType",
     *              type="integer",
     *              paramType="query",
     *              required=true
     *          ),
     *          @SWG\Parameter(
     *              name="body",
     *              description="MHC CareType Object, see toArray as reference.",
     *              required=true,
     *              type="\Medical\MHC\CareType",
     *              paramType="body",
     *              allowMultiple=false
     *          )
     *      )
     * )
     *
     * Update the CareType registered for the treatment.
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function updateAction(Request $request)
    {
        $data = array();

        $queryParams = $request->query->all();
        $requestData = json_decode($request->getContent(), true);

        $this->validateRequest($queryParams, $requestData);
        $this->getMeta()->setCount(0);

        //validate the treatment and the caretype
        if (!$this->hasError()) {
            $treatment = $this->validateTreatment($queryParams['treatmentId']);

            //Checking authentication for the logged in user.
            if (!$this->hasError()) {
                if (!$this->authorizer->isTreatmentWritable($treatment)) {
                    $this->getMeta()->addMessage(
                        Meta::STATUS_ERROR,
                        $this->messageHandler->getOne('UR3')
                    );
                }
            }

            $careType = $this->validateCareType($requestData['id']);
        }

        //validate if the caretype can be set for the treatment.
        if (!$this->hasError()) {
            $this->mhcCareTypeService->validateIsSelectable($careType);
            $this->mhcCareTypeService->validateCareTypeForTreatment($careType, $treatment);
            $this->addErrorsToMeta($this->mhcCareTypeService->getErrors());
        }
        
        //if all validations pass, stored the item.
        if (!$this->hasError() && $treatment->getTreatmentType() === Treatment::TYPE_DBC) {

            $this->mhcCareTypeService->edit($treatment->getDbcMhc(), $careType);
            $data = $careType->toListArray();
            $this->getMeta()->setCount(1);
        }

        $response = new JsonResponse();
        $response->setData(array('data' => $data));

        return $response;
    }

    /**
     * Check if all the parameters are present that are needed.
     *
     * @param array $queryParams
     * @param array $postParams
     *
     */
    private function validateRequest(array $queryParams, array $postParams)
    {
        if (!isset($queryParams['treatmentId'])) {
            $this->addMG01ToMetaForField('treatmentId');
        }

        if (!isset($postParams['id'])) {
            $this->addMG01ToMetaForField('id');
        }
    }

    /**
     * Add MG01 to the Meta for the fieldname passed.
     *
     * @param string $fieldName
     */
    private function addMG01ToMetaForField($fieldName)
    {
        $this->getMeta()->addMessage(
            Meta::STATUS_ERROR,
            $this->messageHandler->getOne(
                'MG01',
                array('list_of_fields' => $fieldName)
            )
        );
    }

    /**
     * Validate if the treatmentId passed to this function is an existing Treatment.
     *
     * @param string $treatmentId
     *
     * @return \Medical\Treatment|null
     */
    public function validateTreatment($treatmentId)
    {
        return $this->createEntity($treatmentId, 'id', $this->treatmentService, 'Medical\Treatment');
    }

    /**
     * Validate if the CareType passed to this function is an existing CareType.
     *
     * @param string $careTypeId
     *
     * @return \System\MHC\CareType|null
     */
    private function validateCareType($careTypeId)
    {
        return $this->createEntity($careTypeId, 'id', $this->systemCareTypeService, 'System\MHC\CareType');
    }
}
