<?php

namespace Controller\Treatment\Activity;

use Actinidium\API\Response\Meta;
use Generic\EmployeeService;
use Controller\Treatment\ActivityController;
use Controller\ValidationResult;
use Generic\CustomerSettingsService;
use Medical\TreatmentActivityService;

class Create
{
    /**
     * @var \Medical\TreatmentActivityService
     */
    private $model;

    /**
     * @var \Controller\AbstractController
     */
    private $parentController;

    /**
     * @var array
     */
    private $data = array();

    /**
     * @var \Medical\Treatment
     */
    private $treatment;

    /**
     * @var \Medical\Activity
     */
    private $activity;

    /**
     * @var \Generic\Employee
     */
    private $specialist;

    /**
     * @var \DateTime
     */
    private $executionDate;

    /**
     * @var int
     */
    private $amount;

    /**
     * @var String
     */
    private $note;

    /**
     * Constructor.
     *
     * @param \Controller\Treatment\ActivityController $controller
     * @param \Medical\TreatmentActivityService        $treatmentActivityService
     */
    public function __construct(
        ActivityController $controller,
        TreatmentActivityService $treatmentActivityService
    ) {
        $this->parentController = $controller;
        $this->model = $treatmentActivityService;
    }

    /**
     * run
     *  The entry for create
     *
     * @param   Array $data
     * @return  Array
     */
    public function run($data)
    {
        $this->data = array();
        $this->createObjects($data);

        if ($this->parentController->getMeta()->hasError()) {
            return $this->data;
        }

        if ($this->save()) {
            $this->data = $this->getDetailedList();
        }

        return $this->data;
    }

    /**
     * getDetailedList
     */
    protected function getDetailedList()
    {
        // @TODO: This will be changed to toArray once its implemented
        $treatmentActivity = $this->model->getTreatmentActivity();
        return $treatmentActivity->toArray();
    }

    /**
     * save
     *      Create new treatment Activity
     *
     * @return boolean
     */
    protected function save()
    {
        $parameters = array(
            "treatment"     => $this->treatment,
            "activity"      => $this->activity,
            "performer"     => $this->specialist,
            "amount"        => $this->amount,
            "executionDate" => $this->executionDate,
            "amountType"    => $this->activity->getTypeOfAmount(),
            "note"          => $this->note
        );

        $parameters['amountMultiplier'] = $this->activity->getAmountMultiplier();

        $treatmentActivity = $this->model->create($parameters);
        if ($treatmentActivity && $treatmentActivity->getPhaseName() !== '') {
            $this->model->registerTreatmentActivityPhase(
                $treatmentActivity->getActivity()->getDefaultPhase(),
                $treatmentActivity
            );
        }

        $errors = $this->model->getErrors();

        ValidationResult::addToMeta($errors, $this->parentController);

        if ($this->model->hasRawMessages()) {
            $this->registerRawMessages();
        }

        return $treatmentActivity;
    }

    /**
     * Register raw messages in the controller meta property.
     */
    private function registerRawMessages()
    {
        $rawMessages = $this->model->getRawMessages();
        foreach ($rawMessages as $rawMessage) {
            $this->parentController->getMeta()->addMessage($rawMessage['level'], $rawMessage['message']);
        }
    }

    /**
     * createObjects
     *      Validate and create proper objects
     *
     * @param array $data
     * @return bool
     */
    protected function createObjects($data)
    {
        $this->createTreatmentObject($data['treatmentId']);

        $this->createActivityObject($data['activityId']);
        $this->createAwbzObject($data['awbz']);
        $this->createSpecialistObject($data['performerId']);
        $this->createExecutionDateObject($data['performedDate']);

        $amountMinimumForActivity = $this->activity->getAmountMinimum();
        $this->setAmount($amountMinimumForActivity);
        if (array_key_exists('amount', $data) && null !== $data['amount'] && $data['amount'] > $amountMinimumForActivity) {
            $this->setAmount($data['amount']);
        }

        $this->setNote($data['note']);
        return true;
    }

    private function createAwbzObject($awbzData)
    {
        $this->awbz = new \Medical\Treatment\Activity\Awbz();
        $this->awbz->setFunctioncode($awbzData['functioncode']);
    }

    /**
     * @return EmployeeService
     */
    protected function getEmployeeModel()
    {
        if (!$this->employeeModel) {
            $this->employeeModel = new EmployeeService();
        }
        return $this->employeeModel;
    }


    /**
     * createTreatmentObject
     *      Create treatment object
     *
     * @param   int $treatmentId
     */
    private function createTreatmentObject($treatmentId)
    {
        $this->treatment = $this->parentController->getTreatmentObject($treatmentId, "treatmentId");
    }

    /**
     * createActivityObject
     *      Create activity object
     *
     * @param   int $activityId
     */
    private function createActivityObject($activityId)
    {
        $this->activity = $this->parentController->getActivityObject($activityId, "activityId");
    }

    /**
     * createSpecialistObject
     *      Create specialist object
     *
     * @param   int $specialistId
     */
    private function createSpecialistObject($specialistId)
    {
        $this->specialist = null;
        if (mb_strlen($specialistId)) {
            $this->specialist = $this->parentController->getSpecialistObject($specialistId, "performerId");
        } else {
            if ($this->treatment) {
                $this->specialist = $this->getEmployeeModel()->getDefaultPerformer($this->treatment);
            }
        }
    }

    /**
     * createExecutionDateObject
     *      Create a new execution date object
     *
     * @param       String $executionDate
     */
    private function createExecutionDateObject($executionDate)
    {
        if (!$executionDate) {
            $this->executionDate = $this->getSystemDate();
        } else {
            $this->executionDate = $this->parentController->validateDate($executionDate, "executionDate");
        }
    }

    /**
     * @return \DateTime
     */
    protected function getSystemDate()
    {
        return CustomerSettingsService::getSystemDate();
    }

    /**
     * Sets the amount for an activity. The amount can be any valid number
     * greater than 0.
     *
     * @param int $amount
     */
    private function setAmount($amount)
    {
        $amount = $amount ? $amount : 1;

        if (\Security\Sanitizer::isPositiveInteger($amount)) {
            $this->amount = $amount;
        } else {
            $this->parentController->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->parentController->getMessageHandler()->getOne('M057')
            );
        }
    }

    /**
     * setNote
     *
     * @param   String $note
     */
    private function setNote($note)
    {
        $this->note = $note;
    }
}
