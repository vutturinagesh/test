<?php

namespace Controller\Treatment\Activity;

use Actinidium\API\Response\Meta;
use Controller\AbstractController;
use Controller\ValidationResult;
use Controller\TreatmentController;
use Medical\TreatmentActivityService;
use Medical\Treatment;
use Medical\TreatmentActivityAuthorizationService;
use Medical\TreatmentActivityAuthorization;
use Generic\Authorizer;
use Message\MessageHandler;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Exception;
use RuntimeException;
use InvalidArgumentException;
use DateTime;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/treatment",
 *     basePath="http://nighlt.mc12.efocus.local/api/v2"
 * )
 */
class AuthorizationController extends AbstractController
{
    /**
     * @var \Medical\TreatmentActivityAuthorizationService
     */
    private $authorizationService;

    /**
     * @var \Medical\TreatmentActivityService
     */
    private $treatmentActivityService;

    /**
     * Holds the default value for 'status'.
     */
    const DEFAULT_STATUS_VALUE = 'leeg';

    /**
     * @SWG\Api(
     *   path="/treatment/activity/authorization",
     *   @SWG\Operation(
     *       method="GET",
     *       summary="Find an authorization.",
     *       notes="Returns authorization information",
     *       @SWG\Parameter(name="id", type="integer", required=true, description="The authorization ID", paramType="query")
     *   )
     * )
     *
     * Returns information about the authorization that is given.
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function getAction(Request $request)
    {
        $response = new JsonResponse();
        $result = array();

        $authorizationId = $request->query->get('id');

        try {
            if (null === $authorizationId) {
                throw new InvalidArgumentException('Authorization id is required.');
            }
            $authorization = $this->get('medicore.medical.treatment_activity_authorization_service')->get($authorizationId);
            $result = $authorization->toArray();
        } catch (Exception $e) {
            $this->logException($e);
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->add(
                    'MG21',
                    MessageHandler::BLOCKING
                )
            );
        }

        $response->setData(array('data' => $result));
        return $response;
    }

    /**
     * @SWG\Api(
     *   path="/treatment/activity/authorization",
     *   @SWG\Operation(
     *       method="POST",
     *       summary="Create an authorization request."
     *   )
     * )
     *
     * Add an authorization request to an activity.
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse;
     */
    public function createAction(Request $request)
    {
        $response = new JsonResponse();
        $result = array();

        $data = json_decode($request->getContent(), true);
        $data = $this->validateInputParameters($data);

        try {
            if (false === $data) {
                throw new Exception('Validation of the request failed.');
            }

            if (!$this->getMeta()->hasError()) {
                $authorizationService = $this->get('medicore.medical.treatment_activity_authorization_service');
                $authorization = $authorizationService->create($data);

                if (count($authorizationService->getErrors()) > 0) {
                    ValidationResult::addToMeta($authorizationService->getErrors(), $this);
                }

                if (null !== $authorization) {
                    $result = $authorization->toArray();
                }
            }
        } catch(Exception $e) {
            $this->logException($e);
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->add(
                    'MG21',
                    MessageHandler::BLOCKING
                )
            );
        }

        $response->setData(array('data' => $result));
        return $response;
    }

    /**
     * @SWG\Api(
     *   path="/treatment/activity/authorization",
     *   @SWG\Operation(
     *       method="PUT",
     *       summary="Update an existing authorization request.",
     *       @SWG\Parameter(name="id", type="integer", required=true, description="The authorization ID")
     *   )
     * )
     *
     * Update details about an authorization request.
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse;
     */
    public function updateAction(Request $request)
    {
        $response = new JsonResponse();
        $result = array();

        $data = json_decode($request->getContent(), true);
        $data = $this->validateInputParameters($data, true);
        $authorizationId = $data['id'];

        $authorizationService = $this->get('medicore.medical.treatment_activity_authorization_service');

        try {
            if (null === $authorizationId) {
                throw new InvalidArgumentException('Authorization id is required.');
            }

            if (!$this->getMeta()->hasError()) {
                $authorization = $authorizationService->edit($data);

                if (count($authorizationService->getErrors()) > 0) {
                    ValidationResult::addToMeta($authorizationService->getErrors(), $this);
                }
            }

            if (null !== $authorization) {
                $result = $authorization->toArray();
            }

        } catch (Exception $e) {
            $this->logException($e);
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->add(
                    'MG21',
                    MessageHandler::BLOCKING
                )
            );
        }

        $response->setData(array('data' => $result));
        return $response;
    }

    /**
     * @SWG\Api(
     *   path="/treatment/activity/authorization",
     *   @SWG\Operation(
     *       method="DELETE",
     *       summary="Delete an existing authorization request.",
     *       @SWG\Parameter(name="id", type="integer", required=true, description="The authorization ID")
     *   )
     * )
     *
     * Delete an authorization.
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse;
     */
    public function deleteAction(Request $request)
    {
        $response = new JsonResponse();
        $result = array();

        $authorizationId = $request->query->get('id');
        $authorizationService = $this->get('medicore.medical.treatment_activity_authorization_service');

        try {
            if (null === $authorizationId) {
                throw new InvalidArgumentException('Authorization id is required.');
            }

            $authorization = $authorizationService->get($authorizationId);

            if (null === $authorization) {
                throw new NotFoundHttpException('Authorization not found');
            }

            $authorizationService->delete($authorization);
        } catch (NotFoundHttpException $e) {
            throw $e;
        } catch (Exception $e) {
            $this->logException($e);
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->add(
                    'MG21',
                    MessageHandler::BLOCKING
                )
            );
        }

        $response->setData(array('data' => array()));

        return $response;
    }

    /**
     * Validate the input parameters from the request when creating or updating authorizations.
     *
     * @param array $data
     * @param boolean $edit
     *
     * @return boolean|array
     */
    private function validateInputParameters(array $data, $edit = false)
    {
        $validatedData = array();
        $treatmentActivityService = $this->get('medicore.medical.treatment_activity_service');
        $treatmentActivity = $treatmentActivityService->find($data['treatmentActivityId']);

        if (null === $treatmentActivity) {
            return false;
        }

        if (!$this->get('medicore.generic.authorizer')->isTreatmentAccessable($treatmentActivity->getTreatment())) {
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne('EMPM102')
            );

            return false;
        }

        $validatedData['treatmentActivity'] = $treatmentActivity;

        if ($edit) {
            if (!is_int($data['id'])) {
                return false;
            }

            $validatedData['id'] = $data['id'];

            if (!$this->getMeta()->hasError() && !$treatmentActivity->hasAuthorization()) {
                $this->getMeta()->addMessage(
                    Meta::STATUS_ERROR,
                    $this->messageHandler->getOne(
                        'GV9',
                        array('object' => "for this treatmentActivity authorizations", 'input' => $data['treatmentActivityId'])
                    )
                );
            }
        }

        if (array_key_exists("insuranceApprovalRequestId", $data)) {
            $validatedData['insuranceApprovalRequestId'] = $this->validateInsuranceApprovalRequestId($data['insuranceApprovalRequestId']);
        }

        if (array_key_exists("declarationUzovi", $data)) {
            $validatedData['declarationUzovi'] = $this->validateDeclarationUzovi($data['declarationUzovi']);
        }

        if (array_key_exists("insuranceApprovalNumber", $data)) {
            $validatedData['insuranceApprovalNumber'] = $this->validateInsuranceApprovalNumber($data['insuranceApprovalNumber']);
        }

        if (array_key_exists("insuranceAgencyReferenceCode", $data)) {
            $validatedData['insuranceAgencyReferenceCode'] = $this->validateInsuranceAgencyReferenceCode($data['insuranceAgencyReferenceCode']);
        }

        if (array_key_exists("status", $data)) {
            $validatedData['status'] = $this->validateStatus($data['status']);
        }

        if (array_key_exists("startDate", $data)) {
            $validatedData['startDate'] = $this->validateStartDate($data['startDate']);
        }

        if (array_key_exists("endDate", $data)) {
            $validatedData['endDate'] = $this->validateEndDate($data['endDate']);
        }

        if (($validatedData['startDate'] instanceof DateTime) && ($validatedData['endDate'] instanceof DateTime)) {
            $this->validateEndDateGreaterOrEqualThanStartDate($validatedData['startDate'], $validatedData['endDate']);
        }

        return $validatedData;
    }

    /**
     * Will validate vecozo requester id.
     *
     * @param int $vecozoRequesterId
     *
     * @return null|int
     */
    private function validateInsuranceApprovalRequestId($vecozoRequesterId)
    {
        if (mb_strlen($vecozoRequesterId) == 0) {
            return null;
        }

        if ($this->isEntityIdPositiveInteger($vecozoRequesterId, 'insuranceApprovalRequestId')) {
            return $vecozoRequesterId;
        }

        return null;
    }

    /**
     * Will validate declaration Uzovi Code.
     *
     * @param int $declarationUzovi
     *
     * @return null|int
     */
    private function validateDeclarationUzovi($declarationUzovi)
    {
        if (mb_strlen($declarationUzovi) == 0) {
            return null;
        }

        if ($this->isEntityIdPositiveInteger($declarationUzovi, 'declarationUzovi')) {
            return $declarationUzovi;
        }

        return null;
    }

    /**
     * Will validate authorization Code.
     *
     * @param string $insuranceApprovalNumber
     *
     * @return null|string
     */
    private function validateInsuranceApprovalNumber($insuranceApprovalNumber)
    {
        if (mb_strlen($insuranceApprovalNumber) == 0) {
            return null;
        }

        if ($this->isRequired($insuranceApprovalNumber, 'insuranceApprovalNumber')) {
            return $insuranceApprovalNumber;
        }

        return null;
    }

    /**
     * Will validate insurance Agent Code.
     *
     * @param string $insuranceAgencyReferenceCode
     *
     * @return null|string
     */
    private function validateInsuranceAgencyReferenceCode($insuranceAgencyReferenceCode)
    {
        if (mb_strlen($insuranceAgencyReferenceCode) == 0) {
                return null;
        }

        if ($this->isRequired($insuranceAgencyReferenceCode, 'insuranceAgencyReferenceCode')) {
            return $insuranceAgencyReferenceCode;
        }

        return null;
    }

    /**
     * Will validate status.
     *
     * @param int $status
     *
     * @return null|int
     */
    private function validateStatus($status)
    {
        if (in_array($status, TreatmentActivityAuthorization::$types)) {
            return $status;
        }

        return null;
    }

    /**
     * Will validate start date.
     *
     * @param string $startDate
     *
     * @return null|\DateTime
     */
    private function validateStartDate($startDate)
    {
        if (mb_strlen($startDate) == 0) {
            return null;
        }

        return $this->ValidateDate($startDate, 'startDate');
    }

    /**
     * Will validate end date.
     *
     * @param string $endDate
     *
     * @return null|\DateTime
     */
    private function validateEndDate($endDate)
    {
        if (mb_strlen($endDate) == 0) {
            return null;
        }

        return $this->ValidateDate($endDate, 'endDate');
    }
}
