<?php

namespace Controller\Treatment\Activity;

use Actinidium\API\Response\Meta;
use Controller\Treatment\ActivityController;
use Generic\ClinicService;
use Generic\EmployeeService;
use Medical\MHC\TreatmentActivity;
use Medical\Treatment\Activity\Awbz;
use Security\Sanitizer;
use System\CostCenterService;
use Controller\TreatmentController;
use Controller\ValidationResult;
use Validation\DotValidationResult;
use Medical\TreatmentActivityService;
use Generic\CustomerSettingsService;

/**
 * Class Update
 *      All the update method about treatment Activity should go in here
 * @package Controller\Treatment\Activity
 */
class Update
{
    /**
     * @var \Medical\TreatmentActivityService
     */
    private $model;

    /**
     * @var ActivityController
     */
    private $parentController;

    /**
     * @var array
     */
    private $data = array();

    /**
     * @var \Medical\Treatment
     */
    private $treatment = null;

    /**
     * @var \Medical\Activity
     */
    private $activity = null;

    /**
     * @var \DateTime
     */
    private $executionDate = null;

    /**
     * @var \Generic\Employee
     */
    private $specialist = null;

    /**
     * @var String
     */
    private $note = null;

    /**
     * @var Boolean
     */
    private $performed = null;

    /**
     * @var string
     */
    private $costCenterCode = null;

    /**
     * @var Boolean
     */
    private $medicalGrounds = null;

    /**
     * @var int
     */
    private $amount = null;

    /**
     * @var \DateTime
     */
    private $performedTime = null;

    /**
     * @var \Generic\Employee
     */
    private $requester = null;

    /**
     * @var \String
     */
    private $requesterInstitution = null;

    /**
     * @var \Generic\Specialism
     */
    private $requesterSpecialty = null;

    /**
     * @var \Generic\Employee
     */
    private $requesterSpecialist = null;

    /**
     * @var \Medical\TreatmentActivity
     */
    private $treatmentActivity = null;

    /**
     * @var string
     */
    private $functioncode;

    /** @var \Medical\Activity\Phase */
    private $phase;


    /**
     * Constructor.
     *
     * @param \Controller\Treatment\ActivityController $controller
     * @param \Medical\TreatmentActivityService $treatmentActivityService
     */
    public function __construct(
        ActivityController $controller,
        TreatmentActivityService $treatmentActivityService
    ) {
        $this->parentController = $controller;
        $this->model = $treatmentActivityService;
    }

    /**
     * getAction
     *      get the current action for the update from the query
     * @return      String
     */
    private function getAction()
    {
        $query = $this->parentController->getRequest()->query;
        $action = $query->get('action');

        return $action;
    }

    /**
     * Update process for Treatment Activities.
     *
     * @param int   $id
     * @param array $data
     *
     * @return  \Medical\TreatmentActivity|null
     */
    public function run($id, array $data)
    {
        $action = $this->getAction();
        $this->treatmentActivity = $this->getTreatmentActivityObject($id);
        if ($this->parentController->getMeta()->hasError()) {
            return null;
        }
        $this->callMethodToUpdate($action, $this->treatmentActivity, $data);

        return $this->treatmentActivity;
    }

    /**
     * @return \Controller\AbstractController|ActivityController
     */
    protected function getParentController()
    {
        return $this->parentController;
    }

    /**
     * getTreatmentActivityObject
     *      Get the treatment activity object based on the id
     * @param       int $id
     * @return      /Medical/TreatmentActivity
     */
    protected function getTreatmentActivityObject($id)
    {
        return $this->parentController->getTreatmentActivityObject($id);
    }

    /**
     * callMethodToUpdate
     * call the Proper method to update
     *
     * @param String $action
     * @param \Medical\TreatmentActivity | null $treatmentActivity
     * @param Array $data
     *
     * @return void
     * @todo remove the action parameter!
     */
    private function callMethodToUpdate($action, $treatmentActivity, array $data)
    {
        switch (strtolower($action)) {
            case 'linkactivitytoappointment':
                $this->linkActivityToAppointment($treatmentActivity, $data);
                break;
            default:
                if (is_null($action)) {
                    $result = $this->edit($data);
                    if ($result) {
                        $this->data = $treatmentActivity->toArray();
                    }
                } else {
                    $this->getParentController()->addMessage(
                        Meta::STATUS_ERROR,
                        'MG01',
                        array(
                            'field_name' => 'action',
                            'expected' => 'linkactivitytoappointment'
                        )
                    );
                }
                break;
        }
    }

    /**
     * Call to activity service: edit functionality.
     *
     * @param array $data
     *
     * @return bool
     */
    private function edit(array $data)
    {
        $this->data = array();
        $this->createObjects($data);
        $this->validateObjects();

        if (!$this->parentController->getMeta()->hasError()) {
            $params = $this->prepareParametersForEdit($data);
            $result = $this->model->edit($params);
            return $result;
        }
        return false;
    }

    /**
     * Register raw messages in the controller meta property.
     */
    private function registerRawMessages()
    {
        $rawMessages = $this->model->getRawMessages();
        foreach ($rawMessages as $rawMessage) {
            $this->parentController->getMeta()->addMessage($rawMessage['level'], $rawMessage['message']);
        }
    }

    /**
     * prepareParametersForEdit
     * @return      Array
     */
    private function prepareParametersForEdit(array $data)
    {
        $params = array();

        $params['treatmentActivity'] = $this->treatmentActivity;

        if (array_key_exists('treatmentId', $data) && $this->treatment) {
            $params['treatment'] = $this->treatment;
        }
        if (array_key_exists('activityId', $data) && $this->activity) {
            $params['activity'] = $this->activity;
        }
        if (array_key_exists('performedDate', $data)) {
            $params['executionDate'] = $this->executionDate;
        }
        if (array_key_exists('amount', $data)) {
            $params['amount'] = $this->amount;
        }
        if (array_key_exists('requesterId', $data)) {
            $params['requester'] = $this->requester;
        }
        if (array_key_exists('performedTime', $data)) {
            $params['performedTime'] = $this->performedTime;
        }
        if (array_key_exists('note', $data)) {
            $params['note'] = $this->note;
        }
        if (array_key_exists('costCenterCode', $data)) {
            $params['costCenter'] = $this->costCenterCode;
        }
        if (array_key_exists('medicalGrounds', $data)) {
            $params['claim'] = $this->medicalGrounds;
        }
        if (array_key_exists('performed', $data)) {
            $params['performed'] = $this->performed;
        }
        if (array_key_exists('performer', $data)) {
            $params['specialist'] = $this->specialist;
        }
        if (array_key_exists('functioncode', $data)) {
            $params['functioncode'] = $this->functioncode;
        }
        $params['phase'] = $this->phase;

        return $params;
    }


    /**
     * This method is executed when the url action is equalto linkActivityToAppointment.
     *
     * @param \Medical\TreatmentActivity $treatmentActivity
     * @param array                      $data
     */
    protected function linkActivityToAppointment(\Medical\TreatmentActivity $treatmentActivity, array $data)
    {
        $appointment = null;
        $result = false;

        if (null !== $data['appointment'] && $data['appointment']['id']) {
            $appointment = $this->parentController->getAppointmentObject($data['appointment']['id']);
        }

        if (!$this->parentController->getMeta()->hasError()) {
            $result = $this->model->linkActivityToAppointment($treatmentActivity, $appointment);
        }

        if ($result) {
            $this->parentController->getMeta()->setCount('1');
        }
    }

    /**
     * execute
     *      Execute an activity
     * @param   \Medical\TreatmentActivity $treatmentActivity
     * @param   Array $data
     */
    protected function execute($treatmentActivity, $data)
    {
        $this->setPerformed($data['performed']);
        if (!$this->parentController->getMeta()->hasError()) {
            $this->model->executed($treatmentActivity, $this->performed);
        }
    }

    /**
     * medicalGround
     *     Edit medicalGround of an activity
     * @param   \Medical\TreatmentActivity $treatmentActivity
     * @param   Array $data
     */
    protected function medicalGround($treatmentActivity, $data)
    {
        $result = false;
        $params = array();
        if (!array_key_exists("medicalGrounds", $data)) {
            $this->parentController->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->parentController->getMessageHandler()->getOne(
                    'MG01',
                    array('list_of_fields' => 'medicalGrounds')
                )
            );
        }
        $claim = \Security\Sanitizer::isStringLengthIsValid($data['medicalGrounds']);

        if ($claim && $treatmentActivity) {
            $params['treatmentActivity'] = $treatmentActivity;
            $params['claim'] = $data['medicalGrounds'];
            $result = $this->model->edit($params);
        }

        return $result;
    }

    /**
     * validateObjects
     *      Validate if the entered values are valid for edit
     * @return boolean
     */
    private function validateObjects()
    {
        $return = true;
        $this->activity && $this->validateActivity();
        $this->requester && $this->validateRequester();
        $this->validateExternalRequester();

        return $return;
    }

    /**
     * validateExternalRequester
     */
    private function validateExternalRequester()
    {
        if ($this->requesterInstitution && !($this->requesterSpecialist || $this->requesterSpecialty)) {
            $this->parentController->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->parentController->getMessageHandler()->getOne('M196')
            );
        }

        if (($this->requesterSpecialist || $this->requesterSpecialty) && !$this->requesterInstitution) {
            $this->parentController->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->parentController->getMessageHandler()->getOne('M195')
            );
        }
    }

    /**
     * validateExecutionDate
     */
    private function validateExecutionDate()
    {
        $treatment = $this->getTreatment();

        if ($treatment && $treatment->getStartDate() > $this->executionDate) {
            $this->parentController->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->parentController->getMessageHandler()->getOne('M008')
            );
        }
    }

    /**
     * validateRequester
     */
    private function validateRequester()
    {
        $this->validateEmployee($this->requester);
    }

    /**
     * validateActivity
     */
    private function validateActivity()
    {
        if (!($this->activity instanceof \Medical\Activity)) {
            return false;
        }

        // @TODO: date validate can be done on task: DBC validation

        return true;
    }

    /**
     * createObjects
     *      Validate and create proper objects
     * @param   Array $data
     */
    protected function createObjects($data)
    {
        array_key_exists('treatmentId', $data) && $this->createTreatmentObject($data['treatmentId']);
        array_key_exists('activityId', $data) && $this->createActivityObject($data['activityId']);
        array_key_exists('functioncode', $data) && ($this->functioncode = $data['functioncode']);

        array_key_exists('performer', $data) && $this->createSpecialistObject($data['performer']['id']);

        array_key_exists('note', $data) && $this->setNote($data['note']);
        array_key_exists('performed', $data) && $this->setPerformed($data['performed']);

        if ($this->performed && is_null($data['performedDate'])) {
            $data['performedDate'] = CustomerSettingsService::getSystemDate()->format("Y-m-d");
        }

        array_key_exists('performedDate', $data) && $this->createExecutionDateObject($data['performedDate']);

        array_key_exists('costCenterCode', $data) && $this->setCostCenterCode($data['costCenterCode']);
        array_key_exists('medicalGrounds', $data) && $this->setMedicalGrounds($data['medicalGrounds']);

        array_key_exists('requesterId', $data) && $this->setRequester($data['requesterId']);

        array_key_exists('amount', $data) && $this->setAmount($data['amount']);
        array_key_exists('performedTime', $data) && $this->setperformedTime($data['performedTime']);

        $this->phase = $this->parentController->getPhaseObject($data['phase']['id']);
    }

    /**
     * setRequesterSpecialist
     * @param   int $requesterSpecialistId
     */
    private function setRequesterSpecialist($requesterSpecialistId)
    {
        $this->requesterSpecialist = null;
        if (mb_strlen($requesterSpecialistId)) {
            $this->requesterSpecialist = $this->parentController->getSpecialistObject(
                $requesterSpecialistId,
                "requesterSpecialistId"
            );
        }
    }

    /**
     * setRequesterSpecialty
     * @param   int $requesterSpecialtyId
     */
    private function setRequesterSpecialty($requesterSpecialtyId)
    {
        $this->requesterSpecialty = null;
        if (mb_strlen($requesterSpecialtyId)) {
            $this->requesterSpecialty = $this->parentController->getSpecialismObject(
                $requesterSpecialtyId,
                "requesterSpecialtyId"
            );
        }
    }

    /**
     * setRequesterInstitution
     * @param int $requesterInstitution
     */
    private function setRequesterInstitution($requesterInstitution)
    {
        $this->requesterInstitution = null;
        if (mb_strlen($requesterInstitution) && $this->isValidRequesterInstitution($requesterInstitution)) {
            $this->requesterInstitution = $requesterInstitution;
        }
    }

    /**
     * setRequester
     * @param int $requesterId
     */
    private function setRequester($requesterId)
    {
        $this->requester = null;
        if (mb_strlen($requesterId)) {
            $this->requester = $this->parentController->getSpecialistObject($requesterId, "requesterId");
        }
    }

    /**
     * setCostCenter
     * @param int $costCenterCode
     */
    private function setCostCenterCode($costCenterCode)
    {
        $this->costCenterCode = "";
        if (mb_strlen($costCenterCode)) {
            $costCenterModel = new CostCenterService();
            $costCenters = $costCenterModel->findByCode($costCenterCode);
            if (!empty($costCenters)) {
                foreach ($costCenters as $costCenter) {
                    if ($costCenterModel->isValidCostCenter(
                        $costCenter,
                        $this->treatmentActivity->getPerformedDate()
                    )
                    ) {
                        $this->costCenterCode = $costCenter->getCode();

                        return;
                    }
                }
            }
            if (empty($this->costCenterCode)) {
                $this->parentController->addMessage(
                    Meta::STATUS_ERROR,
                    "GV9",
                    array("object" => "costCenterCode", "input" => $costCenterCode)
                );
            }
        }
    }

    /**
     * setperformedTime
     * @param   String(HH:MM:SS) $performedTime
     */
    private function setPerformedTime($performedTime)
    {
        $this->performedTime = null;
        if (mb_strlen($performedTime)) {
            if (\Date\Time::isValidTimeString($performedTime)) {
                $this->performedTime = \DateTime::createFromFormat("H:i:s", $performedTime);
            } else {
                $this->parentController->addMessage(
                    Meta::STATUS_ERROR,
                    'MG02',
                    array(
                        'field_name' => "performedTime",
                        'expected' => "Valid Time, in format HH:MM:SS",
                        'actual' => $performedTime,
                    )
                );
            }
        }
    }

    /**
     * setPerformed
     * @param   Boolean $performed
     */
    private function setPerformed($performed)
    {
        if (is_string($performed)) {
            $this->parentController->addMessage(
                Meta::STATUS_ERROR,
                'MG01',
                array('list_of_fields' => "performed")
            );
        } elseif (Sanitizer::isBoolean($performed)) {
            $this->performed = Sanitizer::boolean($performed);
        } else {
            $this->parentController->addMessage(
                Meta::STATUS_ERROR,
                'GV9',
                array('object' => "performed", 'input' => $performed)
            );
        }
    }

    /**
     * Sets MedicalGrounds (=claim).
     *
     * @param bool|null $medicalGrounds
     */
    private function setMedicalGrounds($medicalGrounds)
    {
        if (Sanitizer::isBoolean($medicalGrounds) || is_null($medicalGrounds)) {
            $this->medicalGrounds = $medicalGrounds;
        }
    }

    /**
     * createTreatmentObject
     *      Create treatment object
     * @param   int $treatmentId
     */
    private function createTreatmentObject($treatmentId)
    {
        $this->treatment = $this->parentController->getTreatmentObject($treatmentId, "treatmentId");
    }

    /**
     * createActivityObject
     *      Create activity object
     * @param   int $activityId
     */
    private function createActivityObject($activityId)
    {
        $this->activity = $this->parentController->getActivityObject($activityId, "activityId");
    }

    /**
     * createSpecialistObject
     *      Create specialist object
     * @param   int $specialistId
     */
    private function createSpecialistObject($specialistId)
    {
        $this->specialist = $this->parentController->getSpecialistObject($specialistId, "performer");
    }

    /**
     * createExecutionDateObject
     *      Create a new execution date object
     * @param       String $executionDate
     */
    private function createExecutionDateObject($executionDate)
    {
        $this->executionDate = $this->parentController->validateDate($executionDate, "performedDate");
    }

    /**
     * setAmount
     *      set the amount
     * @param   int $amount
     */
    private function setAmount($amount)
    {
        if (mb_strlen($amount) && $amount == 0) {
            $this->amount = $amount;
        } else {
            $this->amount = ($amount) ? $amount : 1;
        }
    }

    /**
     * setNote
     * @param   String $note
     */
    private function setNote($note)
    {
        $this->note = $note;
    }

    /**
     * isValidRequesterInstitution
     *      check if its a valid requester institution code
     * @param   int $requesterInstitution
     * @return  boolean
     */
    private function isValidRequesterInstitution($requesterInstitution)
    {
        if (!mb_strlen($requesterInstitution)) {
            $this->parentController->addMessage(
                Meta::STATUS_ERROR,
                'MG01',
                array("list_of_fields" => "requesterInstitution")
            );
        }
        if (substr($requesterInstitution, 0, 1) != '0') {
            $getProviderType = substr($requesterInstitution, 0, 2);
        } else {
            $getProviderType = substr($requesterInstitution, 1, 1);
        }

        if (substr($requesterInstitution, 3, 1) != '0') {
            $getPracticeNumber = substr($requesterInstitution, -6);
        } else {
            $getPracticeNumber = substr($requesterInstitution, -5);
        }

        if ((!is_null($getPracticeNumber)) && (!is_null($getProviderType)) && (is_numeric($requesterInstitution))) {
            $providerType = $this->createProviderTypeEntity($getProviderType);

            $institutionService = new \Generic\SystemInstitutionService();
            $isValidInstitution = $institutionService->checkRequesterPracticeNumber($getPracticeNumber);

            if ((!$isValidInstitution) && (is_null($providerType)) && (!is_numeric($requesterInstitution))) {
                $this->parentController->getMeta()->addMessage(
                    Meta::STATUS_ERROR,
                    'GV9',
                    array(
                        'object' => 'RequesterInstitution',
                        'input' => $requesterInstitution
                    )
                );

                return false;
            }
        }

        return true;
    }

    /**
     * create createProviderTypeEntity
     * @param integer $providerTypeId
     * @return \Generic\providerType
     */
    private function createProviderTypeEntity($providerTypeId)
    {
        $providerType = null;

        // not using create entity since we don't want an error if its not available.
        if (!empty($providerTypeId)) {
            $providerTypeService = new \Generic\SystemProviderTypeService();
            $providerType = $providerTypeService->find($providerTypeId);
        }

        return $providerType;
    }

    /**
     * getExecutionDate
     * @return      \DateTime
     */
    protected function getExecutionDate()
    {
        return $this->executionDate ? $this->executionDate :
            ($this->treatmentActivity ? $this->treatmentActivity->getPerformedDate() : null);
    }

    /**
     * getTreatment
     * @return      \Medical\Treatment|null
     */
    private function getTreatment()
    {
        return $this->treatment
            ? $this->treatment
            : ($this->treatmentActivity
                ? $this->treatmentActivity->getTreatment()
                : null
            );
    }

    /**
     * setTreatment
     * @param      \Medical\Treatment
     */
    public function setTreatment(\Medical\Treatment $treatment)
    {
        if ($treatment instanceof \Medical\Treatment) {
            $this->treatment = $treatment;
        }
    }
}
