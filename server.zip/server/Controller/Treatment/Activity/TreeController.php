<?php

namespace Controller\Treatment\Activity;

use Controller\AbstractController;
use DateTime;
use Medical\MHC\ActivityService;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/treatment",
 *     basePath="/api/v2"
 * )
 */
class TreeController extends AbstractController
{
    /** @var  \Medical\MHC\ActivityService */
    private $mhcActivityService;

    public function __construct(ActivityService $activityService)
    {
        $this->mhcActivityService = $activityService;
    }

    /**
     * @SWG\Api(
     *   path="/treatment/activity/tree",
     *   @SWG\Operation(
     *       method="GET",
     *       summary="Returns a list of treatment activities in a tree view.",
     *   )
     * )
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function getListAction(Request $request)
    {
        $query = $request->query;
        $date = ($this->validateDateString($query->get('performedDate')))
            ? new DateTime($query->get('performedDate'))
            : new DateTime();

        $response = new JsonResponse();
        $tree = array();
        $tree = $this->mhcActivityService->buildTree($this->mhcActivityService->findAllValidOnDate($date));
        $response->setData(array("data" => $tree));
        
        return $response;
    }
}
