<?php

namespace Controller\Treatment;

use Controller\AbstractController;
use Factory\TranslatorFactory;
use Generic\Clinic;
use Generic\ClinicService;
use Medical\Treatment\Type;
use Medical\Treatment\TypeService;

/**
 * @SWG\Resource(
 *     apiVersion="1.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/treatment",
 *     basePath="/api"
 * )
 */
class TypeController extends AbstractController
{
    /**
     * @var Clinic
     */
    private $clinic;

    /**
     * @var TypeService
     */
    private $model;

    /**
     * Sets the translator on this controller.
     */
    public function __construct()
    {
        parent::__construct();
        $this->translator = $this->get('medicore.translation.default');
    }

    /**
     * @SWG\Api(
     *     path="/treatment-type",
     *     description="Retrieve the available treatment types.",
     *     @SWG\Operation(
     *         method="GET",
     *         summary="Retrieve the available treatment types.",
     *         @SWG\Parameter(
     *             name="clinicId",
     *             description="The unique identifier of the clinic for which the treatment types should be fetched.",
     *             type="integer",
     *             required=false,
     *             paramType="query"
     *         ),
     *     )
     * )
     *
     * @return array
     */
    public function getListAction()
    {
        $query = $this->getRequest()->query;
        $this->data = array();
        if ($query->has("clinicId")) {
            $this->clinic = $this->getClinic();
            if ($this->getMeta()->hasError()) {
                return $this->data;
            }
            $this->data = $this->findByclinic();
        } else {
            $this->data = $this->findAll();
        }
        return $this->data;
    }

    /**
     * @return array
     */
    private function findByClinic()
    {
        $this->processTypes($this->getModel()->findByClinic($this->getClinic()));
        return $this->data;
    }

    /**
     * @return array
     */
    private function findAll()
    {
        $this->processTypes($this->getModel()->findAll());
        return $this->data;
    }

    /**
     * Display the info needed.
     *
     * @param array $types
     */
    private function processTypes(array $types)
    {
        if (!empty($types)) {
            foreach ($types as $type) {
                if ($type instanceof Type) {
                    $this->data[] = array(
                        'id' => $type->getId(),
                        'code' =>  $type->getCode(),
                        'description' => $this->translator->trans(strtolower($type->getCode()), array(), TranslatorFactory::TRANS_DOMAIN_MEDICAL),
                        'default' => $type->getDefault(),
                        'clinic' => ($type->getClinic() ? $type->getClinic()->toListArray() : null)
                    );
                }
            }
        }
    }

    /**
     * @param TypeService $model
     */
    public function setModel(TypeService $model)
    {
        $this->model = $model;
    }

    /**
     * @return Clinic
     */
    private function getClinic()
    {
        if (!$this->clinic) {
            $this->clinic = $this->createEntity(
                $this->getRequest()->query->get("clinicId"),
                "clinicId",
                new ClinicService(),
                "\\Generic\\Clinic"
            );
        }
        return $this->clinic;
    }

    /**
     * @param Clinic $clinic
     */
    public function setClinic(Clinic $clinic)
    {
        $this->clinic = $clinic;
    }

    /**
     * @return TypeService
     */
    private function getModel()
    {
        if (!$this->model) {
            $this->model = new TypeService();
        }
        return $this->model;
    }
}
