<?php

namespace Controller\Treatment;

use Actinidium\API\Response\Meta;
use Actinidium\API\Response\NonCachedJsonResponse;
use Controller\AbstractController;
use Controller\EpisodeController;
use Controller\ValidationResult;
use Factory\TranslatorFactory;
use Generic\ClinicService;
use Generic\ClosureReason\ClosureReasonServiceFactory;
use Generic\Employee;
use Medical\ClosureReason;
use Medical\ClosureReasonService as SomaticReasonService;
use Medical\Episode;
use Medical\EpisodeService;
use Medical\MHC\Basic\IdToComponentTransformer;
use Medical\Treatment;
use Medical\TreatmentService;
use Medical\Treatment\Factory;
use Medical\Treatment\ProfileService;
use Medical\Validations\ValidateEpisodeHasClosedTreatment;
use Message\MessageHandler;
use Security\Sanitizer;
use System\Dbc\ClosureReasonService as DotClosureReasonService;
use System\Feature;
use System\MHC\Circuit;
use System\MHC\CircuitService;
use System\MHC\ClosingReasonService as MhcClosureReasonService;
use System\Module;
use System\ModuleService;
use Symfony\Component\HttpFoundation\JsonResponse;
use Validation\DotValidationResult;

/**
 * Callable via /api/medical-episode/:action where :action is one of the public *Action methods
 * @property \Medical\ Treatment
 * @package Controller\Medical
 */
class Update
{
    private $controller;
    private $profileModel;

    /**
     * @var \Medical\Treatment
     */
    private $model;
    private $data;
    /* @var \Medical\Treatment */
    private $treatment;
    private $clinicModel;
    private $episodeModel;
    private $episode;
    /* @vat \DateTime */
    private $expectedEndDate;
    private $clinic;
    private $validatedObjects;

    /** @var \Medical\Treatment\ApplyProfileService */
    private $applyProfileService;

    /**
     * Constructor
     */
    public function __construct(AbstractController $controller)
    {
        $this->controller = $controller;
        $this->model = $this->getTreatmentService();
        $this->messageHandler = new MessageHandler();
    }

    /**
     * @return TreatmentService
     */
    protected function getTreatmentService()
    {
        if (!$this->model) {
            $this->model = $this->controller->getTreatmentService();
        }
        return $this->model;
    }

    /**
     * Implemented so we can set the data in PHPUnit.
     * @param array $data
     */
    public function setData(array $data)
    {
        $this->data = $data;
    }

    /**
     * Close a Treatment.
     *
     * @param Treatment $treatment
     * @param \DateTime $endDate
     * @param int $closureReasonId
     */
    public function close(Treatment $treatment, $endDate, $closureReasonId)
    {
        $endDate = $this->controller->validateDate($endDate, "endDate");

        $closureReason = $this->createClosureReason($treatment, $closureReasonId);

        if (!$this->controller->getMeta()->hasError()) {
            $result = $this->getTreatmentService()->close($treatment, $endDate, $closureReason);

            if ($result) {
                $moduleService = new ModuleService();
                if (!$moduleService->isFeatureEnabled(Feature::DOTDBC_NOT_TO_GROUPER, Module::FINANCE)
                    && $treatment->isDot()) {
                    $this->getTreatmentService()->sendToGrouper($treatment);
                }
            }
        }
    }

    /**
     * Instantiates a closure reason, based on treatment type and id.
     *
     * @param Treatment $treatment
     * @param int $id
     *
     * @return \System\Dbc\ClosureReason|\Medical\ClosureReason|\Medical\MHC\ClosingReason|\System\MHC\ClosingReason
     */
    private function createClosureReason(Treatment $treatment, $id)
    {
        $closureReason = null;
        $className = null;

        if ($treatment->isSomatic()) {
            if ($treatment->getTreatmentType() == Treatment::TYPE_DBC) {
                $className = 'System\Dbc\ClosureReason';
            } else {
                $className = 'Medical\ClosureReason';
            }
        } else {
            if ($treatment->getTreatmentType() == Treatment::TYPE_BASIS_MHC) {
                $transformer = $this->controller->getIdToBasicClosureReasonTransformer();
                $closureReason = $transformer->transform($id);
                return $closureReason;
            } elseif ($treatment->getTreatmentType() !== Treatment::TYPE_MHC_UNINSURED) {
                $className = 'System\MHC\ClosingReason';
            }
        }
        if ($className) {
            $closureReason = $this->controller->createEntity(
                $id,
                'closureReasonId',
                $this->getClosureReasonService($treatment),
                $className
            );
        }

        return $closureReason;
    }


    /**
     * @param Treatment $treatment
     *
     * @return SomaticReasonService|DotClosureReasonService|MhcClosureReasonService
     */
    protected function getClosureReasonService(Treatment $treatment)
    {
        if ($treatment->isSomatic()) {
            if ($treatment->getTreatmentType() == Treatment::TYPE_DBC) {
                return new DotClosureReasonService;
            }

            return new SomaticReasonService;
        }

        return new MhcClosureReasonService;
    }

    /**
     * @param \Medical\Treatment $treatment
     * @param ClosureReason $closureReason
     */
    protected function validateTreatmentTypeAndClosureReason(
        Treatment $treatment,
        ClosureReason $closureReason
    ) {
        //PM and insured (treatmenttype = verrichtingen AND verzekerd = yes):
        $this->validateTreatmentIsPmAndInsured($treatment, $closureReason);
        $this->validateTreatmentIsPmAndUnInsured($treatment, $closureReason);
    }

    /**
     * validateTreatmentIsPmAndInsured
     * @param Treatment $treatment
     * @param ClosureReason $closureReason
     */
    protected function validateTreatmentIsPmAndInsured(
        Treatment $treatment,
        ClosureReason $closureReason
    )
    {
        if ($treatment->getTreatmentType() == Treatment::TYPE_TRANSACTION &&
            $treatment->isInsured()
        ) {
            //check if closure id exists in MCIS and has a PM value
            if (is_null($closureReason->getPmValue())) {
                $this->controller->getMeta()->addMessage(
                    Meta::STATUS_ERROR,
                    $this->messageHandler->getOne(
                        'M156',
                        array(
                            'field_name' => 'closureReasonId',
                            'input' => $closureReason->getId()
                        )
                    )
                );
            }
        }
    }

    /**
     * validateTreatmentIsPmAndUnInsured
     * @param Treatment $treatment
     * @param ClosureReason $closureReason
     */
    protected function validateTreatmentIsPmAndUnInsured(Treatment $treatment, ClosureReason $closureReason)
    {
        if ($treatment->getTreatmentType() == \Medical\Treatment::TYPE_TRANSACTION &&
            (!$treatment->isInsured())
        ) {
            //check if closure id exists in MCIS and has a PM value
            if (!is_null($closureReason->getPmValue())) {
                $this->controller->getMeta()->addMessage(
                    Meta::STATUS_ERROR,
                    $this->messageHandler->getOne(
                        '101',
                        array(
                            'field_name' => 'closureReasonId',
                            'input' => $closureReason->getId()
                        )
                    )
                );
            }
        }
    }

    /**
     * Add Profile
     * @param Treatment $treatment
     * @param integer $profileId
     * @return array
     */
    public function addProfile(Treatment $treatment, $profileId)
    {
        $profile = $this->validateProfileId($profileId);

        if (!$this->controller->getMeta()->hasError()) {
            $this->controller->getApplyProfileService()->apply($treatment, $profile);
        }
        return array();
    }

    /**
     * Will validate profile id
     * @param int $id
     * @return \Medical\Treatment\Profile | null
     */
    protected function validateProfileId($id)
    {
        $profileModel = $this->getProfileModel();
        $profile = $this->controller->createEntity(
            $id,
            'profileId',
            $profileModel,
            "Medical\\Treatment\\Profile"
        );
        return $profile;
    }

    /**
     * @return profileService
     */
    protected function getProfileModel()
    {
        if (!$this->profileModel) {
            $this->profileModel = new ProfileService();
        }
        return $this->profileModel;
    }

    /**
     * ReOpen
     * @param Treatment $treatment
     * @return array
     */
    public function reOpen(Treatment $treatment)
    {
        $errors = $this->model->reOpenValidation($treatment);
        ValidationResult::addMessages($this->controller, $errors);

        if (!$this->controller->getMeta()->hasError()) {
           $result = $this->model->reOpen($treatment);
        }

        return $result;
    }

    /**
     * Cancels a treatment.
     *
     * @param Treatment $treatment
     *
     * @return bool
     */
    public function cancel(Treatment $treatment)
    {
        $result = false;
        $errors = $this->model->cancelValidation($treatment);

        ValidationResult::addMessages($this->controller, $errors);

        if (!$this->controller->getMeta()->hasError()) {
            $result =  $this->model->cancel($treatment);
        }

        return $result;
    }

   /**
    * change financial status
    * @param     \Medical\Treatment $treatment
    * @param     string $status
    * @return    array
    */
    public function changeFinancialStatus(Treatment $treatment, $status)
    {
        if ($this->isValidFinancialStatus($status)) {
            $status = Sanitizer::boolean($status);
            $result = $this->model->changeFinancialStatus($treatment, $status);
            if ($result == false) {
                $this->controller->getMeta()->addMessage(
                    Meta::STATUS_ERROR,
                    $this->messageHandler->getOne('M156')
                );
            }
        }

        return array();
    }

    /**
     * isValidFinancialStatus
     *      Check if the status is valid
     * @param   boolean|null $status
     * @return  boolean
     */
    private function isValidFinancialStatus($status)
    {
        $return = true;
        if (Sanitizer::isEmpty($status)) {
            $this->controller->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne('MG01', array('list_of_fields' => 'status'))
            );

            $return = false;
        } elseif (!Sanitizer::isBoolean($status)) {
            $this->controller->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne('GV9', array('object' => 'status', 'input' => $status))
            );

            $return = false;
        }

        return $return;
    }

    /**
     * @param Treatment $treatment
     * @param integer $indicationId
     * @return array
     */
    public function editPM(Treatment $treatment, $indicationId)
    {
        $PMIndication = ($indicationId === '') ? $indicationId : $this->validatePMIndication($indicationId);
        if (!$this->controller->getMeta()->hasError()) {
            $this->model->editPM($treatment, $PMIndication);
        }
        return array();
    }

    /**
     * validatePMIndication
     * @param String $indicationId
     * @return \System\PMIndication
     */
    protected function validatePMIndication($indicationId)
    {
        $PMIndicationService = new \System\PMIndicationService();
        $PMIndication = $this->controller->createEntity(
            $indicationId,
            "indicationId",
            $PMIndicationService,
            "System\\PMIndication"
        );
        return $PMIndication;
    }

    /**
     * @param Treatment $treatment
     * @param $data
     * @return bool
     */
    public function update(\Medical\Treatment $treatment, $data)
    {
        $result = null;
        $this->treatment = $treatment;
        $this->validatedObjects = array();
        $this->data = $data;

        if (Treatment::NEW_STATUS_OPEN == $data['status'] && !$treatment->isOpen()) {
            $this->validatedObjects['treatment'] = $treatment;
            $this->reOpen($treatment);

            if (!$this->hasError()) {
                return $this->getTreatmentService()->getTreatment();
            }
        } else {
            $this->validatedObjects = $this->createObjects();

            if ($this->controller->getMeta()->hasError()) {
                return null;
            }

            if (Treatment::NEW_STATUS_CLOSED == $data['status'] && !$treatment->isClosed()) {
                // do not close if treatment is set being to not invoice-able
                if (!(true == $data['notInvoiceable'] && $treatment->isInvoiceable())) {
                    $this->close($treatment, $data['endDate'], $data['closureReason']['id']);
                }
            }

            if (Treatment::NEW_STATUS_CANCELLED == $data['status'] && !$treatment->isCancelled()) {
                $this->cancel($treatment);
            }
        }

        $data = null;
        if (!$this->hasError() &&
            $this->getTreatmentService()->edit($this->validatedObjects)
        ) {
            $data = $this->getTreatmentService()->getTreatment();
        }

        $this->addErrorToMeta();

        return $data;
    }

    /**
     * Returns true if we got an error from legacy or new validations.
     *
     * @return bool
     */
    private function hasError()
    {
        $legacyMhcValidationMessages = $this->getTreatmentService()->getLegacyMHCValidationMessages();
        foreach ($legacyMhcValidationMessages as $message) {
            if (Meta::STATUS_ERROR == $message['level']) {
                return true;
            }
        }

        return ValidationResult::containsErrors($this->getTreatmentService()->getValidationMessages()) ||
        DotValidationResult::containsErrors($this->getTreatmentService()->getLegacyValidationMessages());
    }

    /**
     * Add the errors we got from the service to the controller's Meta object.
     */
    private function addErrorToMeta()
    {
        if ($this->getTreatmentService()->hasValidationMessages()) {
            ValidationResult::addMessages(
                $this->controller,
                $this->getTreatmentService()->getValidationMessages()
            );
        }

        DotValidationResult::addMessagesToMeta(
            $this->getTreatmentService()->getLegacyValidationMessages(),
            $this->controller->getMeta()
        );
        $this->processLegacyMhcValidationMessages();
    }

    /**
     * Processes the validation result of the legacy MHC validations.
     */
    private function processLegacyMhcValidationMessages()
    {
        $legacyMhcValidationMessages = $this->getTreatmentService()->getLegacyMHCValidationMessages();
        foreach ($legacyMhcValidationMessages as $legacyMhcValidationMessage) {
            $code = $legacyMhcValidationMessage['code'];
            $message = $this->controller->getTranslator()->trans('GGZ_VALIDATIE_MELDING' . $code, array(), TranslatorFactory::TRANS_DOMAIN_MEDICAL_VALIDATIONS);
            $hint = $this->controller->getTranslator()->trans('GGZ_VALIDATIE_HINT' . $code, array(), TranslatorFactory::TRANS_DOMAIN_MEDICAL_VALIDATIONS);
            // there isn't always a hint to translate and we don't want GGZ_VALIDATIE_HINT_205 to be shown in GUI
            if ($hint === 'GGZ_VALIDATIE_HINT' . $code) {
                $hint = '';
            }
            $this->controller->getMeta()->addMessage($legacyMhcValidationMessage['level'], $message, $code, $hint);
        }
    }

    /**
     * @return array
     */
    public function getValidatedObjects()
    {
        return $this->validatedObjects;
    }

    /**
     * @return array
     */
    protected function createObjects()
    {
        $this->data['episodeId'] = $this->treatment->getEpisode()->getId();
        $this->data['type'] = $this->treatment->getType();
        $createHelper = new Create($this->controller);
        $validatedObjects = $createHelper->createObjects($this->data);
        $validatedObjects['treatment'] = $this->treatment;

        if ($validatedObjects['notInvoiceable']) {
            $validatedObjects['remark'] = ($this->controller->isRequired($this->data['remark'], 'remark')) ? $this->data['remark'] : null;
            if (!empty($this->data['remark'])) {
                $this->controller->validateStringLength($this->data['remark'], 'remark');
            }
            if ($this->treatment->isOpen()) {
                $validatedObjects['endDate'] = $this->controller->validateDate($this->data['endDate'], "endDate");
            }
        }

        $validatedObjects['name'] = $this->validateName($this->data['name']);

        if ($this->data['application']) {
            $validatedObjects['application'] = $this->validateEditApplication($this->data['application']);
        }

        $validatedObjects['medicallyEnded'] = $this->data['medicallyEnded'];
        if ($this->data['medicallyEnded']) {
            // medicallyEnded is being 'turned on', medicallyEndedDate must be supplied
            $validatedObjects['medicallyEndedDate'] = $this->controller->validateDate($this->data['medicallyEndedDate'], "medicallyEndedDate");
        }

        unset($validatedObjects['type']);

        return $validatedObjects;
    }

    /**
     * Validate the treatment name.
     * 
     * @param string $name
     *
     * @return string
     */
    protected function validateName($name)
    {
        if (empty($name)) {
            $this->controller->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne('MG01', array('list_of_fields' => "name"))
            );
        } elseif (mb_strlen($name) < 1 || mb_strlen($name) > 255) {
            $this->controller->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne('MG100', array('field_name' => 'name', 'max_length' => '255'))
            );
        }
        return $name;
    }


    /**
     * Validate Episode
     * @param $id
     * @return bool
     */
    protected function validateEpisodeId($id)
    {
        if (!$this->episode) {
            $episodeModel = $this->getEpisodeModel();
            $episode = $this->controller->createEntity(
                $id,
                'episodeId',
                $episodeModel,
                "Medical\\Episode"
            );
            return $episode;
        }
    }

    /**
     * So that we can mock this in our phpunit
     * @return EpisodeService
     */
    protected function getEpisodeModel()
    {
        if (!$this->episodeModel) {
            $this->episodeModel = new EpisodeService();
        }
        return $this->episodeModel;
    }

    /**
     * returns a sanitized date from the input or
     * the expected end date of the treatment itself if none is given
     * or null if this is a new treatment (and we dont have an object then)
     * @return \DateTime|null
     */
    protected function validateExpectedEndDate()
    {
        if (array_key_exists("expectedEndDate", $this->data)) {
            return $this->controller->validateDate($this->data['expectedEndDate'], "expectedEndDate");
        }
        if ($this->treatment) {
            return $this->treatment->getExpectedEndDate();
        }
        return null;
    }

    /**
     * Validate Clinic
     * @param $id
     * @return bool
     */
    protected function validateClinicId($id)
    {
        if (!$this->clinic) {
            $clinicModel = $this->getClinicModel();
            $this->clinic = $this->controller->createEntity(
                $id,
                'clinicId',
                $clinicModel,
                "Generic\\Clinic"
            );
        }
        return $this->clinic;
    }

    /**
     * So that we can mock this in our phpunit
     * @return EpisodeService
     */
    protected function getClinicModel()
    {
        if (!$this->clinicModel) {
            $this->clinicModel = new ClinicService();
        }
        return $this->clinicModel;
    }

    /**
     * @return Circuit
     */
    public function validateCircuitCode()
    {
        if ($this->treatment && $this->treatment->getMhc()) {
            if (array_key_exists("circuitCodeId", $this->data)) {
                $circuitModel = new CircuitService();
                return $this->controller->createEntity(
                    $this->data['circuitCodeId'],
                    "circuitCodeId",
                    $circuitModel,
                    "System\\MHC\\Circuit"
                );
            }
        }
    }

    /**
     * @param integer $diagnoseId
     * @return mixed
     */
    private function validateDiagnoseId($diagnoseId)
    {
        $diagnose = $this->validateDiagnoseInstance($diagnoseId);

        if ($diagnose) {
            $systemDiagnose = $diagnose->getSystemDiagnose();

            if ($systemDiagnose->isDefaultDiagnose()) {
                $this->controller->addMessage(Meta::STATUS_ERROR, 'M525');
            }

            if ($systemDiagnose->getAxis() != 1 && $systemDiagnose->getAxis() != 2) {
                $this->controller->getMeta()->addMessage(
                    Meta::STATUS_ERROR,
                    $this->messageHandler->getOne('M504')
                );
            }
        }
        return $diagnose;
    }

    /**
     * @param string $diagnoseId
     * @return Treatment
     */
    private function validateDiagnoseInstance($diagnoseId)
    {
        $diagnoseModel = new \Medical\MHC\DiagnoseService();
        return $this->controller->createEntity($diagnoseId, "diagnoseId", $diagnoseModel, "Medical\\MHC\\Diagnose");

    }

    /**
     * @param TreatmentService $model
     */
    public function setTreatmentModel(TreatmentService $model)
    {
        $this->model = $model;
    }

    /**
     * @return EpisodeController
     */
    protected function setEpisode()
    {
        if (!$this->episode) {
            $this->episode = new EpisodeController();
        }
        return $this->episode;
    }

    /**
     * Validate Application.
     *
     * @param string $application
     *
     * @return bool
     */
    public function validateEditApplication($application)
    {
        $response = new NonCachedJsonResponse();

        if (!in_array($application, Treatment::$allowedApplication)) {
           $this->controller->addInvalidInputMessageToMeta('application', $application);
           return $response;
        }
        return $application;
    }

    /**
     * @param string $type
     * @return string
     */
    protected function validateType($type)
    {
        if (!Treatment::isValidType($type)) {
            $this->controller->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne('GV9', array('object' => 'Type', 'input' => $type))
            );
        }
        return $type;
    }
}
