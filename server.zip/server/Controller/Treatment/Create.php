<?php

namespace Controller\Treatment;

use Actinidium\API\Response\Meta;
use Controller\AbstractController;
use Controller\ValidationResult;
use Generic\ClinicService;
use Generic\Employee;
use Generic\EmployeeService;
use Medical\Episode;
use Medical\EpisodeService;
use Medical\MHC\Basic as BasicTreatment;
use Medical\MHC\Basic\PerformanceService;
use Medical\Somatic\DbcService;
use Medical\Treatment;
use Medical\TreatmentService;
use Message\MessageHandler;
use Security\Sanitizer;
use System\MHC\CircuitService;
use System\MHC\Performance as SystemPerformance;
use System\MHC\PerformanceService as SystemPerformanceService;
use Validation\DotValidationResult;
use DateTime;

/**
 * Callable via /api/medical-episode/:action where :action is one of the public *Action methods
 */
class Create
{
    const EXPECTEDCAREPRODUCT = "expectedcareproduct";

    /**
     * @var \Controller\AbstractController
     */
    private $controller;

    /**
     * @var \Medical\TreatmentService
     */
    private $model;

    /**
     * @var \Generic\Employee
     */
    private $specialist;

    /**
     * @var \Generic\Employee
     */
    private $secondSpecialist;

    /**
     * @var \Generic\Employee
     */
    private $treatmentPhaseSpecialist;

    /**
     * @var \Generic\Clinic
     */
    private $clinic;

    /**
     * @var \System\MHC\Circuit
     */
    private $circuit;

    /**
     * @var \Medical\EpisodeService
     */
    private $episodeModel;

    /**
     * @var \Medical\Episode
     */
    private $episode;

    /**
     * @var \Generic\ClinicService
     */
    private $clinicModel;

    /**
     * @var \Generic\EmployeeService
     */
    private $employeeModel;

    /**
     * Holds a reference to the System PerformanceService so we can search Performance objects.
     *
     * @var \System\MHC\PerformanceService
     */
    private $systemPerformanceService;

    /**
     * Holds a reference to the Basic MHC PerformanceService so we can validate the Performance Objects.
     *
     * @var \Medical\MHC\Basic\PerformanceService
     */
    private $performanceService;

    /**
     * Constructor.
     *
     * @param \Controller\AbstractController $controller
     */
    public function __construct(AbstractController $controller)
    {
        $this->model = $this->getTreatmentModel();
        $this->controller = $controller;
        $this->messageHandler = new MessageHandler();
        $this->performanceService = new PerformanceService(new SystemPerformanceService());
    }

    /**
     * Call the actual creation of treatment service.
     *
     * @param array $data
     *
     * @return \Medical\Treatment|null
     */
    public function run(array $data = array())
    {
        $validatedObjects = $this->createObjects($data);

        if (!$this->controller->getMeta()->hasError()) {
            $result = $this->save($validatedObjects);
            $validationResults = $this->getTreatmentModel()->getLegacyValidationMessages();

            if ($validationResults) {
                DotValidationResult::addMessagesToMeta($validationResults, $this->controller->getMeta());
            }

            if ($this->getTreatmentModel()->hasMessages()) {
                ValidationResult::addMessages($this->controller, $this->getTreatmentModel()->getValidationMessages());
            }
            return $result;
        }
        return null;
    }

    /**
     * @param array $validatedObjects
     * @return Treatment $treatment
     */
    protected function save($validatedObjects)
    {
        return $this->model->create($validatedObjects);
    }

    /**
     * @param array $data
     * @return array
     */
    public function createObjects($data)
    {
        $validatedObjects = array();
        $validatedObjects["episode"] = $this->validateEpisodeId($data['episodeId']);
        $validatedObjects['type'] = $this->validateType($data['type']);

        $validatedObjects['specialist'] = $this->validateSpecialist($data['specialist']['id']);
        $validatedObjects['clinic'] = $this->validateClinicId($data['clinic']['id']);

        $validatedObjects['name'] = $this->validateName($data['name']);

        $startDate = $this->controller->validateDate($data['startDate'], 'startDate');
        $validatedObjects['startDate'] = $startDate;

        $validatedObjects['expectedEndDate'] = null;
        //Allowing user to give expected endDate for the treatment
        if (!empty($data['expectedEndDate'])) {
            $expectedEndDate = $this->controller->validateDate(
                $data['expectedEndDate'],
                'expectedEndDate'
            );
            $validatedObjects['expectedEndDate'] = $expectedEndDate;
        }

        //Allowing user to give secondary specialist for the treatment
        $validatedObjects['secondSpecialist'] = null;
        if (!empty($data['secondSpecialist']['id'])) {
            $this->secondSpecialist = $this->validateSecondSpecialist($data['secondSpecialist']['id']);
            $validatedObjects['secondSpecialist'] = $this->secondSpecialist;
            if (!empty($validatedObjects['secondSpecialist']) && !empty($validatedObjects['specialist'])) {
                $this->validateSpecialistIsNotTheSameAsSecondSpecialist();
            }
        }

        $validatedObjects['treatmentPhaseSpecialist'] = null;
        if (!empty($data['treatmentPhaseSpecialist']['id'])) {
            $this->treatmentPhaseSpecialist = $this
                ->validateTreatmentPhaseSpecialistSpecialist($data['treatmentPhaseSpecialist']['id']);
            $validatedObjects['treatmentPhaseSpecialist'] = $this->treatmentPhaseSpecialist;
        } elseif (null === $this->treatmentPhaseSpecialist) {
            $validatedObjects['treatmentPhaseSpecialist'] = $this->specialist;
        }

        if (!$this->controller->getMeta()->hasError()) {
            $errors = $this->model->specialistValidation($validatedObjects["episode"], $validatedObjects['specialist']);
        }

        if (!empty($errors)) {
            foreach ($errors as $error) {
                $this->controller->addMessage($error['type'], $error['id'], $error['params']);
            }
        }

        /** @var \DateTime $startDate */
        if ($startDate instanceof DateTime && !empty($data['circuitCode'])) {
            $validatedObjects['circuitCode'] = $this->validateCircuitCodeId($data['circuitCode']['id']);
        }
        if (!empty($data['existingPatient'])) {
            if (Sanitizer::isEmpty($data['existingPatient']) && $data['existingPatient'] !== false) {
                $this->controller->getMeta()->addMessage(
                    Meta::STATUS_ERROR,
                    $this->messageHandler->getOne('MG01', array('list_of_fields' => 'existingPatient'))
                );
            } else {
                $validatedObjects['existingPatient'] = Sanitizer::boolean($data['existingPatient']);
            }
        }

        if (array_key_exists('expectedCareProduct', $data)) {
            $validatedObjects['expectedCareProductCode'] = null;
            if ($startDate instanceof DateTime && !empty($data['expectedCareProduct'])) {
                $validatedObjects['expectedCareProductCode']
                    = $this->validateExpectedCareProduct($data['expectedCareProduct']['code'], $startDate);
            }
        }

        $validatedObjects = array_merge(
            $validatedObjects,
            $this->validateBasicMhcObjects($data, $validatedObjects)
        );

        $validatedObjects['notInvoiceable']
            = $this->controller->validateBoolean($data['notInvoiceable'], 'notInvoiceable');

        return $validatedObjects;
    }

    /**
     * Validate the parameters posted to the controller which are ONLY required for Basic MHC
     *
     * @param array $data
     * @param array $validatedObjects
     *
     * @return array $basicValidatedObjects
     */
    private function validateBasicMhcObjects(array $data = array(), array $validatedObjects = array())
    {
        $basicValidatedObjects = array();

        $romApplied = BasicTreatment::ROM_APPLIED_NO;

        if (isset($data['romApplied']) && $data['romApplied']) {
            $romApplied = BasicTreatment::ROM_APPLIED_YES;
        }

        $basicValidatedObjects['romApplied'] = $romApplied;

        $expectedPerformance = null;
        if (isset($data['expectedPerformance']) &&
            array_key_exists('id', $data['expectedPerformance'])
        ) {
            $expectedPerformance = $this->performanceService->validatePerformanceOnDate(
                $data['expectedPerformance']['id'],
                $validatedObjects['startDate'],
                SystemPerformance::TYPE_EXPECTED
            );
        }
        $basicValidatedObjects['expectedPerformance'] = $expectedPerformance;
        $basicValidatedObjects['expectedPerformanceRemark'] = $data['expectedPerformanceRemark'];

        $deliveredPerformance = null;
        if (isset($data['deliveredPerformance']) &&
            array_key_exists('id', $data['expectedPerformance'])
        ) {
            $deliveredPerformance = $this->performanceService->validatePerformanceOnDate(
                $data['deliveredPerformance']['id'],
                $validatedObjects['startDate'],
                SystemPerformance::TYPE_DELIVERED
            );
        }
        $basicValidatedObjects['deliveredPerformance'] = $deliveredPerformance;
        $basicValidatedObjects['deliveredPerformanceRemark'] = $data['deliveredPerformanceRemark'];

        foreach ($this->performanceService->getErrors() as $error) {
            $this->controller->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne($error['id'], $error['params'])
            );
        }

        return $basicValidatedObjects;
    }

    /**
     * Validates initial specialist and second specialist are not same.
     */
    private function validateSpecialistIsNotTheSameAsSecondSpecialist()
    {
        $secondSpecialistErrors = $this->model->validateSpecialistIsNotTheSameAsSecondSpecialist(
            $this->specialist,
            $this->secondSpecialist
        );
       
        if (!empty($secondSpecialistErrors)) {
            
            foreach ($secondSpecialistErrors as $error) {
                $this->controller->addMessage($error['type'], $error['id'], $error['params']);
            }
        }
    }
    
    /**
     * @param integer $id
     *
     * @return \Medical\Episode|null
     */
    protected function validateEpisodeId($id)
    {
        if (!$this->episode) {
            $episodeModel = $this->getEpisodeModel();
            $this->episode = $this->controller->createEntity(
                $id,
                'episodeId',
                $episodeModel,
                "Medical\\Episode"
            );
        }
        return $this->episode;
    }

    /**
     * @param int $id
     *
     * @return \Generic\Employee|null
     */
    protected function validateSpecialist($id)
    {
        $employeeModel = $this->getEmployeeModel();
        $this->specialist = $this->controller->createEntity(
            $id,
            'specialistId',
            $employeeModel,
            "\\Generic\\Employee"
        );
        return $this->specialist;
    }

    /**
     * @return \Generic\EmployeeService
     */
    protected function getEmployeeModel()
    {
        if (!$this->employeeModel) {
            $this->employeeModel = new EmployeeService();
        }
        return $this->employeeModel;
    }

    /**
     * @param \Generic\EmployeeService $employeeModel
     */
    public function setEmployeeModel(EmployeeService $employeeModel)
    {
        $this->employeeModel = $employeeModel;
    }
    
     /**
     * @param $id
     * @return mixed
     */
    protected function validateSecondSpecialist($id)
    {
        $employeeModel = $this->getEmployeeModel();
        $this->secondSpecialist = $this->controller->createEntity(
            $id,
            'secondSpecialistId',
            $employeeModel,
            "\\Generic\\Employee"
        );
        return $this->secondSpecialist;
    }

    /**
     * Validate and create specialist for treatment phase for mhc.
     *
     * @param int $id
     *
     * @return \Generic\Employee|null
     */
    protected function validateTreatmentPhaseSpecialistSpecialist($id)
    {
        $employeeModel = $this->getEmployeeModel();
        $this->treatmentPhaseSpecialist = $this->controller->createEntity(
            $id,
            'treatmentPhaseSpecialistId',
            $employeeModel,
            "\\Generic\\Employee"
        );
        return $this->treatmentPhaseSpecialist;
    }

    /**
     * @param $id
     *
     * @return \Generic\Clinic|null
     */
    protected function validateClinicId($id)
    {
        $clinicModel = $this->getClinicModel();
        $this->clinic = $this->controller->createEntity(
            $id,
            'clinicId',
            $clinicModel,
            "Generic\\Clinic"
        );

        if (!$this->controller->getMeta()->hasError()) {
            if (!$clinicModel->validAccessToEmployee($this->specialist, $this->clinic)) {
                $this->controller->addTranslatedMessageToMeta(
                    'EM-M2',
                    array(),
                    Meta::STATUS_ERROR
                );
            }

            if (!$clinicModel->doesPatientBelongToClinic($this->episode->getPatient(), $this->clinic)) {
                $this->controller->addTranslatedMessageToMeta(
                    'GM-M03',
                    array(),
                    Meta::STATUS_ERROR
                );
            }
        }

        return $this->clinic;
    }

    /**
     * @param string $type
     *
     * @return string
     */
    protected function validateType($type)
    {
        if (empty($type)) {
            $this->controller->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne('MG01', array('list_of_fields' => "type"))
            );
        } elseif (!Treatment::isValidType($type)) {
            $this->controller->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne('GV9', array('object' => 'Type', 'input' => $type))
            );
        }
        return $type;
    }

    /**
     * Validate the treatment name.
     *
     * @param string $name
     *
     * @return string
     */
    protected function validateName($name)
    {
        if (empty($name)) {
            if (!$this->episode->hasDotTreatments()) {
                $this->controller->getMeta()->addMessage(
                    Meta::STATUS_ERROR,
                    $this->messageHandler->getOne('MG01', array('list_of_fields' => "name"))
                );
            }
        } elseif (mb_strlen($name) < 1 || mb_strlen($name) > 255) {
            $this->controller->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne('MG100', array('field_name' => 'name', 'max_length' => '255'))
            );
        }
        return $name;
    }

    /**
     * @param integer $circuitCodeId
     *
     * @return \System\MHC\Circuit $circuit
     */
    private function validateCircuitCodeId($circuitCodeId)
    {
        if (!is_null($circuitCodeId)) {
            $circuitModel = new CircuitService();
            $this->circuit = $this->controller->createEntity(
                $circuitCodeId,
                'circuitCodeId',
                $circuitModel,
                "\\System\\MHC\\Circuit"
            );
        }
        return $this->circuit;
    }

    /**
     * @param \DateTime $startDate
     *
     * @return \System\MHC\Circuit|null
     */
    private function validateCircuitCodeIsValidOnDate(DateTime $startDate)
    {
        if ($this->circuit) {

            if (!$this->circuit->isValidOnDate($startDate)) {
                $this->controller->addMessage(
                    Meta::STATUS_ERROR,
                    'M147',
                    array('object' => 'Circuit Code ID', 'input' => $startDate->format('Y-m-d'))
                );
                return null;
            }
        }
        return $this->circuit;
    }

    /**
     * @return \Medical\TreatmentService
     */
    protected function getTreatmentModel()
    {
        if (!$this->model) {
            $this->model = new TreatmentService();
        }
        return $this->model;
    }

    /**
     * @param \Medical\TreatmentService $treatmentModel
     */
    public function setTreatmentModel(TreatmentService $treatmentModel)
    {
        $this->model = $treatmentModel;
    }

    /**
     * @return \Medical\EpisodeService
     */
    protected function getEpisodeModel()
    {
        if (!$this->episodeModel) {
            $this->episodeModel = new EpisodeService();
        }
        return $this->episodeModel;
    }

    /**
     * @param \Medical\EpisodeService $episodeModel
     */
    public function setEpisodeModel(EpisodeService $episodeModel)
    {
        $this->episodeModel = $episodeModel;
    }

    /**
     * So that we can mock this in our phpunit.
     *
     * @return \Generic\ClinicService
     */
    protected function getClinicModel()
    {
        if (!$this->clinicModel) {
            $this->clinicModel = new ClinicService();
        }
        return $this->clinicModel;
    }

    /**
     * @param \Generic\ClinicService $clinicModel
     */
    public function setClinicModel(ClinicService $clinicModel)
    {
        $this->clinicModel = $clinicModel;
    }

    /**
     * Validating expected care product exists or not.
     *
     * @param int      $expectedCareProductCode
     * @param DateTime $startDate
     *
     * @return string
     */
    private function validateExpectedCareProduct($expectedCareProductCode, $startDate)
    {
        $dbcModel = new DbcService();

        if (!$dbcModel->validateCareProductGroupCode(
            $expectedCareProductCode,
            $startDate
        )) {
            $this->controller->addMessage(
                Meta::STATUS_ERROR,
                'GV9',
                array('object' => self::EXPECTEDCAREPRODUCT, 'input' => $expectedCareProductCode)
            );
        }

        return $expectedCareProductCode;
    }
}
