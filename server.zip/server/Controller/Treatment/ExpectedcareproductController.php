<?php

namespace Controller\Treatment;

use Actinidium\API\Response\Meta;
use Controller\AbstractController;
use Security\Sanitizer;
use Response\PaginationAdaptor;
use System\Dbc\CareProductService;

/**
 * Class ExpectedcareproductController
 * @package Controller\Treatment
 */
class ExpectedcareproductController extends AbstractController
{
    /**
     * @var CareProductService
     */
    private $model;

    /**
     * The amount of characters the user has to type before the partial search gets added
     */
    const MAX_LENGTH_SEARCHTERM_STARTS_WITH = 3;
    
    /**
     * Controller action for the care product search/list.
     *
     * @return array
     */
    public function getListAction()
    {
        $this->data = array();
        $request = $this->getRequest()->query;

        $offset = (int)$request->get('offset', 0);
        $limit = (int)$request->get('itemsPerPage', PaginationAdaptor::MAXLIMIT);

        $this->isPositiveIntegerOrZero('offset', $offset);
        $this->isEntityIdPositiveInteger($limit, 'itemsPerPage');
        
        $this->data = $this->searchCareProductCodes($offset, $limit);

        if (!$this->getMeta()->hasError()) {
            $totalCount = count($this->data);
            if ($offset >= $totalCount) {
                $offset = 0;
            }

            $careProducts = array_slice($this->data, $offset, $limit);
            $this->addPagination($offset, $limit, $totalCount);
            $this->data =  $this->prepareCareProductsForGUI($careProducts);
        }

        $this->getMeta()->setCount(count($this->data));

        return $this->data;
    }

    /**
     * Search care product codes.
     *
     * @param int $offset
     * @param int $limit
     *
     * @return bool
     */
    private function searchCareProductCodes($offset, $limit)
    {
        $criteria = $this->processRequestValidation();
        $order = array("code" => "ASC");

        if (!$this->getMeta()->hasError()) {
            $results = $this->performSearch($criteria, $order);

            $this->addPagination($offset, $limit, count($results));

            return $results;
        }
        return false;
    }

    /**
     * Populate an array for the GUI to use.
     *
     * @param array $careProducts
     *
     * @return array
     */
    private function prepareCareProductsForGUI($careProducts)
    {
        $list = array();
        foreach ($careProducts as $careProduct) {
            if (is_object($careProduct) && $careProduct instanceof \System\Dbc\CareProduct) {
                $list[] = $careProduct->toListArray();
            }
        }
        $this->checkResults($list);

        return $list;
    }

    /**
     * Function to validate the search string passed to the API
     *
     * @return bool|string
     */
    private function validateSearchString()
    {
        $request = $this->getRequest()->query;

        $searchString = $request->get('search');
        if (!$this->isRequired($searchString, 'search')) {
            return false;
        }

        return $searchString;
    }

    /**
     * Function to check if the passed array contains any items.
     *
     * @param array $list
     */
    private function checkResults(array $list)
    {
        if (count($list) == 0) {
            $this->addMessage(
                Meta::STATUS_INFO,
                "MG103"
            );
        }
    }

    /**
     * Retrieve the dbc care product model.
     *
     * @return CareProductService
     */
    protected function getModel()
    {
        if (!$this->model) {
            $this->model = new CareProductService();
        }

        return $this->model;
    }

    /**
     * Function to get a valid date.
     *
     * If no date is provided, return current system date
     *
     * @return  \DateTime|false
     */
    private function getValidDate()
    {
        $date = $this->getRequestedDate();

        return $this->validateDate($date, "validOn");
    }

    /**
     * Function to get the date passed to the API.
     *
     * @return  String|Boolean
     */
    protected function getRequestedDate()
    {
        $query = $this->getRequest()->query;

        return $query->get('validOn', false);
    }

    /**
     * Function to process all the validations send by the request.
     *
     * @return array
     */
    private function processRequestValidation()
    {
        $request = $this->getRequest()->query;

        $criteria = array();
        if ($request->has('search')) {
            $criteria['searchString'] = $this->validateSearchString();
        }

        $criteria['date'] = $this->getValidDate();

        return $criteria;
    }

    /**
     * Perform search based on criteria.
     *
     * @param array $criteria
     * @param array $order
     *
     * @return array|\System\Dbc\CareInstitution[]
     */
    private function performSearch(array $criteria, array $order)
    {
        //get the exact matches
        $criteria['exactMatches'] = true;
        $results = $this->getModel()->searchAllBy($criteria, $order);

        //if we do not have any errors get the partial matches
        //we will check the errors because if we do not, we will get double error messages
        if (!$this->getMeta()->hasError()) {
            if (mb_strlen(trim($criteria['searchString'])) >= self::MAX_LENGTH_SEARCHTERM_STARTS_WITH) {
                //get the partial matches
                $criteria['exactMatches'] = false;
                $criteria['excludeIds'] = $this->model->getIdsFromResult($results);
                $results = array_merge($results, $this->model->searchAllBy($criteria, $order));
            }
        }

        return $results;
    }
}
