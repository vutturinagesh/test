<?php

namespace Controller\Treatment;

use Actinidium\API\Response\Meta;
use Actinidium\API\Response\NonCachedJsonResponse;
use Controller\AbstractController;
use Medical\Activity\Phase;
use Medical\Activity\PhaseService;
use Symfony\Component\HttpFoundation\JsonResponse;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/treatment-phase",
 *     basePath="/api/v2"
 * )
 */
class PhaseController extends AbstractController
{
    /**
    * @var \Medical\Activity\PhaseService
    */
    private $phaseService;

    /**
     * Constructor.
     *
     * @param \Medical\Activity\PhaseService $phaseService
     */
    public function __construct(PhaseService $phaseService)
    {
        parent::__construct();

        $this->phaseService = $phaseService;
    }

    /**
     * @SWG\Api(
     *   path="/treatment/phase",
     *   @SWG\Operation(
     *       method="GET",
     *       summary="Returns a list of treatment phases."
     *   )
     * )
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function getListAction()
    {
        $data = array();
        $response = new NonCachedJsonResponse();

        $phases = $this->phaseService->findAll();
        if (!empty($phases)) {
            foreach ($phases as $phase) {
                $data[] = $phase->toListArray();
            }
        }

        $data[] = $this->phaseService->addDefaultPhase();

        $this->getMeta()->setCount(count($data));

        $response->setData(array("data" => $data));
        
        return $response;
    }
}
