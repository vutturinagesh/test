<?php
namespace Controller\Treatment;

use Actinidium\API\RestBaseController;
use Controller\AbstractController;
use Generic\CustomerSettingsService;
use Generic\EmployeeService;
use Generic\SystemSettingService;
use Medical\Treatment;
use Medical\TreatmentService;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use System\EncryptionService;
use System\Feature;
use System\Module;
use System\ModuleService;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/treatment",
 *     basePath="/api/v2"
 * )
 */
class MedicationController extends AbstractController
{
    /**
     * @const Farmedz Connection Url
     */
    const FARMEDZ_CONNECTURL = 'gekoppeld_main.php';
    
    /**
     * @var \Generic\Treatment
     */
    private $treatment = null;

    /**
     * @var \Medical\TreatmentService
     */
    private $treatmentService;

    /**
     * @var \Generic\CustomerSettingsService
     */
    private $customerSettingService;

    /**
     * @var \Generic\EmployeeService
     */
    private $employeeService;
    
    /**
     * @var \Generic\SystemSettingService $systemSettingService
     */
    private $systemSettingService;

    /**
     * @var \System\EncryptionService
     */
    private $encryptionService;

    /**
     * @param \Medical\TreatmentService        $treatmentService
     * @param \Generic\CustomerSettingsService $customerSettingsService
     * @param \Generic\EmployeeService         $employeeService
     * @param \Generic\SystemSettingService    $systemSettingService
     * @param \System\EncryptionService        $encryptionService
     */
    public function __construct(
        TreatmentService $treatmentService,
        CustomerSettingsService $customerSettingsService,
        EmployeeService $employeeService,
        SystemSettingService $systemSettingService,
        EncryptionService $encryptionService
    ) {
        parent::__construct();
        $this->treatmentService = $treatmentService;
        $this->customerSettingService = $customerSettingsService;
        $this->employeeService = $employeeService;
        $this->systemSettingService = $systemSettingService;
        $this->encryptionService = $encryptionService;
    }

    /**
     * @SWG\Api(
     *   path="/treatment/medication",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Returns the medication data to send it to external URL.",
     *           @SWG\Parameter(name="id", type="integer", required=true, description="The id of the treatment", paramType="query")
     *       )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function getAction(Request $request)
    {
        $response = new JsonResponse();
        $response->setPublic();

        $id = $request->query->get('id');
        $treatment = $this->getTreatment((int) $id);

        if (!$this->getMeta()->hasError()) {
            $this->data = array();

            $this->data['url'] = $this->prepareUrl($treatment);

            $farmedzssourl = $this->systemSettingService->getByName('farmedzssourl')->getSettingValue();
            $farmedzssousername = $this->systemSettingService->getByName('farmedzssousername')->getSettingValue();
            $farmedzssopassword = $this->getPasswordFromSettings();
            $farmedzssoklant = $this->systemSettingService->getByName('farmedzssoklant')->getSettingValue();

            $this->data['farmedzSsoUrl'] = (null !== $farmedzssourl) ? $farmedzssourl->getValue() : null;
            $this->data['farmedzSsoUsername'] = (null !== $farmedzssousername) ? $farmedzssousername->getValue() : null;
            $this->data['farmedzSsoPassword'] = (null !== $farmedzssopassword) ? $farmedzssopassword : null;
            $this->data['farmedzSsoKlant'] = (null !== $farmedzssoklant) ? $farmedzssoklant->getValue() : null;
        }

        $response->setData(array('data' => $this->data));
        return $response;
    }

    /**
     * Get the password from the settings and decrypt it if needed.
     *
     * @return string
     */
    private function getPasswordFromSettings()
    {
        $farmedzssopassword = null;
        $encryptedPassword = $this->systemSettingService->getByName('farmedzssopassword')->getSettingValue();
        if (null !== $encryptedPassword && null !== $encryptedPassword->getValue()) {
            $farmedzssopassword = $this->encryptionService->decrypt(
                base64_decode($encryptedPassword->getValue()),
                EncryptionService::FARMEDZ_SECRET
            );
        }

        return $farmedzssopassword;
    }

    /**
     * Will prepare URL according to feature 'FarmedZ gebruikt AFAS code en ingelogde gebruiker'.
     *
     * @param \Medical\Treatment $treatment
     *
     * @return string
     */
    private function prepareUrl(Treatment $treatment)
    {
        $moduleService = new ModuleService();

        if ($moduleService->isFeatureEnabled(feature::FARMEDZ_AFAS, module::MEDICAL)) {
            $customer = $this->customerSettingService->getCustomerSettings();

            $this->data['patientId'] = $customer->getAfasCustomerId() . '-' . $treatment->getEpisode()->getPatient()->getId();
            $this->data['userId'] = $customer->getAfasCustomerId() . '-' . $this->employeeService->getCurrentEmployee()->getId();
            $url = self::FARMEDZ_CONNECTURL . '?patid=' . $this->data['patientId'] . '&userid=' . $this->data['userId'];
        } else {
            $this->data['patientId'] = $treatment->getClinic()->getLocationCode() . '-' . $treatment->getEpisode()->getPatient()->getId();
            $this->data['specialistAGB'] = $treatment->getSpecialist()->getAGB();

            $url = self::FARMEDZ_CONNECTURL . '?patid=' . $this->data['patientId'] . '&userid=' . $this->data['specialistAGB'];
        }

        return $url;
    }

    /**
     * Returns the treatment object
     *
     * @param int $id
     *
     * @return \Medical\Treatment
     */
    protected function getTreatment($id)
    {
        if (!isset($this->treatment) || $this->treatment == null) {

            $this->treatment = $this->createEntity(
                $id,
                'id',
                $this->treatmentService,
                "Medical\\Treatment"
            );
        }
        
        return $this->treatment;
    }
    
    /**
     * Set the treatment
     *
     * @param \Medical\Treatment $treatment
     *
     */
    public function setTreatment(Treatment $treatment)
    {
        $this->treatment = $treatment;
    }

    /**
     * Set the treatment
     *
     * @param \Generic\SystemSettingService 
     *
     */
    public function setSystemSettingService(SystemSettingService $systemSettingService)
    {
        $this->systemSettingService = $systemSettingService;
    }
}
