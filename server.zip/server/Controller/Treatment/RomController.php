<?php
namespace Controller\Treatment;

use Actinidium\API\MetaBaseController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Actinidium\API\Response\Meta;
use Controller\AbstractController;
use Medical\TreatmentService;


/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/treatment",
 *     basePath="/api/v2"
 * )
 */
class RomController extends AbstractController
{
    /**
     * @SWG\Api(
     *   path="/treatment/rom",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Will redirect to external URL after clicking the ROM button.",
     *           @SWG\Parameter(name="id", type="integer", required=true, paramType="query"),
     *       )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function getAction(Request $request)
    {
        $id = $request->query->get('id');

        $response = new JsonResponse();
        $response->setPublic();

        $treatmentObj = $this->getTreatment((int) $id);
        $session = $this->getSession();

        $customerService = $this->get('medicore.generic.customer_service');
        $romData = $customerService->getRomData();

        if (!$this->getMeta()->hasError()) {
            $clinic = $treatmentObj->getClinic();
            $clientSettings = $this->getCustomerSettings();
            $romPrefix = $clientSettings->getRomPrefix();
            $romPrefix = (trim($romPrefix) != '') ? trim($romPrefix) : ($clinic instanceOf \Generic\Clinic ? $clinic->getInstitutionCode() : '');
            $data = array();
            $data['url'] = $romData['romUrl'];
            $data['post'] = array();
            $data['post']['InstCode'] = $romData['romInstCode'];
            $data['post']['dateString'] = date("YmdHis");
            $data['post']['Afd3Code'] = $clinic instanceOf \Generic\Clinic ? $clinic->getInstitutionCode() : '';
            $data['post']['MNaam'] = $session['medewerker']['naam'];
            $data['post']['MFunctie'] = $session['medewerker']['type'];
            $data['post']['MEmail'] = $session['medewerker']['email'];
            $data['post']['MRole'] =  'caresupport';
            $data['post']['MCode'] =  $romPrefix . '_' . $session['medewerker']['id'];
            $data['post']['hashCode'] = sha1($clientSettings->getRomSharedKey() . "_" . $data['post']['MCode']."_".$data['post']['dateString']);
            $data['post']['PCode'] = $romPrefix . '_' . $treatmentObj->getEpisode()->getPatient()->getId();
            $data['post']['PVoorletters'] = $treatmentObj->getEpisode()->getPatient()->getVoorletters();
            $data['post']['PRoepnaam'] = $treatmentObj->getEpisode()->getPatient()->getNickname();
            $data['post']['PTussenvoegselGeboortenaam'] = $treatmentObj->getEpisode()->getPatient()->getTussenvoegselEigennaam();
            $data['post']['PGeboortenaam'] = $treatmentObj->getEpisode()->getPatient()->getEigennaam();
            $data['post']['PGebdat'] = $treatmentObj->getEpisode()->getPatient()->getBirthDate()->format('d-m-Y');
            $data['post']['PMVO'] = $this->getGender($treatmentObj, $clientSettings);
            $data['post']['PBSN'] = $treatmentObj->getEpisode()->getPatient()->getBsnValue();
            $data['post']['PTelefoon1'] = $treatmentObj->getEpisode()->getPatient()->getHomePhone();
            $data['post']['PTelefoon2'] = $treatmentObj->getEpisode()->getPatient()->getMobilePhone();
            $data['post']['PEmail'] = $treatmentObj->getEpisode()->getPatient()->getEmail();
            $data['post']['PInschrdat'] = $treatmentObj->getEpisode()->getPatient()->getApplicationDate()->format('d-m-Y');
            $data['post']['BCode'] = $clinic->getInstitutionCode() . '_' . $treatmentObj->getId();
            $data['post']['BEinddatum'] = (!$treatmentObj->getEndDate()) ? '' : $treatmentObj->getEndDate()->format('d-m-Y');
            $data['post']['BBehandelaar'] = $clinic->getInstitutionCode() . '_' . $treatmentObj->getSpecialist()->getId();
            $data['post']['BEmail'] = $this->getSpecialistEmail($treatmentObj);

            $response->setData(array('data' => $data));
            $response->setStatusCode(Response::HTTP_OK);

            return $response;

        } else {
            return $response;
        }


    }

    /**
     * Set the treatment
     *
     * @param \Medical\Treatment $treatmentObj
     *
     * @return void
     */
    public function setTreatment(\Medical\Treatment $treatmentObj)
    {
        $this->treatmentObj[$treatmentObj->getId()] = $treatmentObj;
    }

    /**
     * Returns the customer settings
     *
     * @return object
     */
    protected function getCustomerSettings()
    {
        if ($this->clientSettings == null) {
            $clientSettingsService = new \Generic\CustomerSettingsService();
            $this->clientSettings = $clientSettingsService->getCustomerSettings();
        }

        return $this->clientSettings;
    }

    /**
     * Set the customer settings
     *
     * @param \Generic\CustomerSettings $customerSettings
     *
     * @return void
     */
    public function setCustomerSettings(\Generic\CustomerSettings $customerSettings)
    {
        $this->clientSettings = $customerSettings;
    }

    /**
     * Returns the specialist email
     *
     * @param \Medical\Treatment $treatmentObj
     *
     * @return string
     */
    protected function getSpecialistEmail($treatmentObj)
    {
        $secondSpecialistId = $treatmentObj->getSecondarySpecialist();
        if ($secondSpecialistId > 0) {
            $specialistService = new \Generic\EmployeeService();
            $secondartSpecialistObj = $specialistService->find($secondSpecialistId);
        }

        return (is_object($secondartSpecialistObj) && trim($secondartSpecialistObj->getEmail()) != '') ? $secondartSpecialistObj->getEmail() : $treatmentObj->getSpecialist()->getEmail();
    }

    /**
     * Returns the gender
     *
     * @param \Medical\Treatment $treatmentObj
     * @param \Generic\CustomerSettings $clientSettings
     *
     * @return string
     */
    private function getGender($treatmentObj, $clientSettings)
    {
        $romSupplier = $clientSettings->getRomSupplier();
        if (strtolower($romSupplier) == 'reflectum') {
            $male = 'M';
            $female = 'V';
        } else {
            $male = 'Male';
            $female = 'Female';
        }

        return ($treatmentObj->getEpisode()->getPatient()->getGeslacht() == 'man' ? $male : $female);
    }

    /**
     * Returns the treatment object
     *
     * @param int $id
     *
     * @return \Medical\Treatment
     */
    protected function getTreatment($id)
    {
        if (!isset($this->treatment) || $this->treatment == null) {

            $this->treatment = $this->createEntity(
                $id,
                'id',
                $this->getTreatmentModel(),
                "Medical\\Treatment"
            );
        }

        return $this->treatment;
    }

    /**
     * @return TreatmentService
     */
    protected function getTreatmentModel()
    {
        if (!$this->model) {
            $this->model = new TreatmentService();
        }
        return $this->model;
    }

    /**
     * Returns the session
     *
     * @return array
     */
    private function getSession()
    {
        if ($this->session == null) {
            $this->session = $_SESSION;
        }

        return $this->session;
    }

    /**
     * Set the session
     *
     * @param array $session
     *
     * @return void
     */
    public function setSession($session)
    {
        $this->session = $session;
    }
}
