<?php

namespace Controller\Treatment;

use Actinidium\API\Response\Meta;
use Actinidium\API\Response\NonCachedJsonResponse;
use Controller\AbstractController;
use Controller\ValidationResult;
use DateTime;
use Factory\TranslatorFactory;
use Generic\Authorizer;
use Generic\SettingService;
use Medical\Treatment;
use Medical\TreatmentService;
use Medical\Treatment\ApplyProfileService;
use Medical\Treatment\Profile;
use Medical\Treatment\ProfileService;
use Message\MessageHandler;
use Response\PaginationAdaptor;
use Security\Sanitizer;
use Swagger\Annotations as SWG;
use Symfony\Component\HttpFoundation\ParameterBag;
use Symfony\Component\HttpFoundation\Request;
use Calendar\Appointment\IdToAppointmentTypeTransformer;
use Symfony\Component\Translation\Translator;
use Validation\DotValidationResult;
use Generic\Employee;
use Generic\IdToEmployeeTransformer;
use Symfony\Component\Form\Exception\TransformationFailedException;
use Calendar\Appointment\Type as AppointmentType;
use Generic\IdToClinicTransformer;
use Medical\Treatment\Activity\EmrService;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/treatment-profile",
 *     basePath="/api/v2"
 * )
 *
 * Controller to handle GET, POST, UPDATE, DELETE requests for treatment profiles.
 */
class ProfileController extends AbstractController
{
    /* @var \Medical\Treatment\ProfileService */
    private $profileService;

    /* @var \Medical\TreatmentService */
    private $treatmentService;

    /* @var \Calendar\Appointment\IdToAppointmentTypeTransformer */
    private $idToAppointmentTypeTransformer;

    /* @var \Generic\IdToClinicTransformer */
    private $idToClinicTransformer;

    /** @var \Generic\Authorizer */
    private $authorizer;

    /** @var \Medical\Treatment\ApplyProfileService */
    private $applyProfileService;

    /** @var \Symfony\Component\Translation\Translator  */
    protected $translator;

    /** @var \Generic\IdToEmployeeTransformer */
    private $idToEmployeeTransformer;

    /** @var \Generic\SettingService */
    private $settingService;

    /** @var \Medical\Treatment\Activity\EmrService */
    private $emrService;

    /**
     * Constructs services needed for this controller.
     *
     * @param \Generic\Authorizer                                  $authorizer
     * @param \Medical\TreatmentService                            $treatmentService
     * @param \Medical\Treatment\ApplyProfileService               $applyProfileService
     * @param \Calendar\Appointment\IdToAppointmentTypeTransformer $idToAppointmentTypeTransformer
     * @param \Medical\Treatment\ProfileService                    $profileService
     * @param \Generic\IdToEmployeeTransformer                     $idToEmployeeTransformer
     * @param \Symfony\Component\Translation\Translator            $translator
     * @param \Generic\IdToClinicTransformer                       $idToClinicTransformer
     * @param \Generic\SettingService                              $settingService
     * @param \Medical\Treatment\Activity\EmrService               $emrService
     */
    public function __construct(
        Authorizer $authorizer,
        TreatmentService $treatmentService,
        ApplyProfileService $applyProfileService,
        IdToAppointmentTypeTransformer $idToAppointmentTypeTransformer,
        ProfileService  $profileService,
        IdToEmployeeTransformer $idToEmployeeTransformer,
        Translator $translator,
        IdToClinicTransformer $idToClinicTransformer,
        SettingService $settingService,
        EmrService $emrService
    ) {
        parent::__construct();

        $this->authorizer = $authorizer;
        $this->treatmentService = $treatmentService;
        $this->applyProfileService = $applyProfileService;
        $this->idToAppointmentTypeTransformer = $idToAppointmentTypeTransformer;
        $this->profileService = $profileService;
        $this->idToEmployeeTransformer = $idToEmployeeTransformer;
        $this->translator = $translator;
        $this->idToClinicTransformer = $idToClinicTransformer;
        $this->settingService = $settingService;
        $this->emrService = $emrService;
    }

    /**
     * @SWG\Api(
     *    path="/treatment-profile",
     *    @SWG\Operation(
     *        summary="Retrieves a list of profiles for a treatment.",
     *        method="GET",
     *        type="\Medical\Treatment\Profile",
     *        @SWG\Parameter(name="treatmentId", type="integer", required=false, paramType="query"),
     *        @SWG\Parameter(name="search", type="string", required=false, paramType="query"),
     *        @SWG\Parameter(name="offset", type="integer", required=false, paramType="query"),
     *        @SWG\Parameter(name="limit", type="integer", required=false, paramType="query"),
     *        @SWG\Parameter(name="appointmentTypeId", type="integer", required=false, paramType="query"),
     *        @SWG\Parameter(name="clinicId", type="integer", required=false, paramType="query"),
     *        @SWG\Parameter(name="pagination", type="boolean", required=false, paramType="query"),
     *
     *   )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Actinidium\API\Response\NonCachedJsonResponse
     */
    public function getListAction(Request $request)
    {
        $this->data = array();
        $request = $request->query;

        $offset = (int)$request->get('offset', 0);
        $limit = (int)$request->get('itemsPerPage', PaginationAdaptor::MAXLIMIT);
        $pagination = true;
        if ($request->has("pagination")) {
            $pagination = $this->validateBoolean(
                $request->get("pagination"),
                "pagination"
            );
        }

        if ($this->isPositiveIntegerOrZero('offset', $offset) &&
            $this->isEntityIdPositiveInteger($limit, 'itemsPerPage')
        ) {

            $profiles = $this->getProfiles($request, $offset, $limit, $pagination);

            if (!$this->getMeta()->hasError()
            ) {
                $appointmentType = null;
                if ($request->get('appointmentTypeId')) {
                    try {
                        $appointmentType = $this->idToAppointmentTypeTransformer->transform($request->get('appointmentTypeId'));
                    } catch (TransformationFailedException $e) {
                        $this->addInvalidInputMessageToMeta('appointmentTypeId', $request->get('appointmentTypeId'));
                        return false;
                    }
                }

                $this->data = $this->prepareProfilesForGUI($profiles, $appointmentType);
            }

            $this->getMeta()->setCount(count($this->data));

            $response = new NonCachedJsonResponse();
            $response->setData(array('data' => $this->data));

            return $response;
        }
    }

    /**
     * @SWG\Api(
     *   @SWG\Operation(
     *     summary="Applies a profile on a treatment",
     *     method="PUT",
     *     type="\Medical\Treatment\Profile",
     *     @SWG\Parameter(name="id", type="integer", required=true, description="The id of the profile to apply"),
     *     @SWG\Parameter(name="treatmentId", type="integer", required=true, description="The id of the treatment to apply the profile on"),
     *     @SWG\Parameter(name="appointmentDate", type="date", required=false, description="The date of the appointment to apply the profile on"),
     *     @SWG\Parameter(name="performerId", type="integer", required=false, description="The id of the performer to apply the profile on")
     *   )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Actinidium\API\Response\NonCachedJsonResponse
     */
    public function updateAction(Request $request)
    {
        $appointmentDate = null;
        $performer = null;
        $id = $request->query->get('id');
        $data = json_decode($request->getContent(), true);
        $this->data = array();
        $addedActivities = array();
        $profile = $this->createEntity($id, 'id', $this->profileService, '\Medical\Treatment\Profile');

        $treatment = $this->createEntity(
            $data['treatmentId'],
            'treatmentId',
            $this->treatmentService,
            '\Medical\Treatment'
        );

        if ($data['performerId']) {
            $performer = $this->idToEmployeeTransformer->transform($data['performerId']);
        }

        if ($treatment instanceof Treatment &&
            null !== $profile &&
            !$this->authorizer->isApplyProfileAccessable($treatment)
        ) {
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, $this->messageHandler->getOne('UR3'));

            return $data;
        }

        if ($data['appointmentDate']) {
            $appointmentDate = $this->validateDate($data['appointmentDate'], "appointmentDate");
        } else {
            $performedDate = $this->getPerformedDate($data, $treatment);
        }

        if (!$this->hasError()) {
            $firstAddedActivity =  $this->applyProfileService->apply($treatment, $profile, $performer, $appointmentDate, $performedDate);
            if ($treatment->isMhcDbc()) {
                $errors = $this->applyProfileService->getValidationMessages();
                if ($errors) {
                    ValidationResult::addMessages($this, $errors);
                }
            } else {
                $this->addErrorToMeta();
            }

            $unfoldPhasesSetting = $this->settingService->read('unfold_phases_treatment_profile');
            $unfoldPhases = (bool) $unfoldPhasesSetting->getValue();
            $this->data['unfoldPhases'] = $unfoldPhases;

            $this->data['updatedPhases'] = $treatment->getPhasesList(true);
            if (true === $unfoldPhases) {
                // Always include no-phase to unfold.
                $this->data['updatedPhases'][]['id'] = null;
            }

            $this->data['firstAddedActivity'] = null;
            if ($firstAddedActivity && $firstAddedActivity->getId()) {
                $this->data['firstAddedActivity'] = $firstAddedActivity->toArray();
                $this->data['relatedForms'] = $this->emrService->hydrate($firstAddedActivity);
            }
        }

        $response = new NonCachedJsonResponse();
        $response->setData(array('data' => $this->data));

        $addedActivitiesCount = 0;
        foreach ($addedActivities as $newActivityType) {
            $addedActivitiesCount += count($newActivityType);
        }
        $this->getMeta()->setCount($addedActivitiesCount);
        return $response;
    }

    /**
     * Get performed date.
     *
     * @param array              $data
     * @param \Medical\Treatment $treatment
     *
     * @return \DateTime|null
     */
    private function getPerformedDate(array $data, Treatment $treatment)
    {
        if ($treatment->isSomatic()) {
            return null;
        }

        $dateString = isset($data['performedDate']) ? $data['performedDate'] : '';
        $performedDate = $this->validateDate($dateString, 'performedDate');
        if ($performedDate instanceof DateTime ) {
            $this->validatePastCertainDate(
                $performedDate->format('Y-m-d'),
                'performedDate',
                $treatment->getStartDate()->format('Y-m-d'),
                'TR-M2'
            );
        }

        return $performedDate;
    }

    /**
     * Add the errors we got from the service to the controller's Meta object.
     */
    private function addErrorToMeta()
    {
        ValidationResult::addMessages($this, $this->applyProfileService->getValidationMessages());
        DotValidationResult::addMessagesToMeta(
            $this->treatmentService->getLegacyValidationMessages(),
            $this->getMeta()
        );
    }

    /**
     * Will get profiles according to given params.
     *
     * @param   \Symfony\Component\HttpFoundation\ParameterBag $request
     * @param   int                                            $offset
     * @param   int                                            $limit
     * @param   boolean                                        $pagination
     *
     * @return  array
     */
    private function getProfiles(ParameterBag $request, $offset, $limit, $pagination = true)
    {
        $criteria = array();
        if (null != $request->get('search')) {
            $criteria['searchString'] = $this->validateSearchString($request->get('search'));
        }

        $criteria['active'] = true;
        if ($request->has('clinicId')) {
            try {
                $criteria['clinic'] = $this->idToClinicTransformer->transform($request->get('clinicId'));
                $criteria['typeOfCare'] = Profile::CARETYPE_MHC;
                $criteria['noBasis'] = true;
            } catch (TransformationFailedException $e) {
                $this->addInvalidInputMessageToMeta('clinicId', $request->get('clinicId'));
                return array();
            }
        }

        if ($request->get('treatmentId')) {
            $treatment = $this->validateTreatmentId($request->get('treatmentId'));
        }

        if ($treatment) {
            $criteria['treatmentType'] = $this->prepareTreatmentTypeCriteria($treatment->getTreatmentType());
            $criteria['clinic'] = $treatment->getClinic();
            $criteria['specialty'] = $treatment->getEpisode()->getSpecialty();
            $criteria['typeOfCare'] = ($treatment->isSomatic()) ? Profile::CARETYPE_SOMATIC : Profile::CARETYPE_MHC;

            if ($request->get('appointmentTypeId')) {
                $criteria['profileType'] = $this->prepareProfileTypeCriteria($treatment->getTreatmentType());
                unset($criteria['noBasis']);
            }

            if ($treatment->getTreatmentType() !== Treatment::TYPE_MHC_UNINSURED) {
                $criteria['insured'] = $treatment->isInsured();
            }
        }

        if (!$this->getMeta()->hasError()) {
            $orderBy['name'] = 'ASC';
            if ($pagination) {
                $result = $this->profileService->searchAllBy($criteria, $orderBy, $limit, $offset);
                $this->addPagination($offset, $limit, (int)$this->profileService->getTotalCount());
            } else {
                $result = $this->profileService->searchAllBy($criteria, $orderBy);
            }


            return $result;
        }

        return array();
    }

    /**
     * Will prepare data for GUI.
     *
     * @param array $profiles
     * @param \Calendar\Appointment\Type | null $appointmentType
     *
     * @return array
     */
    private function prepareProfilesForGUI($profiles, AppointmentType $appointmentType = null)
    {
        $data = array();
        foreach ($profiles as $profile) {
            $dataArray['id'] =  $profile->getId();
            $dataArray['name'] =  $profile->getName();
            $dataArray['type'] =  $this->translator->trans(
                $profile->getType(),
                array(),
                TranslatorFactory::TRANS_DOMAIN_MEDICAL
            );
            $dataArray['profileType'] = $profile->getType();
            if ($appointmentType) {
                $defaultProfileId = ($appointmentType->getProfile()) ? $appointmentType->getProfile()->getId() : null;
                $dataArray['isDefault'] =  ($defaultProfileId == $profile->getId()) ? true : false;
            }

            $data[] = $dataArray;
        }

        return $data;
    }

    /**
     * Validate Treatment Id.
     *
     * @param string $treatmentId
     *
     * @return null|\Medical\Treatment
     */
    protected function validateTreatmentId($treatmentId)
    {
        $treatment = $this->createEntity($treatmentId, 'treatmentId', $this->treatmentService, 'Medical\Treatment');

        return $treatment;
    }

    /**
     * Validate Search string provided.
     *
     * @param string $searchString
     *
     * @return null|string
     */
    private function validateSearchString($searchString)
    {
        if (Sanitizer::isEmpty($searchString)) {
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->add(
                    'MG01',
                    MessageHandler::BLOCKING,
                    array(
                        'list_of_fields' => 'search'
                    )
                )
            );
        }
        return $searchString;
    }

    /**
     * Will prepare treatmentType criteria for search.
     *
     * @param string $treatmentType
     *
     * @return string|array
     */
    private function prepareTreatmentTypeCriteria($treatmentType)
    {
        switch ($treatmentType) {
            case Treatment::TYPE_DBC:
            case Treatment::TYPE_FAKE_DBC:
            case Treatment::TYPE_ELP:
                return Treatment::TYPE_DBC;
                break;
            case Treatment::TYPE_BASIS_MHC:
                return Treatment::TYPE_BASIS_MHC;
            case Treatment::TYPE_PM:
                return array(Treatment::TYPE_PM, Treatment::TYPE_PROFILE);
                break;
            case Treatment::TYPE_TRANSACTION:
                return array(Treatment::TYPE_TRANSACTION, Treatment::TYPE_PROFILE);
                break;
            case Treatment::TYPE_PROFILE:
                return Treatment::TYPE_PROFILE;
                break;
            case Treatment::TYPE_MHC_UNINSURED:
                return array(Treatment::TYPE_PROFILE, Treatment::TYPE_DBC);
        }
    }

    /**
     * Will prepare profileType criteria for search.
     *
     * @param string $treatmentType
     *
     * @return string
     */
    function prepareProfileTypeCriteria($treatmentType)
    {
        switch ($treatmentType) {
            case Treatment::TYPE_DBC:
            case Treatment::TYPE_MHC_UNINSURED:
                return Profile::TYPE_SESSION;
                break;
            case Treatment::TYPE_BASIS_MHC:
                return Profile::TYPE_BASIC_MHC;
                break;
        }
    }
}
