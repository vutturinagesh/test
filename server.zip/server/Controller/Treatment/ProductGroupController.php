<?php

namespace Controller\Treatment;

use Controller\AbstractController;
use Controller\ValidationResult;
use Factory\TranslatorFactory;
use Generic\CustomerSettingsService;
use Medical\MHC\DbcService as MedicalMhcDbcService;
use Medical\TreatmentService;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/treatment",
 *     basePath="/api/v2"
 * )
 */
class ProductGroupController extends AbstractController
{
    /**
     * @var string
     */
    const INSURED = "insured";

    /**
     * @var string
     */
    const UNINSURED = "uninsured";

    /**
     * @var \Medical\TreatmentService
     */
    private $treatmentService;

    /**
     * @var \Medical\MHC\DbcService
     */
    private $mhcDbcService;

    /**
     * Constructor
     *
     * @param \Medical\TreatmentService $treatmentService
     * @param \Medical\MHC\DbcService   $medicalMhcDbcService
     */
    public function __construct(TreatmentService $treatmentService, MedicalMhcDbcService $medicalMhcDbcService)
    {
        parent::__construct();

        $this->treatmentService = $treatmentService;
        $this->mhcDbcService    = $medicalMhcDbcService;
    }

    /**
     * @SWG\Api(
     *   path="/treatment/productgroup",
     *   @SWG\Operation(
     *       method="GET",
     *       summary="Get the productGroup summary for a mhc treatment",
     *       @SWG\Parameter(
     *           name="id",
     *           description="Id of the treatment.",
     *           required=true,
     *           type="integer",
     *           paramType="query"
     *       )
     *   )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function getListAction(Request $request)
    {
        $treatment = $this->createEntity(
            $request->get('id'),
            'treatmentId',
            $this->treatmentService,
            'Medical\Treatment'
        );

        $response = new JsonResponse();

        if (null === $treatment) {
            return $response;
        }

        $endDate = $treatment->getEndDate() ? : CustomerSettingsService::getSystemDate();

        $productGroup = $this->mhcDbcService->determineAndSaveProductGroupCode($treatment, $endDate);
        $performances = $this->mhcDbcService->getPerformances($treatment);

        $dataInsured = $this->convertProductGroupDataForGui($productGroup);
        $dataInsured['subperformances'] = array();

        $data = array();
        if (array_key_exists('productcodeUninsured', $productGroup)) {
            $dataUninsured = $this->convertUninsuredProductGroupDataForGui($productGroup);
            $dataUninsured['subperformances'] = $this->convertPreformancesDataForGui($performances);
            $data[] = $dataUninsured;
        } else {
            $dataInsured['subperformances'] = $this->convertPreformancesDataForGui($performances);
        }

        array_unshift($data, $dataInsured);

        $response->setData(array('data' => $data));

        return $response;
    }

    /**
     * Convert the ProductGroup into gui data format.
     *
     * @param array $productGroup
     *
     * @return array
     */
    private function convertProductGroupDataForGui(array $productGroup)
    {
        return array(
            'type'                    => static::INSURED,
            'productGroupCode'        => $productGroup['productcode'],
            'productGroupDescription' => $productGroup['codeDescription'],
            'description'             => $productGroup['derivation'][0]['description'],
            'score'                   => $productGroup['derivation'][0]['value'],
        );
    }

    /**
     * Convert the Uninsured ProductGroup into gui data format.
     *
     * @param array $productGroup
     *
     * @return array
     */
    private function convertUninsuredProductGroupDataForGui(array $productGroup)
    {
        return array(
            'type'                    => static::UNINSURED,
            'productGroupCode'        => $productGroup['productcodeUninsured'],
            'productGroupDescription' => $productGroup['codeDescriptionUninsured'],
            'description'             => $productGroup['derivationUninsured'][0]['description'],
            'score'                   => $productGroup['derivationUninsured'][0]['value'],
        );
    }

    /**
     * Convert the Preformances into gui data format.
     *
     * @param array[] $preformances
     *
     * @return array[]
     */
    private function convertPreformancesDataForGui(array $preformances)
    {
        $data = array();
        foreach ($preformances as $key => $preformance) {
            $data[] = array(
                'code'            => $preformance['code'],
                'date'            => $preformance['datum'],
                'number'          => $preformance['aantal'],
                'declarationCode' => $preformance['declaratiecode'],
                'description'     => $preformance['omschrijving'],
            );
        }

        return $data;
    }
}
