<?php

namespace Controller\Treatment;

use Controller\AbstractController;
use Controller\LegacyMhcValidationResult;
use Controller\ValidationResult;
use Factory\TranslatorFactory;
use Medical\TreatmentService;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Validation\DotValidationResult;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/treatment",
 *     basePath="/api/v2"
 * )
 */
class ValidationController extends AbstractController
{
    /**
     * @var \Medical\TreatmentService
     */
    private $treatmentService;

    /**
     * Constructor.
     *
     * @param \Medical\TreatmentService $treatmentService
     */
    public function __construct(TreatmentService $treatmentService)
    {
        parent::__construct();
        
        $this->treatmentService = $treatmentService;
    }

    /**
     * @SWG\Api(
     *   path="/treatment/validation",
     *   @SWG\Operation(
     *       method="GET",
     *       summary="Validate a mhc treatment and return errors and warnings if any.",
     *       @SWG\Parameter(
     *           name="id",
     *           description="Id of the treatment.",
     *           required=true,
     *           type="integer",
     *           paramType="query"
     *       )
     *   )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function getListAction(Request $request)
    {
        $treatment = $this->createEntity(
            $request->get('id'),
            'treatmentId',
            $this->treatmentService,
            'Medical\Treatment'
        );

        $response = new JsonResponse();

        if (null === $treatment) {
            return $response;
        }

        $data = array();

        $this->treatmentService->validateMHC($treatment);
        $this->addToMeta();

        $response->setData(array('data' => $data));

        return $response;
    }

    /**
     * Add messages to meta
     */
    private function addToMeta()
    {
        ValidationResult::addMessages($this, $this->treatmentService->getValidationMessages());
        LegacyMhcValidationResult::addMessages($this, $this->treatmentService->getLegacyMHCValidationMessages());
    }
}
