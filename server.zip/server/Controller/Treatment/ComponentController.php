<?php

namespace Controller\Treatment;

use Controller\AbstractController;
use Medical\IdToTreatmentTransformer;
use Medical\MHC\Basic\ComponentService;
use Medical\MHC\Basic\IdToComponentTransformer;
use Symfony\Component\HttpFoundation\JsonResponse;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/treatment-component",
 *     basePath="/api/v2"
 * )
 */
class ComponentController extends AbstractController
{
    /** @var  \Medical\IdTotreatmentTransformer */
    private $idToTreatmentTransformer;

    /** @var  \Medical\MHC\Basic\ComponentService */
    private $componentService;

    /**
     * @param \Medical\IdToTreatmentTransformer   $idToTreatmentTransformer
     * @param \Medical\MHC\Basic\ComponentService $componentService
     */
    public function __construct(
        IdToTreatmentTransformer $idToTreatmentTransformer = null,
        ComponentService $componentService = null
    ) {
        parent::__construct();
        $this->idToTreatmentTransformer = $idToTreatmentTransformer;
        $this->componentService = $componentService;

        if (null === $this->idToTreatmentTransformer) {
            $this->idToTreatmentTransformer = $this->get('medicore.medical.id_to_treatment_transformer');
        }
        if (null === $this->componentService) {
            $this->componentService = $this->get('medicore.medical.basic.component_service');
        }

    }

    /**
     * @SWG\Api(
     *   path="/treatment-component?treatmentId={treatmentId}",
     *   @SWG\Operation(
     *       method="GET",
     *       summary="Retrieves valid treatment components",
     *       notes="Valid means where treatment.startdate is between componet.start- and enddate",
     *       @SWG\Parameter(name="treatmentId", type="integer", required=true),
     *   )
     * )
     *
     * This action is used to retrieve components for Basic MHC Treatments.
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function getListAction()
    {
        $response = new JsonResponse();
        $response->setPublic();
        $data = array();

        $treatmentId = $this->getRequest()->query->get('treatmentId');
        $this->isEntityIdEmpty($treatmentId, 'treatmentId');
        $this->isEntityIdPositiveInteger($treatmentId, 'treatmentId');
        try {
            $treatment = $this->idToTreatmentTransformer->transform($treatmentId);
        } catch (TransformationFailedException $e) {
            $this->addMessage(
                Meta::STATUS_ERROR,
                'GV9',
                array('object' => '\Medical\Treatment', 'input' => $treatmentId)
            );
        }
        if (!$this->hasError()) {
            $components = $this->componentService->findByTreatment($treatment);
            foreach ($components as $component) {
                $data[] = array(
                    'id' => $component->getId(),
                    'code' => $component->getCode(),
                    'description' => $component->getDescription()
                );
            }
        }
        $response->setData(array('data' => $data));
        $this->getMeta()->setCount(count($data));

        return $response;
    }
}
