<?php

namespace Controller\Treatment;

use Actinidium\API\Response\Meta;
use Controller\AbstractController;
use Controller\ValidationResult;
use DateTime;
use Generic\CustomerSettingsService;
use Generic\Specialism;
use Generic\SpecialismService;
use Generic\Validation\EventHandler;
use HL7\ObserverService;
use Medical\Somatic\Dbc;
use Medical\Somatic\DbcService;
use Medical\Somatic\DBC\Validation\Service as DbcValidationService;
use Medical\Treatment;
use Medical\TreatmentService;
use Patient\Field\ValidationService;
use System\Dbc\Characterization;
use System\Dbc\CharacterizationService;
use System\Icd10Service as SystemIcd10Service;
use Validation\DotValidationResult;

/**
 * Treatment DBC Controller.
 */
class DbcController extends AbstractController
{
    /**
     * @var \Medical\Treatment
     */
    private $id;

    /**
     * @var \Generic\SpecialismService
     */
    private $specialtyModel;

    /**
     * @var \System\Dbc\CharacterizationService;
     */
    private $systemDbcModel;

    /**
     * @var \Medical\Somatic\DbcService;
     */
    private $model;

    /**
     * @var \Medical\TreatmentService
     */
    private $treatmentModel;

    /**
     * @var \Medical\Somatic\Dbc
     */
    private $dbc;

    /**
     * @var \Medical\Treatment
     */
    private $treatment;

    /**
     * @var \Generic\Specialism;
     */
    private $specialty;

    /**
     * @var \Generic\Authorizer
     */
    private $authorizer;

    /**
     * @var \Medical\Somatic\DBC\Validation\Service
     */
    protected $validationService;

    /**
     * @var \System\Icd10Service
     */
    private $icd10Service;

    const EXPECTEDCAREPRODUCT = "expectedcareproduct";
    const DBCCODE = "dbccode";
    const ALL_DBC_CODE_COUNT = 3;
    const TREATMENT_REGISTER_DBC_CODES_CARE_TYPE = 'Treatment_RegisterDbcCodes_Caretype';
    const TREATMENT_REGISTER_DBC_CODES_CARE_REQUEST = 'Treatment_RegisterDbcCodes_Carerequest';
    const TREATMENT_REGISTER_DBC_CODES_DIAGNOSIS    = 'Treatment_RegisterDbcCodes_Diagnosis';
    const TREATMENT_REGISTER_DBC_CODES_ALL          = 'Treatment_RegisterDbcCodes';

    /**
     * Constructor.
     *
     * @param \Generic\Authorizer  $authorizer
     * @param \System\Icd10Service $icd10Service
     */
    public function __construct(
        Authorizer $authorizer = null,
        SystemIcd10Service $icd10Service = null
    ) {
        parent::__construct();
        $this->authorizer = $authorizer;
        $this->icd10Service = $icd10Service;

        $this->legacyInitDependencies();
    }

    /**
     * Legacy initialize dependencies.
     */
    private function legacyInitDependencies()
    {
        if (!$this->authorizer) {
            $this->authorizer = $this->get('medicore.generic.authorizer');
        }
        if (!$this->icd10Service) {
            $this->icd10Service = $this->get('medicore.system.icd10_service');
        }
    }

    /**
     * Get the validation service to use for validating input values.
     *
     * @return DbcValidationService
     */
    private function getValidationService()
    {
        if (!$this->validationService instanceof DbcValidationService) {
            $this->validationService = new DbcValidationService();
        }

        return $this->validationService;
    }

    /**
     * Get the list of DBC codes according to the passed criteria.
     *
     *  - with given date and specialty id  (or)
     *  - with given treatment id           (or)
     *  - no data given then with system date
     *
     * @return array
     */
    public function getListAction()
    {
        $order = array('componentcode' => 'ASC');
        $this->data = array();

        $criteria = $this->getCriteriaFromRequest();

        if (!$this->getMeta()->hasError()) {
            $dbcList = $this->getSystemDbcModel()->findAllBy($criteria, $order);
            $this->data = $this->prepareForGui($dbcList);
            $this->getMeta()->setCount(count($dbcList));
        }

        return $this->data;
    }

    /**
     * Process the data passed to the request and see what criteria will be passed.
     *
     * @return array
     */
    private function getCriteriaFromRequest()
    {
        $criteria = array();
        $treatment = null;

        $query = $this->getRequest()->query;
        if ($query->has('treatmentId')) {
            $treatmentModel = $this->getTreatmentModel();
            $treatment = $this->createEntity(
                $query->get('treatmentId'),
                'treatmentId',
                $treatmentModel,
                "Medical\\Treatment"
            );

            if (!$this->getMeta()->hasError()) {
                $criteria['validOn'] = $treatment->getDtStart();
                $criteria['specialty'] = $treatment->getSpecialist()->getSpecialism();
            }
        } elseif ($query->has('validOn') && $query->has('specialtyId')) {
            if ($query->get('validOn') == 'systemDate') {
                $criteria['validOn'] = CustomerSettingsService::getSystemDate();
            } else {
                if ($this->isRequired($query->get('validOn'), 'validOn')) {
                    $criteria['validOn'] = $this->validateDate($query->get('validOn'), 'validOn');
                }
            }

            $specialty = $this->createEntity(
                $query->get('specialtyId'),
                'specialtyId',
                $this->getSpecialtyModel(),
                "Generic\\Specialism"
            );

            if ($specialty) {
                $criteria['specialty'] = $specialty;
            }
        }

        if ($query->has('search')) {
            $criteria['search'] = $query->get('search');
        }

        if ($query->has('axis')) {
            $criteria['code'] = $query->get('axis');
        }

        if ($query->has('termId')) {
            $criteria['termId'] = $query->get('termId');

            if (null === $treatment || !array_key_exists('validOn', $criteria)) {
                $criteria['validOn'] = new DateTime();
            }
        }

        return $criteria;
    }

    /**
     * PUT request function.
     *
     * @param int   $id
     * @param mixed $data
     *
     * @return array
     */
    public function updateAction($id, $data)
    {
        $this->id = $id; //treatmentId, this is!
        $this->data = array();

        $this->processRequestData($data);

        $this->treatment = $this->getTreatment();

        if ($this->hasError()) {
            return $this->data;
        }
        if (null !== $this->treatment && !$this->authorizer->isTreatmentAccessable($this->treatment)) {
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne('EMPM102')
            );
            return $this->data;
        }

        if ($this->treatment->getDbcSomatic() === null) {
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne('TR-M17')
            );
            return $this->data;
        }

        $existingDbcCode = array();
        if (strtolower($this->getRequest()->get("action")) == self::DBCCODE) {
            if ($this->treatment->isSomatic() && $this->treatment->isDot()) {
                //Get the current code
                $existingDbcCode = $this->getExistingDbcCode();
            }
        }

        if ($this->getMeta()->hasError()) {
            return $this->data;
        }

        switch (strtolower($this->getRequest()->get("action"))) {
            case self::DBCCODE:
                $this->updateDbcCode($data, $existingDbcCode);
                break;
            default:
                break;
        }

        $validationResults = $this->getModel()->getMeta();
        DotValidationResult::addMessagesToMeta($validationResults, $this->getMeta());

        $errors = $this->getModel()->getErrors();
        if (! empty($errors)) {
            ValidationResult::addMessages($this, $errors);
        }

        if ($this->getMeta()->hasError()) {
            return $this->data;
        }

        $dbcData = $this->getDbc()->toArray();

        //next we need to evaluate if the care type supports any care requests. If none are supported for
        //we set the value for careRequest to false.
        $this->updateCareRequestForTreatment($dbcData);
        return $dbcData;
    }

    /**
     * Function to check if the careRequest should be disabled for a treatment.
     *
     * @param array $dbcData
     */
    private function updateCareRequestForTreatment(array $dbcData)
    {
        $treatment = $this->getDbc()->getTreatment();

        $searchParams = array(
            'validOn' => $treatment->getDtStart(),
            'specialty' => $treatment->getSpecialist()->getSpecialism(),
            'code' => Characterization::CARE_REQUEST_AXIS,
            'removeInactive' => true
        );

        //check the characterization service which care requests are present for the treatment.
        $characterizationService = $this->get('medicore.system.dbc.characterization_service');
        $careRequests = $characterizationService->findAllBy($searchParams);
        //if we get less than 1 carerequest we can disable it.
        $isCareRequestRequired = true;
        if (count($careRequests) < 1) {
            $isCareRequestRequired = false;
        }
        $dbcData['axes']['isCareRequestRequired'] = $isCareRequestRequired;
    }


    /**
     * Loop trough all the data in the request and check if it is supplied if it is mandatory.
     *
     * @param array $data
     */
    private function processRequestData(array $data = array())
    {
        $validationService = $this->getValidationService();
        $mandatoryFields = $validationService->getMandatoryFieldsForUpdate($data);

        if (!$this->hasError()) {
            $this->validateRequestData($data, $mandatoryFields);
        }
    }

    /**
     * Validate the data send in the request for valid input.
     *
     * @param array $data
     * @param array $mandatoryFields
     */
    private function validateRequestData(array $data = array(), array $mandatoryFields = array())
    {
        $validationService = $this->getValidationService();
        //loop trough the posted fields and retrieve all the validators which are required
        foreach ($data as $field => $value) {
            if ($this->requiresValidation($field, $value, $mandatoryFields) === true) {
                $validationService->validateInputValue($field, $value);
            }
        }

        if ($validationService->hasErrors()) {
            $this->addErrorsToMeta($validationService->getErrors());
        }
    }

    /**
     * @param $data
     * @param $existingDbcCode
     * @return array
     */
    protected function updateDbcCode($data, $existingDbcCode)
    {
        $dotValidationEvents =  array();

        if (isset($data["careTypeAxis"])) {
            $dotValidationEvents[] = EventHandler::EVENT_TR_E15_1;
        }

        if (isset($data["diagnosisAxis"])) {
            $dotValidationEvents[] = EventHandler::EVENT_TR_E15_2;
        }

        if (isset($data["careRequestAxis"])) {
            $dotValidationEvents[] = EventHandler::EVENT_TR_E15_3;
        }

        if (isset($data["treatmentAxis"])) {
            $this->validateTreatmentAxis($data["treatmentAxis"]);
        }

        if (isset($data["icd10"]) && !empty($data["icd10"])) {
            $this->validateIcd10($data["icd10"]);
        }

        $dbc = $this->getDbc();

        //Checking if the treatment is dbc treatment.
        if (!$this->getMeta()->hasError()) {
            $result = $this->getModel()->registerDBCCodes($dbc, $data, $dotValidationEvents);

            if ($result) {
                //After register the code , update triggers
                $this->registerHL7Triggers($data, $existingDbcCode);
            }
        }
    }

    /**
     * @param $treatmentAxis
     */
    protected function validateTreatmentAxis($treatmentAxis)
    {
        if (!$this->getModel()->isValidTreatment($this->getDbc(), $this->getSpecialty(), $treatmentAxis)) {
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, $this->messageHandler->getOne("M165"));
        }
    }

    /**
     * @param Dbc $dbc
     */
    public function setDbc(Dbc $dbc)
    {
        $this->dbc = $dbc;
    }

    /**
     * @param DbcService $model
     */
    public function setModel(DbcService $model)
    {
        $this->model = $model;
    }

    /**
     * @return DbcService
     */
    protected function getModel()
    {
        if (!$this->model) {
            $this->model = new DbcService();
        }
        return $this->model;
    }

    /**
     * @return Dbc
     */
    protected function getDbc()
    {
        if (!$this->dbc) {
            if (!$this->treatment) {
                return null;
            }

            /** @var Treatment $treatment */
            if (!$this->treatment->getDbcSomatic()) {
                $params = array(
                    "type" => "Medical\\Somatic\\Dbc",
                    "id" => $this->id
                );
                $this->getMeta()->addMessage(Meta::STATUS_ERROR, $this->messageHandler->getOne("M516", $params));
                return null;
            }
            $this->dbc = $this->treatment->getDbcSomatic();
        }

        return $this->dbc;
    }

    public function setTreatment(Treatment $treatment)
    {
        $this->treatment = $treatment;
    }

    /**
     * @return Treatment
     */
    protected function getTreatment()
    {
        if (!$this->treatment) {
            $this->treatment = $this->createEntity(
                $this->id,
                "id",
                $this->getTreatmentModel(),
                "Medical\\Treatment"
            );
        }

        return $this->treatment;
    }

    /**
     * @param Specialism $specialty
     */
    public function setSpecialty(Specialism $specialty)
    {
        $this->specialty = $specialty;
    }


    /**
     * @throws Exception if specialist or specialty is not present
     *
     * @return mixed
     */
    protected function getSpecialty()
    {
        if (!$this->specialty) {
            $specialist = $this->getTreatment()->getSpecialist();
            if (!$specialist) {
                throw new Exception("No specialist for treatment " . $this->getTreatment()->getId());
            }
            /** @var $specialist \Generic\Employee */
            $this->specialty = $specialist->getSpecialism();
            if (!$this->specialty) {
                throw new Exception(
                    "No specialty found for specialist "
                    . $specialist->getId() . ' for treatment '
                    . $this->getTreatment()->getId()
                );
            }
        }

        return $this->specialty;
    }

    /**
     * @return CharacterizationService
     */
    protected function getSystemDbcModel()
    {
        if (!$this->systemDbcModel) {
            $this->systemDbcModel = new CharacterizationService();
        }
        return $this->systemDbcModel;
    }

    /**
     * @return SpecialismService
     */
    protected function getSpecialtyModel()
    {
        if (!$this->specialtyModel) {
            $this->specialtyModel = new SpecialismService();
        }
        return $this->specialtyModel;
    }

    /**
     * @return TreatmentService
     */
    protected function getTreatmentModel()
    {
        if (!$this->treatmentModel) {
            $this->treatmentModel = new TreatmentService();
        }
        return $this->treatmentModel;
    }

    /**
     * Prepares data for GUI
     * @param array $list
     * @return array
     */

    private function prepareForGui($list)
    {
        $listArray = array();

        foreach ($list as $dbc) {
            /** @var $dbc Dbc */
            $summary = $dbc->toListArray();

            $careType = $dbc->getCareType();
            $group = $dbc->getGroup();

            $listArray[$careType][$group][] = $summary;
        }

        return $listArray;
    }

    /**
     * Register and notify HL7 Triggers
     *
     * @author Karuppachamy Shanmugavel <karuppachamy.shanmugavel@medicore.nl>
     * @param array $data
     * @param array $existingDbcCode

     * @return bool
     */
    private function registerHL7Triggers(array $data, array $existingDbcCode)
    {
        $observerService = $this->getObserverService();
        $eventLabel = array();
        if (count($existingDbcCode) > 0) {
            if (isset($data["careTypeAxis"]) && $existingDbcCode['careTypeAxis'] != $data["careTypeAxis"]) {
                $eventLabel[]  = self::TREATMENT_REGISTER_DBC_CODES_CARE_TYPE;
            }

            if (isset($data["careRequestAxis"]) && $existingDbcCode['careRequestAxis'] != $data["careRequestAxis"]) {
                $eventLabel[]  = self::TREATMENT_REGISTER_DBC_CODES_CARE_REQUEST;
            }

            if (isset($data["diagnosisAxis"]) && $existingDbcCode['diagnosisAxis'] != $data["diagnosisAxis"]) {
                $eventLabel[]  = self::TREATMENT_REGISTER_DBC_CODES_DIAGNOSIS;
            }
        }
        //Found any events need to be updated
        if ($eventLabel) {
            foreach ($eventLabel as $event) {
                $observerService->notify($event, $this->treatment);
            }
        }
        //Check if all the events updated, then notify 'ALL' event as well
        if (count($eventLabel) == self::ALL_DBC_CODE_COUNT) {
            $observerService->notify(self::TREATMENT_REGISTER_DBC_CODES_ALL, $this->treatment);
        }
    }

    /**
     * Get observer service
     *
     * @return \HL7\ObserverService
     */
    private function getObserverService()
    {
        return new observerService();
    }

    /**
     * Get already existing DBC codes before update
     *
     * @return array
     */
    private function getExistingDbcCode()
    {
        $existingDbcCode = array();
        try {
            $dbc = $this->getDbc();

            $existingDbcCode['careTypeAxis'] = $dbc->getDBCCareType();
            $existingDbcCode['careRequestAxis'] =  $dbc->getDBCCareRequest();
            $existingDbcCode['diagnosisAxis'] = $dbc->getDBCCareDiagnose();
        } catch (\Exception $e) {
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne('M170')
            );
        }

        return $existingDbcCode;
    }

    /**
     * Validate icd10 value.
     *
     * @param string $icd10
     */
    private function validateIcd10($icd10)
    {
        if (!$this->getModel()->isValidIcd10($icd10)) {
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, $this->messageHandler->getOne("TR-M16"));
        }
    }
}
