<?php

namespace Controller\Generic;

use Actinidium\API\MetaBaseController;
use Actinidium\API\Response\Meta;
use Actinidium\API\RestBaseController;
use Symfony\Component\HttpFoundation\Request;
use Actinidium\API\Response\CachedJsonResponse;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/generic",
 *     basePath="/api/v2"
 * )
 */
class GeneralPractitionerController extends RestBaseController
{
    /**
     * Holds the system care provider work relation service
     *
     * @var \Generic\SystemCareProviderWorkRelationService
     */
    protected $systemCareProviderService;

    /**
     * Holds the system care provider work relation service
     *
     * @var \Generic\SystemProviderService
     */
    protected $systemProviderService;

    /**
     * Get the system care provider object on demand
     *
     * @return \Generic\SystemCareProviderWorkRelationService
     */
    private function getSystemCareProviderService()
    {
        if (!($this->systemCareProviderService instanceof \Generic\SystemCareProviderWorkRelationService)) {
            $this->systemCareProviderService = new \Generic\SystemCareProviderWorkRelationService();
        }

        return $this->systemCareProviderService;
    }

    /**
     * Get the SystemProvider object on demand
     *
     * @return \Generic\SystemProviderService
     */
    private function getSystemProviderService()
    {
        if (!($this->systemProviderService instanceof \Generic\SystemProviderService)) {
            $this->systemProviderService = new \Generic\SystemProviderService();
        }

        return $this->systemProviderService;
    }

    /**
     * @SWG\Api(
     *   path="/generic-generalPractitioner",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Find general practitioner details",
     *           notes="Returns version",
     *           @SWG\Parameter(name="id", type="integer", required=true, paramType="query"),
     *       )
     * )
     *
     * @param Request $request
     *
     * @return CachedJsonResponse
     */
    public function getAction(Request $request)
    {
        $response = new CachedJsonResponse();

        $id = $request->query->get('id');

        try {
            $result = $this->getSystemCareProviderService()->getGeneralPractitionerDetails($id);
            if (count($result) == 0) {
                $this->getMeta()->addMessage(META::STATUS_ERROR, "No Records Found");
            } else {
                //The count is set one as always return by id returns only one
                $this->getMeta()->setCount(1);
                $response->setData(array('data' => $result));
            }
        } catch (\Exception $e) {
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, $e->getMessage());
        }
        return $response;
    }

    /**
     * @SWG\Api(
     *   path="/generic-generalPractitioner-list",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Find general practitioners",
     *           notes="Returns version",
     *           @SWG\Parameter(name="practiceId", type="integer", required=false, paramType="query"),
     *           @SWG\Parameter(name="name", type="string", required=false, paramType="query"),
     *       )
     * )
     *
     * @return CachedJsonResponse
     */
    public function getListAction()
    {
        $response = new CachedJsonResponse();

        $query = $this->getRequest()->query;

        if ($query->has('practiceId')) {
            $data['practiceId'] = $query->get('practiceId');

            try {
                $result = $this->getSystemCareProviderService()->getGeneralPractitionerByCareInstitution($data);
                if (count($result) == 0) {
                    $this->getMeta()->addMessage(META::STATUS_ERROR, "No Records Found");
                } else {
                    $this->getMeta()->setCount(count($result));
                    $response->setData(array('data' => $result));
                }
            } catch (\Exception $e) {
                $this->getMeta()->addMessage(Meta::STATUS_ERROR, $e->getMessage());
            }
        } else {
            $data['name'] = $query->get('name');

            try {
                $result = $this->getSystemProviderService()->searchGeneralPractitionerDetails($data);
                if (count($result) == 0) {
                    $this->getMeta()->addMessage(META::STATUS_ERROR, "No Records Found");
                } else {
                    $response->setData(array('data' => $result));
                }
            } catch (\Exception $e) {
                $this->getMeta()->addMessage(Meta::STATUS_ERROR, $e->getMessage());
            }
        }

        return $response;
    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::createAction()
     */
    public function createAction($data)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::deleteAction()
     */
    public function deleteAction($id)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::deleteListAction()
     */
    public function deleteListAction()
    {

        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::updateAction()
     */
    public function updateAction($id, $data)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * Added to set the SystemCareProviderWorkRelationService for phpunit
     *
     * @param \Generic\SystemCareProviderWorkRelationService $systemCareProviderService
     */
    public function setSystemCareProviderService(\Generic\SystemCareProviderWorkRelationService $systemCareProviderService)
    {
        $this->systemCareProviderService = $systemCareProviderService;
    }

    /**
     * Added to set the SystemProviderService for phpunit
     *
     * @param \Generic\SystemProviderService $systemProviderService
     */
    public function setSystemProviderService(\Generic\SystemProviderService $systemProviderService)
    {
        $this->systemProviderService = $systemProviderService;
    }
}
