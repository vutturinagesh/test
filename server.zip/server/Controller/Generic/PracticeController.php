<?php

namespace Controller\Generic;

use Actinidium\API\MetaBaseController;
use Actinidium\API\Response\Meta;
use Actinidium\API\RestBaseController;
use Actinidium\API\Response\CachedJsonResponse;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/generic",
 *     basePath="/api/v2"
 * )
 */
class PracticeController extends RestBaseController
{
    /**
     * Holds the system institution service
     *
     * @var \Generic\SystemInstitutionService
     */
    protected $systemInstitutionService;

    /**
     * Get the generic system institution object on demand
     *
     * @return \Generic\SystemInstitutionService
     */
    private function getSystemInstitutionService()
    {
        if (!($this->systemInstitutionService instanceof \Generic\SystemInstitutionService)) {
            $this->systemInstitutionService = new \Generic\SystemInstitutionService();
        }

        return $this->systemInstitutionService;
    }

    /**
     * Function used to set the SystemInstitution service.
     *
     * @param \Generic\SystemInstitutionService $systemInstitutionService
     */
    public function setSystemInstitutionService(\Generic\SystemInstitutionService $systemInstitutionService)
    {
        $this->systemInstitutionService = $systemInstitutionService;
    }

    /**
     * @SWG\Api(
     *   path="/generic-practice",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Find practice details",
     *           notes="Returns version",
     *           @SWG\Parameter(name="name", type="string", required=true, paramType="query"),
     *       )
     * )
     *
     * @return CachedJsonResponse
     */
    public function getListAction()
    {
        $response = new CachedJsonResponse();

        $query = $this->getRequest()->query;

        $data['name'] = $query->get('name');

        try {
            $result = $this->getSystemInstitutionService()->searchPracticeByCriteria($data);
            if (count($result) == 0) {
                $this->getMeta()->addMessage(META::STATUS_ERROR, "No Records Found");
            } else {
                $response->setData(array('data' => $result));
            }
        } catch (\Exception $e) {
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, $e->getMessage());
        }

        return $response;
    }

    /**
     * Get the practice details by id
     *
     * @see \Actinidium\API\RestBaseController::getAction()
     *
     * @param integer $id
     */
    public function getAction($id)
    {
       $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::createAction()
     */
    public function createAction($data)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::deleteAction()
     */
    public function deleteAction($id)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::deleteListAction()
     */
    public function deleteListAction()
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::updateAction()
     */
    public function updateAction($id, $data)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }
}
