<?php

namespace Controller\Generic;

use Actinidium\API\MetaBaseController;
use Actinidium\API\Response\Meta;
use Actinidium\API\RestBaseController;
use Actinidium\API\Response;
use EMR\External\FileResourceService;
use EMR\Field\FileService;
use Patient\Patient;
use Patient\PatientService;

/**
 * Class FileController
 */
class FileController extends RestBaseController
{
    /**
     * Holds the EMR FileService object.
     *
     * @var \EMR\Field\FileService
     */
    private $emrFileService;

    /**
     * Holds the Generic FileService Object.
     *
     * @var \Generic\FileService
     */
    private $fileService;

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::getAction()
     */
    public function getAction($id)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * Download file.
     *
     * @see \Actinidium\API\RestBaseController::getListAction()
     */
    public function getListAction()
    {
        $query = $this->getRequest()->query;
        return $this->downloadFile($query);
    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::createAction()
     */
    public function createAction($data)
    {
        return $this->uploadFile($data);
    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::deleteAction()
     */
    public function deleteAction($id)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::deleteListAction()
     */
    public function deleteListAction()
    {

        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::updateAction()
     */
    public function updateAction($id, $data)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * Returns the file based on fileKey and patientId.
     *
     * @param object $query
     *
     * @return string
     */
    private function downloadFile($query)
    {
        $this->getPatientById($query->get('patientId'));
        $documentDownload = $query->get('documentDownload');
        if (!$this->getMeta()->hasError()) {
            if ($documentDownload) {
                return $this->getFileService()->download($query->get('patientId'), $query->get('fileKey'));
            } else {
                $file = $this->getFileService()->getPathToFile($query->get('patientId'), $query->get('fileKey'));
                if (!is_array($file)) {
                    $this->setResponseType(Response::FILE);
                    return $file;
                }
            }
            $this->getMeta()->addMessage(Meta::STATUS_INFO, $file['errors']);
        }
    }

    /**
     * Upload file.
     *
     * @param array $data
     *
     * @return string
     */
    private function uploadFile($data)
    {
        $this->hasFileBeenUploaded();
        $this->getPatientById($data['patientId']);

        if (!$this->getMeta()->hasError()) {

            // Only validate for EMR
            if (array_key_exists('EMR', $data)) {
                if (array_key_exists('type', $data)) {
                    $fileResourceService = new FileResourceService();
                    $errors = $fileResourceService->validateUpload($data['type'], $_FILES);
                } else {
                    $errors[] = 'Mandatory parameter type not set.';
                }
                if (count ($errors) > 0) {
                    foreach ($errors as $error) {
                        $this->getMeta()->addMessage(Meta::STATUS_ERROR, $error);
                    }
                }
            }

            if (!$this->getMeta()->hasError()) {
                $uploadResults = $this->getFileService()->multiUpload($data['patientId']);
                return $uploadedFile[0][$uploadResults['fileKeyId']] = $uploadResults[0]['key'];
            }
        }
    }

    /**
     * Check if file is uploaded.
     */
    private function hasFileBeenUploaded()
    {
        if (count($_FILES) == 0) {
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, 'No file uploaded.');
        } elseif (count($_FILES) > 1) {
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, 'You can only upload one file at the time.');
        }
    }

    /**
     * Returns the Generic FileService object.
     *
     * @return \Generic\FileService
     */
    private function getFileService()
    {
        if (!($this->fileService instanceof \Generic\FileService)) {
            $this->fileService = new \Generic\FileService();
        }
        return $this->fileService;
    }

    /**
     * Return the patient object.
     *
     * @param integer $patientId
     *
     * @return \Patient\Patient
     */
    private function getPatientById($patientId)
    {
        $patientService = new PatientService();
        $patient = $patientService->findById($patientId);
        if ($patient instanceof Patient) {
            return $patient;
        }
        $this->getMeta()->addMessage(META::STATUS_ERROR, 'Invalid patient');
    }
}
