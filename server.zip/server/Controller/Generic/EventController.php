<?php
/**
 * Event Validation Api
 * Callable via /api/generic-event/:action
 * @author Paul Krijgsman <paul.krijgsman@medicore.nl>
 * @version 20130628
 *
 */
namespace Controller\Generic;

use Actinidium\API\MetaBaseController;
use Actinidium\API\Response\Meta;
use Message\MessageHandler;

class EventController extends MetaBaseController
{
    private $eventHandler;

    public function __construct()
    {
        $this->eventHandler = new \Validation\EventHandler();
    }


    /**
     * Get event by name
     *
     * Call this like: <url>/api/generic-event/by/name/<eventName>/<objectnameId>/<id>
     * 
     * @return type
     */
    public function testEventAction()
    {
        $this->data = null;

        $data = array(//'treatment' => new \Medical\Treatment(),
                      //'activity' => new \Medical\Activity(),
                      //'treatmentId' => 32333,
                      //'specialistId' => 123345,
                      //'performedDate' => new \DateTime(),
                      //'blaErrorException' => 'byPaul',
                      //'performer' => new \Generic\Employee(),
                      //'type' => 'dbc',
                      //'validReferrerValues' => array(1,2,3,4,5,6,7,8),
                      //'episodeId' => 2345,
                      //'episodeId' => 29843, // dbc somatic startdatum >= 2012-01-01 54 treatments
                      //'patientId' => 2208,
                      //'specialtyId' => 1,
                      //'specialtyId' => 8416,
                      //'careTypeCodes' => array(13, 21, 41, 51, 52),
                      'validReferrerValues' => array(1, 2, 3, 4, 5, 6, 7, 8),
                      'episodeId' => 32902,
                      //'patientId' => 2208,
                      //'specialtyId' => 1,
                      //'specialtyId' => 8416,
                     );

        $this->eventHandler->setEvent('testdotvalidationwithepisode');
        $this->eventHandler->setData($data);

        if($this->eventHandler->run()){
            $results = $this->eventHandler->getValidationsRun();
        } else {
            $results = $this->eventHandler->getErrors();
        }

        // for debug show also the givenData array woth values
        return array('givenData' => $data,
                     'validationResults' => $results);

        $this->data = $this->prepareEventForGUI($results);
        $this->getMeta()->setCount(99);

        return $this->data;
    }
}