<?php

namespace Controller\Generic;

use Actinidium\API\Response\Meta;
use Actinidium\API\RestBaseController;
use Symfony\Component\HttpFoundation\JsonResponse;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/banner",
 *     basePath="/api/v2"
 * )
 */
class BannerController extends RestBaseController
{
    /**
     * @SWG\Api(
     *   path="/get-latest",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Get the latest banner",
     *       )
     * )
     *
     * @return JsonResponse
     */
    public function getLatestAction()
    {
        $response = new JsonResponse();
        $em = $this->get('doctrine.orm.entity_manager');

        $banner = $em->getRepository('\Generic\Banner')->getLatest();

        $response->setData(array('data' => $banner));

        return $response;
    }
}
