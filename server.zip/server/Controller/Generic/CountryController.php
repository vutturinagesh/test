<?php

namespace Controller\Generic;

use Actinidium\API\MetaBaseController;
use Actinidium\API\Response\Meta;
use Actinidium\API\RestBaseController;
use Actinidium\API\Response\CachedJsonResponse;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/generic",
 *     basePath="/api/v2"
 * )
 */
class CountryController extends RestBaseController
{
    /**
     * Holds the system Country Service object
     *
     * @var \Generic\SystemCountryService
     */
    protected $systemCountryService;

    /**
     * Get the ssystem Country Service object on demand
     *
     * @return \Generic\SystemCountryService
     */
    private function getSystemCountryService()
    {
        if (!($this->systemCountryService instanceof \Generic\SystemCountryService)) {
            $this->systemCountryService = new \Generic\SystemCountryService();
        }

        return $this->systemCountryService;

    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::getAction()
     */
    public function getAction($id)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * @SWG\Api(
     *   path="/generic-country",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Find countries",
     *           notes="Returns countries",
     *       )
     * )
     *
     * @return CachedJsonResponse
     */
    public function getListAction()
    {
        $response = new CachedJsonResponse();

        try {
            $data = $this->getSystemCountryService()->getAll();
            if (count($data) == 0) {
                $this->getMeta()->addMessage(META::STATUS_ERROR, "No Records Found");
            } else {
                $this->getMeta()->setCount(count($data));
                $response->setData(array('data' => $data));
            }
        } catch (\Exception $e) {
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, $e->getMessage());
        }

        return $response;
    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::createAction()
     */
    public function createAction($data)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");

    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::deleteAction()
     */
    public function deleteAction($id)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::deleteListAction()
     */
    public function deleteListAction()
    {

        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::updateAction()
     */
    public function updateAction($id, $data)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }
}
