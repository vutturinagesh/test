<?php

namespace Controller;

use Actinidium\API\Response\Meta;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Generic\Clinic;
use Generic\ClinicService;
use Security\Sanitizer;
use System\MHC\Circuit;
use System\MHC\CircuitService;
use Swagger\Annotations as SWG;

/**
 * @SWG\Resource(
 *     apiVersion="1.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/circuit",
 *     basePath="/api"
 * )
 */
class CircuitController extends AbstractController
{
    /**
     * @var \DateTime
     */
    private $validOn = null;

    /**
     * @var Clinic
     */
    private $clinic = null;

    /**
     * @SWG\Api(
     *     path="/circuit/getlist",
     *     @SWG\Operation(
     *         summary="Find Circuits, all of them or filtered by clinic.",
     *         method="GET",
     *         type="Circuit",
     *         @SWG\Parameter(name="clinicId", type="integer", required=false, paramType="query"),
     *     )
     * )
     *
     * @return array
     */
    public function getListAction()
    {
        $data = array();
        $circuits = array();

        if ($this->getRequest()->query->has('validOn')) {
            $this->validOn = $this->validateDate($this->getRequest()->query->get('validOn'));
        }
        if ($this->getRequest()->query->has('clinicId')) {
            $this->clinic = $this->createEntity(
                $this->getRequest()->query->get('clinicId'),
                'clinicId',
                new ClinicService(),
                'Generic\Clinic'
            );
        }

        if ($this->hasError()) {
            return $data;
        }

        $circuitService = new CircuitService();

        if ($this->clinic && $this->validOn) {
            $circuits = $circuitService->findAllByClinicAndValidOn($this->clinic, $this->validOn);
        } elseif ($this->clinic) {
            $circuits = $circuitService->findAllByClinic($this->clinic);
        } elseif ($this->validOn) {
            $circuits = $circuitService->findAllValidOn($this->validOn);
        } else {
            $circuits = $circuitService->findAll();
        }

        if (!empty($circuits)) {
            foreach ($circuits as $circuit) {
                /**
                 * @var Circuit $circuit
                 */
                $data[] = $circuit->toListArray();
            }

        }

        $this->getMeta()->setCount(count($data));
        return $data;
    }

}
