<?php
namespace Controller\EMR;

use Actinidium\API\MetaBaseController;
use Actinidium\API\Response\Meta;
use Actinidium\API\RestBaseController;
use Controller\AbstractController;
use Security\Sanitizer;
use Symfony\Component\HttpFoundation\JsonResponse;
use EMR\Deduplication\DeduplicationService;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/EMR",
 *     basePath="/api/v2"
 * )
 */
class DeduplicationController extends AbstractController
{
    /** @var DeduplicationService */
    private $deduplicationService;

    /**
     * @param DeduplicationService $deduplicationService
     */
    public function __construct(DeduplicationService $deduplicationService)
    {
        $this->deduplicationService = $deduplicationService;
    }

    /**
     * @SWG\Api(
     *   path="/emr-Deduplication?id={masterpatientId}",
     *       @SWG\Operation(
     *           method="PUT",
     *           summary="Deduplicate the patient user forms",
     *           notes="Dedpulicates the patient user forms",
     *           @SWG\Parameter(name="id", type="integer", required=true),
     *           @SWG\Parameter(name="slavePatientId", type="integer", required=true),
     *           @SWG\Parameter(
     *               name="body",
     *               description="Deduplicates the patient user forms",
     *               required=true,
     *               type="\EMR\Deduplication",
     *               paramType="body",
     *               allowMultiple=true
     *           )
     *       )
     * )
     *
     * Update action for deduplication of the patient emr user forms.
     *
     * This action is used to deduplicate the emr user forms of the patients.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function updateAction(Request $request)
    {
        $data = array();
        $response = new JsonResponse();
        $deduplicationService = $this->deduplicationService;
        $masterPatientId = $request->query->get('id');
        $slavePatientId = $request->request->get('slavePatientId');
        $requestParameters = array (
            'masterPatientId' => $masterPatientId,
            'slavePatientId' => $slavePatientId
        );
        $mandatoryParameters = array('masterPatientId', 'slavePatientId');
        $validationRules = array(
            'masterPatientId' => 'isPositiveInteger',
            'slavePatientId' => 'isPositiveInteger'
        );
        Validator::mandatoryValidation($mandatoryParameters, $requestParameters);
        Validator::validate($validationRules, $requestParameters);
        $validatorErrors = Validator::getErrors();

        if (!empty($validatorErrors)) {
            $this->getMeta()->addMessage(META::STATUS_ERROR, $validatorErrors);
            $response->setData(array('data' => $data));
        }

        try {
            if (!$this->getMeta()->hasError()) {
                $data = $deduplicationService->deduplicateForms(
                    $masterPatientId,
                    $slavePatientId
                );
                $this->getMeta()->setCount(count($data));
                $response->setData(array('data' => $data));
            }
        } catch (\Exception $e) {
            $this->getMeta()->addMessage(META::STATUS_ERROR, $e->getMessage());
            $response->setData(array('data' => $data));
        }

        return $response;
    }
}
