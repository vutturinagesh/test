<?php

namespace Controller\EMR;

use Actinidium\API\MetaBaseController;
use Actinidium\API\Response\Meta;
use Actinidium\API\RestBaseController;
use Security\Sanitizer;
use Symfony\Component\HttpFoundation\Request;
use Actinidium\API\Response\CachedJsonResponse;
use Symfony\Component\HttpFoundation\JsonResponse;
use Controller\AbstractController;
use Exception;
use Message\MessageHandler;
use EMR\Form\TemplateService;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/EMR",
 *     basePath="/api/v2"
 * )
 */
class TemplateFormController extends AbstractController
{
    /**
     * Holds the object of EMR templateFormService.
     *
     * @var \EMR\Form\TemplateService
     */
    protected $templateService;

    /**
     * Instantiate the controller with all its dependencies.
     *
     * @param \EMR\Form\TemplateService $templateService
     */
    public function __construct(TemplateService $templateService)
    {
        $this->templateService = $templateService;
    }

    /**
     * @SWG\Api(
     *   path="/EMR/templateForm",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Returns all the template forms by criteria.",
     *           notes="Get all the template forms by criteria",
     *           @SWG\Parameter(
     *              name="deleted",
     *              description="deleted value of form",
     *              type="boolean",
     *              required=false,
     *              paramType="query"
     *           ),
     *           @SWG\Parameter(
     *              name="active",
     *              description="active value of form",
     *              type="boolean",
     *              required=false,
     *              paramType="query"
     *           ),
     *           @SWG\Parameter(
     *              name="developmentLines",
     *              description="if development lines forms to be retrieved give boolean value.",
     *              type="boolean",
     *              required=false,
     *              paramType="query"
     *           ),
     *           @SWG\Parameter(
     *              name="background",
     *              description="if background forms needs to be retrieved give a boolean value.",
     *              type="boolean",
     *              required=false,
     *              paramType="query"
     *           ),
     *           @SWG\Parameter(
     *              name="contentHoldingNodes",
     *              description="if the nodes values are needed use this parameter",
     *              type="boolean",
     *              required=false,
     *              paramType="query"
     *           ),
     *           @SWG\Parameter(
     *              name="templateFormUuid",
     *              description="The template form uuid id needed only when teh content holding nodes data is needed",
     *              type="string",
     *              required=false,
     *              paramType="query"
     *           ),
     *          @SWG\Parameter(
     *              name="category",
     *              description="Different categories in an array for which template forms are to be fetched",
     *              type="array",
     *              @SWG\Items("string"),
     *              paramType="query",
     *              required=false
     *           ),
     *           @SWG\ResponseMessage(
     *              code=200,
     *              message="json {messages => 'user_messages', data => 'template forms'}"
     *           )
     *      )
     * )
     *
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function getListAction(Request $request = null)
    {
        $response = new JsonResponse();
        $query = $request->query;
        $requestParameters = $query->all();

        if ($query->has('contentHoldingNodes') && $query->has('templateFormUuid')) {
            $result = $this->getContentHoldingNodes($query->get('templateFormUuid'));
            $response->setData(array('data' => $result));
        } else {
            try {
                $formData = $this->getByCriteria($requestParameters);
                if (!$this->getMeta()->hasError()) {
                    //set count
                    $this->getMeta()->setCount(count($formData));
                    $response->setData(array('data' => $formData));
                }
            } catch (Exception $e) {
                $this->logException($e);
                $this->getMeta()->addMessage(
                    Meta::STATUS_ERROR,
                    $this->messageHandler->add(
                        'MG21',
                        MessageHandler::BLOCKING
                    )
                );
            }
        }

        return $response;
    }

    /**
     * Returns an array with all data holding nodes of a template.
     *
     * @param string $templateFormUuid
     *
     * @return array
     */
    private function getContentHoldingNodes($templateFormUuid)
    {
        try {
            $nodes = $this->templateService->getContentHoldingNodes($templateFormUuid);
            $this->getMeta()->setCount(count($nodes));
            return $nodes;
        } catch (Exception $e) {
            $this->logException($e);
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->add(
                    'MG21',
                    MessageHandler::BLOCKING
                )
            );
        }

    }

    /**
     * This is put in a separate method so we can mock it in phpunit
     * @param array $criteria
     * @return array
     */
    protected function getByCriteria(array $criteria)
    {
        try {
            $formData = $this->templateService->getAll($criteria);
            return $formData;
        } catch (Exception $e) {
            $this->logException($e);
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->add(
                    'MG21',
                    MessageHandler::BLOCKING
                )
            );
        }
    }
}
