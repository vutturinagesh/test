<?php
namespace Controller\EMR\XML;

use Actinidium\API\Response\Meta;
use Symfony\Component\HttpFoundation\Request;
use Actinidium\API\Response\NonCachedJsonResponse;
use Controller\AbstractController;
use EMR\Xml\ExportService;
use Exception;
use EMR\Transformer\IdToTemplateFormTransformer;
use Symfony\Component\Form\Exception\TransformationFailedException;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/EMR/XML",
 *     basePath="/api/v2"
 * )
 */
class ExportController extends AbstractController
{
    /**
     * Export service.
     *
     * @var \EMR\Xml\ExportService
     */
    private $exportService;

    /**
     * Id to template transformer.
     *
     * @var \EMR\Transformer\IdToTemplateFormTransformer
     */
    private $idToTemplateFormTransformer;

    /**
     * Constructor.
     *
     * @param \EMR\Xml\ExportService $exportService
     * @param \EMR\Transformer\IdToTemplateFormTransformer $idToTemplateFormTransformer
     */
    public function __construct(ExportService $exportService, IdToTemplateFormTransformer $idToTemplateFormTransformer)
    {
        $this->exportService = $exportService;
        $this->idToTemplateFormTransformer = $idToTemplateFormTransformer;
    }

    /**
     * @SWG\Api(
     *   path="/api/v2/EMR/XML/Export/{id}",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Exports xml string with the template form id.",
     *           notes="Exports xml string with the template form id.",
     *           @SWG\Parameter(
     *              name="id",
     *              description="Template Form id.",
     *              type="integer",
     *              required=false,
     *              paramType="query"
     *           ),
     *            @SWG\ResponseMessage(
     *              code=200,
     *              message="json {messages => 'user_messages', data => 'string'}"
     *           )
     *      )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     * @param integer $id
     *
     * @return \Actinidium\API\Response\NonCachedJsonResponse
     */
    public function exportAction(Request $request, $id)
    {
        $response = new NonCachedJsonResponse();
        $responseData = array();
        try {
            $template = $this->idToTemplateFormTransformer->transform($id);
            $xml = $this->exportService->export($template);
            $this->exportToFile($xml);
        } catch (TransformationFailedException $e) {
            $this->getMeta()->addMessage(META::STATUS_ERROR, $e->getMessage());
        } catch (Exception $e) {
            $this->getMeta()->addMessage(META::STATUS_ERROR, $e->getMessage());
        }

        $response->setData(array('data' => $responseData));

        return $response;
    }

    /**
     * Export to file.
     *
     * @param string $xml
     */
    protected function exportToFile($xml)
    {
        header('Content-Disposition: attachment; filename="sample.xml"');
        header('Content-Type: text/xml');
        header('Content-Length: ' . strlen($xml));
        header('Connection: close');
        echo $xml;
        exit();
    }
}