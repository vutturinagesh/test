<?php
/**
 * MCIS
 *
 * @package EMR
 */

namespace Controller\EMR\XML;

use Actinidium\API\Response\Meta;
use EMR\Xml\ImportService;
use EMR\Transformer\IdToXmlSourceTransformer;
use Symfony\Component\HttpFoundation\Request;
use Actinidium\API\Response\NonCachedJsonResponse;
use Controller\AbstractController;
use Exception;
use Symfony\Component\Form\Exception\TransformationFailedException;
use Controller\EMR\Validator;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/EMR/XML",
 *     basePath="/api/v2"
 * )
 */
class ImportController extends AbstractController
{
    /**
     * Holds object of xml service
     *
     * @var \EMR\Xml\ImportService
     */
    protected $importService;

    /**
     * Id to xml source transformer.
     *
     * @var \EMR\Transformer\IdToXmlSourceTransformer
     */
    private $idToXmlSourceTransformer;

    /**
     * Constructor.
     *
     * @param \EMR\Xml\ImportService $exportService
     * @param \EMR\Transformer\IdToTemplateFormTransformer $idToTemplateFormTransformer
     */
    public function __construct(ImportService $importService, IdToXmlSourceTransformer $idToXmlSourceTransformer)
    {
        $this->importService = $importService;
        $this->idToXmlSourceTransformer = $idToXmlSourceTransformer;
    }

    /**
     * @SWG\Api(
     *   path="/EMR/XML/Import/{id}",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Creates template form by xml source id",
     *           notes="Creates template form by xml source id",
     *           @SWG\Parameter(
     *              name="id",
     *              description="xml source id.",
     *              type="integer",
     *              required=false,
     *              paramType="query"
     *           ),
     *            @SWG\ResponseMessage(
     *              code=200,
     *              message="json {messages => 'user_messages', data => 'string'}"
     *           )
     *      )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     * @param integer $id
     *
     * @return \Actinidium\API\Response\NonCachedJsonResponse
     */
    public function createTemplateByXmlSourceIdAction(Request $request, $id)
    {
        $response = new NonCachedJsonResponse();
        
        try {
            $xmlSource = $this->idToXmlSourceTransformer->transform($id);
            $data = $this->importService->createTemplateFormByXmlSource($xmlSource);
        } catch (TransformationFailedException $e) {
            $this->getMeta()->addMessage(META::STATUS_ERROR, $e->getMessage());
        } catch (Exception $e) {
            $this->getMeta()->addMessage(META::STATUS_ERROR, $e->getMessage());
        }
        $response->setData(array('data' =>  $data));

        return $response;
    }

    /**
     * @SWG\Api(
     *   path="/EMR/XML/Import",
     *       @SWG\Operation(
     *           method="POST",
     *           summary="Creates template form by xml string",
     *           notes="Creates template form by xml string",
     *           @SWG\Parameter(
     *              name="xml",
     *              description="xml string.",
     *              type="string",
     *              required=false,
     *              paramType="body"
     *           ),
     *            @SWG\ResponseMessage(
     *              code=200,
     *              message="json {messages => 'user_messages', data => 'string'}"
     *           )
     *      )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Actinidium\API\Response\NonCachedJsonResponse
     */
    public function createTemplateByXmlStringAction(Request $request)
    {
        $response = new NonCachedJsonResponse();
        $data = json_decode($request->getContent(), true);
        $responseData = array();
        $mandatoryParameters = array('xml');
        Validator::mandatoryValidation($mandatoryParameters, $data);
        $errorMessages = Validator::getErrors();

        //check whether there is any error in the meta data
        if (is_array($errorMessages) && count($errorMessages) > 0) {
            return $this->getMeta()->addMessage(Meta::STATUS_ERROR, $errorMessages);
        }

        try {
            $responseData = $this->importService->createTemplateFormByXmlString($data['xml']);
        } catch (TransformationFailedException $e) {
            $this->getMeta()->addMessage(META::STATUS_ERROR, $e->getMessage());
        } catch (Exception $e) {
            $this->getMeta()->addMessage(META::STATUS_ERROR, $e->getMessage());
        }
        $response->setData(array('data' =>  $responseData));

        return $response;
    }
}
