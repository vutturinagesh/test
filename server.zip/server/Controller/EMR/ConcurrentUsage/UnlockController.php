<?php

namespace Controller\EMR\ConcurrentUsage;

use Actinidium\API\Response\Meta;
use Controller\EMR\Validator;
use Security\Sanitizer;
use Symfony\Component\Form\Exception\TransformationFailedException;
use Symfony\Component\HttpFoundation\Request;
use Actinidium\API\Response\NonCachedJsonResponse;
use Controller\AbstractController;
use Exception;
use EMR\ConcurrentUsage\UnlockService;
use EMR\Transformer\IdToUserFormTransformer;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/EMR",
 *     basePath="/api/v2"
 * )
 */
class UnlockController extends AbstractController
{
    /**
     * Holds unlock service object.
     *
     * @var \EMR\ConcurrentUsage\UnlockService
     */
    protected $unlockService;

    /**
     * Holds unlock service object.
     *
     * @var IdToUserFormTransformer $idToUserFormTransformer
     */
    protected $idToUserFormTransformer;

    /**
     * Instantiate the controller with all its dependencies.
     *
     * @param UnlockService $unlockService
     * @param idToFormTransformer $idToFormTransformer
     */
    public function __construct(UnlockService $unlockService, IdToUserFormTransformer $idToUserFormTransformer)
    {
        $this->unlockService = $unlockService;
        $this->idToUserFormTransformer = $idToUserFormTransformer;
    }

    /**
     * @SWG\Api(
     *   path="/api/v2/EMR/ConcurrentUsage/Unlock/UserForm/{userFormId}",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="unlocks the passed formId for the logged in User",
     *           notes="unlocks the passed formId for the logged in User",
     *           @SWG\Parameter(
     *              name="userFormId",
     *              description="Id of the user form.",
     *              type="integer",
     *              required=false,
     *              paramType="query"
     *           ),
     *            @SWG\ResponseMessage(
     *              code=200,
     *              message="json {messages => 'user_messages', data => 'user forms'}"
     *           )
     *      )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     * @param int $userFormId
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function unlockSpecificUserFormAction(Request $request, $userFormId)
    {
        $response = new NonCachedJsonResponse();
        try {
            $userForm = $this->idToUserFormTransformer->transform($userFormId);
            $data = $this->unlockService->unlockSpecificUserForm($userForm);
         } catch (TransformationFailedException $e) {
            $this->getMeta()->addMessage(META::STATUS_ERROR, $e->getMessage());

            return $response;
         } catch (Exception $e) {
            $this->getMeta()->addMessage(META::STATUS_ERROR, $e->getMessage());
        }
        $response->setData(array('data' => array('formUnlocked'=> (bool) $data)));

        return $response;
    }

    /**
     * @SWG\Api(
     *   path="/api/v2/EMR/ConcurrentUsage/Unlock/exceptUserForm/{exceptUserFormId}",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="unlocks all forms for the logged in User except the passed formId",
     *           notes="unlocks all forms for the logged in User except the passed formId",
     *           @SWG\Parameter(
     *              name="exceptUserFormId",
     *              description="Id of the user form which we do not want to delete.",
     *              type="integer",
     *              required=false,
     *              paramType="query"
     *           ),
     *            @SWG\ResponseMessage(
     *              code=200,
     *              message="json {messages => 'user_messages', data => 'user forms'}"
     *           )
     *      )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     * @param int $exceptUserFormId
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function unlockUserFormsExceptSpecificUserFormsAction(Request $request, $exceptUserFormId)
    {
        $response = new NonCachedJsonResponse();
        try {
            $exceptUserForm = $this->idToUserFormTransformer->transform($exceptUserFormId);
            $data = $this->unlockService->unlockUserFormsExceptSpecificUserForms($exceptUserForm);
        } catch (TransformationFailedException $e) {
            $this->getMeta()->addMessage(META::STATUS_ERROR, $e->getMessage());

            return $response;
        } catch (Exception $e) {
            $this->getMeta()->addMessage(META::STATUS_ERROR, $e->getMessage());
        }
        $response->setData(array('data' => array('formUnlocked'=> (bool) $data)));

        return $response;
    }

    /**
     * @SWG\Api(
     *   path="/api/v2/EMR/ConcurrentUsage/Unlock",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="unlocks all forms for the logged in User",
     *           notes="unlocks all forms for the logged in User",
     *            @SWG\ResponseMessage(
     *              code=200,
     *              message="json {messages => 'user_messages', data => 'user forms'}"
     *           )
     *      )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function unlockAction(Request $request)
    {
        $response = new NonCachedJsonResponse();
        try {
            $data = $this->unlockService->unlock();
        } catch (Exception $e) {
            $this->getMeta()->addMessage(META::STATUS_ERROR, $e->getMessage());
        }
        $response->setData(array('data' => array('unlocked'=> (bool) $data)));

        return $response;
    }
}
