<?php

namespace Controller\EMR\ConcurrentUsage;

use Actinidium\API\Response\Meta;
use Symfony\Component\HttpFoundation\Request;
use Actinidium\API\Response\NonCachedJsonResponse;
use Controller\AbstractController;
use Exception;
use EMR\ConcurrentUsage\ConcurrentUsageService;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/EMR",
 *     basePath="/api/v2"
 * )
 */
class LockedCountController extends AbstractController
{
    /**
     * Concurrent usage service.
     *
     * @var EMR\ConcurrentUsage\ConcurrentUsageService ConcurrentUsageService
     */
    protected $concurrentUsageService;

    /**
     * Instantiate the controller with all its dependencies.
     *
     * If some are not injected fetch them from the container.
     */
    public function __construct(ConcurrentUsageService $concurrentUsageService)
    {
        $this->concurrentUsageService = $concurrentUsageService;
    }

    /**
     * @SWG\Api(
     *   path="/EMR/ConcurrentUsage/LockedCount",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Retrieve total user forms locked by the employee",
     *           notes="Retrieve total user forms locked by the employee",
     *            @SWG\ResponseMessage(
     *              code=200,
     *              message="json {messages => 'user_messages', data => 'user forms'}"
     *           )
     *      )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function getAction(Request $request)
    {
        $query = $request->query;
        $response = new NonCachedJsonResponse();

        if (!$this->getMeta()->hasError()) {
            try {
                $formCount['count'] = $this->concurrentUsageService->getCount();
                $this->getMeta()->setCount($formCount);
            } catch (Exception $e) {
                $this->getMeta()->addMessage(META::STATUS_ERROR, $e->getMessage());
            }
            $response->setData(array('data' =>  $formCount));

            return $response;
        }
    }
}
