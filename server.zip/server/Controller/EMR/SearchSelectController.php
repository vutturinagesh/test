<?php

namespace Controller\EMR;

use Actinidium\API\Response\Meta;
use Controller\AbstractController;
use EMR\Field\Option\Dynamic;
use EMR\Transformer\UuidToNodeTransformer;
use Symfony\Component\HttpFoundation\JsonResponse;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/EMR",
 *     basePath="/api/v2"
 * )
 */
class SearchSelectController extends AbstractController
{
    /**
     * @var \EMR\Transformer\UuidToNodeTransformer
     */
    private $uuidToNodeTransformer;

    /**
     * @param UuidToNodeTransformer $uuidToNodeTransformer
     */
    public function __construct(UuidToNodeTransformer $uuidToNodeTransformer)
    {
        parent::__construct();
        $this->uuidToNodeTransformer = $uuidToNodeTransformer;
    }

    /**
     * @SWG\Api(
     *   path="/EMR",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Retrieve searchselect options",
     *           notes="Returns array of searchselect options.",
     *           @SWG\Parameter(
     *              name="Uuid",
     *              description="uuid of the emr queryoption node.",
     *              type="integer",
     *              paramType="query",
     *              required=true
     *           )
     *       )
     * )
     *
     * @param int $uuid
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse|void
     */
    public function getAction($uuid)
    {
        $response = new JsonResponse();
        $data = array();
        try {
            $node = $this->uuidToNodeTransformer->transform($uuid);

            if ($node instanceof Dynamic) {
                $data = $node->getOptions();
            } else {
                throw new \Exception('Given uuid does not belong to a dynamic searchselect field');
            }

        } catch (\Exception $e) {
            $this->getMeta()->addMessage(META::STATUS_ERROR, $e->getMessage());
        }

        $response->setData(array('data' => $data));

        return $response;
    }
}
