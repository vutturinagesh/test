<?php

namespace Controller\EMR\UserForm;

use Actinidium\API\MetaBaseController;
use Actinidium\API\Response\Meta;
use Actinidium\API\RestBaseController;
use Security\Sanitizer;
use Symfony\Component\HttpFoundation\Request;
use Actinidium\API\Response\NonCachedJsonResponse;
use EMR\UserForm\TreatmentService;
use Exception;
use Message\MessageHandler;
use Controller\AbstractController;
use Medical\IdToTreatmentTransformer;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/EMR",
 *     basePath="/api/v2"
 * )
 */
class TreatmentController extends AbstractController
{
    /**
     * Holds EMR UserForm TreatmentService object.
     *
     * @var \EMR\UserForm\TreatmentService
     */
    protected $treatmentService;

    /**
     * Holds Treatment transformer.
     *
     * @var  \Medical\IdToTreatmentTransformer
     */
    private $idToTreatmentTransformer;

    /**
     * Instantiate the controller with all its dependencies.
     *
     * If some are not injected fetch them from the container.
     *
     * @param \EMR\UserForm\TreatmentService $treatmentService
     * @param \Medical\IdToTreatmentTransformer $idToTreatmentTransformer
     */
    public function __construct(TreatmentService $treatmentService, IdToTreatmentTransformer $idToTreatmentTransformer) {
        parent::__construct();
        $this->treatmentService = $treatmentService;
        $this->idToTreatmentTransformer = $idToTreatmentTransformer;
    }

    /**
     * @SWG\Api(
     *   path="/EMR/userForm",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Returns all the user forms by criteria.",
     *           notes="Get all the user forms by criteria.",
     *           @SWG\Parameter(
     *              name="treatment",
     *              description="The identifier of the treatment",
     *              type="integer",
     *              required=false,
     *              paramType="query"
     *           ),
     *            @SWG\ResponseMessage(
     *              code=200,
     *              message="json {messages => 'user_messages', data => 'user forms'}"
     *           )
     *      )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     * @param int $treatmentId
     *
     * @return Actinidium\API\Response\NonCachedJsonResponse
     */
    public function getListAction(Request $request, $treatmentId)
    {
        $response = new NonCachedJsonResponse();

        try {
            $treatment = $this->idToTreatmentTransformer->transform($treatmentId);

            // Get the list of user forms
            $userFormData = $this->treatmentService->getAllUserFormsWithinTreatment($treatment);
            if (!$this->getMeta()->hasError()) {
                $this->getMeta()->setCount(count($userFormData));
                $response->setData(array('data' => $userFormData));
            }
        } catch (Exception $e) {
            $this->logException($e);
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->add(
                    'MG21',
                    MessageHandler::BLOCKING
                )
            );
        }

        return $response;
    }
}
