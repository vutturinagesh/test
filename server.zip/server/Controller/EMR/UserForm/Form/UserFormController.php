<?php

namespace Controller\EMR\UserForm\Form;

use Actinidium\API\Response\Meta;
use Controller\EMR\Validator;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Controller\AbstractController;
use EMR\Form\FormService;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/EMR",
 *     basePath="/api/v2"
 * )
 */
class UserFormController extends AbstractController
{
    /**
     * Holds EMR form service object.
     *
     * @var \EMR\Form\FormService
     */
    protected $formService;

    /**
     * Instantiate the controller with all its dependencies.
     *
     * If some are not injected fetch them from the container.
     *
     * @param \EMR\Form\FormService $formService
     */
    public function __construct(FormService $formService = null)
    {
        parent::__construct();

        if (null === $this->formService) {
            $formService = $this->get('medicore.emr.form.form_service');
        }

        $this->formService = $formService;
    }

    /**
     * @SWG\Api(
     *   path="/EMR/UserForm/Form",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Retrieve fields and data(for user forms) of selected user form.",
     *           notes="Returns array of fields and data.",
     *           @SWG\Parameter(
     *              name="id",
     *              description="id of the user form",
     *              type="integer",
     *              required=true,
     *              paramType="query"
     *           ),
     *           @SWG\Parameter(
     *              name="patientId",
     *              description="patient Id of form",
     *              type="integer",
     *              required=true,
     *              paramType="query"
     *           ),
     *           @SWG\Parameter(
     *              name="templateFormId",
     *              description="id of the template form.",
     *              type="integer",
     *              required=true,
     *              paramType="query"
     *           ),
     *            @SWG\ResponseMessage(
     *              code=200,
     *              message="json {messages => 'user_messages', data => 'user forms'}"
     *           )
     *      )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function getListAction(Request $request)
    {
        $query = $request->query;
        $response = new JsonResponse();

        $requestParameters = $query->all();
        $mandatoryParameters = array('id', 'patientId', 'templateFormId');
        $validationRules = array(
            'id' => 'isPositiveInteger',
            'patientId' => 'isPositiveInteger',
            'templateFormId' => 'isPositiveInteger'
        );

        Validator::mandatoryValidation($mandatoryParameters, $requestParameters);
        Validator::validate($validationRules, $requestParameters);
        $errorMessages = Validator::getErrors();

        //check whether there is any error in the meta data
        if (is_array($errorMessages) && count($errorMessages) > 0) {
            foreach ($errorMessages as $errorMessage) {
                $this->getMeta()->addMessage(Meta::STATUS_ERROR, $errorMessage);
            }
        }

        if (!$this->getMeta()->hasError()) {
            try {
                $id = $requestParameters['id'];
                $patientId = $query->get('patientId');
                $templateFormId = $query->get('templateFormId');
                $data = $this->formService->getForm($id, $patientId, $templateFormId);
            } catch (\Exception $e) {
                $this->getMeta()->addMessage(META::STATUS_ERROR, $e->getMessage());
            }
            $response->setData(array('data' =>  $data));
        }

        return $response;
    }
}
