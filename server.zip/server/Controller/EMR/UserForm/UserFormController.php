<?php

namespace Controller\EMR\UserForm;

use Actinidium\API\MetaBaseController;
use Actinidium\API\Response\Meta;
use Actinidium\API\RestBaseController;
use Security\Sanitizer;
use Symfony\Component\HttpFoundation\Request;
use Actinidium\API\Response\CachedJsonResponse;
use Symfony\Component\HttpFoundation\JsonResponse;
use Exception;
use Message\MessageHandler;
use Controller\AbstractController;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/EMR",
 *     basePath="/api/v2"
 * )
 */
class UserFormController extends AbstractController
{
    /**
     * Holds EMR UserService object.
     *
     * @var \EMR\Form\UserService
     */
    protected $userService;

    /**
     * @SWG\Api(
     *   path="/EMR/userForm",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Returns all the user forms by criteria.",
     *           notes="Get all the user forms by criteria.",
     *           @SWG\Parameter(
     *              name="deleted",
     *              description="deleted value of form",
     *              type="boolean",
     *              required=true,
     *              paramType="query"
     *           ),
     *           @SWG\Parameter(
     *              name="active",
     *              description="active value of form",
     *              type="boolean",
     *              required=true,
     *              paramType="query"
     *           ),
     *           @SWG\Parameter(
     *              name="patientId",
     *              description="patient id pof the user whose form is to be retrieved",
     *              type="integer",
     *              required=true,
     *              paramType="query"
     *           ),
     *           @SWG\Parameter(
     *              name="templateFormUuid",
     *              description="uuid of the template form",
     *              type="string",
     *              required=true,
     *              paramType="query"
     *           ),
     *           @SWG\Parameter(
     *              name="categoryIdentifier",
     *              description="The identifier of the category",
     *              type="integer",
     *              required=false,
     *              paramType="query"
     *           ),
     *           @SWG\Parameter(
     *              name="category",
     *              description="category name attached to the template form",
     *              type="string",
     *              required=false,
     *              paramType="query"
     *           ),
     *            @SWG\ResponseMessage(
     *              code=200,
     *              message="json {messages => 'user_messages', data => 'user forms'}"
     *           )
     *      )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function getListAction(Request $request)
    {
        $response = new JsonResponse();
        $requestParameters = $request->query->all();
        $errorMessages = $this->validateRequest($requestParameters);

        $categoryIdentifier = (isset($requestParameters['categoryIdentifier'])) ? $requestParameters['categoryIdentifier'] : null;
        $category = (isset($requestParameters['category'])) ? $requestParameters['category'] : null;

        $deleted = Sanitizer::boolean($requestParameters['deleted']);
        $active = Sanitizer::boolean($requestParameters['active']);

        //check whether there is any error in the meta data
        if (is_array($errorMessages) && count($errorMessages) <= 0) {
            try {
                // Get the list of user forms
                $userFormData = $this->getUserFormsByCriteria(
                    $deleted,
                    $active,
                    $requestParameters['patientId'],
                    $requestParameters['templateFormUuid'],
                    $categoryIdentifier,
                    $category
                );
                if (!$this->getMeta()->hasError()) {
                    //set count
                    $this->getMeta()->setCount(count($userFormData));
                    //return the array of data
                    $response->setData(array('data' => $userFormData));
                }
            } catch (Exception $e) {
                $this->logException($e);
                $this->getMeta()->addMessage(
                    Meta::STATUS_ERROR,
                    $this->messageHandler->add(
                        'MG21',
                        MessageHandler::BLOCKING
                    )
                );
            }
        } else {
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, $errorMessages);
        }

        return $response;
    }

    /**
     * Return userforms by criteria.
     *
     * @param bool $deleted
     * @param bool $active
     * @param integer $patientId
     * @param integer $templateFormUuid
     * @param integer $categoryIdentifier
     * @param string $category
     *
     * @return array
     */
    protected function getUserFormsByCriteria(
        $deleted,
        $active,
        $patientId,
        $templateFormUuid,
        $categoryIdentifier,
        $category
    ) {
        try {
            // Get the list of user forms
            $userFormData = $this->get('medicore.emr.form.user_service')->getUserFormsByCriteria(
                $deleted,
                $active,
                $patientId,
                $templateFormUuid,
                $categoryIdentifier,
                $category
            );
            return $userFormData;
        } catch (Exception $e) {
            $this->logException($e);
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->add(
                    'MG21',
                    MessageHandler::BLOCKING
                )
            );
        }
    }


    /**
     * Validates the given inputs and check that they are boolean.
     *
     * @param array $inputParameters
     *
     * @return array
     */
    private function validateRequest(array $inputParameters)
    {
        $messages = array();
        if (count($inputParameters) == 0) {
            return $messages;
        }

        foreach ($inputParameters as $parameter => $parameterValue) {
            switch ($parameter) {
                case 'deleted':
                case 'active':
                    if (Sanitizer::isBoolean($parameterValue) === false) {
                        $messages[] = 'Invalid parameter value for '. $parameter;
                    }
                    break;
                case 'categoryIdentifier':
                case 'patientId':
                    if (Sanitizer::isPositiveInteger($parameterValue) === false) {
                        $messages[] = 'Invalid parameter value for '. $parameter;
                    }
                    break;
                case 'category':
                case 'templateFormUuid':
                    if (Sanitizer::isValidString($parameterValue) === false) {
                        $messages[] = 'Invalid parameter value for '. $parameter;
                    }
                    break;
            }
        }

        return $messages;
    }
}
