<?php

namespace Controller\EMR\UserForm;

use Security\Sanitizer;
use Symfony\Component\HttpFoundation\Request;
use Actinidium\API\Response\NonCachedJsonResponse;
use Exception;
use Message\MessageHandler;
use Controller\AbstractController;
use Actinidium\API\Response\Meta;
use EMR\Form\UserService;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/EMR",
 *     basePath="/api/v2"
 * )
 */
class CountController extends AbstractController
{
    /**
     * Holds EMR UserService object.
     *
     * @var \EMR\Form\UserService
     */
    protected $userService;

    /**
     * Instantiate the controller with all its dependencies.
     */
    public function __construct(UserService $userService)
    {
        parent::__construct();
        $this->userService = $userService;
    }

    /**
     * @SWG\Api(
     *   path="/EMR/userForm",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Returns all the user forms for all templateforms.",
     *           notes="Get all the user forms by criteria.",
     *           @SWG\Parameter(
     *              name="patient",
     *              description="patient id of the user whose count of form is to be retrieved",
     *              type="integer",
     *              required=true,
     *              paramType="query"
     *           ),
     *            @SWG\ResponseMessage(
     *              code=200,
     *              message="json {messages => 'user_messages', data => 'user forms'}"
     *           )
     *      )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return Actinidium\API\Response\NonCachedJsonResponse
     */
    public function getAllListAction(Request $request, $patientId)
    {
        $response = new NonCachedJsonResponse();

        try {
            $userFormCountData = $this->userService->getCount($patientId);
            $this->getMeta()->setCount(count($userFormCountData));
            $response->setData(array('data' => array('count' => $userFormCountData)));
        } catch (Exception $e) {
            $this->logException($e);
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->add(
                    'MG21',
                    MessageHandler::BLOCKING
                )
            );
        }

        return $response;
    }

    /**
     * @SWG\Api(
     *   path="/EMR/userForm",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Returns all the user forms by template form uuid.",
     *           notes="Get all the user forms by criteria.",
     *           @SWG\Parameter(
     *              name="patient",
     *              description="patient id of the user whose count of form is to be retrieved",
     *              type="integer",
     *              required=true,
     *              paramType="query"
     *           ),
     *           @SWG\Parameter(
     *              name="templateFormUuid",
     *              description="uuid of the template form",
     *              type="string",
     *              required=true,
     *              paramType="query"
     *           ),
     *            @SWG\ResponseMessage(
     *              code=200,
     *              message="json {messages => 'user_messages', data => 'user forms'}"
     *           )
     *      )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return Actinidium\API\Response\NonCachedJsonResponse
     */
    public function getListByTemplateFormUuidAction(Request $request, $patientId, $templateFormUuid)
    {
        $response = new NonCachedJsonResponse();

        try {
            $userFormCountData = $this->userService->getCountForTemplateForm($patientId, $templateFormUuid);
            $this->getMeta()->setCount(count($userFormCountData));
            $response->setData(array('data' => array('count' => $userFormCountData)));
        } catch (Exception $e) {
            $this->logException($e);
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->add(
                    'MG21',
                    MessageHandler::BLOCKING
                )
            );
        }

        return $response;
    }
}
