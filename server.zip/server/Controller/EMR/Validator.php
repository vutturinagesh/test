<?php
namespace Controller\EMR;

use Security\Sanitizer;

class Validator
{
    /**
     * Holds the errors of the validator.
     *
     * @var array;
     */
    public static $errors= array();

    /**
     * Validate the inputs.
     *
     * @param array $validationRules
     * @param array $requestParameters
     */
    public static function validate(array $validationRules, array $requestParameters)
    {
        foreach ($validationRules as $validationInput => $validationRule) {
            if (Sanitizer::$validationRule($requestParameters[$validationInput]) === false) {
                self::$errors[] = 'Invalid input for '.$validationInput;
            }
        }
    }

    /**
     * Validate Mandatory inputs.
     *
     * @param array $mandatoryInputs
     */
    public static function mandatoryValidation(array $mandatoryInputs, array $requestParameters)
    {
        foreach ($mandatoryInputs as $mandatoryInput) {
            if (!array_key_exists($mandatoryInput, $requestParameters) || is_null($requestParameters[$mandatoryInput])) {
                self::$errors[] = 'The request is invalid! mandatory parameter '. $mandatoryInput .' not given';
            }
        }
    }

    /**
     * Get the errors from the validator.
     */
    public static function getErrors()
    {
        return self::$errors;
    }
}
