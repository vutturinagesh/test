<?php

namespace Controller\EMR;

use Actinidium\API\RestBaseController;
use Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Actinidium\API\Response\Meta;
use Actinidium\API\Response\CachedJsonResponse;
use Actinidium\API\MetaBaseController;
use Exception;
use Message\MessageHandler;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/EMR",
 *     basePath="/api/v2"
 * )
 */
class ProcessStepController extends AbstractController
{
    /**
     * @SWG\Api(
     *   path="/EMR/processStep",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Get list of process steps in emr",
     *           notes="Process steps of emr are returned",
     *           @SWG\ResponseMessage(
     *              code=200,
     *              message="json {messages => 'user_messages', data => 'process steps'}"
                )
     *      )
     * )
     *
     * @return JsonResponse
     */
    public function getListAction()
    {
        $response = new JsonResponse();
        try {
            $result = $this->get('medicore.emr.processstep.processstep_service')->getAll();
            $this->getMeta()->setCount(count($result));
            $response->setData(array('data' => $result));
        } catch (Exception $e) {
            $this->logException($e);
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->add(
                    'MG21',
                    MessageHandler::BLOCKING
                )
            );

        }

        return $response;
    }
}
