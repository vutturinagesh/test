<?php
/**
 * MCIS
 *
 * @package EMR
 */

namespace Controller\EMR;

use Actinidium\API\MetaBaseController;
use Actinidium\API\Response\Meta;
use Actinidium\API\RestBaseController;

/**
 * FormCategoryIdentifierController
 *
 * Callable via /api/EMR-FormCategoryIdentifier
 *
 * @package     EMR\Form
 */
class FormCategoryIdentifierController extends RestBaseController
{
    /**
     * Holds object of  EMR Formservice
     *
     * @var \EMR\Form\FormService
     */
    protected $formService;

    /**
     * Get the Emr form service object on demand
     *
     * @return \EMR\Form\FormService
     */
    private function getFormService()
    {
        if (!($this->formService instanceof \EMR\Form\FormService)) {
            $this->formService = new \EMR\Form\FormService();
        }
        return $this->formService;
    }

    /**
     * (non-PHPdoc)
     *
     * @see \Actinidium\API\RestBaseController::getAction()
     */
    public function getAction($id)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * (non-PHPdoc)
     *
     * @see \Actinidium\API\RestBaseController::getListAction()
     */
    public function getListAction()
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * (non-PHPdoc)
     *
     * @see \Actinidium\API\RestBaseController::createAction()
     */
    public function createAction($data)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * (non-PHPdoc)
     *
     * @see \Actinidium\API\RestBaseController::deleteAction()
     */
    public function deleteAction($id)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * (non-PHPdoc)
     *
     * @see \Actinidium\API\RestBaseController::deleteListAction()
     */
    public function deleteListAction()
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * (non-PHPdoc)
     *
     * @see \Actinidium\API\RestBaseController::updateAction()
     */
    public function updateAction($id, $data)
    {
        $query = $this->getRequest()->request;

        $id = $query->get('id');
        $categoryIdentifier = $query->get('categoryIdentifier');

        try {
            // Attach the category Identifier
            $category = $this->getFormService()->attachCategoryIdentifier($id, $categoryIdentifier);
            return $category;
        } catch (\Exception $e) {
            $this->getMeta()->addMessage(META::STATUS_ERROR, $e->getMessage());
        }
    }
}
