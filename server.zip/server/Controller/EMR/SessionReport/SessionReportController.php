<?php

namespace Controller\EMR\SessionReport;

use Actinidium\API\Response\Meta;
use Controller\AbstractController;
use EMR\SessionReport\SessionReportService;
use Exception;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use EMR\Form\User;
use Symfony\Component\HttpFoundation\JsonResponse;
use EMR\Exception\VerslagTemplateFormNotFoundException;

/**
 * Class SessionReportController
 */
class SessionReportController extends AbstractController
{
    /**
     * @var \EMR\SessionReport\SessionReportService $sessionReportService
     */
    private $sessionReportService;

    /**
     * @param \EMR\SessionReport\SessionReportService $sessionReportService
     */
    public function __construct(SessionReportService $sessionReportService)
    {
        parent::__construct();
        $this->sessionReportService = $sessionReportService;
    }

    /**
     * @SWG\Api(
     *   path="/EMR/SessionReport",
     *       @SWG\Operation(
     *           method="POST",
     *           summary="Create a new verslag user form from Session report data.",
     *           notes="called from calendar session report pane.",
     *          @SWG\Parameter(
     *              name="patientId",
     *              description="Id of the patient.",
     *              type="integer",
     *              paramType="body",
     *              required=true
     *           ),
     *          @SWG\Parameter(
     *              name="date",
     *              description="date of session report.",
     *              type="date",
     *              paramType="body",
     *              required=true
     *           ),
     *          @SWG\Parameter(
     *              name="report",
     *              description="text of session report.",
     *              type="string",
     *              paramType="body",
     *              required=true
     *           ),
     *          @SWG\Parameter(
     *              name="performer",
     *              description="performer object with properties, id and name",
     *              type="object",
     *              paramType="body",
     *              required=true
     *           ),
     *          @SWG\Parameter(
     *              name="category",
     *              description="category object with propeties, identifier and name",
     *              type="object",
     *              paramType="body",
     *              required=true
     *           )
     *       )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse|void
     */
    public function createAction(Request $request)
    {
        $requestBody = $request->getContent();
        $response = new JsonResponse();

        try {
            $data = json_decode($requestBody);

            $resultantForm = $this->sessionReportService->transformSessionReportToVerslagForm(
                $data->patientId,
                $data->date,
                $data->performer,
                $data->report,
                $data->category
            );

            if (!$resultantForm instanceof User) {
                $this->getMeta()->addMessage(META::STATUS_ERROR, $resultantForm);

                return $response;
            } else {
                $response->setData(array('data' =>  'success'));
            }

        } catch (VerslagTemplateFormNotFoundException $e) {
            $this->getMeta()->addMessage(META::STATUS_ERROR, $e->getMessage());
        } catch (Exception $e) {
            $this->getMeta()->addMessage(META::STATUS_ERROR, $e->getMessage());
        }

        return $response;
    }
}
