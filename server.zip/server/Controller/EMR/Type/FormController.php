<?php
namespace Controller\EMR\Type;

use Actinidium\API\MetaBaseController;
use Actinidium\API\Response\Meta;
use Actinidium\API\RestBaseController;
use Controller\AbstractController;
use Security\Sanitizer;
use Actinidium\API\Response\CachedJsonResponse;
use Symfony\Component\HttpFoundation\JsonResponse;
use EMR\Type\TypeService;
use EMR\Form\FormService;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/EMR",
 *     basePath="/api/v2"
 * )
 */
class FormController extends AbstractController
{
    /**
     * Holds object of  EMR TypeService.
     *
     * @var \EMR\Type\TypeService
     */
    protected $typeService;

    /**
     * Holds the form service.
     *
     * @var \EMR\Form\FormService
     */
    protected $formService;

    /**
     * Instantiate the controller with all its dependencies.
     *
     * @param \EMR\Type\TypeService $typeService
     * @param \EMR\Form\FormService $formService
     */
    public function __construct(TypeService $typeService, FormService $formService)
    {
        $this->typeService = $typeService;
        $this->formService = $formService;
    }

    /**
     * Get the Emr type service object on demand.
     *
     * @param string $type name of the type
     *
     * @return \EMR\Type\TypeService
     */
    private function getTypeService($type)
    {
        $genericTypeService = $this->typeService;
        return $genericTypeService::getInstance($type);
    }

    /**
     * @SWG\Api(
     *   path="/EMR-Type-Form",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Find emr type form by criteria",
     *           notes="Returns emr type form",
     *           @SWG\Parameter(name="type", type="string", required=true, paramType="query"),
     *           @SWG\Parameter(name="categoryIdentifier", type="integer", required=false, paramType="query"),
     *       )
     * )
     *
     * @return JsonResponse
     */
    public function getListAction()
    {
        $formData = array();
        $response = new JsonResponse();

        $requestParameters = $this->getRequest()->query->all();
        $query = $this->getRequest()->query;
        $type = $query->get('type');
        $categoryIdentifier = $query->get('categoryIdentifier');
        $errorMessages = $this->validateRequest($requestParameters);

        if (is_array($errorMessages) && count($errorMessages) <= 0) {
            try {
                $typeService = $this->getTypeService($type);
                $typeService->setFormService($this->formService);
                $formData = $typeService->getLatestForm($categoryIdentifier);
                $response->setData(array('data' => $formData));
            } catch (\Exception $e) {
                $formData = array();
                $this->getMeta()->addMessage(META::STATUS_ERROR, $e->getMessage());
                $response->setData(array('data' => $formData));
            }
        } else {
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, $errorMessages);
        }
        if (!$this->getMeta()->hasError()) {
            $this->getMeta()->setCount(1);
            $response->setData(array('data' => $formData));
        }
        return $response;
    }

    /**
     * Validates the given inputs.
     *
     * @param array $inputParameters
     *
     * @return array
     */
    private function validateRequest(array $inputParameters)
    {
        $messages = array();
        if (count($inputParameters) == 0) {
            $messages[] = 'No input parameters given';
            return $messages;
        }
        if (array_key_exists('type', $inputParameters) === false) {
            $messages[] = 'type not given';
            return $messages;
        }
        foreach ($inputParameters as $parameter => $parameterValue) {
            switch ($parameter) {
                case 'categoryIdentifier':
                    if (Sanitizer::isPositiveInteger($parameterValue) === false) {
                        $messages[] = 'Invalid parameter value for '. $parameter;
                    }
                    break;
                case '_':
                case 'type':
                    if (Sanitizer::isValidString($parameterValue) === false) {
                        $messages[] = 'Invalid parameter value for '. $parameter;
                    }
                    break;
                default:
                    $messages[] = 'Invalid parameters given';
                    break;
            }
        }
        return $messages;
    }
}
