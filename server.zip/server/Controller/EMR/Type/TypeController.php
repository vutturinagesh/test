<?php

namespace Controller\EMR\Type;

use Actinidium\API\MetaBaseController;
use Actinidium\API\Response\Meta;
use Actinidium\API\RestBaseController;
use Security\Sanitizer;
use Actinidium\API\Response\CachedJsonResponse;
use Symfony\Component\HttpFoundation\JsonResponse;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/EMR",
 *     basePath="/api/v2"
 * )
 */
class TypeController extends RestBaseController
{
    /**
     * Holds object of  EMR TypeService
     *
     * @var \EMR\Type\TypeService
     */
    protected $typeService;

    /**
     * Get the Emr type service object on demand
     *
     * @return \EMR\Type\TypeService
     */
    private function getTypeService()
    {
        if (!($this->typeService instanceof \EMR\Type\TypeService)) {
            $this->typeService = new \EMR\Type\TypeService();
        }
        return $this->typeService;
    }

    /**
     * Get the Emr form service object on demand
     *
     * @return \EMR\Form\FormService
     */
    private function getFormService()
    {
        if (!($this->formService instanceof \EMR\Form\FormService)) {
            $this->formService = new \EMR\Form\FormService();
        }
        return $this->formService;
    }

    /**
     * Get type of a userform
     *
     * @see \Actinidium\API\RestBaseController::getAction()
     */
    public function getAction($id)
    {
        $requestParameters = $this->getRequest()->query->all();
        $errorMessages = $this->validateRequest($requestParameters);

        //check whether there is any error in the meta data
        if (is_array($errorMessages) && count($errorMessages) <= 0) {
            try {
                // get the type
                $objType = $this->getTypeService()->getType($id);
                return $objType->toArray();
            } catch (\Exception $e) {
                $this->getMeta()->addMessage(META::STATUS_ERROR, $e->getMessage());
            }
        } else {
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, $errorMessages);
        }
    }

    /**
     * @SWG\Api(
     *   path="/EMR-Type-Type",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Find emr type type by criteria",
     *           notes="Returns emr type type",
     *           @SWG\Parameter(name="name", type="string", required=false, paramType="query"),
     *           @SWG\Parameter(name="parentId", type="integer", required=false, paramType="query"),
     *       )
     * )
     *
     * @return JsonResponse
     */
    public function getListAction()
    {
        $data = array();
        $response = new JsonResponse();

        $requestParameters = $this->getRequest()->query->all();
        $errorMessages = $this->validateRequest($requestParameters);

        //check whether there is any error in the meta data
        if (is_array($errorMessages) && count($errorMessages) <= 0) {
            try {
                $name = array_key_exists('name', $requestParameters) ? $requestParameters['name'] : null;
                $parent_id = array_key_exists('parent_id', $requestParameters) ? $requestParameters['parent_id'] : null;
                // list types
                $typesCollection = $this->getTypeService()->listTypes($name, $parent_id);
                foreach ($typesCollection as $type) {
                    $data[$type->getId()] = $type->getName();
                }
            } catch (\Exception $e) {
                $this->getMeta()->addMessage(META::STATUS_ERROR, $e->getMessage());
            }
        } else {
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, $errorMessages);
        }

        if (!$this->getMeta()->hasError()) {
            $this->getMeta()->setCount(count($data));
            $response->setData(array('data' => $data));
        }

        return $response;
    }

    /**
     * (non-PHPdoc)
     *
     * @see \Actinidium\API\RestBaseController::createAction()
     */
    public function createAction($data)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * (non-PHPdoc)
     *
     * @see \Actinidium\API\RestBaseController::deleteAction()
     */
    public function deleteAction($id)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * (non-PHPdoc)
     *
     * @see \Actinidium\API\RestBaseController::deleteListAction()
     */
    public function deleteListAction()
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * Attach type to a userform.
     * This action is not yet used.
     *
     * @see \Actinidium\API\RestBaseController::updateAction()
     */
    public function updateAction($userFormId, $data)
    {
        try {
            // attach the type
            return $this->getTypeService()->attachType($userFormId, $data['typeId']);
        } catch (\Exception $e) {
            $this->getMeta()->addMessage(META::STATUS_ERROR, $e->getMessage());
        }

    }

    /**
     * Validates the given inputs and check that they are boolean.
     *
     * @param array $inputParameters
     *
     * @return array
     */
    private function validateRequest(array $inputParameters)
    {
        $messages = array();
        if (count($inputParameters) == 0) {
            return $messages;
        }

        foreach ($inputParameters as $parameter => $parameterValue) {
            switch ($parameter) {
                case 'name':
                    if (Sanitizer::isValidString($parameterValue) === false) {
                        $messages[] = 'Invalid parameter value for '. $parameter;
                    }
                    break;
                case 'parent_id':
                case 'id':
                    if (Sanitizer::isPositiveInteger($parameterValue) === false) {
                        $messages[] = 'Invalid parameter value for '. $parameter;
                    }
                    break;
                case 'default':
                    $messages[] = 'Invalid parameter '. $parameter;
                    break;
            }
        }

        return $messages;
    }
}
