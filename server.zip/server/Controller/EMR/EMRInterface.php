<?php
/**
 * MCIS
 */

namespace Controller\EMR;

/**
 * EmrInterface will be used as a contract between EMR and other modules
 * Purpose of this interface to avoid direct accees of EMR forms 
 */
interface EMRInterface
{
    /**
     * Get the form service object on demand
     *
     * @return \EMR\Form\FormService
     */
    public function getFormService();
    
    /**
     * Set the form service
     *
     * @param \EMR\Form\FormService $formService
     */
    public function setFormService(\EMR\Form\FormService $formService);
}
