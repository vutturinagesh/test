<?php
namespace Controller\EMR\Category;

use Actinidium\API\MetaBaseController;
use Actinidium\API\Response\Meta;
use Actinidium\API\RestBaseController;
use Controller\AbstractController;
use EMR\Form\CategoryService;
use Controller\EMR\Validator;
use Symfony\Component\HttpFoundation\JsonResponse;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/EMR",
 *     basePath="/api/v2"
 * )
 */
class FormController extends AbstractController
{
    /**
     * Holds object of  EMR CategoryService.
     *
     * @var \EMR\Form\CategoryService
     */
    protected $categoryService;

    /**
     * Holds the request parameters.
     *
     * @var array
     */
    protected $requestParameters;

    /**
     * Instantiate the controller with all its dependencies.
     *
     * If some are not injected fetch them from the container.
     *
     * @param \EMR\Form\CategoryService $categoryService
     */
    public function __construct(CategoryService $categoryService = null)
    {
        parent::__construct();

        $this->categoryService = $categoryService;
    }

    /**
     * @SWG\Api(
     *   path="/EMR/Category/Form",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Retrieve templates for given category.",
     *           notes="Returns array of templates",
     *           @SWG\Parameter(
     *              name="category",
     *              description="Name of the category to get the emr templates.",
     *              type="string",
     *              paramType="query",
     *              required=true
     *           )
     *       )
     * )
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function getListAction()
    {
        //@todo:This Api Needs to be deprecated since the template form api has been modified to support categories.
        $response = new JsonResponse();

        $this->requestParameters = $this->getRequest()->query->all();
        if (array_key_exists('categoryIdentifier', $this->requestParameters)) {
            $data = $this->getTemplateUuidByCategoryIdentifier();
        } else {
            $data = $this->getTemplateFormsByCategory();
        }
        $response->setData(array('data' => $data));

        return $response;
    }

    /**
     * Get template forms by category.
     */
    private function getTemplateFormsByCategory()
    {
        $query = $this->getRequest()->query;
        $category = $query->get('category');
        $mandatoryParameters = array('category');
        $validationRules = array(
            'category' => 'isValidString'
        );

        $this->validateRequest($mandatoryParameters, $validationRules);
        if (!$this->getMeta()->hasError()) {
            $formData = $this->categoryService->getTemplateForms(array($category));
            if (!is_null($formData)) {
                $this->getMeta()->setCount(count($formData));
            }
            return $formData;
        }
    }

    /**
     * Returns the template uuid based on category identifier and category.
     *
     * @return array
     */
    private function getTemplateUuidByCategoryIdentifier()
    {
        $mandatoryParameters = array('categoryIdentifier', 'category');
        $validationRules = array(
            'categoryIdentifier' => 'isInteger',
            'category' => 'isValidString'
        );
        $this->validateRequest($mandatoryParameters, $validationRules);
        if (!$this->getMeta()->hasError()) {
            try {
                return $this->categoryService
                    ->getTemplateUuidByCategoryIdentifierAndCategory(
                        $this->getRequest()->get('categoryIdentifier'),
                        $this->getRequest()->get('category')
                    );
            } catch (\Exception $e) {
                $this->getMeta()->addMessage(META::STATUS_ERROR, $e->getMessage());
            }
        }
    }

    /**
     * Validate Request.
     *
     * @param array $mandatoryParameters
     * @param array $validationRules
     *
     * @return \Actinidium\API\Response\Meta
     */
    private function validateRequest($mandatoryParameters, $validationRules)
    {
        Validator::validate($validationRules, $this->requestParameters);
        Validator::mandatoryValidation($mandatoryParameters, $this->requestParameters);
        $validatorErrors = Validator::getErrors();
        if (!empty($validatorErrors)) {
            return $this->getMeta()->addMessage(META::STATUS_ERROR, $validatorErrors);
        }
    }
}
