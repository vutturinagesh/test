<?php

namespace Controller\EMR;

use Actinidium\API\MetaBaseController;
use Actinidium\API\Response\Meta;
use Actinidium\API\RestBaseController;
use Security\Sanitizer;
use Symfony\Component\HttpFoundation\Request;
use Actinidium\API\Response\CachedJsonResponse;
use Symfony\Component\HttpFoundation\JsonResponse;
use Exception;
use Message\MessageHandler;
use Controller\AbstractController;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/EMR",
 *     basePath="/api/v2"
 * )
 */
class FormVersionController extends AbstractController
{
    /**
     * @SWG\Api(
     *   path="/EMR/formVersion",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Returns all the versioned user forms.",
     *           notes="Get all the versioned user forms.",
     *           @SWG\Parameter(
     *              name="id",
     *              description="id of the user form",
     *              type="integer",
     *              required=true,
     *              paramType="query"
     *           ),
     *            @SWG\ResponseMessage(
     *              code=200,
     *              message="json {messages => 'user_messages', data => 'user forms'}"
     *           )
     *      )
     * )
     *
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function getAction(Request $request)
    {
        $response = new JsonResponse();
        $requestParameters = $request->query->all();
        $errorMessages = $this->validateRequest($requestParameters);

        //check whether there is any error in the meta data
        if (is_array($errorMessages) && count($errorMessages) <= 0) {
            try {
                $query = $request->query;
                $id = $query->get('id');
                $formService = $this->get('medicore.emr.form.form_service');
                // Get the userform versions
                $userFormData = $formService->getUserFormVersions($id);
                if (!$this->getMeta()->hasError()) {
                    $this->getMeta()->setCount(count($userFormData));
                    $response->setData(array('data' => $userFormData));
                }
            } catch (Exception $e) {
                $this->logException($e);
                $this->getMeta()->addMessage(
                    Meta::STATUS_ERROR,
                    $this->messageHandler->add(
                        'MG21',
                        MessageHandler::BLOCKING
                    )
                );
            }
        } else {
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, $errorMessages);
        }

        return $response;
    }
    
    /**
     * Validates the given inputs and check that they are boolean.
     *
     * @param array $inputParameters
     *
     * @return array
     */
    private function validateRequest(array $inputParameters)
    {
        $messages = array();
        if (count($inputParameters) == 0) {
            return $messages;
        }

        foreach ($inputParameters as $parameter => $parameterValue) {
            switch ($parameter) {
                case 'id':
                    if (Sanitizer::isPositiveInteger($parameterValue) === false) {
                        $messages[] = 'Invalid parameter value for '. $parameter;
                    }
                    break;
            }
        }

        return $messages;
    }
}
