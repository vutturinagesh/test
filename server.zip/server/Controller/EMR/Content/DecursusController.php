<?php

namespace Controller\EMR\Content;

use Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Security\Sanitizer;
use Exception;
use Message\MessageHandler;
use Actinidium\API\MetaBaseController;
use Actinidium\API\Response\Meta;
use Actinidium\API\RestBaseController;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/EMR",
 *     basePath="/api/v2"
 * )
 */
class DecursusController extends AbstractController
{
    /**
     * @SWG\Api(
     *   path="/EMR/content-decursus",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="returns form content.",
     *           notes="Returns array of fields and data.",
     *           @SWG\Parameter(
     *              name="patientId",
     *              description="Id of the patient.",
     *              type="integer",
     *              paramType="query",
     *              required=true
     *           ),
     *           @SWG\Parameter(
     *              name="page",
     *              description="For pagination.",
     *              type="integer",
     *              paramType="query",
     *              required=true
     *           ),
     *           @SWG\Parameter(
     *              name="limit",
     *              description="limit pagination.",
     *              type="integer",
     *              paramType="query",
     *              required=true
     *           ),
     *           @SWG\Parameter(
     *              name="templateFormUuid",
     *              description="uuid of the template form.",
     *              type="string",
     *              paramType="query",
     *              required=false
     *           )
     *      )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request|null $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse|void
     */
    public function getListAction(Request $request = null)
    {
        $response = new JsonResponse();
        $requestParameters = $request->query->all();
        $errorMessages = $this->validateRequest($requestParameters);

        $page = $this->processPage();
        $limit = $this->processLimit();

        //check whether there is any error in the meta data
        if (is_array($errorMessages) && count($errorMessages) <= 0) {
            try {
                // Get the list of user forms
                $userFormData = $this->getDecursusUserFormsByCriteria(
                    $request->query->get('patientId'),
                    $request->query->get('page'),
                    $request->query->get('limit'),
                    $request->query->get('templateFormUuid'),
                    true,
                    false,
                    'inuse'
                );
                if (!$this->getMeta()->hasError()) {
                    $this->addPaginationMeta($page, $limit, count($userFormData));
                    //set count
                    $this->getMeta()->setCount(count($userFormData));
                    //return the array of data
                    $response->setData(array('data' => $userFormData));
                }
            } catch (Exception $e) {
                $this->logException($e);
                $this->getMeta()->addMessage(
                    Meta::STATUS_ERROR,
                    $this->messageHandler->add(
                        'MG21',
                        MessageHandler::BLOCKING
                    )
                );
            }
        } else {
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, $errorMessages);
        }

        return $response;
    }

    /**
     * Return userforms by criteria.
     *
     * @param integer $patientId
     * @param integer $page
     * @param integer $limit
     * @param integer $templateFormUuid
     * @param bool $active
     * @param bool $deleted
     * @param string $status
     * 
     * @return array
     */
    protected function getDecursusUserFormsByCriteria(
        $patientId,
        $page,
        $limit,
        $templateFormUuid,
        $active,
        $deleted,
        $status
    ) {
        try {
            // Get the list of user forms
            $userFormData = $this->get('medicore.emr.form.user_service')->getAllDecursusForms(
                $patientId,
                $page,
                $limit,
                $templateFormUuid,
                $active,
                $deleted,
                $status
            );

            return $this->prepareDataForGui($userFormData);
            
        } catch (Exception $e) {
            $this->logException($e);
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->add(
                    'MG21',
                    MessageHandler::BLOCKING,
                    array('message' => $e->getMessage())
                )
            );
        }
    }

    /**
     * Returns an array which can be used for displaying in the GUI.
     *
     * @param array $userForms
     *
     * @return array
     */
    private function prepareDataForGui(array $userForms)
    {
        $data = array();
        foreach ($userForms as $userForm) {
            $data[] = $userForm->getUserMetaDataAsArray();
        }
        return $data;
    }

    /**
     * Validates the given inputs and check that they are boolean.
     *
     * @param array $inputParameters
     *
     * @return array
     */
    private function validateRequest(array $inputParameters)
    {
        $messages = array();
        if (count($inputParameters) == 0) {
            $messages[] = "Input parameters missing";
            return $messages;
        }

        foreach ($inputParameters as $parameter => $parameterValue) {
            switch ($parameter) {
                case 'patientId':
                case 'page':
                case 'limit':
                    if (Sanitizer::isPositiveInteger($parameterValue) === false) {
                        $messages[] = 'Invalid parameter value for '. $parameter;
                    }
                    break;
                case 'templateFormUuid':
                    if (Sanitizer::isString($parameterValue) === false) {
                        $messages[] = 'Invalid parameter value for '. $parameter;
                    }
                    break;
            }
        }

        return $messages;
    }
}
