<?php

namespace Controller\EMR\Content;

use Actinidium\API\Response\Meta;
use Controller\AbstractController;
use EMR\Content\DecursusSessionProfileService;
use Message\MessageHandler;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response as SymfonyResponse;
use Exception;

/**
 * Class DecursusSessionProfileController
 */
class DecursusSessionProfileController extends AbstractController
{
    /**
     * @var \EMR\Content\DecursusSessionProfileService
     */
    private $decursusSessionProfileService;

    /**
     * @param \EMR\Content\DecursusSessionProfileService $decursusSessionProfileService
     */
    public function __construct(DecursusSessionProfileService $decursusSessionProfileService)
    {
        parent::__construct();
        $this->decursusSessionProfileService = $decursusSessionProfileService;
    }

    /**
     * @SWG\Api(
     *   path="/EMR/content-decursus-sessionprofile",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="returns form content.",
     *           notes="Returns array of fields and data.",
     *           @SWG\Parameter(
     *              name="patient",
     *              description="Id of the patient.",
     *              type="integer",
     *              paramType="query",
     *              required=true
     *           ),
     *           @SWG\Parameter(
     *              name="page",
     *              description="For pagination.",
     *              type="integer",
     *              paramType="query",
     *              required=true
     *           ),
     *           @SWG\Parameter(
     *              name="limit",
     *              description="limit pagination.",
     *              type="integer",
     *              paramType="query",
     *              required=true
     *           ),
     *           @SWG\Parameter(
     *              name="emrTypeName",
     *              description="the emr type name",
     *              type="string",
     *              paramType="query",
     *              required=true
     *           ),
     *            @SWG\ResponseMessage(
     *              code=200,
     *              message="json {messages => 'user_messages', data => 'user forms'}"
     *           )
     *      )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @param integer $patientId
     * @param string $emrTypeName
     * @param integer $page
     * @param integer $limit
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function getListAction(Request $request, $patientId, $emrTypeName, $page, $limit)
    {
        $response = new JsonResponse();

        $this->processPage();
        $this->processLimit();

        if ($this->getMeta()->hasError()) {
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, $this->getMeta()->getMessages());
        } else {

            try {
                $userFormData = $this->decursusSessionProfileService->getDecursusUserForms(
                    $patientId,
                    $emrTypeName,
                    $page,
                    $limit
                );

                $this->addPaginationMeta($page, $limit, count($userFormData));
                $this->getMeta()->setCount(count($userFormData));

                $response->setData(array('data' => $userFormData));

            } catch (Exception $e) {
                $this->logException($e);
                $this->getMeta()->addMessage(
                    Meta::STATUS_ERROR,
                    $e->getMessage()
                );
            }
        }

        return $response;
    }
}
