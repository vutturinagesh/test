<?php

namespace Controller\EMR;

use Actinidium\API\Response\Meta;
use Actinidium\API\Response;
use Controller\AbstractController;
use EMR\Content\ContentService;
use EMR\Form\FormService;
use EMR\Form\User;
use Security\Sanitizer;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response as SymfonyResponse;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/EMR",
 *     basePath="/api/v2"
 * )
 */
class FormController extends AbstractController
{
    /**
     * Holds EMR form service object.
     *
     * @var \EMR\Form\FormService
     */
    protected $formService;

    /**
     * Instantiate the controller with all its dependencies.
     *
     * If some are not injected fetch them from the container.
     *
     * @param \EMR\Form\FormService $formService
     */
    public function __construct(FormService $formService = null)
    {
        parent::__construct();
        $this->formService = $formService;
    }

    /**
     * @SWG\Api(
     *   path="/EMR/Form",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Retrieve fields and data(for user forms) of selected template or user form.",
     *           notes="Returns array of fields and data.",
     *           @SWG\Parameter(
     *              name="id",
     *              description="Id of the emr template or user form.",
     *              type="integer",
     *              paramType="query",
     *              required=true
     *           ),
     *          @SWG\Parameter(
     *              name="patientId",
     *              description="Id of the patient.",
     *              type="integer",
     *              paramType="query",
     *              required=true
     *           )
     *       )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse|void
     */
    public function getAction(Request $request)
    {
        $query = $request->query;
        $response = new JsonResponse();

        $requestParameters = $query->all();
        $mandatoryParameters = array('id');
        $validationRules = array('id' => 'isPositiveInteger');
        Validator::mandatoryValidation($mandatoryParameters, $requestParameters);
        Validator::validate($validationRules, $requestParameters);
        $errorMessages = Validator::getErrors();

        //check whether there is any error in the meta data
        if (is_array($errorMessages) && count($errorMessages) > 0) {
            return $this->getMeta()->addMessage(Meta::STATUS_ERROR, $errorMessages);
        }

        if (!$this->getMeta()->hasError()) {
            try {
                $id = $requestParameters['id'];
                $patientId = $query->get('patientId');
                $data = $this->formService->getForm($id, $patientId);
            } catch (\Exception $e) {
                $this->getMeta()->addMessage(META::STATUS_ERROR, $e->getMessage());
            }
            $response->setData(array('data' =>  $data));
            
            return $response;
        }
    }

    /**
     * @SWG\Api(
     *   path="/EMR/Form",
     *       @SWG\Operation(
     *           method="POST",
     *           summary="Create a new user form with selected template or create new
     *                    version for existing user form(update).",
     *           notes="Returns array of fields.",
     *           @SWG\Parameter(
     *              name="formId",
     *              description="Id of the emr template for create or user form id for creating new version(update).",
     *              type="integer",
     *              paramType="body",
     *              required=true
     *           ),
     *          @SWG\Parameter(
     *              name="templateFormId",
     *              description="Id of the emr template.",
     *              type="integer",
     *              paramType="body",
     *              required=true
     *           ),
     *          @SWG\Parameter(
     *              name="patientId",
     *              description="Id of the patient.",
     *              type="integer",
     *              paramType="body",
     *              required=true
     *           ),
     *          @SWG\Parameter(
     *              name="node",
     *              description="Values for the form fields, keys should be uuid of fields.",
     *              type="array",
     *              @SWG\Items("string"),
     *              paramType="body",
     *              required=true
     *           ),
     *          @SWG\Parameter(
     *              name="categoryIdentifier",
     *              description="id of the categoryIdentifier",
     *              type="integer",
     *              paramType="body",
     *              required=false
     *           ),
     *          @SWG\Parameter(
     *              name="userFormCategoryName",
     *              description="category of the user form",
     *              type="string",
     *              paramType="body",
     *              required=false
     *           )
     *       )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse|void
     */
    public function createAction(Request $request)
    {
        $response = new JsonResponse();
        $data = json_decode($request->getContent(), true);

        $formId             = $data['formId'];
        $templateFormId     = $data['templateFormId'];
        $fieldValues        = $data['node'];
        $patientId          = $data['patientId'];
        $categoryIdentifier   = array_key_exists("categoryIdentifier", $data) ? $data["categoryIdentifier"] : null;
        $groupDataEdited      = array_key_exists("groupDataEdited", $data) ? $data["groupDataEdited"] : false;
        $userFormCategoryName = array_key_exists("userFormCategoryName", $data) ? $data["userFormCategoryName"] : null;

        /**
         * @fixme don't use a singleton like Contentservice to get the patient
         */
        ContentService::getInstance($patientId);

        $validationRules = array(
            'formId'         => 'isPositiveInteger',
            'patientId'      => 'isPositiveInteger',
            'templateFormId' => 'isPositiveInteger'
        );
        $requestParameters = $this->getRequest()->request->all();
        $validatorErrors = $this->validateInputs($validationRules, $requestParameters);


        if (!empty($validatorErrors)) {
            $this->getMeta()->addMessage(META::STATUS_ERROR, $validatorErrors);
        }

        $responseData = array();
        try {
            if (!$this->getMeta()->hasError()) {
                $fieldValues = $this->convertEmptyStringToNull($fieldValues);
                // create the userform with version
                $userForm = $this->formService
                    ->createNewVersion(
                        $formId,
                        $patientId,
                        $fieldValues,
                        $templateFormId,
                        $categoryIdentifier,
                        $groupDataEdited,
                        $userFormCategoryName
                    );
                //This means there are custom errors on user form creation
                if (!$userForm  instanceof User) {
                    $this->addErrorMessagesToMetaData($userForm);
                    $response->setStatusCode(SymfonyResponse::HTTP_CONFLICT);

                    return $response;

                } else {
                    $formValues = $userForm->getFieldValues();
                    $templateForm = $userForm->getTemplateForm();
                    $response->setStatusCode(SymfonyResponse::HTTP_CREATED);

                    $responseData = $templateForm->toArray($formValues, $userForm);
                }
            }
        } catch (\Exception $e) {
            $this->getMeta()->addMessage(META::STATUS_ERROR, $e->getMessage());
        }

        $response->setData(array('data' => $responseData));
        return $response;
    }

    /**
     * Let's make sure we don't parse empty strings but null values.
     *
     * @param array $fieldValues
     *
     * @return array
     */
    private function convertEmptyStringToNull(array $fieldValues)
    {
        $data = array();
        foreach ($fieldValues as $key => $value) {
            if (trim($value) === '') {
                $data[$key] = null;
            } else {
                $data[$key] = $value;
            }
        }

        return $data;
    }

    /**
     * Add error messages.
     *
     * @param array $returnData
     */
    private function addErrorMessagesToMetaData(array $returnData)
    {
        foreach ($returnData as $errorMessages) {
            foreach ($errorMessages as $errorMessage) {
                $this->getMeta()->addMessage(META::STATUS_ERROR, $errorMessage);
            }
        }
    }

    /**
     * Validate the given inputs.
     *
     * @param array $validationRules
     *
     * @return array
     */
    private function validateInputs(array $validationRules, $requestParameters)
    {
        $errors = array();

        if (count($validationRules) === 0 || count($requestParameters) === 0) {
            return $errors;
        }

        foreach ($validationRules as $validationInput => $validationRule) {
            if (Sanitizer::$validationRule($requestParameters[$validationInput]) === false) {
                $errors[$validationInput] = 'Invalid input for '.$validationInput;
            }
        }

        return $errors;
    }
}
