<?php

namespace Controller\EMR;

use Actinidium\API\Response\Meta;
use Controller\AbstractController;
use \EMR\Content\ContentService;
use Security\Sanitizer;
use Symfony\Component\HttpFoundation\ParameterBag;

/**
 * Class FormController
 */
class ContentController extends AbstractController
{
    /**
     * List action.
     *
     * @return array
     */
    public function getListAction()
    {
        $query = $this->getRequest()->query;
        if ($query->has('patientId') && $query->has('templateFormUuid') && $query->has('fieldUuid')) {
            return $this->getContentFromLatestUserFormData($query);
        } elseif ($query->has('templateFormUuid') && $query->has('patientId') && $query->has('categoryIdentifier')) {
            return $this->getContentForUserForm($query);
        } else {
            return $this->getMeta()->addMessage(META::STATUS_ERROR, 'The request is invalid!');
        }
    }

    /**
     * Get the content for the userform.
     *
     * @param \Symfony\Component\HttpFoundation\ParameterBag $query
     *
     * @return string
     */
    private function getContentForUserForm(ParameterBag $query)
    {
        $requestParameters = $query->all();

        $validateParameters = array(
            'patientId' => 'isPositiveInteger',
            'categoryIdentifier' => 'isPositiveInteger',
            'templateFormUuid' => 'isValidString'
        );
        $mandatoryParameters = array(
            'patientId',
            'categoryIdentifier',
            'templateFormUuid'
        );
        Validator::mandatoryValidation($mandatoryParameters, $requestParameters);
        Validator::validate($validateParameters, $requestParameters);
        $errorMessages = Validator::getErrors();
        //check whether there is any error in the meta data
        if (is_array($errorMessages) && count($errorMessages) > 0) {

            return $this->getMeta()->addMessage(Meta::STATUS_ERROR, $errorMessages);

        }
        try {
            $contentService = ContentService::getInstance($query->get('patientId'));
            $content =
                $contentService->getContentForLatestUserForm(
                    $requestParameters['templateFormUuid'],
                    $requestParameters['categoryIdentifier']
                );
            $this->getMeta()->setCount(count($content));
            return $content;
        } catch (\Exception $e) {
            $this->getMeta()->addMessage(META::STATUS_ERROR, $e->getMessage());
        }

    }

    /**
     * Get the content of a field from latest userform created on the basis of the give template form.
     *
     * @param \Symfony\Component\HttpFoundation\ParameterBag $query
     *
     * @return string
     */
    private function getContentFromLatestUserFormData (ParameterBag $query)
    {

        $requestParameters = $query->all();

        $errorMessages = $this->validateRequest($requestParameters);

        //check whether there is any error in the meta data
        if (is_array($errorMessages) && count($errorMessages) > 0) {

            $this->getMeta()->addMessage(Meta::STATUS_ERROR, $errorMessages);

        } else {

            try {
                $contentService = ContentService::getInstance($query->get('patientId'));
                $content = $contentService->getContentByTemplateFormAndUuid($requestParameters['templateFormUuid'], $requestParameters['fieldUuid']);

                if (!$this->getMeta()->hasError()) {
                    $this->getMeta()->setCount(count($content));
                    return $content;
                }

            } catch (\Exception $e) {
                $this->getMeta()->addMessage(META::STATUS_ERROR, $e->getMessage());
            }

        }

    }

    /**
     * Validates the given inputs and check that they are boolean.
     *
     * @param array $inputParameters
     *
     * @return array
     */
    private function validateRequest(array $inputParameters)
    {
        $messages = array();
        if (count($inputParameters) == 0) {
            return $messages;
        }

        if (
            !array_key_exists('patientId', $inputParameters) ||
            !array_key_exists('templateFormUuid', $inputParameters) ||
            !array_key_exists('fieldUuid', $inputParameters)
        ) {
            $messages[] = 'The request is invalid! Not All mandatory parameters given';
        }

        foreach ($inputParameters as $parameter => $parameterValue) {
            switch ($parameter) {
                case 'patientId':
                case 'templateFormId':
                    if (Sanitizer::isPositiveInteger($parameterValue) === false) {
                        $messages[] = 'Invalid parameter value for '. $parameter;
                    }
                    break;
                case 'templateFormUuid':
                    if (Sanitizer::isValidString($parameterValue) === false) {
                        $messages[] = 'Invalid parameter value for '. $parameter;
                    }
                    break;
                case 'fieldUuid':
                    if (Sanitizer::isValidString($parameterValue) === false) {
                        $messages[] = 'Invalid parameter value for '. $parameter;
                    }
                    break;
            }
        }
        return $messages;
    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::createAction()
     */
    public function createAction($data)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::deleteAction()
     */
    public function deleteAction($id)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::deleteListAction()
     */
    public function deleteListAction()
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::updateAction()
     */
    public function updateAction($id, $data)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }
}
