<?php

namespace Controller\EMR;

use Actinidium\API\Response\Meta;
use Actinidium\API\RestBaseController;
use Exception;

/**
 * CategoryController
 *
 * Callable via /api/EMR-FormCategory
 *
 * @package     EMR\Form
 */
class FormCategoryController extends RestBaseController
{
    /**
     * Holds object of  EMR Formservice
     *
     * @var \EMR\Form\FormService
     */
    protected $formService;

    /**
     * Consrructor.
     */
    public function __construct()
    {
        $this->formService = $this->get('medicore.emr.form.form_service');
    }

    /**
     * Get the Emr form service object on demand
     *
     * @return \EMR\Form\FormService
     */
    private function getFormService()
    {
        return $this->formService;
    }

    /**
     * (non-PHPdoc)
     *
     * @see \Actinidium\API\RestBaseController::getAction()
     */
    public function getAction($id)
    {
        try {
            return $this->getFormService()->fetchCategory($id);
        } catch (Exception $e) {
            $this->getMeta()->addMessage(META::STATUS_ERROR, $e->getMessage());
        }
    }

    /**
     * (non-PHPdoc)
     *
     * @see \Actinidium\API\RestBaseController::getListAction()
     */
    public function getListAction()
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * (non-PHPdoc)
     *
     * @see \Actinidium\API\RestBaseController::createAction()
     */
    public function createAction($data)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * (non-PHPdoc)
     *
     * @see \Actinidium\API\RestBaseController::deleteAction()
     */
    public function deleteAction($id)
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * (non-PHPdoc)
     *
     * @see \Actinidium\API\RestBaseController::deleteListAction()
     */
    public function deleteListAction()
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * (non-PHPdoc)
     *
     * @see \Actinidium\API\RestBaseController::updateAction()
     */
    public function updateAction($id, $data)
    {
        $query = $this->getRequest()->request;

        $id = $query->get('id');
        $category = $query->get('categoryId');

        try {
            // Attach the category
            $form = $this->getFormService()->attachCategory($id, $category);
            return $form;
        } catch (Exception $e) {
            $this->getMeta()->addMessage(META::STATUS_ERROR, $e->getMessage());
        }
    }
}
