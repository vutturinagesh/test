<?php

namespace Controller;

use Actinidium\API\Response\Meta;
use Factory\TranslatorFactory;

class LegacyMhcValidationResult
{
    /**
     * @var string
     */
    const MHC_VALIDATE_HINT = 'GGZ_VALIDATIE_HINT';

    /**
     * @var string
     */
    const MHC_VALIDATE_MESSAGE = 'GGZ_VALIDATIE_MELDING';

    /**
     * @var string
     */
    const LEGACY_VALIDATION_MESSAGE = 'melding';

    /**
     * @var string
     */
    const LEGACY_VALIDATION_ERROR = 'foutcode';

    /**
     * @var string
     */
    const LEGACY_VALIDATION_WARNING = 'debugmelding';

    /**
     * Checks if there are any legacy mhc validation errors.
     *
     * @param array $messages
     *
     * @return bool
     */
    public static function containsError(array $messages)
    {
        foreach ($messages as $key => $message) {
            if (isset($message['level']) && $message['level'] == Meta::STATUS_ERROR) {
                return true;
            }
        }

        return false;
    }

    /**
     * Adds legacy validation messages to meta.
     *
     * @param \Controller\AbstractController $controller
     * @param array                          $messages
     */
    public static function addMessages(AbstractController $controller, array $messages)
    {
        if (empty($messages)) {
            return;
        }

        foreach ($messages as $message) {
            $type = $message['level'];
            $translatedMessage = $controller
                ->getTranslator()
                ->trans(static::MHC_VALIDATE_MESSAGE . $message['code'], array(), TranslatorFactory::TRANS_DOMAIN_MEDICAL_VALIDATIONS);
            $messageCode = $message['code'];
            $hint = $controller
                ->getTranslator()
                ->trans(static::MHC_VALIDATE_HINT . $message['code'], array(), TranslatorFactory::TRANS_DOMAIN_MEDICAL_VALIDATIONS);

            $controller->getMeta()->addMessage($type, $translatedMessage, $messageCode, $hint);
        }
    }

    /**
     * Processes the result given from the 1.10 response.
     *
     * @param array $results
     *
     * @return array
     */
    public static function processLegacyMhcValidationResult(array $results)
    {
        $messages = array();
        if (array_key_exists(self::LEGACY_VALIDATION_ERROR, $results)) {
            foreach ($results[self::LEGACY_VALIDATION_ERROR] as $error) {
                $messages[] = array (
                    'level' => Meta::STATUS_ERROR,
                    'code' => $error,
                );
            }
        }
        if (array_key_exists(self::LEGACY_VALIDATION_MESSAGE, $results)) {
            foreach ($results[self::LEGACY_VALIDATION_MESSAGE] as $error) {
                $messages[] = array (
                    'level' => Meta::STATUS_ERROR,
                    'code' => $error['code'],
                );
            }
        }
        if (array_key_exists(self::LEGACY_VALIDATION_WARNING, $results)) {
            foreach ($results[self::LEGACY_VALIDATION_WARNING] as $error) {
                $messages[] = array (
                    'level' => Meta::STATUS_WARNING,
                    'code' => $error,
                );
            }
        }

        return $messages;
    }
}
