<?php
namespace Controller\Calendar;

use Actinidium\API\RestBaseController;
use Actinidium\API\Response\Meta;
use Calendar\Interval;
use Calendar\ParticipantService;
use Generic\CalendarService;
use Generic\ClinicService;
use Generic\Calendar;

/**
 * ItemController
 */
class ItemController extends RestBaseController
{
    /**
     * Supported calendar types
     */
    const TYPE_DAY = 'day';
    const TYPE_WEEK = 'week';
    const TYPE_MONTH = 'month';

    /**
     * Supported items types
     */
    const ITEM_APPOINTMENT = 'appointment';
    const ITEM_AVAILABILITY = 'availability';
    const ITEM_ABSENCE = 'absence';
    const ITEM_COUNTER = 'counter';

    /**
     * Get calendar items
     *
     * returned item types are:
     * - appointment
     * - availability (roster rule)
     * - absence (roster rule || break)
     * - counter (number of appointments per day, for month only)
     *
     * @return array
     */
    public function getListAction()
    {
        $query = $this->getRequest()->query;

        $ownerId = $query->getDigits('owner');
        $clinicId = $query->getDigits('clinic', 0);
        $startDate = $query->get('startDate');
        $endDate = $query->get('endDate', $query->get('startDate'));
        $type = $query->get('type', 'day');

        $participantService = new ParticipantService();
        $owner = $participantService->findParticipant($ownerId);

        // Get the clinic object
        $clinic = null;
        if ($clinicId > 0) {
            $clinicService = new ClinicService();
            $clinic = $clinicService->find($clinicId);
        }

        $from = new \DateTime($startDate);
        $from->setTime(0, 0, 0);
        $until = new \DateTime($endDate);
        $until->setTime(23, 59, 59);
        $interval = new Interval($from, $until);

        $calendarService = new CalendarService();
        $calendar = $calendarService->getCalendar($interval, $owner, $clinic);

        if ($type !== self::TYPE_MONTH) {

            $data = array_merge(
                $this->getAppointmentItems($calendar),
                $this->getAvailabilityItems($calendar),
                $this->getAbsenceItems($calendar)
            );
        } else {
            $data = $this->getCounterItems($calendar);
        }

        return $data;
    }

    /**
     * Get appointment type items from calendar
     *
     * @param Calendar $calendar
     * @return array
     */
    private function getAppointmentItems(Calendar $calendar)
    {
        $appointments = $calendar->getAppointments();

        $items = array();
        foreach ($appointments as $appointment) {
            $item = $appointment->toListArray();
            $item['type'] = self::ITEM_APPOINTMENT;
            $items[] = $item;
        }

        return $items;
    }

    /**
     * Get availability type items from calendar
     *
     * @param Calendar $calendar
     * @return array
     */
    private function getAvailabilityItems(Calendar $calendar)
    {
        $rosters = $calendar->getRosters();

        $availabilities = array();
        foreach ($rosters as $ruleInterval) {
            if (!$ruleInterval->getRule()->isBreak() && !$ruleInterval->getRoster()->isAbsence()) {
                $availabilities[] = $ruleInterval;
            }
        }

        $items = array();
        foreach ($availabilities as $ruleInterval) {
            $item = $ruleInterval->toListArray();
            $item['type'] = self::ITEM_AVAILABILITY;
            $items[] = $item;
        }

        return $items;
    }

    /**
     * Get absence type items from calendar
     *
     * @param Calendar $calendar
     * @return array
     */
    private function getAbsenceItems(Calendar $calendar)
    {
        $rosters = $calendar->getRosters();

        $absences = array();
        foreach ($rosters as $ruleInterval) {
            if ($ruleInterval->getRule()->isBreak() || $ruleInterval->getRoster()->isAbsence()) {
                $absences[] = $ruleInterval;
            }
        }

        $items = array();
        foreach ($absences as $ruleInterval) {
            $item = $ruleInterval->toListArray();
            $item['type'] = self::ITEM_ABSENCE;
            $items[] = $item;
        }

        return $items;
    }

    /**
     * Get counter type items from calendar
     *
     * @param Calendar $calendar
     * @return array
     */
    private function getCounterItems(Calendar $calendar)
    {
        $items = array();
        foreach ($calendar->getNumberOfAppointmentsPerDay() as $item) {
            $item['type'] = self::ITEM_COUNTER;
            $items[] = $item;
        }

        return $items;
    }

    /**
     * Get single item
     *
     * @param int $id
     * @return null
     * @throws \Exception
     */
    public function getAction($id)
    {
        throw new \Exception(__CLASS__ . '::' . __METHOD__ . ' is not implemented');
    }

    /**
     * Create new item
     *
     * @param array $data
     * @return null
     * @throws \Exception
     */
    public function createAction($data)
    {
        throw new \Exception(__CLASS__ . '::' . __METHOD__ . ' is not implemented');
    }

    /**
     * Update item
     *
     * @param int $id
     * @param array $data
     * @return null
     * @throws \Exception
     */
    public function updateAction($id, $data)
    {
        throw new \Exception(__CLASS__ . '::' . __METHOD__ . ' is not implemented');
    }

    /**
     * Delete Item
     *
     * @param int $id
     * @return null
     * @throws \Exception
     */
    public function deleteAction($id)
    {
        throw new \Exception(__CLASS__ . '::' . __METHOD__ . ' is not implemented');
    }

    /**
     * Delete list of items
     *
     * @return null
     * @throws \Exception
     */
    public function deleteListAction()
    {
        throw new \Exception(__CLASS__ . '::' . __METHOD__ . ' is not implemented');
    }
}