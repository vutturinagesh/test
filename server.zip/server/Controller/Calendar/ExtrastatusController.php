<?php
namespace Controller\Calendar;

use Actinidium\API\RestBaseController;
use Actinidium\API\Response\Meta;
use Calendar\Appointment\ExtraStatusService;

/**
 * ExtrastatusController
 *
 * Callable via /api/calendar-extraStatus
 */
class ExtrastatusController extends RestBaseController
{
    /**
     * @var ExtraStatusService
     */
    private $extraStatusService;

    /**
     * Get the ExtraStatusService
     *
     * @return ExtraStatusService
     */
    protected function getExtraStatusService()
    {
        if ($this->extraStatusService == null) {
            $this->extraStatusService = new ExtraStatusService();
        }

        return $this->extraStatusService;
    }
    
    /**
     * Function to set the ExtraStatusService.
     *
     * @param \Calendar\ExtraStatusService $extraStatusService
     */
    public function setExtraStatusService(\Calendar\ExtraStatusService $extraStatusService)
    {
        $this->extraStatusService = $extraStatusService;
    }

    /**
     * Get Extra status by identity
     *
     * @param mixed $id
     *
     * @throws \Exception
     */
    public function getAction($id)
    {
        throw new \Exception(__METHOD__.' is not implemented');
    }

    /**
     * Get list of extra statuses
     *
     * @return array
     */
    public function getListAction()
    {
        $service = $this->getExtraStatusService();
        $criteria = array();
        $orderBy = array('name' => 'ASC');

        $statusList = $service->getAllBy($criteria, $orderBy);

        $data = array();
        foreach ($statusList as $status) {
           $data[] = $status->toListArray();
        }

        return $data;
    }

    /**
     * Create a extra status
     *
     * @param array $data
     * 
     * @throws \Exception
     */
    public function createAction($data)
    {
        throw new \Exception(__METHOD__.' is not implemented');
    }

    /**
     * Update a extra status
     *
     * @param int $id
     * @param array $data
     *
     * @throws \Exception
     */
    public function updateAction($id, $data)
    {
        throw new \Exception(__METHOD__.' is not implemented');
    }

    /**
     * Delete a extra status
     *
     * @param int $id
     * 
     * @throws \Exception
     */
    public function deleteAction($id)
    {
        throw new \Exception(__METHOD__.' is not implemented');
    }

    /**
     * Delete multiple extra statuses
     *
     * @throws \Exception
     */
    public function deleteListAction()
    {
        throw new \Exception(__METHOD__.' is not implemented');
    }
}