<?php
namespace Controller\Calendar;

use Actinidium\API\RestBaseController;
use Actinidium\API\Response\Meta;
use Generic\Employee;
use Generic\EmployeeService;
use Generic\Resource;
use Generic\ResourceService;

/**
 * OwnerController
 *
 * Callable via /api/calendar-owner/:action where :action is one of the public *Action methods
 */
class OwnerController extends RestBaseController
{
    /**
     * @var EmployeeService
     */
    private $employees;

    /**
     * @var ResourceService
     */
    private $resources;

    /**
     * @return EmployeeService
     */
    private function employees()
    {
        if (!$this->employees) {
            $this->employees = new EmployeeService();
        }

        return $this->employees;
    }

    /**
     * @return ResourceService
     */
    private function resources()
    {
        if (!$this->resources) {
            $this->resources = new ResourceService();
        }

        return $this->resources;
    }

    /**
     * Transform list of owner (objects!) to array
     *
     * @param array $owners
     * @return array
     */
    private function transformToArray($owners)
    {
        $list = array();
        foreach ($owners as $owner) {
            if ($owner instanceof Resource) {
                $list[] = array(
                    'id' => $owner->getParticipant()->getId(),
                    'name' => utf8_decode($owner->getName())
                );
            } elseif ($owner instanceof Employee) {
                $list[] = array(
                    'id' => $owner->getParticipant()->getId(),
                    'name' => utf8_decode($owner->getFullName())
                );
            }
        }

        return $list;
    }

    /**
     * Get status by id
     *
     * @param int $id
     * @return array|null
     */
    public function getAction($id)
    {
        $this->getMeta()->addMessage(Meta::STATUS_ERROR, 'Not implemented');

        return null;
    }

    /**
     * Get list of owners
     *  Allowed query parameters are
     * - (bool) inactive: If set to true will also return owners that have NO rosters
     * - (string) query: The query to use for matching
     * - (string) type: Type of owner to search for (employee/resource)
     * - (int) clinic: Identity of clinic to filter on
     *
     * @return array
     */
    public function getListAction()
    {
        $query = $this->getRequest()->query;
        $withOutRosters = $query->get('inactive') === 'true';

        $criteria = array(
            'name' => $query->get('query', '')
        );
        if ($query->has('clinic')) {
            $criteria['clinic'] = $query->get('clinic');
        }

        $owners = array();
        switch ($query->get('type', false)) {
            default:
                // Unknown type, ignore
                break;
            case 'employee':
                if ($withOutRosters) {
                    $owners = $this->employees()->findAllBy($criteria);
                } else {
                    $owners = $this->employees()->findWithRoster($criteria);
                }
                break;
            case 'resource':
                $orderBy = array('name' => 'ASC');
                $criteria['withrr'] = !$withOutRosters;
                $owners = $this->resources()->findOrderedBy($criteria, $orderBy);
                break;
        }

        return $this->transformToArray($owners);
    }

    /**
     * Create new owner
     *
     * @param array $data
     * @return null
     * @throws \Exception
     */
    public function createAction($data)
    {
        throw new \Exception(__METHOD__.' is not implemented');
    }

    /**
     * Update owner
     *
     * @param int $id
     * @param array $data
     * @return null
     * @throws \Exception
     */
    public function updateAction($id, $data)
    {
        throw new \Exception(__METHOD__.' is not implemented');
    }

    /**
     * Delete owner
     *
     * @param int $id
     * @return null
     * @throws \Exception
     */
    public function deleteAction($id)
    {
        throw new \Exception(__METHOD__.' is not implemented');
    }

    /**
     * Delete multiple owners
     *
     * @return null
     * @throws \Exception
     */
    public function deleteListAction()
    {
        throw new \Exception(__METHOD__.' is not implemented');
    }
}