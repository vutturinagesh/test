<?php
namespace Controller\Calendar;

use Actinidium\API\RestBaseController;
use Actinidium\API\Response\Meta;
use Calendar\AppointmentService;
use Calendar\Appointment;
use Calendar\Interval;
use Calendar\ParticipantService;
use Generic\CalendarService;
use Generic\ClinicService;
use Generic\Calendar;
use Generic\ContactMannerService;
use Calendar\Appointment\ExtraStatusService;
use Calendar\Appointment\StatusService;

/**
 * AppointmentController
 */
class AppointmentController extends RestBaseController
{
    /**
     * @var AppointmentService
     */
    private $service;

    /**
     * Get appointment domain service
     *
     * @return AppointmentService
     */
    private function getService()
    {
        if (!$this->service) {
            $this->service = new AppointmentService();
        }

        return $this->service;
    }

    /**
     * @param AppointmentService $service
     */
    public function setService(AppointmentService $service)
    {
        $this->service = $service;
    }

    /**
     * Get list of appointments
     *
     * @throws \Exception
     * @return void
     */
    public function getListAction()
    {
        throw new \Exception(__METHOD__ . ' is not implemented');
    }

    /**
     * Get appointment
     *
     * @param int $id
     *
     * @return \Calendar\Appointment
     */
    private function getAppointmentById($id)
    {
        return $this->getService()->findOneById($id);
    }

    /**
     * Get appointment
     *
     * @param int $id
     *
     * @return array|null
     */
    public function getAction($id)
    {
        $appointment = $this->getAppointmentById($id);
        if (!$appointment) {
            return $this->notFound($id);
        }

        return $appointment->toArray();
    }

    /**
     * Create a new appointment
     *
     * @param array $data
     *
     * @return null|array
     */
    public function createAction($data)
    {
        $appointment = new Appointment();

        $service = $this->getService();
        $validator = $service->getValidator();
        $validator->setData($data);
        $validator->bind($appointment);

        if ($validator->isValid()) {
            if (array_key_exists('notes', $data)) {
                $notes = $data['notes'];
                $appointment->setNotes($notes);
            }
            if (array_key_exists('contactManner', $data) && array_key_exists('id', $data['contactManner'])) {
                $contactMannerService = new \Generic\ContactMannerService();
                $contactManner = $contactMannerService->find($data['contactManner']['id']);
                $appointment->setContactManner($contactManner);
            }
            $statusService = new \Calendar\Appointment\StatusService();
            if (array_key_exists('status', $data) && array_key_exists('id', $data['status'])) {
                if ($data['status']['id']) {
                    $status = $statusService->find($data['status']['id']);
                }
            } else {
                $status = $statusService->findDefaultStatus();
            }
            $appointment->setStatus($status);
            if (array_key_exists('referrer', $data)) {
                if($data['referrer']['type'] == 'external') {
                    // always save the fixed type, date and type
                    $referrer['referrerfixedtype'] = 'organization';

                    if (isset($data['referrer']['date'])) {
                        $referrerDate = new \DateTime($data['referrer']['date']);
                        $referrer['referrerdate'] = $referrerDate;
                    } else {
                        $referrer['referrerdate'] = $data['referrer']['date'];
                    }

                    $referrer['referrertype_id'] = $data['referrer']['type_id'];

                    $referrer['referrer_owninitiative_id'] = $data['referrer']['selfinitiative_id'];

                    // if a specific care institution is selected
                    if (isset($data['referrer']['CareInstitution']) && !empty($data['referrer']['CareInstitution'])) {
                        // we can save more info
                        $referrer['referrerfixedtype'] = ($data['referrer']['type_id'] == 0 ? 'general_practitioner'
                                : 'organization');
                        $careInstitution = $data['referrer']['CareInstitution'];
                        $referrer['referrerorganization_id'] = is_array($careInstitution) ? $careInstitution['id']
                                : $careInstitution;
                        if (isset($data['referrer']['person_id'])) {
                            $referrer['referrerperson_id'] = $data['referrer']['person_id'];
                        }
                    }
                } else if($data['referrer']['type'] == 'internal') {
                    // always save the fixed type and date
                    $referrer['referrerfixedtype'] = 'internal_specialist';

                    if (isset($data['referrer']['date'])) {
                        $referrerDate = new \DateTime($data['referrer']['date']);
                        $referrer['referrerdate'] = $referrerDate;
                    } else {
                        $referrer['referrerdate'] = $data['referrer']['date'];
                    }

                    $referrer['referrerclinic_id'] = $data['referrer']['referrer_clinic_id'];

                    // if a specific employee is selected
                    if (isset($data['referrer']['employee_id'])) {
                        // we can save more info
                        $referrer['referrerperson_id'] = $data['referrer']['employee_id'];
                    }
                } else {
                    if (isset($data['referrer']['selfinitiative_id'])) {
                        $referrer['referrerfixedtype'] = 'self_initiative';
                        $referrer['referrer_owninitiative_id'] = $data['referrer']['selfinitiative_id'];
                    }
                }

                $appointment->setReferrerOrganizationId($referrer['referrerorganization_id']);
                $appointment->setReferrerOwnInitiativeId($referrer['referrer_owninitiative_id']);
                $appointment->setReferrerId($referrer['referrerperson_id']);
                $appointment->setReferrertypeId($referrer['referrertype_id']);
                $appointment->setReferrerDate($referrer['referrerdate']);
                $appointment->setReferrerType($referrer['referrerfixedtype']);
                $appointment->setReferrerClinicId($referrer['referrerclinic_id']);
            }

            if ($service->update($appointment, $validator->getValues())) {
                // TODO: [QA-1980] need to verify availability before persisting
                $service->updateAvailability($appointment);
                // TODO need to log changes
                return $appointment->toArray();
            } else {
                $this->getMeta()->addMessage(Meta::STATUS_ERROR, 'Persistance failed');
            }
        } else {
            // Handle errors
            $meta = $this->getMeta();
            foreach ($validator->getMessages() as $field => $messages) {
                $meta->addMessage(
                    Meta::STATUS_ERROR,
                    array(
                        'field' => $field,
                        'errors' => $messages
                    )
                );
            }
        }

        return null;
    }

    /**
     * Update an appointment
     *
     * @param int $id
     * @param array $data
     *
     * @return null|array
     */
    public function updateAction($id, $data)
    {
        $appointment = $this->getAppointmentById($id);
        if (!$appointment) {
            return $this->notFound($id);
        }

        $service = $this->getService();
        $validator = $service->getValidator();
        $validator->setData($data);
        $validator->bind($appointment);

        if ($validator->isValid()) {
            if ($data['notes']) {
                $notes = $data['notes'];
                $appointment->setNotes($notes);
            }
            if ($data['contactManner']['id']) {
                $contactMannerService = new \Generic\ContactMannerService();
                $contactManner = $contactMannerService->find($data['contactManner']['id']);
                $appointment->setContactManner($contactManner);
            }
            $statusService = new \Calendar\Appointment\StatusService();
            if (array_key_exists('status', $data) && array_key_exists('id', $data['status'])) {
                if ($data['status']['id']) {
                    $status = $statusService->find($data['status']['id']);
                }
            } else {
                $status = $statusService->findDefaultStatus();
            }
            $appointment->setStatus($status);
            if (array_key_exists('referrer', $data)) {
                if($data['referrer']['type'] == 'external') {
                    // always save the fixed type, date and type
                    $referrer['referrerfixedtype'] = 'organization';

                    if (isset($data['referrer']['date'])) {
                        $referrerDate = new \DateTime($data['referrer']['date']);
                        $referrer['referrerdate'] = $referrerDate;
                    } else {
                        $referrer['referrerdate'] = $data['referrer']['date'];
                    }

                    $referrer['referrertype_id'] = $data['referrer']['type_id'];

                    $referrer['referrer_owninitiative_id'] = $data['referrer']['selfinitiative_id'];

                    // if a specific care institution is selected
                    if (isset($data['referrer']['CareInstitution']) && !empty($data['referrer']['CareInstitution'])) {
                        // we can save more info
                        $referrer['referrerfixedtype'] = ($data['referrer']['type_id'] == 0 ? 'general_practitioner'
                                : 'organization');
                        $careInstitution = $data['referrer']['CareInstitution'];
                        $referrer['referrerorganization_id'] = is_array($careInstitution) ? $careInstitution['id']
                                : $careInstitution;
                        if (isset($data['referrer']['person_id'])) {
                            $referrer['referrerperson_id'] = $data['referrer']['person_id'];
                        }
                    }
                } else if($data['referrer']['type'] == 'internal') {
                    // always save the fixed type and date
                    $referrer['referrerfixedtype'] = 'internal_specialist';

                    if (isset($data['referrer']['date'])) {
                        $referrerDate = new \DateTime($data['referrer']['date']);
                        $referrer['referrerdate'] = $referrerDate;
                    } else {
                        $referrer['referrerdate'] = $data['referrer']['date'];
                    }

                    $referrer['referrerclinic_id'] = $data['referrer']['referrer_clinic_id'];

                    // if a specific employee is selected
                    if (isset($data['referrer']['employee_id'])) {
                        // we can save more info
                        $referrer['referrerperson_id'] = $data['referrer']['employee_id'];
                    }
                } else {
                    if (isset($data['referrer']['selfinitiative_id'])) {
                        $referrer['referrerfixedtype'] = 'self_initiative';
                        $referrer['referrer_owninitiative_id'] = $data['referrer']['selfinitiative_id'];
                    }
                }

                $appointment->setReferrerOrganizationId($referrer['referrerorganization_id']);
                $appointment->setReferrerOwnInitiativeId($referrer['referrer_owninitiative_id']);
                $appointment->setReferrerId($referrer['referrerperson_id']);
                $appointment->setReferrertypeId($referrer['referrertype_id']);
                $appointment->setReferrerDate($referrer['referrerdate']);
                $appointment->setReferrerType($referrer['referrerfixedtype']);
                $appointment->setReferrerClinicId($referrer['referrerclinic_id']);
            }
            if ($service->update($appointment, $validator->getValues())) {
                // TODO: [QA-1980] need to verify availability before persisting
                $service->updateAvailability($appointment);
                // TODO need to log changes
                return $appointment->toArray();
            } else {
                $this->getMeta()->addMessage(Meta::STATUS_ERROR, 'Persistance failed');
            }
        } else {
            // Handle errors
            $meta = $this->getMeta();
            foreach ($validator->getMessages() as $field => $messages) {
                $meta->addMessage(
                    Meta::STATUS_ERROR,
                    array(
                        'field' => $field,
                        'errors' => $messages
                    )
                );
            }
        }

        return null;
    }

    /**
     * Delete an appointment
     *
     * @param int $id
     *
     * @return null
     * @throws \Exception
     */
    public function deleteAction($id)
    {
        $appointment = $this->getAppointmentById($id);
        if (!$appointment) {
            return $this->notFound($id);
        }

        $service = $this->getService();
        $service->deleteOne($appointment);

        // TODO need to log deletion

        return null;
    }

    /**
     * Delete multiple appointments
     *
     * @return void
     * @throws \Exception
     */
    public function deleteListAction()
    {
        throw new \Exception(__METHOD__ . ' is not implemented');
    }

    /**
     * Add not found error to meta
     *
     * @param int $id
     *
     * @return null
     */
    private function notFound($id)
    {
        $this->getMeta()->addMessage(Meta::STATUS_ERROR, 'Unknown appointment (' . $id . ')');

        return null;
    }
}