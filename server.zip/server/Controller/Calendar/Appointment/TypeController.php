<?php

namespace Controller\Calendar\Appointment;

use Actinidium\API\RestBaseController;

/**
 * MenuController
 *
 * Callable via /api/calendar-appointment-type
 */
class TypeController extends RestBaseController
{
    /** 
     * const default language (dutch)
     */
    const DEFAULT_LANGUAGE = 'nl';
    
    /**
     * Get resource by id
     *
     * @param mixed $id
     *
     * @return null
     */
    public function getAction($id) 
    {
        $this->getMeta()->addMessage(Meta::STATUS_ERROR, 'Not implemented');
        
        return null;
    }

    /**
     * Create new resource
     *
     * @param mixed $data
     *
     * @return null
     */
    public function createAction($data) 
    {
        $this->getMeta()->addMessage(Meta::STATUS_ERROR, 'Not implemented');
        
        return null;
    }

    /**
     * Update resource
     *
     * @param mixed $id
     * @param mixed $data
     *
     * @return null
     */
    public function updateAction($id, $data) 
    {
        $this->getMeta()->addMessage(Meta::STATUS_ERROR, 'Not implemented');
        
        return null;
    }

    /**
     * Delete resource
     *
     * @param int $id
     *
     * @return null
     */
    public function deleteAction($id) 
    {
        $this->getMeta()->addMessage(Meta::STATUS_ERROR, 'Not implemented');
        
        return null;
    }

    /**
     * Delete multiple resources
     *
     * @return null
     */
    public function deleteListAction() 
    {
        $this->getMeta()->addMessage(Meta::STATUS_ERROR, 'Not implemented');
        
        return null;
    }
    
    /**
     * Function used to get the appointment types
     *
     * @return array of id and name of active appointment types
     */
    public function getListAction()
    {
        $service = $this->getTypeService();
        $criteria = array();
        
        $queryObject = $this->getRequest()->query;
        
        if ($queryObject->has('clinic')) {
            $criteria['clinic'] = (int)$queryObject->get('clinic');
        }
        if ($queryObject->has('specialism')) {
            $criteria['specialism'] = (int)$queryObject->get('specialism') ;
        }
        
        if (count($criteria) > 0) {
            // get appointment type based on criteria
            $criteria['active'] = 1;
            $criteria['unavailableDate'] = date('Y-m-d');
            $result = $service->search($criteria, array(), false);
        } else {
            // get all active appointment types
            $result = $service->findAllActive();
        }

        // loop through the result to set it to view
        $data = array();
        foreach ($result as $res) {
            $data[] = $res->toListArray();
        }
        $this->getMeta()->setCount(count($data));

        return $data;
    }
    
    /**
     * Function used to get the type service.
     *
     * @return Calendar\Appointment\TypeService
     */
    protected function getTypeService()
    {
        if ($this->typeService == null) {
            $this->typeService = new \Calendar\Appointment\TypeService();
        }
        
        return $this->typeService;
    }
    
    /**
     * Function used to set the appointment type service.
     * 
     * @param Calendar\Appointment\TypeService $typeService
     */
    public function setTypeService(\Calendar\Appointment\TypeService $typeService)
    {
        $this->typeService = $typeService;
    }
}