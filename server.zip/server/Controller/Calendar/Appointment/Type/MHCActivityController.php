<?php

namespace Controller\Calendar\Appointment\Type;

use Controller\AbstractController;
use Actinidium\API\Response\Meta;
use Security\Sanitizer;
use Exception;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Message\MessageHandler;
use DateTime;

/**
 * MHCActivityTime controller.
 *
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/calendar-appointment-type-mhcactivity",
 *     basePath="/api/v2/"
 * )
 */
class MHCActivityController extends AbstractController
{
    /**
     * const default language (dutch)
     */
    const DEFAULT_LANGUAGE = 'nl';

    /**
     * The time registered for the activity associated to the appointment.
     *
     * @SWG\Api(
     *   path="/api/v2/calendar-appointment-type-mhcactivity",
     *   description="The time registered for the activity associated to the appointment",
     *       @SWG\Operation(
     *           method="POST",
     *           summary="the time registered for the activity associated to the appointment.",
     *           notes="Returns some stuff",
     *           @SWG\Parameter(
     *              name="appointmentId",
     *              description="Id of the appointment",
     *              type="integer",
     *              paramType="query",
     *              required=true
     *           ),
     *           @SWG\Parameter(
     *              name="code",
     *              description="the code of the activity",
     *              type="string",
     *              paramType="query",
     *              required=true
     *           ),
     *           @SWG\Parameter(
     *              name="activityTimeData",
     *              description="array consisting of the time to be registered",
     *              type="array",
     *              @SWG\Items("string"),
     *              paramType="query",
     *              required=true
     *           ),
     *           @SWG\ResponseMessage(
     *              code=200,
     *              message="json {messages => 'ok', data => ''}"
     *           )
     *       )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function createAction(Request $request)
    {
        $response = new JsonResponse();
        $data = json_decode($request->getContent(), true);
        $appointmentId = $data['appointmentId'];
        $code = $data['code'];
        $activityTimeData = $data['activityTimeData'];
        $validationRules = array(
            'appointmentId' => 'isPositiveInteger',
            'code' => 'isValidString'
        );
        $validatorErrors = $this->validateInputs($validationRules, $data);

        if (!empty($validatorErrors)) {
            $this->getMeta()->addMessage(META::STATUS_ERROR, $validatorErrors);
            $response->setData(array('data' => $data));
            return $response;
        }
        try {
            if (!$this->getMeta()->hasError()) {
                $MHCActivityTimeService = $this->get('medicore.calendar.appointment.participation.mhcactivitytime_service');
                $data = $MHCActivityTimeService->storeMHCActivityTime($appointmentId, $code, $activityTimeData);
                $this->getMeta()->setCount(count($data));
                $response->setData(array('data' => $data));
            }
        } catch (Exception $e) {
            $this->logException($e);
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->add(
                    'MG21',
                    MessageHandler::BLOCKING
                )
            );
        }

        return $response;
    }

    /**
     * The time registered for the activity associated to the appointment.
     *
     * @SWG\Api(
     *   path="/api/v2/calendar-appointment-type-mhcactivity",
     *   description="The time registered for the activity associated to the appointment",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="The time registered for the activity associated to the appointment",
     *           @SWG\Parameter(
     *              name="appointmentTypeId",
     *              description="Id of the appointment Type",
     *              type="string",
     *              paramType="query",
     *              required=true
     *           ),
     *           @SWG\Parameter(
     *              name="appointmentDate",
     *              description="Date of the appointment",
     *              type="string",
     *              paramType="query",
     *              required=true
     *           ),
     *           @SWG\ResponseMessage(
     *              code=200,
     *              message="json {messages => 'user_messages', data => 'records'}"
     *           )
     *       )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Actinidium\API\Response\JsonResponse $JsonResponse
     */
    public function getListAction(Request $request)
    {
        $data = array();
        $response = new JsonResponse();
        $MHCActivityService = $this->get('medicore.calendar.appointment.type.mhcactivity_service');
        $appointmentTypeId = $request->query->get('appointmentTypeId');
        $appointmentDate = $request->query->get('appointmentDate');
        $data = array(
            'appointmentTypeId' => $appointmentTypeId,
            'appointmentDate' => $appointmentDate
        );
        $validationRules = array(
            'appointmentTypeId' => 'isPositiveInteger',
            'appointmentDate' => 'date'
        );
        $validatorErrors = $this->validateInputs($validationRules, $data);

        if (!empty($validatorErrors)) {
            $this->getMeta()->addMessage(META::STATUS_ERROR, $validatorErrors);
            $response->setData(array('data' => $data));
            return $response;
        }
        $appointmentDate = new DateTime($appointmentDate);
        try {
            if (!$this->getMeta()->hasError()) {
                $MHCActivityDetails = $MHCActivityService->getMHCActivityDetails(
                    $appointmentTypeId,
                    $appointmentDate
                );
                if (null == $MHCActivityDetails) {
                    $response->setData(array('data' => null));
                    return $response;
                }
                $data = $MHCActivityService->toArray($MHCActivityDetails);
                $this->getMeta()->setCount(count($data));
                $response->setData(array('data' => $data));
            }
        } catch (Exception $e) {
            $this->logException($e);
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->add(
                    'MG21',
                    MessageHandler::BLOCKING
                )
            );
        }

        return $response;
    }

    /**
     * Validate the given inputs.
     *
     * @param array $validationRules
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return array
     */
    private function validateInputs(array $validationRules, $data)
    {
        $errors = array();
        if (count($validationRules) === 0) {
            return $errors;
        }
        foreach ($validationRules as $validationInput => $validationRule) {
            if (Sanitizer::$validationRule($data[$validationInput]) === false) {
                $errors[$validationInput] = 'Invalid input for ' . $validationInput;
            }
        }

        return $errors;
    }
}
