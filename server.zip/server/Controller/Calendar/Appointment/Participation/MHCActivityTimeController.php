<?php

namespace Controller\Calendar\Appointment\Participation;

use Controller\AbstractController;
use Actinidium\API\Response\Meta;
use Security\Sanitizer;
use Exception;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Message\MessageHandler;

/**
 * MHCActivityTime controller.
 *
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/calendar-appointment-participation-mhcactivitytime",
 *     basePath="/api/v2/"
 * )
 */
class MHCActivityTimeController extends AbstractController
{
    /**
     * @var const DEFAULT_LANGUAGE default language (dutch)
     */
    const DEFAULT_LANGUAGE = 'nl';

    /**
     * Gets time registered of an activity for the appointment.
     *
     * @SWG\Api(
     *   path="/api/v2/calendar-appointment-participation-mhcactivitytime",
     *   description="Gets time registered of an activity for the appointment",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Get a list of resources from a collection.",
     *           notes="Returns some stuff",
     *           @SWG\Parameter(
     *              name="appointmentId",
     *              description="Id of the appointment",
     *              type="integer",
     *              paramType="query",
     *              required=true
     *           ),
     *           @SWG\ResponseMessage(
     *              code=200,
     *              message="json {messages => 'user_messages', data => 'records'}"
     *           )
     *       )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function getListAction(Request $request)
    {
        $data = array();
        $response = new JsonResponse();
        $MHCActivityTimeService = $this->get('medicore.calendar.appointment.participation.mhcactivitytime_service');
        $appointmentId = $request->query->get('appointmentId');

        $validationRules = array(
            'appointmentId' => 'isPositiveInteger',
            'appointmentDate' => 'date'
        );
        $validatorErrors = $this->validateInputs($validationRules, $request);
        if (!empty($validatorErrors)) {
            $this->getMeta()->addMessage(META::STATUS_ERROR, $validatorErrors);
            $response->setData(array('data' => $data));
            return $response;
        }
        try {
            if (!$this->getMeta()->hasError()) {
                $data = $MHCActivityTimeService->getMHCActivityTimeDetails($appointmentId);
                $this->getMeta()->setCount(count($data));
                $response->setData(array('data' => $data));
            }
        } catch (Exception $e) {
            $this->logException($e);
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->add(
                    'MG21',
                    MessageHandler::BLOCKING
                )
            );
        }

        return $response;
    }

    /**
     * Validate the given inputs.
     *
     * @param array $validationRules
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return array
     */
    private function validateInputs(array $validationRules, Request $request)
    {
        if (count($validationRules) === 0) {
            return $errors;
        }

        foreach ($validationRules as $validationInput => $validationRule) {
            if (Sanitizer::$validationRule($request->query->get($validationInput)) === false) {
                $errors[$validationInput] = 'Invalid input for ' . $validationInput;
            }
        }

        return $errors;
    }
}
