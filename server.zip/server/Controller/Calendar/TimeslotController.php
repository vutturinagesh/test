<?php
namespace Controller\Calendar;

use Actinidium\API\RestBaseController;
use Actinidium\API\Response\Meta;
use Calendar\AppointmentService;
use Calendar\Interval;
use Calendar\ParticipantService;
use Calendar\QuickSearch\TimeslotService;
use Generic\Calendar;

/**
 * TimeslotController
 */
class TimeslotController extends RestBaseController
{
    /**
     * @var TimeslotService
     */
    protected $timeslotService;

    /**
     * Get timeslot domain service
     *
     * @return TimeslotService
     */
    private function getTimeslotService()
    {
        if (!$this->timeslotService) {
            $this->timeslotService = new TimeslotService();
        }

        return $this->timeslotService;
    }

    /**
     * Set the timeslotService
     *
     * @param TimeslotService $service
     *
     * @return void
     */
    public function setTimeslotService(TimeslotService $service)
    {
        $this->timeslotService = $service;
    }

    /**
     * Get available timeslot
     *
     * @param mixed $data
     *
     * @return void
     *
     * @throws \Exception
     */
    public function getAction($data)
    {
        throw new \Exception(__METHOD__ . ' is not implemented');
    }

    /**
     * Get available timeslots
     *
     * @return boolean
     */
    public function getListAction()
    {
        $data = $this->getRequest()->query;

        $this->getTimeslotService();

        $validator = $this->timeslotService->getValidator();
        $dataArray = $data->all();

        $validator->setData($dataArray);
        if($validator->isValid()) {
            $this->timeslotService->populate($validator->getValues());

            return $this->timeslotService->getAvailableTimeslots();
        } else {
            // Handle errors
            $meta = $this->getMeta();
            foreach($validator->getMessages() as $field => $messages) {
                $meta->addMessage(Meta::STATUS_ERROR, array(
                    'field' => $field,
                    'errors'=> $messages
                ));
            }

            return false;
        }
    }

    /**
     * Create a new timeslot
     *
     * @param array $data
     *
     * @return void
     *
     * @throws \Exception
     */
    public function createAction($data)
    {
        throw new \Exception(__METHOD__ . ' is not implemented');
    }

    /**
     * Update a timeslot
     *
     * @param int $id
     * @param array $data
     *
     * @return void
     *
     * @throws \Exception
     */
    public function updateAction($id, $data)
    {
        throw new \Exception(__METHOD__ . ' is not implemented');
    }

    /**
     * Delete a timeslot
     *
     * @param int $id
     *
     * @return void
     *
     * @throws \Exception
     */
    public function deleteAction($id)
    {
        throw new \Exception(__METHOD__ . ' is not implemented');
    }

    /**
     * Delete multiple timeslots
     *
     * @return void
     *
     * @throws \Exception
     */
    public function deleteListAction()
    {
        throw new \Exception(__METHOD__ . ' is not implemented');
    }
}
