<?php
namespace Controller\Calendar;

use Actinidium\API\RestBaseController;
use Actinidium\API\Response\Meta;
use Calendar\Appointment\StatusService;

/**
 * StatusController
 *
 * Callable via /api/calendar-status
 */
class StatusController extends RestBaseController
{
    /**
     * @var StatusService
     */
    private $statusService;

    /**
     * Get the StatusService
     *
     * @return StatusService
     */
    private function getStatusService()
    {
        if (!$this->statusService) {
            $this->statusService = new StatusService();
        }

        return $this->statusService;
    }

    /**
     * Get status by identity
     *
     * @param mixed $id
     * @return null
     * @throws \Exception
     */
    public function getAction($id)
    {
        throw new \Exception(__METHOD__.' is not implemented');
    }

    /**
     * Get list of statuses
     *
     * Allowed query parameters are:
     *  - includeId (int) Identity of status that MUST be in this list (even if not active)
     *
     * @return array
     */
    public function getListAction()
    {
        $service = $this->getStatusService();
        $query = $this->getRequest()->query;

        $criteria = array();
        if ($query->has('active')) {
            $criteria['active'] = $query->get('active') == 'true';
        }
        if ($query->has('includeId')) {
            $criteria['includeId'] = $query->getDigits('includeId');
        }

        $orderBy = array('name' => 'ASC');

        $statusList = $service->findBy($criteria, $orderBy);

        $data = array();
        foreach ($statusList as $status) {
            $data[] = $status->toArray();
        }

        return $data;
    }

    /**
     * Create a status
     *
     * @param array $data
     * @return null
     * @throws \Exception
     */
    public function createAction($data)
    {
        throw new \Exception(__METHOD__.' is not implemented');
    }

    /**
     * Update a status
     *
     * @param int $id
     * @param array $data
     * @return null
     * @throws \Exception
     */
    public function updateAction($id, $data)
    {
        throw new \Exception(__METHOD__.' is not implemented');
    }

    /**
     * Delete a status
     *
     * @param int $id
     * @return null
     * @throws \Exception
     */
    public function deleteAction($id)
    {
        throw new \Exception(__METHOD__.' is not implemented');
    }

    /**
     * Delete multiple statuses
     *
     * @return null
     * @throws \Exception
     */
    public function deleteListAction()
    {
        throw new \Exception(__METHOD__.' is not implemented');
    }
}
