<?php

namespace Controller;

use Actinidium\API\RestBaseController;
use System\SmsReleaseService;
use Generic\CustomerService;
use Actinidium\API\Response\CachedJsonResponse;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/extranet",
 *     basePath="/api/v2"
 * )
 */
class ExtranetController extends RestBaseController
{
    /**
     * Get resource by id
     *
     * @param int $id
     * @return null
     */
    public function getAction($id)
    {
        $this->getMeta()->addMessage(Meta::STATUS_ERROR, 'Not implemented');

        return null;
    }

    /**
     * Create new resource
     *
     * @param array $data
     * @return null
     */
    public function createAction($data)
    {
        $this->getMeta()->addMessage(Meta::STATUS_ERROR, 'Not implemented');

        return null;
    }

    /**
     * Update resource
     *
     * @param int $id
     * @param array $data
     * @return null
     */
    public function updateAction($id, $data)
    {
        $this->getMeta()->addMessage(Meta::STATUS_ERROR, 'Not implemented');

        return null;
    }

    /**
     * Delete resource
     *
     * @param int $id
     * @return null
     */
    public function deleteAction($id)
    {
        $this->getMeta()->addMessage(Meta::STATUS_ERROR, 'Not implemented');

        return null;
    }

    /**
     * Delete multiple resources
     *
     * @return null
     */
    public function deleteListAction()
    {
        $this->getMeta()->addMessage(Meta::STATUS_ERROR, 'Not implemented');

        return null;
    }

    /**
     * @SWG\Api(
     *   path="/extranet",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Find current revision and extranet messages",
     *           notes="Returns version",
     *       )
     * )
     *
     * @return CachedJsonResponse
     */
    public function getListAction()
    {
        $response = new CachedJsonResponse();

        $items = $this->getExtranetMessages();
        $list = array();
        foreach ($items as $item) {
            $date = new \DateTime($item['pubdate']);
            $listItem = array(
                'title' => $item['title'],
                'date' => $date->format(\Config\Date::FORMAT_DATETIME),
                'href' => $item['link']
            );
            $list[] = $listItem;
        }
        $this->getMeta()->setCount(count($items));
        $response->setData(array('data' => $list));

        return $response;
    }

    /**
     * Retrieve extranet messages
     *
     * @return array List with messages
     */
    protected function getExtranetMessages()
    {
        if (defined('EXTRANET_FEED_URL')) {
            //get extranet messages
            $rssFeed = file_get_contents(EXTRANET_FEED_URL);
            $rssReader = new \System_RSS($rssFeed, 'UTF-8');

            return $rssReader->getItems();
        } 
        return array();
    }
}
