<?php
/**
 * Created by JetBrains PhpStorm.
 * User: eddy.de.boer
 * Date: 20-6-13
 * Time: 13:22
 * To change this template use File | Settings | File Templates.
 */

namespace Controller\Episode;

use Actinidium\API\MetaBaseController;
use Actinidium\API\Response\Meta;
use Generic\PatientService;
use Generic\Referrer\QuickReferrerService;
use Generic\SpecialismService;
use Medical\Episode;
use Medical\EpisodeService;
use Generic\SystemInstitutionService;
use Generic\SystemProviderService;
use Generic\Referrer\IndividualService;
use Generic\Referrer\OrganizationService;
use Generic\Referrer\SelfInitiativeService;
use Controller\AbstractController;

/**
 * Callable via /api/medical-episode/:action where :action is one of the public *Action methods
 * @property \Generic\ patientModel
 * @package Controller
 */
class ReferrerController extends AbstractController
{
    private $patientModel;
    private $specialtyModel;
    private $episodeModel;
    private $quickSearchModel;
    private $model;

    public function __construct()
    {
        parent::__construct();
        $this->episodeModel = $this->getEpisodeModel();
    }

    /**
     *
     * @return EpisodeService
     */
    protected function getEpisodeModel()
    {
        if (!$this->model) {
            $this->model = new EpisodeService();
        }
        return $this->model;
    }

    /**
     * @return QuickReferrerService
     */
    protected function getQuickReferrerModel()
    {
        if (!$this->quickSearchModel) {
            $this->quickSearchModel = new QuickReferrerService();
        }

        return $this->quickSearchModel;
    }

    /**
     * @return array|mixed|void
     */
    public function getListAction()
    {
        $this->data = array();
        $this->episodeArray = array();
        $query = $this->getRequest()->query;
        
        if ($query->has('episodeId')) {
            $episode = $this->createEntity(
                $query->get("episodeId"),
                'episodeId',
                $this->episodeModel,
                "Medical\\Episode"
            );
            $controller = new \Controller\ViewReferrer();
            $this->data['referrer'] = $controller->viewReferrer($episode);
        } elseif ($query->has('specialtyId')) {
            $criteria = array();
            $specialty = $this->createEntity(
                $query->get('specialtyId'),
                'specialtyId',
                $this->getSpecialismService(),
                "Generic\\Specialism"
            );
            $criteria['specialty'] = $specialty;
            if ($query->has('patientId')) {
                $patient = $this->createEntity(
                    $query->get('patientId'),
                    'patientId',
                    $this->getPatientService(),
                    "Generic\\Patient"
                );
                $criteria['patient'] = $patient;
            }

            if (!$this->getMeta()->hasError()) {
                $this->data = $this->getQuickReferrerModel()->findReferrers($criteria);
                $this->getMeta()->setCount(count($this->data));
            }
        }
        return $this->data;
    }

    /**
     * @return PatientService
     */
    protected function getPatientService()
    {
        if (!$this->patientModel) {
            $this->patientModel = new PatientService();
        }
        return $this->patientModel;
    }

    /**
     * @param PatientService $patientService
     */
    public function setPatientService(PatientService $patientService)
    {
        $this->patientModel = $patientService;
    }

    /**
     * @return SpecialismService
     */
    protected function getSpecialismService()
    {
        if (!$this->specialtyModel) {
            $this->specialtyModel = new SpecialismService();
        }
        return $this->specialtyModel;
    }

    /**
     * @param SpecialismService $specialtyService
     */
    public function setSpecialismService(SpecialismService $specialtyService)
    {
        $this->specialtyModel = $specialtyService;
    }
    
    /** @todo */
    public function getAction($id)
    {
        
    }
}
