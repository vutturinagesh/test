<?php
namespace Controller\Episode\Pm;

use Actinidium\API\MetaBaseController;
use Actinidium\API\Response\Meta;

use Medical\EpisodeService;
use Medical\EpisodeParaMedicalDiagnoseService;
use Controller\AbstractController;
use Security\Sanitizer;
use Controller\EpisodeController;
use Medical\TreatmentService;
use Medical\Treatment;

/**
 * Controller to handle GET, POST, UPDATE, DELETE requests for treatment profiles
 * @package Controller
 */
class DiagnosisController extends AbstractController
{
    private $episodeModel;
    private $episode;
    
    public function __construct()
    {
        parent::__construct();
        $this->episodeModel = $this->getEpisodeModel();
    }

    /**
     *
     * @return EpisodeService
     */
    private function getEpisodeModel()
    {
        if (!$this->model) {
            $this->model = new EpisodeService();
        }
        return $this->model;
    }


    public function createAction($data)
    {
        $this->data = array();
        $validatedData = array();

        $validatedData['episode'] = $this->validateEpisodeId($data['episodeId']);

        $episodeController = new EpisodeController();
        if (!$this->getMeta()->hasError() && !$episodeController->isEpisodeWritable($validatedData['episode'])) {
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne('EMPM102')
            );
            return $this->data;
        }

        if ($this->episode instanceof \Medical\Episode) {
            if (!($this->episode->isOpen())) {
                $this->addMessage(Meta::STATUS_ERROR,'M157');
            } 
            if(!$this->hasValidTreatmentType()) {
                $this->addMessage(Meta::STATUS_ERROR,'M522');
            }
        }
        
        if (array_key_exists("accident", $data)) {
            $validatedData['accidentFlag'] = $this->validateBoolean($data['accident'], "accident");
        }

        if (array_key_exists("diagnosis", $data)) {
            if (mb_strlen($data['diagnosis']) == 0) {
                $validatedData['diagnosis'] = null;
            } else {
                $validatedData['diagnosis'] = $this->validatePMDiagnosisId($data['diagnosis']);
            }
        }

        if (!$this->getMeta()->hasError()) {
            $result = $this->model->editParaMedicalDiagnose($validatedData);
            if ($result) {
                $this->data = $validatedData['episode']->toArray();
            }
        }
        
        return $this->data;
    }

    /**
     * validateEpisodeId
     *
     * @param int $id
     * @return \Medical\Episode
     */
    private function validateEpisodeId($id)
    {
        $this->episode = $this->createEntity(
            $id,
            'episodeId',
            $this->episodeModel,
            "Medical\\Episode"
        );
        return $this->episode;
    }

    /**
     * hasValidTreatmentType
     *
     * @return boolean
     */
    private function hasValidTreatmentType()
    {
        if (!$this->episode->hasTreatments()) {
            return false;
        }
            
        $treatments = $this->episode->getTreatments();
        $treatmentModel = new treatmentService();
        return $treatmentModel->hasValidTreatmentType($treatments[0], Treatment::TYPE_PM);
    }
    
    /**
     * validatePMDiagnosisId
     *
     * @param    string $diagnosis
     * @return   string|boolean
     */
    public function validatePMDiagnosisId($diagnosis)
    {
        if ($this->isEntityIdPositiveInteger($diagnosis, "diagnosis")) {

            if (!\Security\Sanitizer::isValidLengthString($diagnosis, 4)) {
                $this->getMeta()->addMessage(
                    Meta::STATUS_ERROR,
                    $this->messageHandler->getOne('M506')
                );
                return false;
            }

            $paraMediacalDiagnoseService = new \System\ParaMedicalDiagnoseService();
            if ($paraMediacalDiagnoseService->isValidCombination($diagnosis)) {
                return $diagnosis;
            } else {
                $this->getMeta()->addMessage(
                    Meta::STATUS_ERROR,
                    $this->messageHandler->getOne('GV9', array('object' => "diagnosis", 'input' => $diagnosis))
                );
            }
        }
        return false;
    }

}
