<?php

namespace Controller\Episode\MHC\Diagnosis;

use Actinidium\API\HTTPRequest;
use Actinidium\API\Response\Meta;
use Actinidium\API\Router;
use Controller\AbstractController;
use Exception;
use Generic\Authorizer;
use Medical\Episode;
use Medical\EpisodeService;
use Medical\MHC\DiagnoseService as MhcDiagnoseService;
use Security\Sanitizer;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use System\MHC\Diagnose as SystemMhcDiagnose;
use System\MHC\DiagnoseService as SystemMhcDiagnoseService;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/episode/mhc/diagnosis",
 *     basePath="/api/v2"
 * )
 */
class PrimaryController extends AbstractController
{
    /**
     * @var \Medical\EpisodeService
     */
    private $episodeService;

    /**
     * @var \Medical\MHC\DiagnoseService
     */
    private $medicalMhcDiagnoseService;

    /**
     * @var \System\MHC\DiagnoseService
     */
    private $systemMhcDiagnoseService;

    /**
     * @var \System\MHC\Diagnose
     */
    private $systemMhcDiagnose;

    /**
     * @var \Generic\Authorizer
     */
    private $authorizer;

    /**
     * Instantiate the controller with all its dependencies.
     *
     * If some are not injected fetch them from the container.
     *
     * @param \Medical\EpisodeService      $episodeService
     * @param \Medical\MHC\DiagnoseService $mhcDiagnoseService
     * @param \System\MHC\DiagnoseService  $systemMhcDiagnoseService
     * @param \Generic\Authorizer          $authorizer
     */
    public function __construct(
        EpisodeService           $episodeService = null,
        MhcDiagnoseService       $mhcDiagnoseService = null,
        SystemMhcDiagnoseService $systemMhcDiagnoseService = null,
        Authorizer               $authorizer = null
    ) {
        parent::__construct();

        if (null === $episodeService) {
            $episodeService = $this->get('medicore.medical.episode_service');
        }

        if (null === $mhcDiagnoseService) {
            $mhcDiagnoseService = $this->get('medicore.medical.treatment.mhc.diagnose_service');
        }

        if (null === $systemMhcDiagnoseService) {
            $systemMhcDiagnoseService = $this->get('medicore.system.diagnose_mhc_service');
        }

        if (null === $authorizer) {
            $authorizer = $this->get('medicore.generic.authorizer');
        }

        $this->systemMhcDiagnose = null;

        $this->episodeService            = $episodeService;
        $this->medicalMhcDiagnoseService = $mhcDiagnoseService;
        $this->systemMhcDiagnoseService  = $systemMhcDiagnoseService;
        $this->authorizer                = $authorizer;
    }

    /**
     *  @SWG\Api(
     *      path="/episode/mhc/diagnosis/primary",
     *      @SWG\Operation(
     *          summary="set primary diagnosis",
     *          method="POST",
     *          type="Episode",
     *          @SWG\Parameter(
     *              name="episodeId",
     *              description="Id of the episode.",
     *              type="integer",
     *              paramType="query",
     *              required=true
     *          ),
     *          @SWG\Parameter(
     *              name="body",
     *              description="Medical Diagnose object, see toArray as reference.",
     *              required=true,
     *              type="\Medical\MHC\Diagnose",
     *              paramType="body",
     *              allowMultiple=false
     *          )
     *      )
     *  )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function createAction(Request $request)
    {
        $response = new JsonResponse();

        $contentData = json_decode($request->getContent(), true);
        $episodeId = $request->query->get('episodeId');
        $episode = $this->validateEpisodeId($episodeId);

        $this->checkUserEpisodeAccessMode($episode);

        $errors = $this->validateDiagnosisId($contentData['diagnose']['id'], $episode);
        if (!empty($errors)) {
            foreach ($errors as $error) {
                $this->getMeta()->addMessage(
                    $error['type'],
                    $this->messageHandler->getOne($error['id'], $error['params'])
                );
            }
        } else {
            $this->systemMhcDiagnose = $this->systemMhcDiagnoseService->find($contentData['diagnose']['id']);
        }

        $data = $this->validateInputData($request);

        try {
            if (!$this->getMeta()->hasError()) {
                $data['diagnose'] = $this->systemMhcDiagnose;
                $result = $this->episodeService->setPrimaryDiagnoseMHC($episode, $data);

                if ($result) {
                    $response->setData(array('data' => $episode->toArray())) ;
                }
            }
        } catch (Exception $e) {
            $this->getMeta()->addMessage(META::STATUS_ERROR, $e->getMessage());
        }

        return $response;
    }

    /**
     * @SWG\Api(
     *  path="/episode/mhc/diagnosis/primary",
     *  @SWG\Operation(
     *      summary="Update the primary diagnose",
     *      method="PUT",
     *      type="Episode",
     *      @SWG\Parameter(
     *          name="episodeId",
     *          description="Id of the episode.",
     *          type="integer",
     *          paramType="query",
     *          required=true
     *      ),
     *      @SWG\Parameter(
     *          name="body",
     *          description="Medical Episode object, see toArray as reference.",
     *          required=true,
     *          type="\Medical\MHC\Episode",
     *          paramType="body",
     *          allowMultiple=false
     *      )
     *   )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function updateAction(Request $request)
    {
        $response = new JsonResponse();

        $episodeId = $request->query->get('episodeId');
        $episode = $this->validateEpisodeId($episodeId);

        if ($episode !== null) {
            $this->checkUserEpisodeAccessMode($episode);
            $primaryDiagnosis = $episode->getMHCEpisode();

            if ($primaryDiagnosis === null) {
                $this->getMeta()->addMessage(
                    Meta::STATUS_ERROR,
                    $this->messageHandler->getOne('M524')
                );
            } else {
                $this->systemMhcDiagnose = $primaryDiagnosis->getSystemDiagnose();
            }
        }

        $data = $this->validateInputData($request);

        try {
            if (!$this->getMeta()->hasError()) {
                $result = $this->episodeService->updatePrimaryDiagnosis($episode, $data);
                if ($result) {
                    $response->setData(array('data' => $episode->toArray())) ;
                }
            }
        } catch (Exception $e) {
            $this->getMeta()->addMessage(META::STATUS_ERROR, $e->getMessage());
        }

        return $response;
    }

    /**
     * @SWG\Api(
     *  path="episode/mhc/diagnosis/primary/get",
     *      @SWG\Operation(
     *          method="GET",
     *          summary="Retrieve primary diagnose of an episode.",
     *          @SWG\Parameter(
     *              name="episodeId",
     *              description="Id of the episode.",
     *              type="integer",
     *              paramType="query",
     *              required=true
     *           )
     *       )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function getAction(Request $request)
    {
        $response = new JsonResponse();

        $requestParameters = $request->query->all();

        $episode = $this->validateEpisodeId($requestParameters['episodeId']);

        $this->checkUserEpisodeAccessMode($episode, false);

        if (!$this->getMeta()->hasError()) {
            $mhcPrimaryDiagnosis = $episode->getPrimaryDiagnosis();

            $data = (($mhcPrimaryDiagnosis !== null) ? $mhcPrimaryDiagnosis->toListArray() : null);
            if ($mhcPrimaryDiagnosis) {
                $response->setData(
                    array('data' => $data)
                );
            }
        }

        return $response;
    }

    /**
     * @SWG\Api(
     *  path="/episode/mhc/diagnosis/primary",
     *  @SWG\Operation(
     *      summary="Deletes primary diagnosis.",
     *      method="DELETE",
     *      @SWG\Parameter(
     *          name="episodeId",
     *          description="Id of the episode.",
     *          type="integer",
     *          paramType="query",
     *          required=true
     *      )
     *   )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function deleteAction(Request $request)
    {
        $response = new JsonResponse();

        $episode = $this->validateEpisodeId($request->get('episodeId'));

        $this->checkUserEpisodeAccessMode($episode);

        if (!$this->getMeta()->hasError()) {
            $response->setData(array('data' => $this->episodeService->setPrimaryDiagnoseMHC($episode, array())));
        }

        return $response;
    }

    /**
     * Validate the episode.
     *
     * @param int $id
     *
     * @return \Medical\Episode|bool
     */
    protected function validateEpisodeId($id)
    {
        $episode = $this->createEntity(
            $id,
            'episodeId',
            $this->episodeService,
            "Medical\\Episode"
        );

        if (($episode !== null) && ($this->episodeService->isAnyTreatmentClosed($episode))) {
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne('M505')
            );
        }

        return $episode;
    }

    /**
     * Validates the input parameters from the request.
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return array
     */
    protected function validateInputData(Request $request)
    {
        $data = array();

        $contentData = json_decode($request->getContent(), true);

        if (($request->getMethod() === 'POST') ||  array_key_exists('date', $contentData)) {
            $data['date'] = $this->validateDiagnosisDate($contentData['date']);
        }

        if (array_key_exists('symptomsOf', $contentData) && ($this->systemMhcDiagnose !== null)) {
            $data['symptomsOf'] = $this->validateSymptomsOf($this->systemMhcDiagnose, $contentData['symptomsOf']);
        }

        if (array_key_exists('remark', $contentData)) {
            $data['remark'] = $this->validateRemark($contentData['remark']);
        }

        return $data;
    }

    /**
     * Validate the diagnose.
     *
     * @param int $diagnoseId
     * @param \Medical\Episode|null $episode
     *
     * @return array
     */
    private function validateDiagnosisId($diagnoseId, Episode $episode = null)
    {
        $startDate = null;

        if ($episode) {
            $startDate = $episode->getStartDate();
        }

        return $this->medicalMhcDiagnoseService->validatePrimaryDiagnoseId($diagnoseId, $startDate);
    }

    /**
     * Validate the remark field.
     *
     * @param string $remark
     * @param int    $limit
     *
     * @access private Access lowered due to unit testing.
     *
     * @return null|string
     */
    protected function validateRemark($remark, $limit = 255)
    {
        if (!Sanitizer::isStringLengthIsValid($remark, $limit)) {
            $params = array(
                'field_name' => "remark",
                'expected' => "Maximum of ".$limit." characters",
                'actual' => $remark,
                'max_length' => $limit
            );

            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne('MG100', $params)
            );
        } else {
            return $remark;
        }
    }

    /**
     * Validate if the diagnose date passed is actually a valid date.
     *
     * @param string $date
     *
     * @access private Access lowered due to unit testing.
     *
     * @return \DateTime|null
     */
    protected function validateDiagnosisDate($date)
    {
        return $this->validateDate($date, "date");
    }

    /**
     * Validate the input for the symptoms of field.
     *
     * @param \System\MHC\Diagnose $diagnose
     * @param boolean              $symptomsOf
     *
     * @access private Access lowered due to unit testing.
     *
     * @return boolean
     */
    protected function validateSymptomsOf(SystemMhcDiagnose $diagnose, $symptomsOf)
    {
        if (!Sanitizer::isBoolean($symptomsOf)) {
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne(
                    'MG101',
                    array('field_name' => "symptomsOf", 'input' => $symptomsOf)
                )
            );
        } else {
            $symptomsOf = Sanitizer::boolean($symptomsOf);

            if ($diagnose) {
                return $diagnose->getValidSymptomsOf($symptomsOf);
            }
        }
    }

    /**
     * Checks whether the user has write/read premissions for the Episode.
     *
     * @param \Medical\Episode $episode
     * @param boolean          $writeAccess
     */
    protected function checkUserEpisodeAccessMode(Episode $episode, $writeAccess = true)
    {
        if (!$this->hasError()) {
            if ($writeAccess) {
                $allowed = $this->authorizer->isEpisodeWritable($episode);
            } else {
                $allowed = $this->authorizer->isEpisodeAccessible($episode);
            }

            if (!$allowed) {
                $this->getMeta()->addMessage(
                    Meta::STATUS_ERROR,
                    $this->messageHandler->getOne('UR3')
                );
            }
        }
    }
}
