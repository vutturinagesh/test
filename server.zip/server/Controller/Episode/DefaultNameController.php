<?php
namespace Controller\Episode;

use Actinidium\API\MetaBaseController;
use Actinidium\API\Response\Meta;

use Medical\EpisodeService;
use Controller\AbstractController;
use Generic\PatientService;
use Generic\SpecialismService;

class DefaultNameController extends AbstractController
{
    private $episodeModel;
    
    public function __construct()
    {
        parent::__construct();
        $this->episodeModel = $this->getEpisodeModel();
    }

    /**
     *
     * @return EpisodeService
     */
    private function getEpisodeModel()
    {
        if (!$this->model) {
            $this->model = new EpisodeService();
        }
        return $this->model;
    }

    public function getListAction()
    {
        $this->data = array();
        $query = $this->getRequest()->query;
        
        if ($this->isSomatic()) {
            $patient = $this->validatePatientId($query->get("patientId"));
            if ($query->has('specialtyId')) {
                $specialty = $this->validateSpecialtyId($query->get("specialtyId"));
            }

            if (!$this->getMeta()->hasError()) {
                $data = array();
                $data['name'] = $this->model->getDefaultName($patient, $specialty);
                $this->data = $data;
            }
        }
        return $this->data;
    }

    /**
     * @param int $patientId
     * @return Generic\Patient | null
     */
    private function validatePatientId($patientId)
    {
        $patientModel = new PatientService();
        $patient = $this->createEntity($patientId, "patientId", $patientModel, "Generic\\Patient");
        
        return $patient;
    }

    /**
     * @param int $specialtyId
     * @return Generic\Specialism | null
     */
    private function validateSpecialtyId($specialtyId)
    {
        $specialtyModel = new SpecialismService();
        $specialty = $this->createEntity($specialtyId, "specialtyId", $specialtyModel, "Generic\\Specialism");

        return $specialty;
    }
}
