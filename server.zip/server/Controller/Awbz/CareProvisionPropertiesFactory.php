<?php
namespace Controller\Awbz;

use Actinidium\API\Response\Meta;
use Controller\AbstractController;
use Controller\EntityFactory;
use Security\Sanitizer;

/**
 * Class CareProvisionPropertiesFactory
 *
 * This Class is responsible for creating the properties for a CareProvision.
 * In case of preliminary, there are more fields optional than in case of definitive.
 */
class CareProvisionPropertiesFactory
{

    /**
     * Creates the properties for a preliminary CareProvision
     * The difference with a definitve one is that less properties are mandatory in a preliminary CareProvision
     *
     * @param AbstractController $controller
     * @param $data
     *
     * @return array
     */
    public function preliminary(AbstractController $controller, $data)
    {
        $params = array();
        $params += $this->fillMandatory($controller, $data);
        $params += $this->fillOptional($controller, $data);

        $params['clinic'] = null;
        if (!is_null($data['clinic'])) {
            $params['clinic'] = EntityFactory::clinic($controller, $data['clinic']['id']);
        }
        $params['coordinator'] = null;
        if (!is_null($data['coordinator'])) {
            $params['coordinator'] = EntityFactory::employee($controller, $data['coordinator']['id']);
        }
        $params['endDate'] = null;
        if (!is_null($data['endDate'])) {
            $params['endDate'] = $controller->validateDate($data['endDate'], 'endDate');
        }
        $params['deliveryStatus'] = null;
        if (!is_null($data['deliveryStatus'])) {
            $params['deliveryStatus'] = EntityFactory::awbzDeliveryStatus($controller, $data['deliveryStatus']['id']);
        }
        $params['deadline'] = null;
        if (!is_null($data['deadline'])) {
            $params['deadline'] = $controller->validateDate($data['deadline'], 'deadline');
        }

        return $params;
    }


    /**
     * Creates all the properties for a definitive CareProvision.
     *
     * @param AbstractController $controller
     * @param array $data
     *
     * @return array
     */
    public function definitive(AbstractController $controller, array $data)
    {
        $params = array();
        $params += $this->fillMandatory($controller, $data);
        $params['clinic'] = EntityFactory::clinic($controller, $data['clinic']['id']);
        $params['coordinator'] = EntityFactory::employee($controller, $data['coordinator']['id']);
        $params['endDate'] = $controller->validateDate($data['endDate'], 'endDate');
        $params['deadline'] = $controller->validateDate($data['deadline'], 'deadline');
        $params['deliveryStatus'] = EntityFactory::awbzDeliveryStatus($controller, $data['deliveryStatus']['id']);
        $params += $this->fillOptional($controller, $data);

        return $params;
    }

    /**
     * Fills the fields which are mandatory for preliminary as well as definitive
     *
     * @param AbstractController $controller
     * @param $data
     *
     * @return array
     */
    private function fillMandatory(AbstractController $controller, $data)
    {
        $params = array();

        $params['client'] = EntityFactory::patient($controller, $data['client']['id']);
        $params['ztwType'] = EntityFactory::ztwType($controller, $data['ztwType']['id']);
        $params['startDate'] = $controller->validateDate($data['startDate'], 'startDate');
        $params['amount'] = $controller->validateInteger($data['amount'], 'amount');
        $params['preliminary'] = $controller->validateBoolean($data['preliminary'], 'preliminary');
        $params['unit'] = EntityFactory::awbzUnit($controller, $data['unit']['id']);
        $params['frequency'] = EntityFactory::awbzFrequency($controller, $data['frequency']['id']);

        return $params;
    }

    /**
     * Create the properties that are optional for preliminary as well as definitive.
     *
     * @param AbstractController $controller
     * @param $data
     *
     * @return array
     */
    private function fillOptional(AbstractController $controller, $data)
    {
        $params = array();
        if (!Sanitizer::isStringLengthIsValid($data['remark'], 255)) {
            $controller->addMessage(Meta::STATUS_ERROR, 'MG100', array('field_name' => 'remark', 'max_length' => 255));
        }

        $params['remark'] = $data['remark'];

        if (array_key_exists('function', $data) &&
            !is_null($data['function']) &&
            array_key_exists('id', $data['function'])) {

            $params['function'] = EntityFactory::awbzFunction($controller, $data['function']['id']);
        } else if (array_key_exists('function', $data)) {
            $params['function'] = null;
        }

        if (array_key_exists('class', $data) &&
            !is_null($data['class']) &&
            array_key_exists('id', $data['class'])) {

            $params['class'] = EntityFactory::awbzClass($controller, $data['class']['id']);
        } else if (array_key_exists('class', $data)) {
            $params['class'] = null;
        }

        return $params;
    }
}
