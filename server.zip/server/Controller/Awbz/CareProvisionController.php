<?php

namespace Controller\Awbz;

use Controller\AbstractController;
use Awbz\CareProvision\FindService;
use Controller\EntityFactory;
use Awbz\CareProvision\AddService;
use Awbz\CareProvision\UpdateService;
use System\Awbz\DeliverystatusService;

/**
 * Class CareProvisionController
 * Dispatcher to determine which Usecases for CareProvision should be called.
 */
class CareProvisionController extends AbstractController
{
    /**
     * @var \Awbz\CareProvision\FindService
     */
    private $findService;

    /**
     * @var \Awbz\CareProvision\DeleteService
     */
    private $deleteService;

    /**
     * @var \Awbz\CareProvision\AddService
     */
    private $addModel;

    /**
     * @var \Awbz\CareProvision\UpdateService
     */
    private $updateModel;

    /**
     * @var Array
     */
    private $criteria = array();

    /**
     * Returns the careprovisions or employees.
     *
     * api/awbz-careProvision?deadline=yyyy-mm-dd filters on deadline
     * api/awbz-careProvision?deadline=employeeId=x filters on an employee
     * api/awbz-careProvision?deadline=employees returns all coordinators present in careProvision.
     *
     * @return array
     */
    public function getListAction()
    {
        $data = array();
        $orderBy = array();

        if ($this->getRequest()->query->has('employees')) {
            $data = $this->findEmployees();
            $this->getMeta()->setCount(count($data));

            return $data;
        }

        if ($this->getRequest()->query->has('preliminary')) {

            $this->preparePreliminaryCriteria();
        }

        if ($this->getRequest()->query->has('employeeId')) {
            $this->prepareEmployeeCriteria();
        }

        if ($this->getRequest()->query->has('deadline')) {
            $this->prepareDeadlineCriteria();
        }

        if ($this->getRequest()->query->has('ended')) {
           $this->prepareEndedCriteria();
        }

        if (!$this->getMeta()->hasError()) {
            $orderBy['deadline'] = 'ASC';

            $careProvisions = $this->getFindService()->findAllBy($this->criteria, $orderBy);

            if (!empty($careProvisions)) {
                foreach ($careProvisions as $careProvision) {
                    $data[] = $careProvision->toArray();
                }
            }
        }
        $this->getMeta()->setCount(count($data));

        return $data;
    }

    /**
     * Finds the coordinators for all careprovisions.
     *
     * @return array of \Generic\Employee
     */
    private function findEmployees()
    {
        $data = array();
        $employees = $this->getFindService()->findEmployees();
        if (count($employees)) {
            foreach ($employees as $employee) {
                $employeeArray = $employee->toListArray();
                $employeeArray['current'] = false;
                if ($employee->isCurrent()) {
                    $employeeArray['current'] = true;
                }
                $data[] = $employeeArray;
            }
        }
        return $data;
    }

    /**
     * Adds employee to criteria.
     */
    private function prepareEmployeeCriteria()
    {
        $this->criteria['employee'] = EntityFactory::employee($this, $this->getRequest()->query->get('employeeId'));
    }

    /**
     * To prepare preliminary criteria.
     */
    private function preparePreliminaryCriteria()
    {
        $this->criteria['preliminary'] = $this->validateBoolean(
            $this->getRequest()->query->get("preliminary"),
            'preliminary'
        );
    }

    /**
     * To prepare deadline criteria.
     */
    private function prepareDeadlineCriteria()
    {
        $this->criteria['deadline'] = $this->validateDate($this->getRequest()->query->get("deadline"), 'deadline');
    }

    /*
     * to Prepare Ended Criteria
     */
    private function prepareEndedCriteria()
    {
        $deliveryStatusService = new DeliverystatusService();
        $checkEndate = $this->validateBoolean(
            $this->getRequest()->query->get("ended"),
            'ended'
        );
        if ($checkEndate) {
            $this->criteria['ended'] = $deliveryStatusService->findNotEnded();
        }
    }

    /**
     * Creates the findService for you if it does not exists yet.
     * If you have already set it, maybe as a mock in your Unit tests, it leaves it alone.
     *
     * @return \Awbz\CareProvision\FindService
     */
    private function getFindService()
    {
        if (!$this->findService) {
            $this->findService = new \Awbz\CareProvision\FindService();
        }
        return $this->findService;
    }

    /**
     * Deletes a Care Provision.
     *
     * @param int $id
     *
     * @return Array
     */
    public function deleteAction($id)
    {
        $careProvision = $this->getCareProvision($id);

        if ($careProvision) {
            $this->data['success'] = $this->getDeleteService()->execute($careProvision);
        }

        return $this->data;
    }

    /**
     * Calls the factory to create a careProvision.
     *
     * @param int $id
     *
     * @return \Awbz\CareProvision
     */
    private function getCareProvision($id)
    {
        return $this->createEntity($id, 'id', $this->getFindService(), '\Awbz\CareProvision');
    }

    /**
     * Invoke new DeleteService, or use existing one.
     *
     * @return \Awbz\CareProvision\DeleteService
     */
    private function getDeleteService()
    {
        if (!$this->deleteService) {
            $this->deleteService = new \Awbz\CareProvision\DeleteService();
        }

        return $this->deleteService;
    }

    /*
     * Creates CareProvision.
     *
     * @param array $data
     *
     * @return array
     */
    public function createAction($data)
    {
        $this->data = array();
        $validatedObjects = $this->createObjects($data);
        if (!$this->hasError()) {
            $careProvision = $this->getAddModel()->execute($validatedObjects);
            if ($careProvision instanceof \Awbz\CareProvision) {
                $this->data = $careProvision->toArray();
            }
            return $this->data;
        }
    }

    /**
     * Gets the service to add a CareProvision.
     *
     * @return AddService
     */
    private function getAddModel()
    {
        if (!$this->addModel) {
            $this->addModel = new AddService();
        }
        return $this->addModel;
    }

    /**
     * Creates the objects needed to create/update a CareProvision
     *
     * @param array $data
     *
     * @return array
     */
    private function createObjects($data)
    {
        $factory = new CareProvisionPropertiesFactory();
        if ($data['preliminary'] == true) {
            $params = $factory->preliminary($this, $data);
        } else {
            $params = $factory->definitive($this, $data);
        }

        if (array_key_exists('id', $data) && !is_null($data['id'])) {
            $params['careProvision'] = EntityFactory::careProvision($this, $data['id']);
        }

        return $params;
    }

    /**
     * Updates a careProvision identified by $id by $data.
     *
     * @param integer $id
     * @param array $data
     *
     * @return array
     */
    public function updateAction($id, $data)
    {
        $this->data = array();
        $data['id'] = $id;
        $validatedObjects = $this->createObjects($data);
        if (!$this->hasError()) {
            $careProvision = $this->getUpdateModel()->execute($validatedObjects);
            if ($careProvision instanceof \Awbz\CareProvision) {
                $this->data = $careProvision->toArray();
            }
        }
        return $this->data;
    }

    /**
     * To avoid the "new" keyword, call this getter.
     *
     * @return UpdateService
     */
    private function getUpdateModel()
    {
        if (!$this->updateModel) {
            $this->updateModel = new UpdateService();
        }
        return $this->updateModel;
    }
}

