<?php

namespace Controller;

use Actinidium\API\RestBaseController;
use Factory\TranslatorFactory;
use Generic\User;
use Symfony\Component\HttpFoundation\JsonResponse;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/menu",
 *     basePath="/api/v2"
 * )
 */
class MenuController extends RestBaseController
{
    /**
     * const default language (dutch)
     */
    const DEFAULT_LANGUAGE = 'nl';

    const MENU_ITEM_PREFIX = 'menu_item_';

    /**
     * @var array
     */
    private $userData = null;

    /**
     * @var string
     */
    private $settingsLanguage;

    /**
     * @var array
     */
    private $menuItems;

    /*
     * @var array
     */
    private $activeFeatures;

    /**
     * @var array
     */
    private $sessionMenuItems;

    /**
     * @var \Symfony\Component\Translation\Translator
     */
    private $translator;

    /**
     * Sets the translator on this controller.
     */
    public function __construct()
    {
        parent::__construct();
        $this->translator = $this->get('medicore.translation.default');
    }

    /**
     * @SWG\Api(
     *   path="/menu",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Find menu by criteria",
     *           notes="Returns menu",
     *       )
     * )
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function getListAction()
    {
        $response = new JsonResponse();

        $userData = $this->getUserData();

        $menuItems = $this->getMenuItemsByUser((int) $userData['userId']);

        $params['userName'] = $userData['userName'];
        $params['menuItems'] = $menuItems;
        $activeFeaturesByUser = $userData['activeFeatures'];
        $params['activeFeatures'] = $activeFeaturesByUser;
        if ($this->getSettingsLanguage() != '') {
            $params['language'] = $this->getSettingsLanguage();
        } else if ($userData['defaultLanguage'] != '') {
            $params['language'] = $userData['defaultLanguage'];
        }
        $order['parentId'] = 'ASC';
        $order['order'] = 'ASC';

        $menuItems = $this->getMenuItems($params, $order);

        $activeFeatures = $this->getActiveFeatures();
        $menu = array();

        if (count($menuItems) > 0) {
            $menu = $this->processResult($menuItems, $activeFeatures, $activeFeaturesByUser);
        }

        $this->getMeta()->setCount(count($menu));
        $response->setData(array('data' => $menu));

        return $response;
    }
    
    /**
     * Function used to get menu items.
     *
     * @param  array $params
     * @param  array $order
     *
     * @return array menu items
     */
    protected function getMenuItems(array $params, array $order)
    {
        if(empty($this->menuItems)) {
            $menuItemService = new \System\MenuItemService();
            $this->menuItems = $menuItemService->findAllBy($params, $order);
        }
        
        return $this->menuItems;
    }
    
    /**
     * Function used to set menu items.
     *
     * @param array $menuItems
     */
    public function setMenuItems(array $menuItems)
    {
        $this->menuItems = $menuItems;
    }
    
    /**
     * Function used to get active features.
     *
     * @return array active features
     */
    protected function getActiveFeatures()
    {
        if(empty($this->activeFeatures)) {
            $moduleService = new \System\ModuleService();
            $this->activeFeatures = $moduleService->getActiveFeatureIds();
        } 
        
        return $this->activeFeatures;
    }
    
    /**
     * Function used to set active features.
     *
     * @param array $activeFeatures
     */
    public function setActiveFeatures(array $activeFeatures)
    {
        $this->activeFeatures = $activeFeatures;
    }
    
    /**
     * Function used to set user data.
     *
     * @param array $userData
     */
    public function setUserData(array $userData)
    {
        $this->userData = $userData;
    }
    
    /**
     * Function used to get user data.
     *
     * @return array user data
     */
    private function getUserData()
    {
        if ($this->userData === null) {
            $session = $this->getSession();
            $this->userData['userId'] = $session['user']->id;
            $this->userData['userName'] = $session['user']->username;
            $this->userData['activeFeatures'] = $session['user']->getActiveFeatures();
            $this->userData['defaultLanguage'] = $session['user']->defaultlanguage;
        }
        
        return $this->userData;
    }

    /**
     * Function used to set settings language (Used from PHPUNIT).
     *
     * @param string $settingsLanguage
     */
    public function setSettingsLanguage($settingsLanguage)
    {
        $this->settingsLanguage = $settingsLanguage;
    }
    
    /**
     * Function used to get session menu items.
     *
     * @return string settings language
     */
    public function getSettingsLanguage() 
    {
        if ($this->settingsLanguage === null) {
            $session = $this->getSession();
            $this->settingsLanguage = (isset($session['settings']['language']))? $session['settings']['language'] : self::DEFAULT_LANGUAGE;
        }
        
        return $this->settingsLanguage;
    }
    
    /**
     * Function used to get session menu items.
     *
     * @return array session menuitems
     */
    public function getSessionMenuItems() 
    {
        if ($this->sessionMenuItems === null) {
            $session = $this->getSession();
            $this->sessionMenuItems = $session['layout']['menu'];
        }
        
        return $this->sessionMenuItems;
    }
    
    /**
     * Function used to set session menu items (Used from PHPUNIT).
     *
     * @param array $sessionMenuItems
     */
    public function setSessionMenuItems(array $sessionMenuItems) 
    {
        $this->sessionMenuItems = $sessionMenuItems;
    }
    
    
    /**
     * Function used to get the translations.
     *
     * @return array translations
     */
    protected function getTranslations()
    {
        $translationService = new \System\TableTranslationService();
        $translationsData = $translationService->findBy(array('tableName' => 'systeemmenuitem', 'columnName' => 'naam'));
        $translations = array();
        foreach ($translationsData as $translation) {
            $translations[$translation->getLanguageCode()][$translation->getTableRowId()] = $translation->getValue();    
        }
        
        return $translations;
    }
    
    /**
     * Function used to process the data.
     *
     * @param array $menuItems
     * @param array $activeFeatures
     * @param array $activeFeaturesByUser
     *
     * @return array menu items
     */
    public function processResult(array $menuItems, array $activeFeatures, $activeFeaturesByUser)
    {
        $menu = array();

        foreach ($menuItems as $menuItem) {
            $systemFeatures = $menuItem->getSystemFeature();
            $systemFeature = isset($systemFeatures[0]) ? $systemFeatures[0] : null;

            if ((in_array($menuItem->getId(),$activeFeatures) && 
                ($systemFeature instanceOf \System\Feature && 
                 in_array($systemFeature->getName(), (array) $activeFeaturesByUser))) || 
                (count($systemFeatures) == 0)) {
                    $menu[] = $this->getMenuData($menuItem);
            }
        }

        return $menu;
    }
    
    /**
     * Function used to get the session.
     *
     * @return array session
     */
    private function getSession()
    {
        // Prevent continous writing to session handler, just do it once.
        if (!isset($_SESSION['layout']['menu'])) {
            $_SESSION['layout']['menu'] = array();
        }
        
        return $_SESSION;
    }

    
    /**
     * Function used to get the menu items based on user.
     *
     * @param  int $userId logged in user id
     *
     * @return array menu items
     */
    protected function getMenuItemsByUser($userId) 
    {
        $userService = new \Actinidium\UserService();
        $user = $userService->find($userId);
        
        $employee = $user->getEmployee();
        
        $menuItemGroups = $employee->getMenuItemGroupsByMedewerker();
        $menuItems = array();
        foreach ($menuItemGroups as $menuItemGroup) {
            $tempMenuItems = $menuItemGroup->getMenuItems();
            foreach ($tempMenuItems as $menuItem) {
                $menuItems[] = $menuItem->getId();
            }
        }

        return $menuItems;
    }

    /**
     * Function used to get the menu data.
     *
     * @param \System\MenuItem $menuItem
     *
     * @return array
     */
    private function getMenuData(\System\MenuItem $menuItem)
    {
        $menuData = array();
        $menuData['id'] = (int) $menuItem->getId();
        $menuData['parentId'] = ((int)$menuItem->getParentId() == 0) ? null : (int)$menuItem->getParentId();

        $menuData['name'] = $this->translator->trans(
            self::MENU_ITEM_PREFIX.$menuItem->getId(),
            array(),
            TranslatorFactory::TRANS_DOMAIN_MENU
        );

        $menuData['path'] = $menuItem->getNewUrl();
        $menuData['img'] = ($menuData['parentId'] == null) ? $menuItem->getIcon() : '';

        return $menuData;
    }
}
