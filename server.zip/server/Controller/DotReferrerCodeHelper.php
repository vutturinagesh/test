<?php

namespace Controller;

use Medical\EpisodeService;
use Medical\Episode;
use System\DOTReferrerCodeService;
use System\DOTReferrerCode;
use Actinidium\API\Response\Meta;

class DotReferrerCodeHelper extends AbstractController
{
    /**
     * @var AbstractController
     */
    private $controller;

    /**
     * @var EpisodeService
     */
    private $episodeService;

    public function __construct(AbstractController $controller)
    {
        $this->controller = $controller;
    }

    /**
     * @param array $data
     *
     * @return DotReferrerCode|null
     */
    public function validateDOTReferrerCode(array $data)
    {
        $DOTReferrerCode = null;


        if (mb_strlen($data['DOTReferrerCode']['code']) == 0) {
            $data['DOTReferrerCode']['code'] = 1;
        }

        $DOTReferrerCode = $this->controller->createEntity(
            $data['DOTReferrerCode']['id'],
            "DOTReferrerCode",
            new DOTReferrerCodeService(),
            'System\DOTReferrerCode'
        );

        return $DOTReferrerCode;
    }

    /**
     * @param Episode $episode
     * @param array $data
     *
     * @return array
     */
    public function setDOTReferrerCode(Episode $episode, array $data)
    {
        $DOTReferrerCode = $this->validateDOTReferrerCode($data);

        $this->episodeService = new EpisodeService();

        if (!$this->controller->getMeta()->hasError()) {
            $result = $this->getEpisodeService()->setDOTReferrerCode($episode, $DOTReferrerCode);
            if ($result) {
                $data = $episode->toArray();
            }
        }

        return $data;
    }

    /**
     * Factory method for EpisodeService.
     *
     * @return EpisodeService
     */
    private function getEpisodeService()
    {
        if (!$this->episodeService) {
            $this->episodeService = new EpisodeService();
        }
        return $this->episodeService;
    }
}
