<?php

namespace Controller;

use Actinidium\API\Response\CachedJsonResponse;
use Actinidium\API\Response\Meta;
use Generic\Authorizer;
use Generic\Clinic;
use Generic\ClinicService;
use Generic\Employee;
use Generic\EmployeeService;
use Generic\IdToClinicTransformer;
use Generic\IdToEmployeeTransformer;
use Message\MessageHandler;
use Patient\IdToPatientTransformer;
use Symfony\Component\Form\Exception\TransformationFailedException;
use Symfony\Component\HttpFoundation\Request;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/clinics",
 *     basePath="/api/v2"
 * )
 */
class ClinicController extends AbstractController
{
    /**
     * @var array $session
     */
    private $session = null;

    /**
     * @var \Generic\ClinicService
     */
    private $service;

    /**
     * @var \Generic\EmployeeService
     */
    private $employeeService;

    /**
     * @var \Generic\IdToEmployeeTransformer
     */
    private $idToEmployeeTransformer;

    /**
     * @var \Patient\IdToPatientTransformer
     */
    private $idToPatientTransformer;

    /**
     * @var \Generic\IdToClinicTransformer
     */
    private $idToClinicTransformer;

    /**
     * Constructor.
     *
     * @param \Generic\ClinicService            $clinicService
     * @param \Message\MessageHandler           $messageHandler
     * @param \Generic\IdToClinicTransformer    $idToClinicTransformer
     * @param \Generic\IdToEmployeeTransformer  $idToEmployeeTransformer
     * @param \Patient\IdToPatientTransformer   $idToPatientTransformer
     * @param \Generic\Authorizer               $authorizer
     *
     */
    public function __construct(
        ClinicService           $clinicService,
        MessageHandler          $messageHandler,
        IdToClinicTransformer   $idToClinicTransformer,
        IdToEmployeeTransformer $idToEmployeeTransformer,
        IdToPatientTransformer  $idToPatientTransformer,
        Authorizer              $authorizer
    )
    {
        $this->service                 = $clinicService;
        $this->messageHandler          = $messageHandler;
        $this->idToClinicTransformer   = $idToClinicTransformer;
        $this->idToEmployeeTransformer = $idToEmployeeTransformer;
        $this->idToPatientTransformer  = $idToPatientTransformer;
        $this->authorizer              = $authorizer;
    }

    /**
     * @SWG\Api(
     *   path="/clinics/{id}",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Find clinic by id",
     *           notes="Returns clinic",
     *           @SWG\Parameter(name="id", type="integer", required=true, paramType="path"),
     *       )
     * )
     *
     * @param Request $request
     *
     * @return CachedJsonResponse
     */
    public function getAction(Request $request)
    {
        $headers = array('cache-control' => 'max-age=30, private, s-maxage=900');
        $response = new CachedJsonResponse('', 200, $headers);
        $response->setData(array('data' => array()));
        $id = $request->get('id');

        try {
            $clinic = $this->idToClinicTransformer->transform($id);
        } catch (TransformationFailedException $e) {
            $this->addInvalidInputMessageToMeta('clinicId', $id);
            return $response;
        }

        $response->setData(array('data' => $clinic->toListArray()));
        return $response;
    }

    /**
     * @SWG\Api(
     *   path="/clinics",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Find clinic(s) by criteria",
     *           notes="Returns clinic(s)",
     *           @SWG\Parameter(name="type", type="string", required=false, paramType="query"),
     *           @SWG\Parameter(name="employeeId", type="integer", required=false, paramType="query"),
     *           @SWG\Parameter(name="appointmentTypeId", type="integer", required=false, paramType="query"),
     *           @SWG\Parameter(name="specialismId", type="integer", required=false, paramType="query"),
     *           @SWG\Parameter(name="patientId", type="integer", required=false, paramType="query"),
     *       )
     * )
     *
     * @return CachedJsonResponse
     */
    public function getListAction()
    {
        $headers = array('cache-control' => 'max-age=30, private, s-maxage=900');
        $response = new CachedJsonResponse('', 200, $headers);

        $data = array();
        $criteria = array();
        $order = array("name" => "ASC");

        $queryObject = $this->getRequest()->query;

        $session = $this->getSession();

        // TODO: please fix me.
        if ($queryObject->has('type') && $queryObject->get('type') == 'employee' && isset($session['employee_id'])) {
            $criteria['employee'] = $session['employee_id'];
        }

        // if query has it, add it to criteria; $key ('criteria ID') => $value ('query ID')
        $propertiesForCriteria = array(
            'specialism' => 'specialismId',
            'appointmentType' => 'appointmentTypeId',
            'specialism' => 'specialismId',
            'employee' => 'employeeId',
            'patient' => 'patientId',
        );

        foreach ($propertiesForCriteria as $criteriaId => $queryId) {
            if ($queryObject->has($queryId)) {
                $criteria[$criteriaId] = $queryObject->get($queryId);
            }
        }

        if ($queryObject->has('employeeId')) {
            try {
                $employee = $this->idToEmployeeTransformer->transform($queryObject->get('employeeId'));
                $criteria['employee'] = $employee;
            } catch (TransformationFailedException $e) {
                $this->addInvalidInputMessageToMeta('employeeId', $queryObject->get('employeeId'));
                return false;
            }
        }

        if ($queryObject->has('patientId')) {
            try {
                $patient = $this->idToPatientTransformer->transform($queryObject->get('patientId'));
                $criteria['patient'] = $patient;
            } catch (TransformationFailedException $e) {
                $this->addInvalidInputMessageToMeta('patientId', $queryObject->get('patientId'));
                return false;
            }
        }

        $clinicService = $this->getClinicService();
        $employeeService = $this->getEmployeeService();
        $currentEmployee = $employeeService->getCurrentEmployee();
        if ($currentEmployee instanceof Employee && $currentEmployee->isSupportAccount() && !$queryObject->has('employeeId')) {
            $clinics = $clinicService->findAll();
        } else {
            $clinics = $clinicService->getAllBy($criteria, $order);
        }

        foreach ($clinics as $clinic) {
            $data[] = $clinic->toListArray();
        }

        $response->setData(array('data' => $data));
        $this->getMeta()->setCount(count($data));

        return $response;
    }

    /**
     * Get employee service object.
     *
     * @return EmployeeService
     */
    public function getEmployeeService()
    {
        if (!($this->employeeService instanceof EmployeeService)) {
            $this->employeeService = new EmployeeService();
        }
        return $this->employeeService;
    }

    /**
     * Function used to get the clinic service.
     *
     * @return \Generic\ClinicService
     */
    protected function getClinicService()
    {
        if ($this->service == null) {
            $this->service = new ClinicService();
        }

        return $this->service;
    }

    /**
     * Function used to set the clinic service.
     *
     * @param \Generic\ClinicService $clinicService
     */
    public function setClinicService(ClinicService $clinicService)
    {
        $this->service = $clinicService;
    }

    /**
     * Returns the session.
     *
     * @return array
     */
    private function getSession()
    {
        if ($this->session === null) {
            $this->session = $_SESSION;
        }

        return $this->session;
    }

    /**
     * Set the session.
     *
     * @param array $session
     */
    public function setSession($session)
    {
        $this->session = $session;
    }

    /**
     * Create new clinic.
     *
     * @param array $data
     *
     * @return null
     *
     * @throws \Exception
     */
    public function createAction($data)
    {
        throw new \Exception(__METHOD__.' is not implemented');
    }

    /**
     * Update a clinic.
     *
     * @param int $id
     * @param array $data
     *
     * @throws \Exception
     */
    public function updateAction($id, $data)
    {
        throw new \Exception(__METHOD__.' is not implemented');
    }

    /**
     * Delete a clinic.
     *
     * @param int $id
     *
     * @throws \Exception
     */
    public function deleteAction($id)
    {
        throw new \Exception(__METHOD__.' is not implemented');
    }

    /**
     * Delete multiple clinics.
     *
     * @throws \Exception
     */
    public function deleteListAction()
    {
        throw new \Exception(__METHOD__.' is not implemented');
    }
}
