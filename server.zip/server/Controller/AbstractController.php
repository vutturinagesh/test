<?php
namespace Controller;

use Actinidium\API\RestBaseController;
use Actinidium\API\Response\Meta;
use Actinidium\Date\DateValidator;
use Actinidium\Date\ValidDateCreator;
use Message\MessageHandler;
use Response\PaginationAdaptor;
use Generic\CustomerService;
use Generic\Customer;
use Symfony\Component\Translation\Translator;
use Symfony\Component\HttpFoundation\JsonResponse;
use Factory\TranslatorFactory;
use Symfony\Component\Validator\ConstraintViolation;

/**
 * Callable via /api/medical-episode/:action where :action is one of the public *Action methods
 * @package Controller\Medical
 */
abstract class AbstractController extends RestBaseController
{
    /** @var array */
    protected $data = array();

    /** @var MessageHandler */
    protected $messageHandler;

    /** @var Translator */
    protected $translator;

    /**
     * @return Translator
     */
    public function getTranslator()
    {
        return $this->translator;
    }

    /**
     * Constructor.
     */
    public function __construct()
    {
        parent::__construct();

        $this->messageHandler = new MessageHandler();
        $this->translator = $this->get('medicore.translation.default');
    }

    /**
     * @return \Message\MessageHandler
     */
    public function getMessageHandler()
    {
        return $this->messageHandler;
    }

    /**
     * Adds a GV9 Message to Meta.
     *
     * @param string $name
     * @param mixed $value
     */
    public function addInvalidInputMessageToMeta($name, $value)
    {
        $this->getMeta()->addMessage(
            Meta::STATUS_ERROR,
            $this->messageHandler->getOne(
            'GV9', array(
                     'object' => $name,
                     'input'  => $value
                 )
            )
        );
    }

    /**
     * Returns an entity if the given Id is valid.
     *
     * If not, it fills the messageHandler with the proper messages and return null.
     *
     * @param int $entityId The Id of the entity
     * @param string $inputName The name of the input field as given in the URL, like "id" or "TreatmentId"
     * @param \Service\AbstractService $serviceModel The service in the model that can create the entity
     * @param string $className With escape character and full Namespace, like "Medical\\Treatment"
     *
     * @return mixed
     */
    public function createEntity($entityId, $inputName, $serviceModel, $className)
    {
        if ($this->isEntityIdEmpty($entityId, $inputName) ||
            !$this->isEntityIdPositiveInteger($entityId, $inputName)
        ) {
            return null;
        }

        return $this->createSanitizedEntity($entityId, $serviceModel, $className);
    }

    /**
     * Returns true if the id is empty
     *
     * @param int $entityId The Id of the entity
     * @param string $inputName The name of the input field as given in the URL, like "id" or "TreatmentId"
     * @return boolean
     */
    protected function isEntityIdEmpty($entityId, $inputName)
    {
        if (\Security\Sanitizer::isEmpty($entityId)) {
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne(
                    'MG01',
                    array('list_of_fields' => $inputName)
                )
            );

            return true;
        }

        return false;
    }

    /**
     * Returns true if the given entityId is a positive Integer.
     *
     * @param int $entityId
     * @param string $inputName
     *
     * @return bool
     */
    protected function isEntityIdPositiveInteger($entityId, $inputName)
    {
        if (!\Security\Sanitizer::isPositiveInteger($entityId)) {
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne(
                    'MG02',
                    array(
                        "field_name" => $inputName,
                        "expected" => "Integer, greater than zero",
                        "actual" => $entityId
                    )
                )
            );

            return false;
        }

        return true;
    }

    /**
     * Returns true if the given value is a positive Integer.
     *
     * @param int $value
     * @param string $inputName
     *
     * @return bool
     */
    public function validateInteger($value, $inputName)
    {
        if (!\Security\Sanitizer::isPositiveInteger($value)) {
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne(
                    'MG02',
                    array(
                        "field_name" => $inputName,
                        "expected" => "Integer, greater than zero",
                        "actual" => $value
                    )
                )
            );

            return false;
        }

        return $value;
    }

    /**
     * Returns true if the given value is a positive Integer or zero.
     *
     * @param int $value
     *
     * @return boolean
     */
    protected function isPositiveIntegerOrZero($inputName, $value)
    {
        if (!\Security\Sanitizer::isPositiveIntegerOrZero($value)) {
            $this->addMessage(
                Meta::STATUS_ERROR,
                'MG02',
                array(
                    "field_name" => $inputName,
                    "expected" => "Integer",
                    "actual" => $value
                )
            );

            return false;
        }

        return true;
    }

    /**
     * Returns an entity if the given Id is valid.
     *
     * If not, it fills the messageHandler with the proper messages and return null.
     *
     * @param int $entityId The Id of the entity
     * @param \Service\AbstractService $serviceModel The service in the model that can create the entity
     * @param string $className With escape character and full Namespace, like "Medical\\Treatment"
     *
     * @return boolean
     */
    protected function createSanitizedEntity($entityId, \Service\AbstractService $serviceModel, $className)
    {
        $entity = \Security\Sanitizer::entityId($entityId, $serviceModel, $className);

        if (!$entity) {
            $this->addMessage(
                Meta::STATUS_ERROR,
                'GV9',
                array('object' => $this->subtractClassName($className), 'input' => $entityId)
            );
        }

        return $entity;
    }

    /**
     * Displays the result of the executed service on the screen.
     *
     * Because we do not have a GUI yet, we just use dump()
     * How deep a structure should be shown. For Doctrine objects,  higher than 4 can cause memory issues.
     *
     * @param int $level
     *
     * @return void
     */
    protected function showResult($level = 3)
    {
        $this->data['message'] = $this->messageHandler->get();
        dump($this->data, $level);
    }

    /**
     * return class name form a full specified class path
     * @param $fullClassName
     * @internal param \Controller\type $className
     * @return type
     */
    private function subtractClassName($fullClassName)
    {
        $bits = explode("\\", $fullClassName);

        return $bits[count($bits) - 1];
    }

    /**
     * Function to check if a value is a boolean.
     *
     * @param bool $value
     * @param string $fieldName
     *
     * @return boolean
     */
    public function validateBoolean($value, $fieldName)
    {
        if (!\Security\Sanitizer::isBoolean($value)) {
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->add(
                    'MG101',
                    \Message\MessageHandler::BLOCKING,
                    array('field_name' => $fieldName, 'input' => $value)
                )
            );
        } else {
            $value = \Security\Sanitizer::boolean($value);
        }

        return $value;
    }

    /**
     * Validate date must be between 2 dates.
     *
     * @param \DateTime $date
     * @param \DateTime $floor
     * @param \DateTime $ceiling
     * @param string $objectName
     *
     * @return void
     */
    public function validateDateBetween(
        \DateTime $date,
        \DateTime $floor,
        \DateTime $ceiling,
        $objectName
    ) {
        if (!\Security\Sanitizer::isDateBetween($date, $floor, $ceiling)) {
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->add(
                    'M147',
                    \Message\MessageHandler::BLOCKING,
                    array(
                        'input' => date("Y-m-d", $date->getTimestamp()),
                        'object' => $objectName
                    )
                )
            );
        }
    }

    /**
     * Validate isSelectable is true.
     *
     * @param  bool $isSelectable
     *
     * @return boolean true
     */
    public function isSelectable($isSelectable, $inputName)
    {
        if (!$isSelectable) {
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->add(
                    'M511',
                    \Message\MessageHandler::BLOCKING,
                    array(
                        "input" => $inputName
                    )
                )
            );
        }
    }

    /**
     * Validate isNotSelectable.
     *
     * @param boolean $isNotSelectable
     *
     * @return boolean true
     */
    public function isNotSelectable($isSelectable, $inputName)
    {
        if ($isSelectable) {
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->add(
                    'M513',
                    \Message\MessageHandler::BLOCKING,
                    array(
                        "input" => $inputName
                    )
                )
            );
        }
    }

    /**
     * Function to check if the passed dateString is a valid date.
     *
     * @todo make sure that inputName is given to all calls for validateDate in the controllers
     *
     * @param string $dateString
     * @param string $fieldName
     *
     * @return \DateTime
     */
    public function validateDate($dateString, $fieldName = "")
    {
        if (empty($dateString)) {
            $this->addMessage(
                Meta::STATUS_ERROR,
                'MG01',
                array('list_of_fields' => $fieldName)
            );

            return null;
        }

        if (!preg_match('/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/', $dateString)) {
            $params = array(
                'expected' => 'YYYY-mm-dd',
                'actual' => $dateString,
                'field_name' => $fieldName
            );

            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne('MG02', $params)
            );

            return null;

        } else {
            $dateObj = ValidDateCreator::createDateTimeObject($dateString);
            if (empty($dateObj)) {
                $this->getMeta()->addMessage(
                    Meta::STATUS_ERROR,
                    $this->messageHandler->getOne('GV1')
                );
            }

            return $dateObj;
        }
    }

    /**
     * The date string should be of format 'YYYY-MM-DD'.
     *
     * @param $dateString
     *
     * @return bool
     */
    public function validateDateString($dateString)
    {
        return DateValidator::isValidDateString($dateString);
    }

    /**
     * Function to validate if the date is in the past. Validates also if it is even a date!.
     *
     * Today also counts.
     *
     * @param string $dateString
     * @param string $fieldName
     * @param bool $includeToday
     *
     * @return bool
     */
    public function validatePastDate($dateString, $fieldName, $includeToday = false)
    {
        $isPastDate = false;

        $dateObj = $this->validateDate($dateString, $fieldName);
        if ($dateObj !== null) {

            //get the current date
            $currentDate = ValidDateCreator::createDateTimeObject(date('Y-m-d', time()));
            if ($includeToday === true) {
                //add 1 day (people can be born today or die today!)
                $currentDate->add(\DateInterval::createfromdatestring('+1 day'));
            }

            if ($dateObj->getTimestamp() < $currentDate->getTimestamp()) {
                $isPastDate = true;
            } else {
                $this->addMessage(
                    Meta::STATUS_ERROR,
                    'PRM01',
                    array(
                        "field_name" => $fieldName
                    )
                );
            }
        }

        return $isPastDate;

    }

    /**
     * Validates whether the given date string is a valid date and does not lie past the comparison date.
     *
     * @param string $dateString
     * @param string $fieldName
     * @param string $comparisonString
     *
     * @return bool
     */
    public function validatePastCertainDate($dateString, $fieldName, $comparisonString, $messageCode = 'PR-M21')
    {
        $date = $this->validateDate($dateString, $fieldName);
        $comparisonDate = $this->validateDate($comparisonString, $fieldName);
        if (null !== $date && null !== $comparisonDate && $comparisonDate <= $date) {
            return true;
        }

        $this->addMessage(
            Meta::STATUS_ERROR,
            $messageCode,
            array(
                "field_name" => $fieldName,
                "comparison" => $comparisonString,
            )
        );

        return false;
    }

    /**
     * Will check string length is <= given limit.
     *
     * @param string $string
     * @param string $fieldName
     * @param int $limit
     *
     * @return string
     */
    public function validateStringLength($string, $fieldName, $limit = 255)
    {
        if (!\Security\Sanitizer::isStringLengthIsValid($string, $limit)) {
            $params = array(
                'field_name' => $fieldName,
                'expected' => "Maximum of " . $limit . " characters",
                'actual' => $string,
                'max_length' => $limit
            );

            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne('MG100', $params)
            );
        }

        return $string;
    }

    /**
     * Returns true if no input is found.
     *
     * @param string $input
     * @param string $inputName
     *
     * @return boolean
     */
    public function isRequired($input, $inputName)
    {
        if (\Security\Sanitizer::isEmpty($input)) {
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->add(
                    'MG01',
                    \Message\MessageHandler::BLOCKING,
                    array("list_of_fields" => $inputName)
                )
            );

            return false;
        }

        return true;
    }

    /**
     * Function to check if the enddate is past the start date.
     *
     * @param string $startDate
     * @param string $endDate
     * @param string $messageCode
     *
     * @return bool
     */
    public function validateEndDateGreaterOrEqualThanStartDate(
        $startDate,
        $endDate,
        $messageCode = 'M036'
    ) {
        //if we check with endDate null we return true, since the startDate is always a datetime object.
        if ($endDate === null) {
            return true;
        }

        if ($startDate === null || $startDate > $endDate) {
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne($messageCode)
            );

            return false;
        }

        return true;
    }

    /**
     * Function to check if the enddate prior to the start date.
     *
     * @param \DateTime | string $startDate
     * @param \DateTime | string $endDate
     * @param string $messageCode
     *
     * @return bool
     */
    public function validateEndDateBeforeStartDate($startDate, $endDate, $messageCode = 'PA-V3')
    {
        $startDateObject = ValidDateCreator::createDateTimeObject($startDate);
        $endDateObject = $this->validateDate($endDate, 'endDate');

        if ($startDateObject !== null && $endDateObject !== null) {
            if ($endDateObject < $startDateObject) {
                $this->getMeta()->addMessage(
                    Meta::STATUS_ERROR,
                    $this->messageHandler->getOne($messageCode)
                );

                return false;
            }

            return true;
        }
    }

    /**
     * Check if the searched value is in the predefined Array.
     *
     * @param string $value
     * @param array $predefinedValues
     *
     * @return boolean
     */
    public function validatePredefinedValue($fieldName, $value, $predefinedValues)
    {
        if (!in_array($value, $predefinedValues)) {
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->add(
                    'MG02',
                    \Message\MessageHandler::BLOCKING,
                    array(
                        'field_name' => $fieldName,
                        'expected' => implode(', ', $predefinedValues),
                        'actual' => $value
                    )
                )
            );

            return false;
        }

        return true;
    }

    /**
     * Function to add multiple messages to the Meta.
     *
     * @param array $errors
     *
     * @return null
     */
    public function addErrorsToMeta(array $errors)
    {
        foreach ($errors as $error) {
            $this->getMeta()->addMessage(
                isset($error['type']) ? $error['type'] : Meta::STATUS_ERROR,
                $this->messageHandler->getOne($error['id'], $error['params'])
            );
        }

        return null;
    }

    /**
     * Will check the given string is integer , is >= minLimit && <= maxLimit.
     *
     * @param string $string
     * @param string $fieldName
     * @param int $minLimit
     * @param int $maxLimit
     *
     * @return string
     */
    public function validateIntegerInBetween($string, $fieldName, $minLimit, $maxLimit)
    {
        if (!\Security\Sanitizer::isIntegerInBetween($string, $minLimit, $maxLimit)) {
            $params = array(
                'input' => $string,
                'field_name' => $fieldName
            );

            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne('MG101', $params)
            );
        }

        return $string;
    }


    /**
     * Function to add a message to the Meta.
     *
     * @param string $status
     * @param string $code
     * @param array $params
     *
     * @return void
     */
    public function addMessage($status, $code, $params = array())
    {
        $this->getMeta()->addMessage(
            $status,
            $this->messageHandler->getOne($code, $params)
        );
    }

    /**
     * Function to add messages to the Meta.
     *
     * @param array $messages
     */
    public function addMessagesToMeta(array $messages)
    {
        foreach ($messages as $message) {
            $this->addMessage(Meta::STATUS_SUCCESS, $message['id']);
        }
    }

    /**
     * Adds a translated message to the Meta.
     *
     * @param string $source
     * @param array  $params
     * @param string $level
     * @param string $domain
     */
    public function addTranslatedMessageToMeta($source, $params = array(), $level, $domain)
    {
        $this->getMeta()->addMessage(
            $level,
            $this->translator->trans(
                $source,
                $params,
                $domain
            )
        );
    }

    /**
     * Check if there are errors present in the Meta.
     *
     * @return bool
     */
    public function hasError()
    {
        return $this->getMeta()->hasError();
    }

    /**
     * Function to add a pagination object to the meta.
     *
     * @param integer $offset
     * @param integer $limit
     * @param integer $totalCount
     *
     * @return void
     */
    public function addPagination($offset, $limit, $totalCount)
    {
        $paginationAdapter = new PaginationAdaptor();
        if ($offset >= $totalCount) {
            $offset = 0;
        }
        $page = intval(($offset / $limit) + 1);
        $paginator = $paginationAdapter->getPaginator($page, $totalCount, $limit);
        $this->getMeta()->addPagination($paginator);
    }

    /**
     * Function to check if the customerType is somatic.
     *
     * @return boolean
     */
    public function isSomatic()
    {
        $customerService = new CustomerService();
        if ($customerService->getCareType() == Customer::CARETYPE_SOMATIC) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Check is the searched needle is present in the haystack.
     *
     * Returns false if the field is not set, returns true if the field is found
     *
     * @param string $needle
     * @param array $haystack
     *
     * @return boolean
     */
    public function isSupplied($needle, array $haystack)
    {
        if (!isset($needle, $haystack)) {
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->add(
                    'MG01',
                    \Message\MessageHandler::BLOCKING,
                    array("list_of_fields" => $needle)
                )
            );

            return false;
        }

        return true;
    }

    /**
     * Public function to check if a value is a string (no numbers).
     *
     * @param $value
     * @param $inputName
     *
     * @return bool;
     */
    public function validateString($value, $inputName)
    {
        $isValid = false;

        if (intval(preg_match('#[0-9]#', $value)) > 0 || strlen($value) === 0) {
            $this->addMessage(
                Meta::STATUS_ERROR,
                'MG101',
                array(
                    "field_name" => $inputName,
                    "input" => $value
                )
            );
        } else {
            $isValid = true;
        }

        return $isValid;
    }

    /**
     * Will check the given string is a mobile phonenumber.
     *
     * Valid regex for dutch mobile phone numbers: $regex = '/^[0]{1}[6]{1}[-]?[1-9]{1}[0-9]{7}/i';
     *
     * @todo: Add validation for international numbers with $countryId
     *
     * @param string $value
     * @param string $inputName
     * @param int | null $countryId
     *
     * @return bool;
     */
    public function validateMobilePhoneNumber($value, $inputName, $countryId)
    {
        $isValid = false;

        $regex = '/[A-Za-z!=_@#$%^&*{},.\/\|;:]/i';
        if (strlen($value) === 0 || intval(preg_match($regex, $value)) > 0) {
            $this->addMessage(
                Meta::STATUS_ERROR,
                'MG101',
                array(
                    "field_name" => $inputName,
                    "input" => $value
                )
            );
        } else {
            $isValid = true;
        }

        return $isValid;
    }

    /**
     * Public function to check if something is a valid phone numbers.
     *
     * Valid dutch phone number regex for later: '/^(([0-9]{3}[-]?[0-9]{7})|([0-9]{4}[-]?[0-9]{6}))$/'
     * Valid international phone number regex for later: '/\+?[0-9][0-9-?]{6,}/';
     *
     * @todo use countryid for international validation
     *
     * @param string $value
     * @param string $inputName
     * @param int | null $countryId
     *
     * @return bool
     */
    public function validatePhoneNumber($value, $inputName, $countryId)
    {
        $isValid = false;

        $regex = '/[A-Za-z!=_@#$%^&*{},.\/\|;:]/i';
        if (intval(preg_match($regex, $value)) > 0) {
            $this->addMessage(
                Meta::STATUS_ERROR,
                'MG101',
                array(
                    "field_name" => $inputName,
                    "input" => $value
                )
            );
        } else {
            $isValid = true;
        }

        return $isValid;
    }

    /**
     * Function to check if a postcode is valid.
     *
     * @param string $value
     * @param string $inputName
     * @param int | null $countryId
     *
     * @return bool;
     */
    public function validatePostcode($value, $inputName, $countryId)
    {
        $isValid = true;

        if ((int)$countryId != \Person\Address::DEFAULT_COUNTRY) {
            return $isValid;
        }

        $regex = '/^[1-9][0-9]{3}[\s]?[A-Za-z]{2}$/i';
        if (intval(preg_match($regex, $value)) === 0) {
            $this->addMessage(
                Meta::STATUS_ERROR,
                'MG101',
                array(
                    "field_name" => $inputName,
                    "input" => $value
                )
            );
            $isValid = false;
        }

        return $isValid;
    }

    /**
     * Function to check if an email is valid.
     *
     * @param string $value
     * @param string $inputName
     *
     * @return bool
     */
    public function validateEmailAddress($value, $inputName)
    {
        $isValid = false;
        if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
            $this->addMessage(
                Meta::STATUS_ERROR,
                'MG101',
                array(
                    "field_name" => $inputName,
                    "input" => $value
                )
            );
        } else {
            $isValid = true;
        }

        return $isValid;
    }

    /**
     * Returns true if the given value is a BSN.
     *
     * @param string $value
     * @param string $inputName
     *
     * @return boolean
     */
    protected function validateBSN($value, $inputName)
    {
        $isValid = $this->processBSNValidation($value);
        if ($isValid === false) {
            $this->addMessage(
                Meta::STATUS_ERROR,
                'MG101',
                array(
                    "field_name" => $inputName,
                    "input" => $value
                )
            );
        }

        return $isValid;
    }

    /**
     * Function to validate if a passed id is actually an object.
     *
     * @todo: now it only works on id. Rework this to work on all properties.
     *
     * @param array | string $value
     * @param string $class
     * @param string $inputName
     * @param array $data
     *
     * @return bool
     */
    public function validateObject($value, $class, $inputName, array $data)
    {
        $isValid = false;
        if (is_array($value)) {
            //check if the passed value is actually an array and has an id parameter
            if (array_key_exists('id', $value)) {
                try {
                    //instantiate the repository so we can fetch the object by its id
                    $serviceClass = $class . 'Service';
                    $service = new $serviceClass();
                    $result = $service->find($value['id']);
                    if ($result instanceof $class) {
                        $isValid = true;
                    }
                } catch (\Exception $e) {
                    // do nothing
                }
            }
        }

        if ($isValid === false) {
            $this->addMessage(
                Meta::STATUS_ERROR,
                'MG101',
                array(
                    "field_name" => $inputName,
                    "input" => $value['id']
                )
            );
        }

        return $isValid;
    }

    /**
     * Function to process the BSN check.
     *
     * @param $value
     *
     * @return bool
     */
    protected function processBSNValidation($value)
    {
        $result = false;

        if (intval(preg_match('/^[0-9]{9}$/', $value)) >= 1) {

            if ($value == '999999999') {
                $result = true;
            } else {
                $result = $this->elevenTest($value);
            }

        }

        return $result;
    }

    /**
     * function to perform the "Elfproef" which checks for valid BSN values
     *
     * @param string $value
     *
     * @return bool
     */
    private function elevenTest($value)
    {
        $isValid = false;

        $sum = 0;
        for ($i = 9; $i > 0; $i--) {
            if ($i != 1) {
                $sum += $i * $value[9 - $i];
            } else {
                $sum -= $i * $value[9 - $i];
            }
        }

        if (intval($value) > 0 && ($sum % 11) === 0) {
            $isValid = true;
        }

        return $isValid;
    }

    /**
     * Execute the array of validator methods with arguments.
     *
     * @param array $validators
     */
    public function executeValidators(array $validators)
    {
        $isValid = true;
        foreach ($validators as $validator => $args) {
            $isValid = call_user_func_array(array($this, $validator), $args);
            //validators should return false or true as a default. If they do not, we assert them as true.
            //but if they return false, we break the current field validation so only 1 error per field
            //will be given at a certain time.
            if ($isValid === false) {
                break;
            }
        }
    }

    /**
     * Will check string length is the exact length given.
     *
     * @param string $string
     * @param string $fieldName
     * @param int $length
     *
     * @return string
     */
    public function validateExactStringLength($string, $fieldName, $length)
    {
        if (!\Security\Sanitizer::isValidLengthString($string, $length)) {
            $params = array(
                'field_name' => $fieldName,
                'length' => $length
            );

            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->getOne('MG107', $params)
            );
        }

        return $string;
    }

    /**
     * Function to process the mandatory fields.
     *
     * @param array $mandatoryFields
     * @param array $data
     */
    protected function processMandatoryFields(array $mandatoryFields, array $data)
    {
        //loop trough the mandatory fields and process the validation functions that are required for them
        //Any errors found will be set in the meta, so the result of this function is void
        foreach ($mandatoryFields as $index => $mandatoryField) {
            if ($this->isSupplied($mandatoryField, $data)) {
                if ($this->isRequired($data[$mandatoryField], $mandatoryField) === false) {
                    //the message was added to the meta
                }
            } else {
                //the message was added to the meta
            }
        }
    }

    /**
     * Protected function to check if the posted field requires validation.
     *
     * if the value is set we validate is
     * if the value is null but the field is required, we validate it.
     * if the value is "" but the field is required we validate it.
     *
     * @param string $field
     * @param string $value
     * @param array $mandatoryFields
     *
     * @return bool $requiresValidation
     */
    protected function requiresValidation($field, $value, array $mandatoryFields)
    {
        $requiresValidation = false;
        if ($value !== null && $value !== "") {
            $requiresValidation = true;
        } else {
            $isEmpty = false;
            if ($value === null | $value === "") {
                $isEmpty = true;
            }

            if ($isEmpty && array_key_exists($field, $mandatoryFields)) {
                $requiresValidation = true;
            }
        }

        return $requiresValidation;
    }

    /**
     * Verifies if a model is valid and adds error messages to the meta response when the model is not valid.
     *
     * @param mixed $model
     * @param array $groups
     *
     * @return boolean
     */
    public function isModelValid($model, array $groups = array())
    {
        $violations = $this->get('validator')->validate($model, $groups);

        if (0 === count($violations)) {
            return true;
        }
        $alreadyAddedPropertyMessages = array();
        foreach ($violations as $violation) {
            if ($alreadyAddedPropertyMessages[$violation->getMessage()] != $violation->getPropertyPath()) {
                $this->getMeta()->addMessage(
                    Meta::STATUS_ERROR,
                    $this->getValidationMessage($violation)
                );
            }
            $alreadyAddedPropertyMessages[$violation->getMessage()] = $violation->getPropertyPath();
        };

        return false;
    }

    /**
     * Get validation message for model constraints.
     *
     * @param \Symfony\Component\Validator\ConstraintViolation $violation
     *
     * @return string
     */
    private function getValidationMessage(ConstraintViolation $violation)
    {
        $properties = $violation->getConstraint()->payload;
        if (!is_array($properties) || empty($properties)) {
            $properties = array(
                '{*input*}' => $violation->getPropertyPath(),
            );
        }

        $message = $this->translator->trans(
            $violation->getMessage(),
            $properties,
            TranslatorFactory::TRANS_DOMAIN_GENERIC
        );

        if ($message == $violation->getMessage()) {
            return $this->messageHandler->add(
                $violation->getMessage(),
                MessageHandler::BLOCKING,
                array("list_of_fields" => $violation->getPropertyPath())
            );
        }
        return $message;
    }

    /**
     * Returns the default Json response for v2 API's.
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    protected function defaultResponse()
    {
        $response = new JsonResponse();
        $response->setPublic();
        $response->setMaxAge(300);
        $response->setSharedMaxAge(3600);
        $response->headers->addCacheControlDirective('must-revalidate', true);
        return $response;
    }

    /**
     * Function to check the page param posted to the controller.
     *
     * @return int
     */
    protected function processPage()
    {
        $query = $this->getRequest()->query;

        $page = $query->get('page', 1);
        if ($page < 1) {
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, 'Invalid page requested');
            $page = 1;
        }

        return $page;
    }

    /**
     * Function to check the page param posted to the controller.
     *
     * @return int
     */
    protected function processLimit()
    {
        $query = $this->getRequest()->query;

        $limit = $query->get('limit', PaginationAdaptor::MAXLIMIT);

        if ($limit < 1) {
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, 'Invalid number of rows requested');
            $limit = 1;
        }

        return $limit;
    }

    /**
     * Handle pagination, sets the proper values in meta.
     *
     * @param int      $page
     * @param int      $limit
     * @param int|null $totalCount
     */
    protected function addPaginationMeta($page, $limit, $totalCount = null)
    {
        $paginationAdapter = new PaginationAdaptor($page);
        $paginator = $paginationAdapter->getPaginator($page, $totalCount, $limit);
        $this->getMeta()->addPagination($paginator);
    }
}
