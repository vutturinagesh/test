<?php

namespace Controller\Referrer;

use Actinidium\API\Response\Meta;
use Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Generic\Referrer\Organization;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/referrer",
 *     basePath="/api/v2"
 * )
 */
class OrganizationController extends AbstractController
{
     /**
      * @SWG\Api(
      *   path="/referrer-organization",
      *   @SWG\Operation(
      *       method="GET",
      *       summary="Find institutions by criteria",
      *       @SWG\Parameter(name="search", type="string", required=false, paramType="query"),
      *       @SWG\Parameter(name="code", type="string", required=false, paramType="query"),
      *       @SWG\Parameter(name="individualId", type="integer", required=false, paramType="query"),
      *       @SWG\Parameter(name="referrerOrganizationTypeId", type="string", required=false, paramType="query"),
      *       @SWG\Parameter(name="offset", type="integer", required=false, paramType="query", defaultValue=0),
      *       @SWG\Parameter(name="itemsPerPage", type="integer", required=false, paramType="query", defaultValue=30),
      *   )
      * )
      *
      * @param \Symfony\Component\HttpFoundation\Request $request
      *
      * @return \Symfony\Component\HttpFoundation\JsonResponse
      */
    public function getListAction(Request $request)
    {
        $data = array();
        $response = $this->defaultResponse();
        $referrerOrganizationService = $this->get('medicore.generic.referrer.organization_service');
        $search = $referrerOrganizationService->getOrganizationSearchByRequest($request);

        $isSearchValid = $this->isModelValid($search);

        if ($isSearchValid) {
            if ($search->hasIndividualId()) {
                list ($data, $totalCount) = $this->getIndividualOrganization($search->getIndividualId());
            } else {
                list ($data, $totalCount) = $referrerOrganizationService->search($search);

                $data = array_map(function(Organization $item) {
                        return $item->toListArray();
                    }, $data
                );
            }

            $this->addPagination(
                $search->getOffset(),
                $search->getLimitPerPage(),
                $totalCount
            );
        }

        if ($isSearchValid && 0 === count($data)) {
            $this->getMeta()->addMessage(
                Meta::STATUS_INFO,
                $this->get('medicore.message.message_handler')->getOne('MG103')
            );
        }

        $response->setData(array('data' => $data));
        return $response;
    }

    /**
     * Get the organization for an individual ID.
     *
     * @param integer $individualId
     *
     * @return array
     */
    private function getIndividualOrganization($individualId)
    {
        $individualService = $this->get('medicore.generic.referrer.individual_service');
        $individual = $individualService->find($individualId);

        if (null !== $individual) {
            return array(
                $individual->getOrganization()->toListArray(),
                1
            );
        }
        return null;
    }
}
