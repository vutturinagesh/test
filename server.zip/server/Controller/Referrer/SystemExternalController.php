<?php

namespace Controller\Referrer;

use Actinidium\API\Response\Meta;
use Controller\AbstractController;
use Controller\DotReferrerCodeHelper;
use Controller\MHCReferrerCodeHelper;
use Controller\ValidationResult;
use Medical\Episode;
use Medical\EpisodeService;
use Medical\Treatment;
use Security\Sanitizer;
use System\CareInstitutionService;
use System\CareProviderService;

/**
 * Controller to perform CURD operations for episode system external referrer.
 *
 * @SWG\Resource(
 *     apiVersion="1.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/referrer",
 *     basePath="/api"
 * )
 */
final class SystemExternalController extends AbstractController
{
    /**
     * System care institution service.
     *
     * @var \System\CareInstitutionService
     */
    private $systemInstitutionService;

    /**
     * System provider service.
     *
     * @var \System\CareProviderService
     */
    private $systemProviderService;

    /**
     * Episode service.
     *
     * @var \Medical\EpisodeService
     */
    private $episodeService;

    /**
     * Constructor.
     *
     * @param \System\CareInstitutionService $systemInstitutionService
     * @param \System\CareProviderService $systemProviderService
     * @param \Medical\EpisodeService
     */
    public function __construct(
        CareInstitutionService $systemInstitutionService = null,
        CareProviderService $systemProviderService = null,
        EpisodeService $episodeService = null
    ) {
        parent::__construct();
        $this->systemInstitutionService = $systemInstitutionService;
        $this->systemProviderService = $systemProviderService;
        $this->episodeService = $episodeService;

        if (!$this->systemInstitutionService) {
            $this->systemInstitutionService = $this->get('medicore.system.care_institution_service');
        }
        if (!$this->systemProviderService) {
            $this->systemProviderService = $this->get('medicore.system.care_provider_service');
        }
        if (!$this->episodeService) {
            $this->episodeService = $this->get('medicore.medical.episode_service');
        }
    }

    /**
     * Implements POST for collection systemExternal.
     *
     * Example input:
     *
     * POST
     *
     *  {
     *       "organization":{"id":2},
     *       "person":{"id":6889},
     *       "episode":{"id":2396},
     *       "date":"2014-07-24",
     *       "emergencyRoom":true
     *  }
     *
     * @SWG\Api(
     *     path="/referrer-systemExternal",
     *     @SWG\Operation(
     *         method="POST",
     *         summary="Create",
     *     )
     * )
     *
     * @param array $data
     *
     * @return array
     */
    public function createAction(array $data)
    {
        $episode = $this->createEntity(
            $data['episode']['id'],
            'episodeId',
            $this->episodeService,
            '\Medical\Episode'
        );

        /* @var $episode \Medical\Episode */
        $careInstitution = $this->createEntity(
            $data['organization']['id'],
            'organizationId',
            $this->systemInstitutionService,
            '\System\CareInstitution'
        );

        //if we have a GP provider, then person is mandatory.
        $careProvider = null;
        if ($careInstitution instanceof \System\CareInstitution &&
            $careInstitution->isProviderTypeGP()
        ) {
            $careProvider = $this->createCareProvider($data);
        } elseif (!empty($data['person']['id'])) {
            //else person is not mandatory, so it won't come here, and then we have no error.
            $careProvider = $this->createCareProvider($data);
        }

        $date = $this->validateDate($data['date'], "date");
        $emergencyRoom = $this->validateEmergencyRoom($data['emergencyRoom']);

        if (!$episode) {
            return $this->data;
        }

        $referrerCodeObject = null;
        if ($episode->canHaveDOTReferrerCode()) {
            $dotReferrerHelper = new DotReferrerCodeHelper($this);
            $referrerCodeObject = $dotReferrerHelper->validateDOTReferrerCode($data);
        }

        $MHCReferrerCode = null;
        if (array_key_exists('MHCReferrerCode', $data)) {
            if (!empty($data['MHCReferrerCode']['id'])
                && ($episode->getTreatmentTypeWithCareType() == Treatment\Factory::TYPE_DBCMHC || $episode->getTreatmentTypeWithCareType() == Treatment\Factory::TYPE_BASIS_MHC)) {
                $mhcReferrerHelper = new MHCReferrerCodeHelper($this);
                if (Sanitizer::boolean($data['MHCReferrerCode']['youth'])
                && $this->episodeService->checkYouthReferrerCodeApplicable($episode)) {
                    $MHCReferrerCode = $mhcReferrerHelper->validateMHCYouthReferrerCode($data);
                } else {
                    $MHCReferrerCode = $mhcReferrerHelper->validateMHCReferrerCode($data);
                }
            }
        }

        if ($this->getMeta()->hasError()) {
            return $this->data;
        }

        $result = $this->episodeService->editExternalReferrerGp(
            $episode,
            $careInstitution,
            $careProvider,
            $date,
            $emergencyRoom,
            $referrerCodeObject,
            $MHCReferrerCode
        );

        if ($result) {
            $this->data = $episode->getEpisodeReferrer()->getGeneralPractitioner()->toArray() +
                array('emergencyRoom' => $episode->getEpisodeReferrer()->getEmergencyRoom());

            if ($date) {
                $this->data += array(
                    "date" => $episode->getEpisodeReferrer()
                            ->getReferrerDate()->format(\Date\Format::getFormat())
                );
            }

            if ($episode->getEpisodeReferrer()->getDOTReferrerCode()) {
                $this->data += array(
                    "DOTReferrerCode" => ($episode->getEpisodeReferrer()->getDOTReferrerCode()) ? $episode->getEpisodeReferrer()->getDOTReferrerCode()->toListArray() : null
                );
            }

            if ($episode->getEpisodeReferrer()) {
                $this->data += array(
                    "MHCReferrerCode" => $episode->getEpisodeReferrer()->getReferrerCodeMHCData()
                );
            }
        }

        $errors = $this->episodeService->getErrors();
        if (!empty($errors)) {
            ValidationResult::addToMeta($errors, $this);
        }

        return $this->data;
    }

    /**
     * Returns a careProvider, based on id.
     *
     * @param array $data
     *
     * @return mixed
     */
    private function createCareProvider(array $data)
    {
        $careProvider = $this->createEntity(
            $data['person']['id'],
            'personId',
            $this->systemProviderService,
            '\System\CareProvider'
        );
        return $careProvider;
    }

    /**
     * Validate emergency room.
     *
     * @param boolean $emergencyRoom
     *
     * @return boolean
     */
    private function validateEmergencyRoom($emergencyRoom)
    {
        if (is_string($emergencyRoom)) {
            if (!Sanitizer::isBoolean($emergencyRoom)) {
                $this->addMessage(
                    Meta::STATUS_ERROR,
                    'MG101',
                    array('field_name' => 'emergencyRoom', 'input' => $emergencyRoom)
                );

            } else {
                $emergencyRoom = Sanitizer::boolean($emergencyRoom);
            }
        }

        return $emergencyRoom;
    }
}