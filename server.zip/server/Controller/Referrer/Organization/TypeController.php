<?php
/**
 * Created by Development.
 * User: anush.prem
 * Date: 9/23/13
 * 
 */

namespace Controller\Referrer\Organization;


use Controller\AbstractController;

/**
 * Class TypeController
 *
 * Implements HTTP method GET
 * @package Controller\Referrer\Organization
 */
class TypeController extends AbstractController
{

    /**
     * @var \Referrer\OrganizationTypeService
     */
    private $model;

    /**
     * Retrievs all active organization types and serves it as array.
     *
     * @return array
     */
    public function getListAction()
    {
        $this->model = $this->getModel();
        $types = $this->model->findAll();

        $data = array();
        $names = array();

        foreach ($types as $type) {
            /* @var $type \Generic\Referrer\OrganizationType */
            $data[$type->getId()] = $type->toListArray();
            $names[$type->getId()] = strtolower($type->getName());
        }
        array_multisort($names, SORT_ASC, $data);
        $this->getMeta()->setCount(count($this->data));

        return $data;
    }

    /**
     * Returns the use case service.
     *
     * @return \Generic\Referrer\OrganizationTypeService
     */
    protected function getModel()
    {
        if (!$this->model) {
            $this->model = new \Generic\Referrer\OrganizationTypeService();
        }

        return $this->model;
    }
}
