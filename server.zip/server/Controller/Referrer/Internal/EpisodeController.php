<?php

namespace Controller\Referrer\Internal;

use Controller\AbstractController;
use Medical\Episode;
use Medical\EpisodeService;
use Medical\FindReferringEpisodesService;

/**
 * Class EpisodeController
 *
 * Responsible for episodes as internal referrers.
 *
 * @package Controller\Referrer\Internal
 */
class EpisodeController extends AbstractController
{
    /**
     * @var FindReferringEpisodesService
     */
    private $findReferringEpisodesService;

    /**
     * @var EpisodeService
     */
    private $episodeService;

    /**
     * Returns episodes from the same patient as the one given (episodeId).
     *
     * api/referrer-internal-episode?episodeId={id}
     *
     * @return Array
     */
    public function getListAction()
    {
        $episodes = $this->findReferringEpisodes();
        if (!empty($episodes)) {
            foreach ($episodes as $episode) {
                /**
                 * @var Episode $episode
                 */
                $this->data[] = $episode->toListArray();
            }
            $this->getMeta()->setCount(count($this->data));
        }
        return $this->data;
    }

    /**
     * Find potential referring episodes, based on the current one given.
     * If that is not a correct episode, we end with an error message.
     *
     * @return Array of episdes.
     */
    private function findReferringEpisodes()
    {
        $episode = $this->createEntity(
            $this->getRequest()->get('episodeId'),
            'episodeId',
            $this->getEpisodeService(),
            '\Medical\Episode'
        );
        if (!$episode) {
            return $this->data;
        }
        return $this->getFindReferringEpisodesService()->find($episode);
    }

    /**
     * Factory method for getting the EpisodeService.
     *
     * @return EpisodeService
     */
    protected function getEpisodeService()
    {
        if (!$this->episodeService) {
            $this->episodeService = new EpisodeService();
        }
        return $this->episodeService;
    }


    /**
     * Factory method for this service.
     *
     * @return FindReferringEpisodesService
     */
    protected function getFindReferringEpisodesService()
    {
        if (!$this->findReferringEpisodesService) {
            $this->findReferringEpisodesService = new FindReferringEpisodesService();
        }
        return $this->findReferringEpisodesService;
    }
}
