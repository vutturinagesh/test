<?php

namespace Controller\Referrer\Internal;

use Controller\AbstractController;
use Medical\EpisodeService;
use Medical\FindReferringTreatmentsService;
use Medical\Treatment;
use Medical\TreatmentService;

/**
 * Handling the Request for api/referrer/internal/treatment
 * @package Controller\Referrer\Internal
 */
class TreatmentController extends AbstractController
{
    /**
     * @var FindReferringEpisodesService
     */
    private $findReferringTreatmentsService;

    /**
     * @var EpisodeService
     */
    private $episodeService;

    /**
     * @var TreatmentService
     */
    private $treatmentService;

    /**
     * Returns treatments which are potential internal referrers in n episode.
     * The episode is given in the request by episodeId.
     *
     * api/referrer-internal-treatment?episodeId=x
     *
     * @return Array
     */
    public function getListAction()
    {
        $treatments = $this->findReferringTreatments();
        if (!empty($treatments)) {
            foreach ($treatments as $treatment) {
                /**
                 * @var Treatment $treatment
                 */
                $treatmentInfo = $treatment->toListArray();
                $diagnosisInfo = $this->addDiagnosisInfo($treatment);
                $this->data[] = array_merge($treatmentInfo, $diagnosisInfo);
            }
            $this->getMeta()->setCount(count($this->data));
        }
        return $this->data;
    }

    /**
     * Add the diagnosis info to the output.
     *
     * @param Treatment $treatment
     *
     * @return array
     */
    private function addDiagnosisInfo(Treatment $treatment)
    {
        $code = null;
        $info = null;
        $somaticDiagnosis = $this->getTreatmentService()->getDbcCharacterization($treatment);
        if ($somaticDiagnosis) {
            $code = $somaticDiagnosis->getComponentCode();
            $description = $somaticDiagnosis->getShortDesc();
        } else {
            $mhcPrimaryDiagnosis = $this->getTreatmentService()->getPrimaryDiagnosis($treatment);
            if ($mhcPrimaryDiagnosis) {
                $code = $mhcPrimaryDiagnosis->getReferenceCodeICD9();
                $description = $mhcPrimaryDiagnosis->getDescription();
            }
        }
        if ($code) {
            $info = array(
                'code' => $code,
                'description' => $description
            );
        }
        return array('diagnosis' => $info);
    }

    /**
     * @return TreatmentService
     */
    protected function getTreatmentService()
    {
        if (!$this->treatmentService) {
            $this->treatmentService = new TreatmentService();
        }
        return $this->treatmentService;
    }

    /**
     * Find potential referring treatments, based on the episode given.
     * If that is not a correct episode, we end with an error message.
     *
     * @return Array of episdes.
     */
    private function findReferringTreatments()
    {
        $episode = $this->createEntity(
            $this->getRequest()->get('episodeId'),
            'episodeId',
            $this->getEpisodeService(),
            '\Medical\Episode'
        );
        if (!$episode) {
            return $this->data;
        }
        return $this->getFindReferringTreatmentsService()->find($episode);
    }

    /**
     * @return EpisodeService
     */
    protected function getEpisodeService()
    {
        if (!$this->episodeService) {
            $this->episodeService = new EpisodeService();
        }
        return $this->episodeService;
    }

    /**
     * Factory method for this service.
     *
     * @return FindReferringTreatmentsService
     */
    protected function getFindReferringTreatmentsService()
    {
        if (!$this->findReferringTreatmentsService) {
            $this->findReferringTreatmentsService = new FindReferringTreatmentsService();
        }
        return $this->findReferringTreatmentsService;
    }

} 
