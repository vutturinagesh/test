<?php

namespace Controller\Referrer;

use Actinidium\API\Response\Meta;
use Controller\AbstractController;
use Controller\DotReferrerCodeHelper;
use Controller\MHCReferrerCodeHelper;
use Controller\ValidationResult;
use Medical\Episode;
use Medical\EpisodeService;
use Medical\Treatment;
use Medical\TreatmentService;
use Security\Sanitizer;
use System\MHC\IReferrerCode;
use System\DOTReferrerCode;

/**
 * Controller to perform CURD operations for episode internal referrer.
 *
 * @SWG\Resource(
 *     apiVersion="1.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/referrer",
 *     basePath="/api"
 * )
 */
final class InternalController extends AbstractController
{
    /**
     * Episode service.
     *
     * @var \Medical\EpisodeService
     */
    private $episodeService;

    /**
     * Treatment service.
     *
     * @var \Medical\TreatmentService
     */
    private $treatmentService;

    /**
     * Constructor.
     *
     * @param \Medical\EpisodeService $episodeService
     * @param \Medical\TreatmentService $treatmentService
     */
    public function __construct(
        EpisodeService $episodeService = null,
        TreatmentService $treatmentService = null
    ) {
        parent::__construct();
        $this->episodeService = $episodeService;
        $this->treatmentService = $treatmentService;

        if (!$this->episodeService) {
            $this->episodeService = $this->get('medicore.medical.episode_service');
        }
        if (!$this->treatmentService) {
            $this->treatmentService = $this->get('medicore.medical.treatment_service');
        }
    }

    /**
     * Method to add/edit inter referrer of an episode.
     *
     * @SWG\Api(
     *     path="/referrer-internal",
     *     @SWG\Operation(
     *         method="POST",
     *         summary="Create",
     *     )
     * )
     *
     * @param array $data
     *
     * @return array
     */
    public function createAction(array $data)
    {
        $episode = $this->createEntity(
            $data['episode']['id'],
            'episodeId',
            $this->episodeService,
            '\Medical\Episode'
        );

        $treatment = $this->createEntity(
            $data['referringTreatment']['id'],
            'referringTreatmentId',
            $this->treatmentService,
            '\Medical\Treatment'
        );

        $date = $this->validateDate($data['date'], "date");
        $emergencyRoom = Sanitizer::boolean($data['emergencyRoom']);

        if (!$episode) {
            return $this->data;
        }

        $referrerCodeObject = null;
        if ($episode->canHaveDOTReferrerCode()) {
            $dotReferrerHelper = new DotReferrerCodeHelper($this);
            $referrerCodeObject = $dotReferrerHelper->validateDOTReferrerCode($data);
        }

        $MHCReferrerCode = null;
        if (array_key_exists('MHCReferrerCode', $data)) {

            if (!empty($data['MHCReferrerCode']['id'])
                    && ($episode->getTreatmentTypeWithCareType() == Treatment\Factory::TYPE_DBCMHC
                    || $episode->getTreatmentTypeWithCareType() == Treatment\Factory::TYPE_BASIS_MHC)) {
                $mhcReferrerHelper = new MHCReferrerCodeHelper($this);
                if (Sanitizer::boolean($data['MHCReferrerCode']['youth'])
                && $this->episodeService->checkYouthReferrerCodeApplicable($episode)) {
                    $MHCReferrerCode = $mhcReferrerHelper->validateMHCYouthReferrerCode($data);
                } else {
                    $MHCReferrerCode = $mhcReferrerHelper->validateMHCReferrerCode($data);
                }

            }
        }
        if ($this->hasError()) {
            return $this->data;
        }
        /* @var $episode \Medical\Episode */
        /* @var $treatment \Medical\Treatment */
        /* @var $specialist \Generic\Employee */

        $result = $this->setInternalReferrer(
            $episode,
            $treatment,
            $date,
            $emergencyRoom,
            $referrerCodeObject,
            $MHCReferrerCode
        );
        if ($result) {
            $internalReferrer = $episode->getEpisodeReferrer()->getInternalReferrer();
            $this->data =
                $internalReferrer->toArray() +
                array('emergencyRoom' => $episode->getEpisodeReferrer()->getEmergencyRoom());

            $this->data += array("date" => $episode->getEpisodeReferrer()
                ->getReferrerDate()->format(\Date\Format::getFormat()));

            if ($episode->getEpisodeReferrer()->getDOTReferrerCode()) {
                $this->data += array("DOTReferrerCode" => ($episode->getEpisodeReferrer()->getDOTReferrerCode()) ? $episode->getEpisodeReferrer()->getDOTReferrerCode()->toListArray() : null);
            }
            if ($episode->getEpisodeReferrer()) {
                $this->data += array("MHCReferrerCode" => $episode->getEpisodeReferrer()->getReferrerCodeMHCData());
            }
        }
        $errors = $this->episodeService->getErrors();
        if (!empty($errors)) {
            ValidationResult::addToMeta($errors, $this);
        }
       
        return $this->data;
    }

    /**
     * Will save the internal referrer data.
     *
     * @param \Medical\Episode $episode
     * @param \Medical\Treatment $referringTreatment
     * @param \DateTime $date
     * @param boolean $emergencyRoom
     * @param \System\DOTReferrerCode $referrerCodeObject
     * @param \System\MHC\IReferrerCode $mhcReferrerCodeObject
     *
     * @return \Generic\Referrer\Internal
     */
    private function setInternalReferrer(
        Episode $episode,
        Treatment $referringTreatment,
        $date,
        $emergencyRoom,
        DOTReferrerCode $referrerCodeObject = null,
        IReferrerCode $mhcReferrerCodeObject = null
    ) {
        $referrerData = array(
            'referringEpisode' => $referringTreatment->getEpisode(),
            'referringTreatment' => $referringTreatment,
            'referrerDate' => $date,
            'emergencyRoom' => $emergencyRoom
        );
        if ($referrerCodeObject) {
            $referrerData['DOTReferrerCode'] = $referrerCodeObject;
        }

        $referrerData['MHCReferrerCode'] = $mhcReferrerCodeObject;

        return $this->episodeService->editInternalReferrer(
            $episode,
            $referrerData
        );
    }
}