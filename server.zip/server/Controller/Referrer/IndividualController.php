<?php

namespace Controller\Referrer;

use Actinidium\API\Response\Meta;
use Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Generic\Referrer\Individual;
use Message\MessageHandler;
use Generic\Referrer\IndividualService;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/referrer",
 *     basePath="/api/v2"
 * )
 */
class IndividualController extends AbstractController
{
    /** @var IndividualService */
    protected $individualService;

    /**
     * @param IndividualService $individualService
     * @param MessageHandler $messageHandler
     */
    public function __construct(IndividualService $individualService, MessageHandler $messageHandler)
    {
        $this->individualService = $individualService;
        $this->messageHandler = $messageHandler;
    }

    /**
     * @SWG\Api(
     *   path="/referrer-individual",
     *   @SWG\Operation(
     *      method="GET",
     *      summary="Find individuals by criteria",
     *      @SWG\Parameter(name="search", type="string", required=false, paramType="query"),
     *      @SWG\Parameter(name="code", type="string", required=false, paramType="query"),
     *      @SWG\Parameter(name="organizationId", type="string", required=false, paramType="query"),
     *      @SWG\Parameter(name="offset", type="integer", required=false, paramType="query", defaultValue=0),
     *      @SWG\Parameter(name="itemsPerPage", type="integer", required=false, paramType="query", defaultValue=30),
     *   )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function getListAction(Request $request)
    {
        $data = array();
        $response = $this->defaultResponse();
        $referrerIndividualService = $this->individualService;
        $search = $referrerIndividualService->getIndividualSearchByRequest($request);

        $isSearchValid = $this->isModelValid($search);

        if ($isSearchValid) {
            list ($data, $totalCount) = $referrerIndividualService->search($search);

            $this->addPagination(
                $search->getOffset(),
                $search->getLimitPerPage(),
                $totalCount
            );

            $data = array_map(function(Individual $item) {
                return $item->toListArray();
            }, $data);

        }

        if ($isSearchValid && 0 === count($data)) {
            $this->getMeta()->addMessage(
                Meta::STATUS_INFO,
                $this->messageHandler->getOne('MG103')
            );
        }

        $response->setData(array('data' => $data));
        return $response;
    }
}
