<?php

namespace Controller\Referrer\External;

use \Controller\AbstractController;
use \Generic\SystemProviderTypeService;

/**
 * Class TypeController
 * Retrieves all external types
 */
class TypeController extends AbstractController
{
    const EXTERNAL = 'external';
    const SYSTEM_EXTERNAL = 'systemexternal';

    /* @var \Generic\Referrer\OrganizationTypeService */
    private $organizationTypeService;

    /* @var \Generic\SystemProviderTypeService */
    private $systemProviderTypeService;

    /**
     * Retrieves all possible external referrer types
     *
     * @return array of strings
     */
    public function getListAction()
    {
        $list = array_merge(
            $this->getNames(
                $this->createOrganizationTypeService(),
                self::EXTERNAL
            ),
            $this->getNames(
                $this->createSystemProviderTypeService(),
                self::SYSTEM_EXTERNAL
            )
        );
        $this->getMeta()->setCount(count($list));
        return $list;
    }

    /**
     * Checks if $id and $type are in the list of referrer types.
     *
     * @param int $id
     * @param string $type
     *
     * @return bool
     */
    public function validateType($id, $type)
    {
        $list = $this->getListAction();
        if (!empty($list)) {
            foreach ($list as $refType) {
                if ($refType['id'] == $id && $refType['src'] == $type) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Creates \Generic\Referrer\OrganizationTypeService if not yet exists.
     *
     * @return \Generic\Referrer\OrganizationTypeService
     */
    private function createOrganizationTypeService()
    {
        if (!$this->organizationTypeService) {
            $this->organizationTypeService = new \Generic\Referrer\OrganizationTypeService();
        }
        return $this->organizationTypeService;
    }

    /**
     * Creates a \Generic\SystemProviderTypeService if not exists yet.
     *
     * @return \Generic\SystemProviderTypeService
     */
    private function createSystemProviderTypeService()
    {
        if (!$this->systemProviderTypeService) {
            $this->systemProviderTypeService = new \Generic\SystemProviderTypeService();
        }
        return $this->systemProviderTypeService;
    }

    /**
     * Return the names from external referral types
     *
     * @param \Service\AbstractService $service
     * @param string $src
     *
     * @return array of string
     */
    private function getNames(\Service\AbstractService $service, $src)
    {
        $names = array();
        $types = $service->findAll();
        if (!empty($types)) {
            foreach ($types as $type) {
                $names[] = array(
                    "id" => $type->getId(),
                    "name" => ucfirst($type->getName()),
                    "src" => $src
                );
            }
        }
        return $names;
    }
}
