<?php

namespace Controller\Referrer;


use Actinidium\API\Response\Meta;
use Controller\AbstractController;
use Generic\Referrer\IndividualService;
use Generic\Referrer\OrganizationService;
use Generic\SpecialismService;
use Medical\Episode;
use Medical\EpisodeService;
use Security\Sanitizer;
use Controller\ValidationResult;
use Controller\DotReferrerCodeHelper;
use Controller\MHCReferrerCodeHelper;
use System\DOTReferrerCode;
use System\MHC\ReferrerCodeService;
use System\MHC\ReferrerCode;
use Medical\Treatment;
use Medical\Treatment\Factory as TreatmentFactory;


/**
 * Class ExternalController
 * CRUD for External Referrer
 */
class ExternalController extends AbstractController
{
    /**
     * @var EpisodeService
     */
    private $episodeService;

    /**
     * @var SpecialismService
     */
    private $specialtyService;

    /**
     * @var OrganizationService
     */
    private $organizationService;

    /**
     * @var IndividualService
     */
    private $individualService;


    /**
     * @param mixed $data
     *
     * @return array
     */
    public function createAction($data)
    {

        $this->data = array();
        $referrerData = $this->validateData($data);

        if (!$this->getMeta()->hasError()) {
            $result = $this->episodeService->setExternalReferrer($referrerData['episode'], $referrerData);
            if ($result) {
                $this->data = $referrerData['episode']->getEpisodeReferrer()->getExternalReferrer()->toArray()
                    + array(
                        'emergencyRoom' => $referrerData['episode']->getEpisodeReferrer()->getEmergencyRoom(),
                        "date" => $referrerData['episode']->getEpisodeReferrer()
                            ->getReferrerDate()->format(\Date\Format::getFormat()),
                        "DOTReferrerCode" => ($referrerData['episode']->getEpisodeReferrer()->getDOTReferrerCode()) ? $referrerData['episode']->getEpisodeReferrer()->getDOTReferrerCode()->toListArray() : null,
                        "MHCReferrerCode" => $referrerData['episode']->getEpisodeReferrer()->getReferrerCodeMHCData()
                    );
            }
        }
        $errors = $this->episodeService->getErrors();
        if (!empty($errors)) {
            ValidationResult::addToMeta($errors, $this);
        }

        return $this->data;
    }

    /**
     * @param $referrerData
     *
     * @return array
     */
    protected function validateData($referrerData)
    {
        $data = array();

        $data['episode'] = $this->createEntity(
            $referrerData['episode']['id'],
            'episodeId',
            $this->getEpisodeService(),
            '\Medical\Episode'
        );

        if (!empty($referrerData['specialty']['id'])) {
            $data['specialism'] = $this->createEntity(
                $referrerData['specialty']['id'],
                'specialtyId',
                $this->getSpecialtyService(),
                'Generic\Specialism'
            );
        }

        $data['organization'] = $this->createEntity(
            $referrerData['organization']['id'],
            'organizationId',
            $this->getOrganizationService(),
            'Generic\Referrer\Organization'
        );

        if (!empty($referrerData['person']['id'])) {
            $data['individual'] = $this->createEntity(
                $referrerData['person']['id'],
                'personId',
                $this->getIndividualService(),
                'Generic\Referrer\Individual'
            );
        }

        $data['referrerDate'] = $this->validateDate($referrerData['date'], 'date');
        $data['emergencyRoom'] = $this->validateEmergencyRoom($referrerData['emergencyRoom']);

        if (!$data['episode']) {
            return $this->data;
        }

        $referrerCodeObject = null;

        if ($this->isDotReferrerNeeded($data['episode'])) {
            $dotReferrerHelper = new DotReferrerCodeHelper($this);
            $data['DOTReferrerCode'] = $dotReferrerHelper->validateDOTReferrerCode($referrerData);
        }

        if (array_key_exists('MHCReferrerCode', $referrerData)) {
            $data['MHCReferrerCode'] = null;

            if (!empty($referrerData['MHCReferrerCode']['id']) && ($data['episode']->getTreatmentTypeWithCareType() == Treatment\Factory::TYPE_DBCMHC || $data['episode']->getTreatmentTypeWithCareType() == Treatment\Factory::TYPE_BASIS_MHC)) {
                $mhcReferrerHelper = new MHCReferrerCodeHelper($this);
                if (Sanitizer::boolean($referrerData['MHCReferrerCode']['youth'])
                && $this->getEpisodeService()->checkYouthReferrerCodeApplicable($data['episode'])) {
                    $data['MHCReferrerCode'] = $mhcReferrerHelper->validateMHCYouthReferrerCode($referrerData);
                } else {
                    $data['MHCReferrerCode'] = $mhcReferrerHelper->validateMHCReferrerCode($referrerData);
                }
            }
        }

        return $data;
    }

    /**
     * Only apply a DOT Referrer Code if the treatment is of a certain type.
     *
     * @param \Medical\Episode $episode
     *
     * @return bool
     */
    private function isDotReferrerNeeded(Episode $episode)
    {
        return ($episode->getTreatmentTypeWithCareType() == TreatmentFactory::TYPE_DBCsomatic ||
            $episode->getTreatmentType() == Treatment::TYPE_PM ||
            $episode->getTreatmentTypeWithCareType() == TreatmentFactory::TYPE_INSURED_SOMATIC);
    }

    /**
     * Is it a correct boolean?
     *
     * @param bool $emergencyRoom
     *
     * @return bool
     */
    private function validateEmergencyRoom($emergencyRoom)
    {
        if (is_string($emergencyRoom)) {
            if (!Sanitizer::isBoolean($emergencyRoom)) {
                $this->addMessage(
                    Meta::STATUS_ERROR,
                    'MG101',
                    array('field_name' => 'emergencyRoom', 'input' => $emergencyRoom)
                );

            } else {
                $emergencyRoom = Sanitizer::boolean($emergencyRoom);
            }
        }
        return $emergencyRoom;
    }

    /**
     * @return IndividualService
     */
    protected function getIndividualService()
    {
        if (!$this->individualService) {
            $this->individualService = new IndividualService();
        }

        return $this->individualService;
    }

    /**
     * @return OrganizationService
     */
    protected function getOrganizationService()
    {
        if (!$this->organizationService) {
            $this->organizationService = new OrganizationService();
        }

        return $this->organizationService;
    }

    /**
     * @return SpecialismService
     */
    protected function getSpecialtyService()
    {
        if (!$this->specialtyService) {
            $this->specialtyService = new SpecialismService();
        }
        return $this->specialtyService;
    }

    /**
     * @return EpisodeService
     */
    protected function getEpisodeService()
    {
        if (!$this->episodeService) {
            $this->episodeService = new EpisodeService();
        }
        return $this->episodeService;
    }
}
