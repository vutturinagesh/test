<?php

namespace Controller\Referrer;

use Actinidium\API\Response\Meta;
use Controller\AbstractController;
use Controller\DotReferrerCodeHelper;
use Controller\MHCReferrerCodeHelper;
use Medical\Episode;
use Medical\EpisodeService;
use Medical\Treatment;
use Security\Sanitizer;
use System\MHC\IReferrerCode;
use System\DOTReferrerCode;

/**
 * Callable via /api/referrer-noreferrer/:action where :action is one of the public *Action methods.
 *
 * @SWG\Resource(
 *     apiVersion="1.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/referrer",
 *     basePath="/api"
 * )
 */
final class NoReferrerController extends AbstractController
{
    /*
     * Episode service.
     *
     * @var \Medical\EpisodeService
     */
    private $episodeService;

    /**
     * Constructor.
     *
     * @param \Medical\EpisodeService $episodeService
     */
    public function __construct(EpisodeService $episodeService = null)
    {
        parent::__construct();
        $this->episodeService = $episodeService;

        if (!$this->episodeService) {
            $this->episodeService = $this->get('medicore.medical.episode_service');
        }
    }

    /**
     * Create action.
     *
     * @SWG\Api(
     *     path="/referrer-noReferrer",
     *     @SWG\Operation(
     *         method="POST",
     *         summary="Create",
     *     )
     * )
     *
     * @param array $data
     *
     * @return array
     */
    public function createAction(array $data)
    {
        $episode = $this->createEntity($data['episode']['id'], 'episodeId', $this->episodeService, '\Medical\Episode');
        $emergencyRoom = false;
        if (mb_strlen($data['emergencyRoom'])) {
            $emergencyRoom = $this->validateEmergencyRoom($data['emergencyRoom']);
        }

        if (!$episode) {
            return $this->data;
        }

        $referrerCodeObject = null;
        if ($episode->canHaveDOTReferrerCode()) {
            $dotReferrerHelper = new DotReferrerCodeHelper($this);
            $referrerCodeObject = $dotReferrerHelper->validateDOTReferrerCode($data);
        }

        $MHCReferrerCode = null;
        if (array_key_exists('MHCReferrerCode', $data)) {

           if (!empty($data['MHCReferrerCode']['id']) &&
                ($episode->getTreatmentTypeWithCareType() == Treatment\Factory::TYPE_DBCMHC ||
                $episode->getTreatmentTypeWithCareType() == Treatment\Factory::TYPE_BASIS_MHC)) {
                $mhcReferrerHelper = new MHCReferrerCodeHelper($this);
                if (Sanitizer::boolean($data['MHCReferrerCode']['youth'])
                && $this->episodeService->checkYouthReferrerCodeApplicable($episode)) {
                    $MHCReferrerCode = $mhcReferrerHelper->validateMHCYouthReferrerCode($data);
                } else {
                    $MHCReferrerCode = $mhcReferrerHelper->validateMHCReferrerCode($data);
                }
            }
        }
        if ($this->hasError()) {
            return $this->data;
        }
        $this->data = $this->create($episode, $emergencyRoom, $referrerCodeObject, $MHCReferrerCode);
        return $this->data;
    }

    /**
     * Create.
     *
     * @param \Medical\Episode $episode
     * @param boolean $emergencyRoom
     * @param \System\DOTReferrerCode $referrerCodeObject
     * @param \System\MHC\IReferrerCode $mhcReferrerCodeObject
     *
     * @return array
     */
    private function create(
        Episode $episode,
        $emergencyRoom,
        DOTReferrerCode $referrerCodeObject = null,
        IReferrerCode $mhcReferrerCodeObject = null
    ) {
        $result = $this->episodeService->setNoReferrer($episode, $emergencyRoom, $referrerCodeObject, $mhcReferrerCodeObject);
        if ($result) {
            $this->data =
                $episode->getEpisodeReferrer()->getNoReferrer()->toArray() +
                array('emergencyRoom' => $episode->getEpisodeReferrer()->getEmergencyRoom(),
                'DOTReferrerCode' => ($episode->getEpisodeReferrer()->getDOTReferrerCode()) ? $episode->getEpisodeReferrer()->getDOTReferrerCode()->toListArray() : null,
                'MHCReferrerCode' => $episode->getEpisodeReferrer()->getReferrerCodeMHCData()
                );
        } else {
            $this->addErrorsToMeta($this->episodeService->getErrors());
        }
        return $this->data;
    }

    /**
     * Validate emergency room.
     *
     * @param boolean $emergencyRoom
     *
     * @return boolean
     */
    private function validateEmergencyRoom($emergencyRoom)
    {
        if (is_string($emergencyRoom)) {
            if (!\Security\Sanitizer::isBoolean($emergencyRoom)) {
                $this->getMeta()->addMessage(
                    Meta::STATUS_ERROR,
                    $this->messageHandler->getOne(
                        'MG101',
                        \Message\MessageHandler::BLOCKING,
                        array(
                            'field_name' => 'emergencyRoom',
                            'input' => $emergencyRoom
                        )
                    )
                );

            } else {
                $emergencyRoom = \Security\Sanitizer::boolean($emergencyRoom);
            }
        }
        return $emergencyRoom;
    }
}