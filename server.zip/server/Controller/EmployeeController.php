<?php

namespace Controller;

use Actinidium\API\Response\NonCachedJsonResponse;
use Generic\Clinic;
use Generic\ClinicService;
use Generic\Customer;
use Generic\CustomerSettingsService;
use Generic\Employee;
use Generic\EmployeeService;
use Generic\SpecialismService;
use Actinidium\API\Response\Meta;
use Response\PaginationAdaptor;
use Symfony\Component\HttpFoundation\JsonResponse;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/employee",
 *     basePath="/api/v2"
 * )
 */
class EmployeeController extends AbstractController
{
    private $model;
    private $specialtyModel;
    private $clinicModel;
    const SPECIALIST = 'specialist';
    public function __construct()
    {
        parent::__construct();
        $this->model = $this->getEmployeeModel();
    }

    /**
     * @SWG\Api(
     *   path="/employee",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Find employee by criteria",
     *           notes="Returns employee",
     *           @SWG\Parameter(name="specialtyId", type="integer", required=false, paramType="query"),
     *           @SWG\Parameter(name="clinicId", type="integer", required=false, paramType="query"),
     *           @SWG\Parameter(name="attendingPhysician", type="boolean", required=false, paramType="query"),
     *           @SWG\Parameter(name="skipAuthorization", type="boolean", required=false, paramType="query"),
     *           @SWG\Parameter(name="mainSpecialistId", type="integer", required=false, paramType="query"),
     *           @SWG\Parameter(name="activeOn", type="string", format="date", required=false, paramType="query"),
     *           @SWG\Parameter(name="offset", type="integer", required=false, paramType="query"),
     *           @SWG\Parameter(name="itemsPerPage", type="integer", required=false, paramType="query"),
     *           @SWG\Parameter(name="type", type="string", required=false, paramType="query"),
     *           @SWG\Parameter(name="pagination", type="boolean", required=true, paramType="query")
     *       )
     * )
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function getListAction()
    {
        $response = new NonCachedJsonResponse();

        $this->data = array();
        $pagination = true;

        $criteria = array();
        $order = array("surname" => "ASC");

        $queryObject = $this->getRequest()->query;

        $offset = (int)$queryObject->get('offset', 0);
        $limit = (int)$queryObject->get('itemsPerPage', PaginationAdaptor::MAXLIMIT);

        $this->isPositiveIntegerOrZero('offset', $offset);
        $this->isEntityIdPositiveInteger($limit, 'itemsPerPage');

        if ($queryObject->has("pagination")) {
            $pagination = $this->validateBoolean(
                $queryObject->get("pagination"),
                "pagination"
            );
        }

        if ($queryObject->has("specialtyId")) {
            $specialtyModel = $this->getSpecialtyModel();
            $specialty = $this->createEntity(
                $queryObject->get("specialtyId"),
                "specialtyId",
                $specialtyModel,
                "Generic\\Specialism"
            );
            if ($specialty) {
                $criteria["specialty"] = $specialty;
            }
        }
        if ($queryObject->has("clinicId")) {
            $clinicModel = $this->getClinicModel();
            $clinic = $this->createEntity(
                $queryObject->get("clinicId"),
                "clinicId",
                $clinicModel,
                "Generic\\Clinic"
            );
            if ($clinic) {
                $criteria["clinic"] = $clinic;
            }
        }

        if ($queryObject->has("attendingPhysician")) {
            $criteria["attendingPhysician"] = $this->validateBoolean(
                $queryObject->get("attendingPhysician"),
                "attendingPhysician"
            );
        }

        if (($queryObject->has("activeOn"))) {
            $activeOn = $this->getActiveOn($queryObject->get("activeOn"));
            if ($activeOn) {
                $criteria["activeOn"] = $activeOn;
            }
        }
        
        if ($queryObject->has("mainSpecialistId")) {
            $mainSpecialist = $this->createEntity(
                $queryObject->get("mainSpecialistId"),
                "mainSpecialistId",
                $this->model,
                "Generic\\Employee"
            );
            if ($mainSpecialist) {
                $criteria["mainSpecialist"] = $mainSpecialist;
            }
        }

        if ($queryObject->get('type') == self::SPECIALIST) {
            $criteria["searchOnlySpecialist"] = true;
        }

        $criteria['skipAuthorization'] = false;
        $skipAuthorization = $queryObject->get('skipAuthorization');
        if ($queryObject->has('skipAuthorization') && ($skipAuthorization !== '1' && $skipAuthorization !== '0')) {
            $criteria['skipAuthorization'] = $this->validateBoolean(
                $skipAuthorization,
                "skipAuthorization"
            );
        }

        if ($this->getMeta()->hasError()) {
            return $this->data;
        }

        if ($pagination) {
            list($employees, $totalCount) = $this->getEmployeeModel()->findAllByEmployee($criteria, $order, $offset, $limit, $pagination);
            $this->addPagination($offset, $limit, $totalCount);
        } else {
            $employees = $this->getEmployeeModel()->findAllByEmployee($criteria, $order, $offset, $limit, $pagination);
        }
        
        foreach ($employees as $employee) {
            $this->data[] = $this->toListArray($employee);
        }

        $this->getMeta()->setCount(count($this->data));

        $response->setData(array('data' => $this->data));

        return $response;
    }

    /**
     * Returns the object data from Employee.
     * 
     * Specifically not using Employee#toListArray, because it is up to each Controller to show the information
     * it needs.
     * 
     * @param \Generic\Employee $employee
     * 
     * @return array
     */
    private function toListArray(Employee $employee)
    {
        $clinics = $employee->getClinics();
        $clinicArray = array();
        foreach ($clinics as $clinic) {
            $clinicArray[] = array('id' => $clinic->getId());
        }
        return array(
            'id' => $employee->getId(),
            'name' => $employee->getFullName(),
            'agb' => $employee->getAGB(),
            'specialty' => $employee->getSpecialtyAsArray(),
            'abbreviation' => $employee->getAbbreviation(),
            'ownerId' => ($employee->getParticipantId() ? $employee->getParticipantId() : null),
            'agb' => $employee->getAGB(),
            'clinics' => $clinicArray,
            'attending' => $employee->isAttendingPhysician(),
            'deactivated' => $employee->getDeactivationDate() ? $employee->getDeactivationDate()->format('Y-m-d') : null
        );
    }

    /**
     * @return EmployeeService
     */
    protected function getEmployeeModel()
    {
        if (!$this->model) {
            $this->model = new EmployeeService();
        }
        return $this->model;
    }

    /**
     * @return SpecialismService
     */
    protected function getSpecialtyModel()
    {
        if (!$this->specialtyModel) {
            $this->specialtyModel = new SpecialismService();
        }
        return $this->specialtyModel;
    }

    /**
     * @return Clinic
     */
    protected function getClinicModel()
    {
        if (!$this->clinicModel) {
            $this->clinicModel = new ClinicService();
        }
        return $this->clinicModel;
    }

    /**
     * @return \DateTime
     */
    protected function getSystemDate()
    {
        return CustomerSettingsService::getSystemDate();
    }

    /**
     * @param string $activeOnString
     * @return \DateTime
     */
    protected function getActiveOn($activeOnString)
    {
        if ("systemdate" === strtolower($activeOnString)) {
            return $this->getSystemDate();
        }
        return $this->validateDate($activeOnString, "activeOn");
    }
}
