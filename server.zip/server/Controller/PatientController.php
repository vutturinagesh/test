<?php

namespace Controller;

use Actinidium\API\Response\Meta;
use Actinidium\API\Response\SortOrderCollection;
use Actinidium\API\Response\NonCachedJsonResponse;
use Exception\NotAuthorizedException;
use Exception;
use Generic\EmployeeService;
use Generic\Patient;
use InvalidArgumentException;
use Message\MessageHandler;
use Patient\ContactPersonValidationService as ContactPersonValidationService;
use Patient\Generic\PatRegException;
use Patient\Field\ValidationService as FieldValidationService;
use Patient\Insurance\ValidationService as InsuranceValidationService;
use Patient\LocationService;
use Patient\Location\ValidationService as LocationValidationService;
use Patient\Patient as PatientPatient;
use Patient\PatientService as PatientService;
use Patient\Relation\ValidationService as RelationValidationService;
use Patient\Referrer\ValidationService as ReferrerValidationService;
use Patient\Youthregion\ValidationService as YouthregionValidationService;
use Response\OrderingAdaptor;
use Symfony\Component\HttpFoundation\Request;

/**
 * @SWG\Resource(
 *     apiVersion="1.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/patient",
 *     basePath="/api"
 * )
 */
class PatientController extends AbstractController
{
    /**
     * Holds the patient service.
     *
     * @var PatientService.
     */
    protected $patientService;

    /**
     * Holds the patient validation service.
     *
     * @var FieldValidationService
     */
    protected $validationService;

    /**
     * Holds the patient insurance validation service.
     *
     * @var InsuranceValidationService
     */
    protected $insuranceValidationService;

    /**
     * Holds the contact person validation service.
     *
     * @var ContactPersonValidationService
     */
    protected $contactPersonValidationService;

    /**
     * Holds the relation validation service.
     *
     * @var RelationValidationService
     */
    private $relationValidationService;

    /**
     * @var ReferrerValidationService
     */
    private $referrerValidationService;

    /**
     * Holds the patient youthregion validation service.
     *
     * @var YouthregionValidationService
     */
    protected $youthregionValidationService;

    /**
     * Constant to hold the method name for update.
     *
     * @var string
     */
    const HTTP_REQUEST_METHOD_PUT = 'PUT';

    /**
     * @var LocationValidationService
     */
    private $locationValidationService;

    /**
     * Get the insurance validation service object on demand.
     *
     * @return InsuranceValidationService
     */
    private function getInsuranceValidationService()
    {
        if (!($this->insuranceValidationService instanceof InsuranceValidationService)) {
            $this->insuranceValidationService = new InsuranceValidationService();
        }

        return $this->insuranceValidationService;
    }

    /**
     * Get the contact person service object on demand.
     *
     * @return ContactPersonValidationService
     */
    private function getContactPersonValidationService()
    {
        if (!($this->contactPersonValidationService instanceof ContactPersonValidationService)) {
            $this->contactPersonValidationService = new ContactPersonValidationService();
        }

        return $this->contactPersonValidationService;
    }

    /**
     * Get the contact relation service object on demand.
     *
     * @return RelationValidationService
     */
    private function getRelationValidationService()
    {
        if (!($this->relationValidationService instanceof RelationValidationService)) {
            $this->relationValidationService = new RelationValidationService();
        }

        return $this->relationValidationService;
    }

    /**
     * Get the referrer service object on demand.
     *
     * @return RelationValidationService
     */
    private function getReferrerValidationService()
    {
        if (!($this->referrerValidationService instanceof ReferrerValidationService)) {
            $this->referrerValidationService = new ReferrerValidationService();
        }

        return $this->referrerValidationService;
    }

    /**
     * Get the Patient validation service object on demand.
     *
     * @return FieldValidationService
     */
    private function getValidationService()
    {
        if (!($this->validationService instanceof FieldValidationService)) {
            $this->validationService = new FieldValidationService();
        }

        return $this->validationService;
    }

    /**
     * Get the Patient Youthregion validation service object on demand.
     *
     * @return YouthregionValidationService
     */
    private function getYouthregionValidationService()
    {
        if (!($this->youthregionValidationService instanceof YouthregionValidationService)) {
            $this->youthregionValidationService = new YouthregionValidationService();
        }

        return $this->youthregionValidationService;
    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::getAction()
     * Display Patient
     */
    public function getAction($id)
    {
        $service = $this->get('medicore.patient.patient_service');

        try {
            return $service->get($id);
        } catch (InvalidArgumentException $e) {
            return $this->addPatientNotFoundMessageToMeta();
        } catch (NotAuthorizedException $e) {
            return $this->addPatientNotAllowedToAccessMessageToMeta();
        }
    }

    /**
     * Method adds the proper message about patient not found.
     *
     * @return \Actinidium\API\Response\Meta
     */
    private function addPatientNotFoundMessageToMeta()
    {
        return $this->getMeta()->addMessage(
            Meta::STATUS_ERROR,
            $this->messageHandler->add(
                'UR4',
                MessageHandler::BLOCKING
            )
        );
    }

    /**
     * Method adds the proper message about patient not found.
     *
     * @return \Actinidium\API\Response\Meta
     */
    private function addPatientNotAllowedToAccessMessageToMeta()
    {
        return $this->getMeta()->addMessage(
            Meta::STATUS_ERROR,
            $this->messageHandler->add(
                'UR3',
                MessageHandler::BLOCKING
            )
        );
    }

    /**
     * (non-PHPdoc)
     * @see \Actinidium\API\RestBaseController::getListAction()
     */
    public function getListAction()
    {
        $query = $this->getRequest()->query;
        $action = $query->get('action');
        $ids = $query->get('ids');

        if ($action != 'history') {

            $page = $this->processPage();
            $limit = $this->processLimit();
            $sortOrderGroup = $this->processSortOrder();
        }
        if ($this->hasError() === false) {
            $result = array();
            switch ($action)
            {
                case 'history':
                    $result = $this->getHistory($ids);
                    break;
                case 'searchNewPatient': // search before new patient screen
                    $result = $this->searchNewPatient($page, $limit, $sortOrderGroup);
                    break;
                case 'alllocation':
                    $result = $this->searchPatientByAllLocations($page, $limit, $sortOrderGroup);
                    break;
                default:
                    $result = $this->searchPatient($page, $limit, $sortOrderGroup);
                    break;
            }
        }

        return $result;

    }

    /**
     * Create patient controller action.
     *
     * @see \Actinidium\API\RestBaseController::createAction()
     * create a patient
     */
    public function createAction($data)
    {
        //Check whether logged in user has rights to create new patient?
        $mayEditPatient = $this->getEmployeeService()->mayEditPatient();
        if (!$mayEditPatient) {
            return $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->add(
                    'EMPM102',
                    \Message\MessageHandler::BLOCKING
                )
            );
        }

        $result = null;
        try {

            $this->processRequestValidation($data);
            $patientService = $this->get('medicore.patient.patient_service');

            if ($this->hasError() === false) {
                $this->validateRegistration($data);
                if ($this->hasError() === false) {

                    $patient = $patientService->beforeSave($data);

                    if ($patientService->hasErrors()) {
                        $this->addErrorsToMeta($patientService->getErrors());
                    } else {
                        $this->getMeta()->setCount(1);
                        $this->getMeta()->addMessage(
                            Meta::STATUS_SUCCESS,
                            $this->messageHandler->add(
                                'SA1',
                                \Message\MessageHandler::CONFIRMATION
                            )
                        );
                        $patientService->save($patient);

                        // Add an opposite relation for the related patient to this patient.
                        $patientService->addOppositePatientRelations($patient, $data);

                        $patientData= $patientService->prepareResponse($patient);

                        return $patientData;
                    }
                }
            }
        } catch (PatRegException $e) {
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, $e->getMessage());
        } catch (\Exception $e) {
            //@todo ideally control should never reach here. If invoked, need to be addressed
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, "IMP!". $e->getMessage());
        }

        return $result;
    }

    /**
     * API action, can we show the COV refresh link?
     *
     * @param int|null $patientId
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function canShowCovLinkAction($patientId = null)
    {
        $response = new NonCachedJsonResponse();
        $response->setData(
            array('data' => array('allowed' => false))
        );

        $typeService = $this->get('medicore.medical.treatment_type_service');

        $patientService = $this->get('medicore.patient.patient_service');
        $patient = $patientService->findById($patientId);

        if (!$typeService->hasMhcTreatmentTypes() ||
            (null !== $patient &&
            $patientService->isLinkedToSomaticClinics($patient))) {

            $response->setData(
                array('data' => array('allowed' => true))
            );
        }

        return $response;
    }

    /**
     * Delete Patient controller action.
     *
     * @param int $id
     *
     * @return boolean
     *
     * @see \Actinidium\API\RestBaseController::deleteAction()
     */
    public function deleteAction($id)
    {
        $id = $this->getRequest()->query->get('id');

        if (null === $id) {
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, 'Request parameter (id) not found', null);
            return false;
        }

        try {
            $patientService = $this->get('medicore.patient.patient_service');
            $result = $patientService->delete($id);

            if ($patientService->hasErrors()) {
                $this->addErrorsToMeta($patientService->getErrors());
            }

            $this->getMeta()->addMessage(Meta::STATUS_SUCCESS, $this->messageHandler->getOne('AC1'));

            return $result;
        } catch (PatRegException $e) {
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, $this->messageHandler->getOne('PR-M19'));

            return false;
        }
    }

    /**
     * @SWG\Api(
     *   path="/patient",
     *       @SWG\Operation(
     *           method="PUT",
     *           summary="Save a patient",
     *           @SWG\Parameter(name="id", type="integer", paramType="path", required=true),
     *           @SWG\Parameter(
     *               name="body",
     *               description="Updated patient object, see toArray as reference.",
     *               required=true,
     *               type="\Patient\Patient",
     *               paramType="body",
     *               allowMultiple=false
     *           )
     *       )
     * )
     *
     * @param integer $id
     * @param array   $data
     *
     * @return array|null
     */
    public function updateAction($id, $data)
    {
        $mayEditPatient = $this->getEmployeeService()->mayEditPatient();
        if (!$mayEditPatient) {
            return $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->add(
                    'EMPM102',
                    \Message\MessageHandler::BLOCKING
                )
            );
        }

        $patientService = $this->get('medicore.patient.patient_service');

        try {
            $patient = $patientService->get($id);
        } catch (InvalidArgumentException $e) {
            return $this->addPatientNotFoundMessageToMeta();
        } catch (NotAuthorizedException $e) {
            return $this->addPatientNotAllowedToAccessMessageToMeta();
        }

        $result = null;

        try {
            $data['id'] = $id;

            // Validate incoming request (mandatory fields).
            $this->processRequestValidation($data);

            if ($this->hasError() === false) {
                // Mo input validation errors, Validate registration itself.
                $this->validateRegistration($data);

                if ($this->hasError() === false) {
                    $patient = $patientService->beforeSave($data, $id);

                    if ($patientService->hasErrors()) {
                        $this->addErrorsToMeta($patientService->getErrors());
                    } else {
                        $this->getMeta()->addMessage(
                            Meta::STATUS_SUCCESS,
                            $this->messageHandler->add(
                                'SA1',
                                \Message\MessageHandler::CONFIRMATION
                            )
                        );
                        $this->getMeta()->setCount(1);
                        $patientService->save($patient);

                        // Add an opposite relation for the related patient to this patient.
                        $patientService->addOppositePatientRelations($patient, $data);

                        $patientData = $patientService->prepareResponse($patient);

                        return $patientData;
                    }
                }
            }
        } catch (PatRegException $e) {
            return $this->addPatientNotFoundMessageToMeta();
        } catch (Exception $e) {
            $this->logException($e);

            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->add(
                    'MG21',
                    MessageHandler::BLOCKING
                )
            );
        }

        return $result;
    }

    /**
     * Delete list patient controller action.
     *
     * @see \Actinidium\API\RestBaseController::deleteListAction()
     */
    public function deleteListAction()
    {
        $this->getMeta()->addMessage(Meta::STATUS_INFO, "Action not implemented");
    }

    /**
     * This is invoked when we search patient.
     *
     * This is equivalent to the popup of the old mcis for search patient
     *
     * @param int                 $page
     * @param int                 $limit
     * @param SortOrderCollection $sortOrderGroup
     *
     * @return array
     */
    private function searchPatient($page, $limit, SortOrderCollection $sortOrderGroup)
    {
        $data = $this->validateAndReturnRequestData();

        if (!$this->hasError()) {
            list($result, $totalCount) = $this->get('medicore.patient.patient_search_service')->searchPatient(
                $data,
                $page,
                $limit,
                $sortOrderGroup
            );

            $this->addPaginationMeta($page, $limit, $totalCount);

            return $this->setMetaMessagesByResponse($result);
        }
    }

    /**
     * This is invoked when we search patient in contact person panel.
     *
     * @param int                 $page
     * @param int                 $limit
     * @param SortOrderCollection $sortOrderGroup
     *
     * @return array
     */
    private function searchPatientByAllLocations($page, $limit, SortOrderCollection $sortOrderGroup = null)
    {
        $data = $this->validateAndReturnRequestData();
        if (!$this->hasError()) {
            list($result, $totalCount) = $this->get('medicore.patient.patient_search_service')->searchPatientInAllLocations(
                $data,
                $page,
                $limit,
                $sortOrderGroup
            );
            $this->addPaginationMeta($page, $limit, $totalCount);

            return $this->setMetaMessagesByResponse($result);
        }
    }

    /**
     * Handle the reponse and setting correct values in output.
     *
     * @param array $result
     *
     * @return array|null $result
     */
    private function setMetaMessagesByResponse(array $result)
    {
        if (count($result) == 0) {
            $this->getMeta()->addMessage(META::STATUS_ERROR, "No Records Found");
        } else {
            $this->getMeta()->setCount(count($result));
        }

        return $result;
    }

    /**
     * Process the posted data and handles validations as well.
     *
     * @return array $data
     */
    private function validateAndReturnRequestData()
    {
        $data = $this->processPostData();

        $this->processValidators($data, $this->getValidationService());

        return $data;
    }

    /**
     * Function to process the postdata and create an array of searchparams from it.
     *
     * @return array
     */
    private function processPostData()
    {
        $data = array();

        $query = $this->getRequest()->query;

        $bsnValue = $query->get('bsnValue');
        if (!is_null($bsnValue)) {
            $data['bsnValue'] =  $bsnValue;
        }

        $postCode = $query->get('postCode');
        if (!is_null($postCode)) {
            $data['postCode'] =  $postCode;
        }

        $dateOfBirth = $query->get('dateOfBirth');
        if (!is_null($dateOfBirth)) {
            $data['dateOfBirth'] =  $dateOfBirth;
        }

        $name = $query->get('name');
        if (!is_null($name)) {
            $data['name'] =  $name;
        }

        $patientCode = $query->get('patientCode');
        if (!is_null($patientCode)) {
            $data['patientCode'] =  $patientCode;
        }

        if (count($data) === 0) {
            $this->getMeta()->setCount(0);
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, $this->messageHandler->getOne(
                'MG01',
                array('list_of_fields' => 'id')
            ));
        }

        return $data;

    }

    /**
     * Function to create a sortorder adapter from the request query and set it to the Meta.
     *
     * @return \Actinidium\API\Response\SortOrderCollection
     */
    private function processSortOrder()
    {
        $direction = $this->processDirection();

        if (!$this->hasError()) {
            $query = $this->getRequest()->query;

            $orderBy = $query->get('orderby', 'id');
            $orderByArray = explode(",", $orderBy);

            $orderingAdapter = new OrderingAdaptor();
            foreach ($orderByArray as $orderItem) {
                $orderingAdapter->add($orderItem, $direction);
            }

            $sortOrderGroup = $orderingAdapter->getOrderingCollection();
            $this->getMeta()->addSortOrder($sortOrderGroup);
        }
        return $sortOrderGroup;
    }

    /**
     * Function to process direction.
     *
     * @return string
     */
    private function processDirection()
    {
        $allowedOrdering = array('desc', 'asc');

        $query = $this->getRequest()->query;
        $direction = mb_strtolower($query->get('direction', 'desc'));

        if (!in_array($direction, $allowedOrdering)) {
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->add(
                    'MG101',
                    \Message\MessageHandler::BLOCKING,
                    array('field_name' => 'direction', 'input' => $direction)
                )
            );
        }

        return $direction;
    }

    /**
     * This method os invoked when some one presses new patient.
     *
     * This method will be used for the bsn, gender, lastName, dateOfBirth
     *
     * @param int                 $page
     * @param int                 $limit
     * @param SortOrderCollection $sortOrderGroup
     *
     * @return array $result
     */
    public function searchNewPatient($page, $limit, $sortOrderGroup)
    {
        $requestData = $this->getRequest()->query;

        $data['bsnValue'] = $requestData->get('bsnValue');
        $data['physicalPostCode'] = $requestData->get('physicalPostCode');
        $data['physicalHouseNumber'] = $requestData->get('physicalHouseNumber');
        $data['dateOfBirth'] = $requestData->get('dateOfBirth');

        if (!$data['bsnValue'] &&
            !$data['physicalPostCode'] &&
            !$data['physicalHouseNumber'] &&
            !$data['dateOfBirth']) {

            $this->getMeta()->addMessage(Meta::STATUS_ERROR, $this->messageHandler->getOne(
                'MG01',
                array('list_of_fields' => 'bsnValue')
            ));
            return null;
        }

        list($result, $totalCount) = $this->get('medicore.patient.patient_search_service')->searchNewPatient(
            $data,
            $page,
            $limit,
            $sortOrderGroup
        );

        $this->addPaginationMeta($page, $limit, $totalCount);
        $this->getMeta()->setCount(count($result));

        return $result;
    }

    /**
     * Return the array of patients.
     *
     * @param string $ids
     *
     * @return array
     */
    private function getHistory($ids)
    {
        list($patients, $totalCount) = $this->get('medicore.patient.patient_service')->getHistory($ids);
        $this->getMeta()->setCount($totalCount);

        return $patients;
    }

    /**
     * Function to process the field validations.
     *
     * @param array $data
     */
    private function processRequestValidation(array $data)
    {
        $mandatoryFields = array();
        $insuranceData = array();
        // 1. Validation for patient related fields
        $this->processPatientFields($data);
        // 2. Insurance validation for both registrations
        $this->processInsuranceFields($data);
        // 3.Process contact person validation fields.
        $this->processContactPersonFields($data);
        // 4.Process relation validation fields.
        $this->processRelationsFields($data);
        //5. Process referrer validation fields.
        $this->processReferrerFields($data);
        //6.Process location validation fields.
        $this->processLocationFields($data);
        //7. Check if all youthregion mandatory fields are there.
        $this->validateMandatoryYouthregionFields($data);
    }

    /**
     * Process youthregion fields passed to the frontend and check if all required fields are there.
     *
     * @param array $data
     */
    public function validateMandatoryYouthregionFields(array $data)
    {
        if (isset($data['youthRegions']) && is_array($data['youthRegions']) && count($data['youthRegions']) > 0) {
            $youthregionValidationService = $this->getYouthregionValidationService();
            $youthregionData = $data['youthRegions'];

            foreach ($youthregionData as $youthregion) {
                // Validate top level youthregion input
                $mandatoryYouthregionFields = $youthregionValidationService->collectMandatoryFields($youthregion);
                $this->processMandatoryFields($mandatoryYouthregionFields, $youthregion);
                $this->validatePreliminaryYouthregion($youthregion);
            }
        }
    }

    /**
     * Validate a preliminary youthregion.
     *
     * @param array $youthregion
     */
    private function validatePreliminaryYouthregion(array $youthregion = array())
    {
        if (!array_key_exists("preliminary", $youthregion)
            || is_null($youthregion['preliminary'])
            || $youthregion['preliminary'] === '') {
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->add(
                    'MG01',
                    \Message\MessageHandler::BLOCKING,
                    array("list_of_fields" => 'preliminary')
                )
            );
        }
    }

    /**
     * Process location fields passed to the frontend and check if all required fields are there.
     *
     * @param array $data
     */
    private function processLocationFields(array $data)
    {
        $validationService = $this->getLocationValidationService();
        $mandatoryLocationFields = $validationService->getMandatoryFields('location');
        $locationsData = $data['locations'];
        if (empty($locationsData) || !is_array($locationsData)) {
            $this->processMandatoryFields($mandatoryLocationFields, array());
        } else {
            foreach ($locationsData as $location) {
                $this->processMandatoryFields($mandatoryLocationFields, $location);
            }
        }
    }

    /**
     * Function to process the posted insurance fields.
     *
     * @param array $data
     */
    private function processInsuranceFields(array $data)
    {
        if (isset($data['insurances']) && is_array($data['insurances']) && count($data['insurances']) > 0) {
            $insuranceValidationService = $this->getInsuranceValidationService();
            $insuranceData = $data['insurances'];

            foreach ($insuranceData as $insurance) {
                // Validate top level insurance input
                $mandatoryInsuranceFields = $insuranceValidationService->collectMandatoryFields($insurance);
                $this->processMandatoryFields($mandatoryInsuranceFields, $insurance);
            }
        }
    }

    /**
     * Function to process the posted insurance fields.
     *
     * @param array $data
     */
    private function processContactPersonFields(array $data)
    {
        if (isset($data['contacts']) && is_array($data['contacts']) && count($data['contacts']) > 0) {
            $contactPersonValidationService  = $this->getContactPersonValidationService();
            $contactPersonData = $data['contacts'];

            foreach ($contactPersonData as $contactPerson) {
                $mandatoryContactPersonFields = $contactPersonValidationService->collectMandatoryFields($contactPerson);
                $this->processMandatoryFields($mandatoryContactPersonFields, $contactPerson);
            }
        }
    }

    /**
     * Function to process the posted relation fields.
     *
     * @param array $data
     */
    private function processRelationsFields(array $data)
    {
        if (isset($data['relations']) && is_array($data['relations']) && count($data['relations']) > 0) {
            $relationsValidationService  = $this->getRelationValidationService();
            $relationsData = $data['relations'];
            if (!empty($relationsData)) {
                foreach ($relationsData as $relation) {
                    $mandatoryRelationsFields = $relationsValidationService->getMandatoryFields('relation');
                    $this->processMandatoryFields($mandatoryRelationsFields, $relation);
                }
            }
        }
    }

    /**
     * Process referrer field validations.
     *
     * @param array $data
     */
    private function processReferrerFields(array $data)
    {
        if (isset($data['referrer']) && is_array($data['referrer']) && count($data['referrer']) > 0) {
            $referrerValidationService  = $this->getReferrerValidationService();
            $referrerData = $data['referrer'];
            if (!empty($referrerData)) {
                if (isset($referrerData['type']) && $referrerData['type'] == 'no-referrer') {
                    $mandatoryReferrerFields = $referrerValidationService->getMandatoryFields('no-referrer');
                } else {
                    $mandatoryReferrerFields = $referrerValidationService->getMandatoryFields('referrer');
                }
                $this->processMandatoryFields($mandatoryReferrerFields, $referrerData);
                if (isset($data['referrer']['externalType'])) {
                    $mandatoryExternalTypeFields = $referrerValidationService->getMandatoryFields('externalType');
                    $this->processMandatoryFields($mandatoryExternalTypeFields, $data['referrer']['externalType']);
                }
            }
        }
    }

    /**
     * Function to process the posted patient related fields.
     *
     * @param array $data
     */
    private function processPatientFields(array $data)
    {
        $validationService = $this->getValidationService();

        if (array_key_exists('temporaryRegistration', $data)
            && isset($data['temporaryRegistration']) && $data['temporaryRegistration'] == true) {
            $mandatoryFields = $validationService->getMandatoryFieldsTempReg($data);
        } else {
            $mandatoryFields = $validationService->getMandatoryFieldsPermReg($data);
        }

        $this->processMandatoryFields($mandatoryFields, $data);
    }

    /**
     * Function to validate the registration for a patient (not temp).
     *
     * @param array $data
     *
     * @return void
     */
    public function validateRegistration(array $data)
    {
        $mandatoryFields = array();
        $validationService = $this->getValidationService();
        $isTempReg = false;

        if (array_key_exists('temporaryRegistration', $data)
            && isset($data['temporaryRegistration']) && $data['temporaryRegistration'] == true) {
            $mandatoryFields = $validationService->getMandatoryFieldsTempReg($data);
            $isTempReg = true;
        } else {
            $mandatoryFields = $validationService->getMandatoryFieldsPermReg($data);
        }
        $mandatoryFields = array_flip($mandatoryFields);

        $this->processValidators($data, $validationService, $mandatoryFields, $isTempReg);

        $this->validateInsurances($data, $isTempReg);

        $this->validateContactPersons($data, $isTempReg);

        $this->validateRelations($data, $isTempReg);

        $this->validateReferrer($data, $isTempReg);

        $this->validateLocations($data, $isTempReg);

        $this->validateYouthRegions($data, $isTempReg);
    }

    /**
     * Validate youthregion fields.
     *
     * @param array   $data
     * @param boolean $isTemporaryRegistered
     */
    public function validateYouthRegions(array $data = array(), $isTemporaryRegistered = false)
    {
        //also check for patient youthregion fields....
        if (isset($data['youthRegions']) && is_array($data['youthRegions']) && count($data['youthRegions']) > 0) {
            $youthregionData = $data['youthRegions'];
            $youthregionValidationService = $this->getYouthregionValidationService();
            foreach ($youthregionData as $youthregion) {
                $mandatoryYouthregionfields = $youthregionValidationService->collectMandatoryFields($youthregion);
                $this->processValidators(
                    $youthregion,
                    $youthregionValidationService,
                    array_flip($mandatoryYouthregionfields),
                    $isTemporaryRegistered
                );
            }
        }
    }

    /**
     * Validate location fields.
     *
     * @param array $data
     * @param bool  $isTempReg
     */
    private function validateLocations(array $data, $isTempReg)
    {
        // Get locations vs employees.
        $locationService = $this->getLocationService();
        $validEmployeeLocations = $locationService->getIdsFromObjects($locationService->getAccessableLocations());
        $allLocations = $locationService->getAllLocations();

        // Validate locations, except when request->locations === all locations
        if (isset($data['locations']) && is_array($data['locations']) && count($data['locations']) > 0
            && count($data['locations']) !== count($allLocations)) {

            $locationsData = $data['locations'];
            $validationService = $this->getLocationValidationService();

            if ($data['id'] !== null) {
                $patient = $this->get('medicore.patient.patient_service')->find($data['id']);
                if ($patient instanceof PatientPatient) {
                    $validationService->validateLocationRemovalForPatient($patient, $data['locations']);
                    $this->addErrorsToMeta($validationService->getErrors());
                }
            }

            foreach ($locationsData as $location) {
                $mandatoryLocationFields = $validationService->getMandatoryFields('location');
                $this->processValidators(
                    $location,
                    $validationService,
                    array_flip($mandatoryLocationFields),
                    $isTempReg
                );
            }
        }
    }

    /**
     * Function to validate the insurance fields posted for the patient.
     *
     * @param array $data
     * @param bool  $isTempReg
     *
     * @return void
     */
    private function validateInsurances(array $data, $isTempReg)
    {
        //also check for patient insurance fields....
        if (isset($data['insurances']) && is_array($data['insurances']) && count($data['insurances']) > 0) {
            $insuranceData = $data['insurances'];

            $insuranceValidationService = $this->getInsuranceValidationService();
            foreach ($insuranceData as $insurance) {
                $mandatoryInsuranceFields = $insuranceValidationService->collectMandatoryFields($insurance);
                $this->processValidators(
                    $insurance,
                    $insuranceValidationService,
                    array_flip($mandatoryInsuranceFields),
                    $isTempReg
                );
            }
        }
    }

    /**
     * Validate contact persons data.
     *
     * @param array $data
     * @param bool $isTempReg
     */
    private function validateContactPersons(array $data, $isTempReg)
    {
        if (isset($data['contacts']) && is_array($data['contacts']) && count($data['contacts']) > 0) {
            $contactPersonsData = $data['contacts'];

            $contactPersonsValidationService = $this->getContactPersonValidationService();

            foreach ($contactPersonsData as $contactPerson) {
                $mandatoryContactPersonFields = $contactPersonsValidationService
                    ->collectMandatoryFields($contactPerson);

                $relationTypeData = $contactPerson['relationType'];
                if (array_key_exists('gender', $relationTypeData)) {
                    unset($contactPerson['relationType']['gender']);
                }

                if (array_key_exists('label', $relationTypeData)) {
                    unset($contactPerson['relationType']['label']);
                }

                $this->processValidators(
                    $contactPerson,
                    $contactPersonsValidationService,
                    array_flip($mandatoryContactPersonFields),
                    $isTempReg
                );
            }
        }
    }

    /**
     * Validate relations.
     *
     * @param array $data
     * @param bool $isTempReg
     */
    private function validateRelations(array $data, $isTempReg)
    {
        if (isset($data['relations']) && is_array($data['relations']) && count($data['relations']) > 0) {
            $relationsData = $data['relations'];

            $relationsValidationService = $this->getRelationValidationService();

            foreach ($relationsData as $relation) {
                $mandatoryRelationFields = $relationsValidationService->getMandatoryFields('relation');

                $this->processValidators(
                    $relation,
                    $relationsValidationService,
                    array_flip($mandatoryRelationFields),
                    $isTempReg
                );
            }
        }
    }

    /**
     * Validate referrer data.
     *
     * @param array $data
     * @param bool  $isTempReg
     */
    private function validateReferrer(array $data, $isTempReg)
    {
        if (isset($data['referrer']) && is_array($data['referrer']) && count($data['referrer']) > 0) {
            $referrerData = $data['referrer'];
            $referrerValidationService = $this->getReferrerValidationService();

               $mandatoryReferrerFields = $referrerValidationService->getMandatoryFields('referrer');

                $this->processValidators(
                    $referrerData,
                    $referrerValidationService,
                    array_flip($mandatoryReferrerFields),
                    $isTempReg
                );
        }
    }

    /**
     * Function to process the validation for the posted data on a passed service.
     *
     * @param array $data
     * @param FieldValidationService | InsuranceValidationService | ContactPersonValidationService
     *        ReferrerValidationService
     * @param array $mandatoryFields
     * @param bool  $isTempReg
     *
     * @return void
     */
    private function processValidators(array $data, $validationService, $mandatoryFields = array(), $isTempReg = false)
    {
        //loop trough the posted fields and retrieve all the validators which are required
        foreach ($data as $field => $value) {
            if ($this->requiresValidation($field, $value, $mandatoryFields) === true) {
                $validators = array();
                if ($isTempReg === true) {
                    if (array_key_exists($field, $mandatoryFields)) {
                        $validators = $validationService->getValidationsByField($field, $value, $data);
                    }
                } else {

                    $validators = $validationService->getValidationsByField($field, $value, $data);

                }
                $this->executeValidators($validators);
            }
        }
    }

    /**
     * Protected function to check if a BSN is already in use by another patient.
     *
     * @param string     $bsn
     * @param string     $fieldName
     * @param int | null $patientId
     *
     * @return bool $isDuplicate
     */
    protected function validateUniqueBsn($bsn, $fieldName, $patientId)
    {
        $isDuplicate = true;

        if (intval($bsn) === 999999999 || intval($bsn) === 123456782) {
            $isDuplicate = false;
        } else {
            $result = null;

            $validationService = $this->getValidationService();
            $result = $validationService->validateUniqueBsn($bsn);

            if ($result === null) {
                $isDuplicate = false;
            } else {
                if ($result->getId() === (int) $patientId &&
                    $this->getRequest()->getMethod() == self::HTTP_REQUEST_METHOD_PUT
                ) {
                    $isDuplicate = false;
                }
            }
        }

        if ($isDuplicate === true) {
            $this->addMessage(
                Meta::STATUS_ERROR,
                'PRM05',
                array('fieldname' => $fieldName)
            );
        }

        return $isDuplicate;
    }

    /**
     * Get employee service object.
     *
     * @return EmployeeService
     */
    public function getEmployeeService()
    {
        if (!($this->employeeService instanceof EmployeeService)) {
            $this->employeeService = new EmployeeService();
        }
        return $this->employeeService;
    }

    /**
     * Get Location validation service.
     *
     * @return LocationValidationService
     */
    public function getLocationValidationService()
    {
        if (!($this->locationValidationService instanceof LocationValidationService)) {
            $this->locationValidationService = new LocationValidationService();
        }

        return $this->locationValidationService;
    }

    /**
     * Get patient location service.
     *
     * @return LocationService
     */
    protected function getLocationService()
    {
        if (!($this->locationService instanceof LocationService)) {
            $this->locationService = new LocationService();
        }
        return $this->locationService;
    }
}
