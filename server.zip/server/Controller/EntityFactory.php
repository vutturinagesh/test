<?php

namespace Controller;

use Actinidium\API\Response\Meta;
use Controller\AbstractController;

class EntityFactory
{
    /**
     * @param AbstractController $controller
     * @param $id
     * @return mixed
     */
    public static function patient(AbstractController $controller, $id) {
        return $controller->createEntity($id, 'patient', new \Generic\PatientService(), '\Generic\Patient');
    }

    /**
     * @param AbstractController $controller
     * @param $id
     * @return mixed
     */
    public static function clinic(AbstractController $controller, $id) {
        return $controller->createEntity($id, 'clinic', new \Generic\ClinicService(), '\Generic\Clinic');
    }

    /**
     * @param AbstractController $controller
     * @param $id
     * @return mixed
     */
    public static function employee(AbstractController $controller, $id) {
        return $controller->createEntity($id, 'employee', new \Generic\EmployeeService(), '\Generic\Employee');
    }

    /**
     * @param AbstractController $controller
     * @param $id
     * @return mixed
     */
    public static function awbzFunction(AbstractController $controller, $id) {
        return $controller->createEntity($id, 'function', new \System\Awbz\FunctioncodeService(), '\System\Awbz\Functioncode');
    }

    /**
     * @param AbstractController $controller
     * @param $id
     * @return mixed
     */
    public static function awbzClass(AbstractController $controller, $id) {
        return $controller->createEntity($id, 'class', new \System\Awbz\FindStatusClassService(), '\System\Awbz\StatusClass');
    }

    /**
     * @param AbstractController $controller
     * @param $id
     * @return mixed
     */
    public static function awbzUnit(AbstractController $controller, $id) {
        return $controller->createEntity($id, 'unit', new \System\Awbz\UnitService(), '\System\Awbz\Unit');
    }

    /**
     * @param AbstractController $controller
     * @param $id
     * @return mixed
     */
    public static function awbzFrequency(AbstractController $controller, $id) {
        return $controller->createEntity($id, 'frequency', new \System\Awbz\FrequencyService(), '\System\Awbz\Frequency');
    }

    /**
     * @param AbstractController $controller
     * @param $id
     * @return mixed
     */
    public static function awbzDeliveryStatus(AbstractController $controller, $id) {
        return $controller->createEntity($id, 'delivery status', new \System\Awbz\DeliverystatusService(), '\System\Awbz\Deliverystatus');
    }

    /**
     * @param AbstractController $controller
     * @param $id
     * @return mixed
     */
    public static function ztwType(AbstractController $controller, $id) {
        return $controller->createEntity($id, 'ztwType', new \System\Awbz\ZtwTypeService(), '\System\Awbz\ZtwType');
    }

    /**
     * @param AbstractController $controller
     * @param $id
     * @return mixed
     */
    public static function careProvision(AbstractController $controller, $id) {
        return $controller->createEntity($id, 'careprovision', new \Awbz\CareProvision\FindService(), '\Awbz\CareProvision');
    }
}
