<?php

namespace Controller;

/**
 * MCIS
 *
 * @author      Hank Kam <hank.kam@medicore.nl>
 * @copyright   Copyright (c) Medicore B.V.
 *
 * @category    MCIS
 * @package     
 * @version     $Id$
 */

/**
 * Sub class
 *          View Referrer
 *          This class creates an array of referrer information for the GUI

 * @author  Hank Kam <hank.kam@medicore.nl>
 *
 */
class ViewReferrer {

    private
            $episodeReferrerData = array(
                'id' => '',
                'referrer_noreferrer_id' => '',
                'referrer_internal_id' => '',
                'referrer_external_id' => '',
                'referrer_externalgp_id' => '',
                'referrer_date' => '',
                'emercencyRoom' => ''
                    ),
            $referrerSelfInitiative,
            $specialist,
            $referringEpisode,
            $careInstitution,
            $careProvider,
            $referrerOrganisation,
            $referrerIndividual,
            $referrerSpecialsm,
            $episodeReferrer,
            $referrer;

    /** Empty constructor */
    public function __construct() {
        
    }

    /**
     * Method
     *          View Referrer
     * @author  Hank Kam <hank.kam@medicore.nl>
     * 
     * @param   \Medical\Episode $episode
     */
    public function viewReferrer(\Medical\Episode $episode) {
        $this->episodeReferrer = $episode->getEpisodeReferrer();
        if ($this->episodeReferrer) {
            try {
                $this->episodeReferrer->getId();
                return $this->getReferrerInformation();
            } catch (\Exception $e) {
                //I have no episode referrer, dump the empty array
            }
        }
        return $this->mergeViewData();
    }

    /**
     * Method
     *          get Referrer Information
     * @author  Hank Kam <hank.kam@medicore.nl>
     * @todo    create interface IReferrer and add showData method
     *          then you can call $referrer->showData() and you can get rid of this switch 
     *          statement
     */
    private function getReferrerInformation() {
        $this->setViewDataEpisodeReferrer();
        $this->referrer = $this->episodeReferrer->getReferrer();

        if ($this->referrer) {
            switch ($this->referrer) {
                case $this->referrer instanceof \Generic\Referrer\External :
                    $this->setViewDataExternalReferrer();
                    break;
                case $this->referrer instanceof \Generic\Referrer\GeneralPractitioner :
                    $this->setViewDataGeneralPractitioner();
                    break;
                case $this->referrer instanceof \Generic\Referrer\Internal :
                    $this->setViewDataInternalReferrer();
                    break;
                case $this->referrer instanceof \Generic\Referrer\NoReferrer :
                    $this->setViewDataNoReferrer();
                    break;
                default:
                    break;
            }
        }
        return $this->mergeViewData();
    }

    /**
     * Method
     *          Merge all data for view
     * @author  Hank Kam <hank.kam@medicore.nl>
     * @return  array Referrer Information
     */
    private function mergeViewData() {
        $viewData = array(
            'episodeReferrer' => $this->episodeReferrerData,
            'referrerSelfInitiative' => $this->referrerSelfInitiative,
            'specialist' => $this->specialist,
            'referringEpisode' => $this->referringEpisode,
            'careInstitution' => $this->careInstitution,
            'careProvider' => $this->careProvider,
            'referrerOrganisation' => $this->referrerOrganisation,
            'referrerIndividual' => $this->referrerIndividual,
            'referrerSpecialty' => $this->referrerSpecialsm
        );
        return $viewData;
    }

    /**
     * Method
     *          sets the view data for episode referrer
     * @author  Hank Kam <hank.kam@medicore.nl>
     */
    private function setViewDataEpisodeReferrer() {
        $this->episodeReferrerData['id'] = $this->episodeReferrer->getId();
        $this->episodeReferrerData['referrer_external_id'] = $this->getExternalReferrerId();
        $this->episodeReferrerData['referrer_externalgp_id'] = $this->getGeneralPractitionerReferrerId();
        $this->episodeReferrerData['referrer_noreferrer_id'] = $this->getNoReferrerId();
        $this->episodeReferrerData['referrer_internal_id'] = $this->getInternalReferrerId();
        $this->episodeReferrerData['referrer_date'] = $this->episodeReferrer->getReferrerDate();
        $this->episodeReferrerData['emercencyRoom'] = $this->episodeReferrer->getEmergencyRoom();
    }

    /**
     * Method
     *          Get the referrer_external_id
     * @author  Hank Kam <hank.kam@medicore.nl>
     * @return  integer $id
     */
    private function getExternalReferrerId() {
        $id = '';
        $externalReferrer = $this->episodeReferrer->getExternalReferrer();
        if ($externalReferrer) {
            try {
                $id = $externalReferrer->getId();
            } catch (\Exception $e) {
                // do nothing
            }
        }
        return $id;
    }

    /**
     * Method
     *          Get the referrer_noreferrer_id
     * @author  Hank Kam <hank.kam@medicore.nl>
     * @return integer $id
     */
    private function getNoReferrerId() {
        $id = '';
        $noReferrer = $this->episodeReferrer->getNoReferrer();
        if ($noReferrer) {
            try {
                $id = $noReferrer->getId();
            } catch (\Exception $e) {
                // do nothing
            }
        }
        return $id;
    }

    /**
     * Method
     *          Get the referrer_internal_id
     * @author  Hank Kam <hank.kam@medicore.nl>
     * @return integer $id
     */
    private function getInternalReferrerId() {
        $id = '';
        $internalReferrer = $this->episodeReferrer->getInternalReferrer();
        if ($internalReferrer) {
            try {
                $id = $internalReferrer->getId();
            } catch (\Exception $e) {
                // do nothing
            }
        }
        return $id;
    }

    /**
     * Method
     *          Get the referrer_externalgp_id
     * @author  Hank Kam <hank.kam@medicore.nl>
     * @return integer $id
     */
    private function getGeneralPractitionerReferrerId() {
        $id = '';
        $gereralPractitionerReferrer = $this->episodeReferrer->getGeneralPractitioner();
        if ($gereralPractitionerReferrer) {
            try {
                $id = $gereralPractitionerReferrer->getId();
            } catch (\Exception $e) {
                // do nothing
            }
        }
        return $id;
    }

    /**
     * Method
     *          Sets the View Data for NoReferrer
     *          Self initiative (own initiative)
     * @author  Hank Kam <hank.kam@medicore.nl>
     */
    private function setViewDataNoReferrer() {
        $selfInitiative = $this->referrer->getSelfInitiative();
        if ($selfInitiative) {
            try {
                $this->referrerSelfInitiative = array('id' => $selfInitiative->getId(), 'name' => $selfInitiative->getName());
            } catch (\Exception $e) {
                // do nothing
            }
        }
    }

    /**
     * Method
     *          Sets the View Data for teh External Referrer
     *          Organisation
     *          Individual
     *          Specialty (specialism)
     * @author  Hank Kam <hank.kam@medicore.nl>
     */
    private function setViewDataExternalReferrer() {
        $referrerOrganisation = $this->referrer->getOrganization();
        if ($referrerOrganisation) {
            try {
                $this->referrerOrganisation = array('id' => $referrerOrganisation->getId(), 'name' => $referrerOrganisation->getName());
            } catch (\Exception $e) {
                // do nothing
            }
        }

        $referrerIndividual = $this->referrer->getIndividual();
        if ($referrerIndividual) {
            try {
                $this->referrerIndividual = array('id' => $referrerIndividual->getId(), 'fullName' => $referrerIndividual->getFullName());
            } catch (\Exception $e) {
                // do nothing
            }
        }

        $referrerSpecialsm = $this->referrer->getSpecialism();
        if ($referrerSpecialsm) {
            try {
                $this->referrerSpecialsm = array('id' => $referrerSpecialsm->getId(), 'name' => $referrerSpecialsm->getName());
            } catch (\Exception $e) {
                // do nothing
            }
        }
    }

    /**
     * Method
     *          Sets the View Data for General Practitioner
     *          Care Institution
     *          Care provider
     * @author  Hank Kam <hank.kam@medicore.nl>
     */
    private function setViewDataGeneralPractitioner() {
        $careInstitution = $this->referrer->getCareInstitution();
        if ($careInstitution) {
            try {
                $this->careInstitution = array('id' => $careInstitution->getId(), 'name' => $careInstitution->getname());
            } catch (\Exception $e) {
                // do nothing
            }
        }
        $careProvider = $this->referrer->getCareProvider();
        if ($careProvider) {
            try {
                $this->careProvider = array('id' => $careProvider->getId(), 'fullName' => $careProvider->getFullName());
            } catch (\Exception $e) {
                // do nothing
            }
        }
    }

    /**
     * Method
     *          Sets the View Data for Internal Referrer
     *          Specialist
     *          Referring Episode
     * @author  Hank Kam <hank.kam@medicore.nl>
     */
    private function setViewDataInternalReferrer() {
        $specialist = $this->referrer->getSpecialist();
        if ($specialist) {
            try {
                $this->specialist = array('id' => $specialist->getId(), 'fullName' => $specialist->getFullName());
            } catch (\Exception $e) {
                // do nothing
            }
        }

        $referringEpisode = $this->referrer->getReferringEpisode();
        if ($referringEpisode) {
            try {
                $this->referringEpisode = array('id' => $referringEpisode->getId(), 'name' => $referringEpisode->getName());
            } catch (\Exception $e) {
                // do nothing
            }
        }
    }

}
