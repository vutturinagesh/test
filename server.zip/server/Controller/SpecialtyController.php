<?php

namespace Controller;

use Actinidium\API\Response\Meta;
use Generic\CustomerSettingsService;
use Symfony\Component\HttpFoundation\JsonResponse;
use Security\Sanitizer;
use Message\MessageHandler;
use Symfony\Component\HttpFoundation\ParameterBag;

/**
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/specialty",
 *     basePath="/api/v2"
 * )
 */
class SpecialtyController extends AbstractController
{
    /**
     * Get list of specialties.
     *
     * @SWG\Api(
     *   path="/specialty/{appointmentType}/{clinic}/{appointmentType}/{active}/{activeOn}",
     *       @SWG\Operation(
     *           method="GET",
     *           summary="Find specialty by criteria",
     *           notes="Returns specialty",
     *           @SWG\Parameter(name="appointmentType", type="integer", required=false, paramType="path"),
     *           @SWG\Parameter(name="clinic", type="integer", required=false, paramType="path"),
     *           @SWG\Parameter(name="active", type="boolean", required=false, paramType="path"),
     *           @SWG\Parameter(name="activeOn", type="string", format="date", required=false, paramType="path"),
     *       )
     * )
     *
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     */
    public function getListAction()
    {
        $response = new JsonResponse();

        $this->data = array();
        $request = $this->getRequest()->query;

        if ($request->has('active')) {
            $specialties = $this->filterActiveSpecialties($request);
        } else {
            $specialties = $this->filterSpecialties($request);
        }

        if (!$this->messageHandler->hasBlocking()) {
            $list = array_map(
                function($specialty) {
                    return $specialty->toListArray();
                },
                $specialties
            );
            $this->data = $this->sortSpecialtyByName($list);
        }

        $this->getMeta()->setCount(count($this->data));

        $response->setData(array('data' => $this->data));

        return $response;
    }

    /**
     * Validate request parameters.
     *
     * @param string $value
     * @param string $fieldName
     */
    private function validateActive($value, $fieldName)
    {
        if ($value != 'true') {
            if (empty($value)) {
                $this->getMeta()->addMessage(
                    Meta::STATUS_ERROR,
                    $this->messageHandler->add(
                        'MG01',
                        MessageHandler::BLOCKING,
                        array('list_of_fields' => $fieldName)
                    )
                );
            } else {
                $this->getMeta()->addMessage(
                    Meta::STATUS_ERROR,
                    $this->messageHandler->add(
                        'MG101',
                        MessageHandler::BLOCKING,
                        array("field_name" => $fieldName, "search" => $value)
                    )
                );
            }
        }
    }
    
    /**
     * Get and filter active specialties.
     *
     * @param \Symfony\Component\HttpFoundation\ParameterBag $query
     *
     * @return array
     */
    private function filterActiveSpecialties(ParameterBag $query)
    {
        if ($query->has('activeOn')) {
            $activeOnDate = $this->getActiveOn($query->get("activeOn"));
        }
        $this->validateActive($query->get('active'), 'active');
        if (!$this->getMeta()->hasError()) {
            if ($query->has('activeOn')) {
                $specialties = $this->getActiveSpecialtiesByDate($activeOnDate);
            } else {
                $specialties = $this->getActiveSpecialties();
            }
        }
        
        return $specialties;
    }

    /**
     * Filter specialties.
     *
     * @param \Symfony\Component\HttpFoundation\ParameterBag $query
     *
     * @return array
     */
    protected function filterSpecialties(ParameterBag $query)
    {
        $criteria = array();
        $this->data = array();

        if ($query->has('activeOn')) {
              $activeOnDate = $this->getActiveOn($query->get("activeOn"));
        }
        if ($query->has('appointmentType')) {
            $criteria['appointmentType'] = $query->get('appointmentType');
        }
        if ($query->has('search')) {
            $search = $query->get('search');
            $this->validateSearch($search);
        }
        if ($query->has('clinicId')) {
            $criteria['clinic'] = $query->get('clinicId');
        }
        if ($this->getMeta()->hasError()) {
            return $this->data;
        }
        if (isset($activeOnDate)) {
            $criteria['validEndDate'] = $activeOnDate;
        }
        if (isset($search)) {
            $criteria['searchString'] = $search;
        }
        
        return $this->searchSpecialties($criteria);
    }

    /**
     * Get active on value on 'activeOn' input.
     *
     * @param string $activeOnString
     *
     * @return \DateTime
     */
    protected function getActiveOn($activeOnString)
    {
        $this->isRequired($activeOnString, "activeOn");
        if ($this->getMeta()->hasError()) {
            return;
        }

        if ("systemdate" === strtolower($activeOnString)) {
            return CustomerSettingsService::getSystemDate();
        }

        return $this->validateDate($activeOnString, "activeOn");
    }

    /**
     * Find all specialties by date.
     *
     * @param \DateTime $activeOn
     *
     * @return array
     */
    protected function getActiveSpecialtiesByDate(DateTime $activeOn)
    {
        return $this->get('medicore.generic.specialism_service')->findActiveSpecialtiesByDate($activeOn);
    }

    /**
     * Find all specialties.
     *
     * @return  array
     */
    protected function getActiveSpecialties()
    {
        return $this->get('medicore.generic.specialism_service')->findActiveSpecialties();
    }

    /**
     * Sort specialty by name.
     *
     * The query result comes from the employee table so we could not sort on the name of the specialty.
     *
     * @param   array $list
     *
     * @return  array
     */
    private function sortSpecialtyByName(array $list)
    {
        $id = array();
        $name = array();
        foreach ($list as $key => $row) {
            $id[$key] = $row['id'];
            $name[$key] = $row['name'];
        }
        array_multisort($name, SORT_ASC, $id, SORT_ASC, $list);
        
        return $list;
    }

    /**
     * Validates that the search is not empty.
     *
     * @param string $search
     */
    private function validateSearch($search)
    {
        if (Sanitizer::isEmpty($search)) {
            $this->getMeta()->addMessage(
                Meta::STATUS_ERROR,
                $this->messageHandler->add(
                    'MG01',
                    MessageHandler::BLOCKING,
                    array(
                        'list_of_fields' => 'search'
                    )
                )
            );
        }
    }

    /**
     * Search for specialties.
     *
     * @param array $criteria
     *
     * @return array
     */
    private function searchSpecialties(array $criteria)
    {
        return $this->get('medicore.generic.specialism_service')->findAllBy(
            $criteria,
            array(
                'name' => 'ASC'
            )
        );
    }
}
