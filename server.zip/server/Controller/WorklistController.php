<?php

namespace Controller;

use HL7\ObserverService;
use Medical\TreatmentService;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Creates a worklist entry for an Enterprise Service Bus (in this case Mirth).
 *
 * @SWG\Resource(
 *     apiVersion="2.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/worklist",
 *     basePath="/api/v2/"
 * )
 */
class WorklistController extends AbstractController
{

    /**
     * @var \Medical\TreatmentService
     */
    private $treatmentService;

    /**
     * @var \HL7\ObserverService
     */
    private $observerService;

    /**
     * @param TreatmentService $treatmentService
     * @param ObserverService $observerService
     */
    public function __construct(
        TreatmentService $treatmentService = null,
        ObserverService  $observerService =null
    ) {
        parent::__construct();
        if (null == $treatmentService) {
            $treatmentService = $this->get('medicore.medical.treatment_service');
        }
        if (null == $observerService) {
            $observerService = $this->get('medicore.hL7.observer_service');
        }
        $this->treatmentService = $treatmentService;
        $this->observerService = $observerService;
    }

    /**
     * @SWG\Api(
     *   path="/worklist",
     *       @SWG\Operation(
     *           method="POST",
     *           summary="Creates a worklist entry for an Enterprise Service Bus (in this case Mirth)",
     *           @SWG\Parameters(
     *               @SWG\Parameter(
     *                   name="treatmentId",
     *                   type="\Medical\Treatment",
     *                   required=true,
     *                   paramType="body"
     *               ),
     *               @SWG\Parameter(
     *                   name="event",
     *                   type="string",
     *                   required=true,
     *                   paramType="body"
     *               ),
     *          ),
     *       )
     * )
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function createAction(Request $request)
    {
        $data = json_decode($request->getContent(), true);

        $response = new JsonResponse();
        $response->setPublic();
        $response->setData(array('data' => null));

        $treatment = $this->createSanitizedEntity($data['treatmentId'], $this->treatmentService, '\Medical\Treatment');
        if ($treatment && isset($data['event'])) {
            $this->observerService->notify($data['event'], $treatment);
            $response->setStatusCode(Response::HTTP_OK);
        } else {
            $response->setStatusCode(Response::HTTP_INTERNAL_SERVER_ERROR);
        }
        return $response;
    }
}
