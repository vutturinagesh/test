<?php

namespace Controller\Closure;

use Actinidium\API\Response\Meta;
use Controller\AbstractController;
use Generic\ClosureReason\ClosureReasonInterface;
use Generic\ClosureReason\ClosureReasonServiceFactory;
use Medical\Treatment;
use Medical\TreatmentService;
use Medical\Somatic\Dbc as SomaticDbc;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;

/**
 * @SWG\Resource(
 *     apiVersion="1.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/closure",
 *     basePath="/api/v2"
 * )
 *
 * Closure reason controller.
 */
class ReasonController extends AbstractController
{
    /**
     * @var \Generic\ClosureReason\ClosureReasonServiceFactory
     */
    private $closureReasonServiceFactory;

    /**
     * @var \Medical\TreatmentService
     */
    private $treatmentService;

    /**
     * @var \Medical\Treatment
     *
     * @access private Lowered accessibility due to unit testing
     */
    protected $treatment;

    /**
     * Constructor.
     *
     * @param \Generic\ClosureReason\ClosureReasonServiceFactory $closureReasonServiceFactory
     * @param \Medical\TreatmentService                          $treatmentService
     */
    public function __construct(
        ClosureReasonServiceFactory $closureReasonServiceFactory,
        TreatmentService $treatmentService
    ) {
        parent::__construct();

        $this->closureReasonServiceFactory = $closureReasonServiceFactory;
        $this->treatmentService = $treatmentService;
        $this->treatment = null;
    }

    /**
     * @SWG\Api(
     *     path="/closure-reason",
     *     @SWG\Operation(
     *         method="GET",
     *         summary="Find closure reasons for a specific treatment.",
     *         @SWG\Parameter(
     *             name="treatmentId",
     *             description="Treatment id.",
     *             type="integer",
     *             required=true,
     *             paramType="query"
     *         )
     *     )
     * )
     *
     * Get list action.
     *
     * @param \Symfony\Component\HttpFoundation\Request $request
     *
     * @return \Actinidium\API\Response\JsonResponse
     */
    public function getListAction(Request $request)
    {
        $response = new JsonResponse();
        $treatmentId = $request->query->get('treatmentId');
        $this->initTreatment($treatmentId);

        if ($this->hasError()) {
            return $response->setData(array('data' => array()));
        }

        $data = $this->getClosureReasons();
        $response->setData(array('data' => $data));
        
        return $response;
    }

    /**
     * Initialize the treatment by id.
     *
     * @param integer $treatmentId
     *
     * @access private Lowered accessibility due to unit testing
     */
    protected function initTreatment($treatmentId)
    {
        $this->treatment = $this->createEntity(
            $treatmentId,
            'treatmentId',
            $this->treatmentService,
            'Medical\Treatment'
        );
    }

    /**
     * Get closure reasons.
     *
     * @return array
     *
     * @access private Lowered accessibility due to unit testing
     */
    protected function getClosureReasons()
    {
        if ($this->treatment->isSomatic()) {
            $reasons = $this->getClosureReasonsSomatic();
        } else {
            $reasons = $this->getClosureReasonsMhc();
        }

        $data = $this->prepareClosureReasonsForGui($reasons);
        $this->getMeta()->setCount(count($data));

        return $data;
    }

    /**
     * Get somatic closure reasons.
     *
     * @return array
     *
     * @access private Lowered accessibility due to unit testing
     */
    protected function getClosureReasonsSomatic()
    {
        $criteria = array();
        $order = array('code' => 'ASC');
        if ($this->isDbcTreatment()) {
            $criteria = $this->addCriteriaForSomaticDbcTreatment($criteria);
        }

        return $this->getClosureReasonService()->findAllBy($criteria, $order, false);
    }

    /**
     * Get MHC closure reasons.
     *
     * @return array
     *
     * @access private Lowered accessibility due to unit testing
     */
    protected function getClosureReasonsMhc()
    {
        return $this->getClosureReasonService()->getActiveOn($this->treatment->getStartDate());
    }

    /**
     * Add criteria for when it is a Somatic Dbc Treatment.
     *
     * @param array $criteria
     *
     * @return array
     *
     * @access private Lowered accessibility due to unit testing
     */
    protected function addCriteriaForSomaticDbcTreatment(array $criteria)
    {
        $dbc = $this->treatment->getDbcSomatic();
        if ($dbc instanceof SomaticDbc) {
            $dbcCareType = $dbc->getDBCCareType();

            if (!empty($dbcCareType)) {
                $criteria['careType'] = $dbcCareType;
            } else {
                $this->addMessage(Meta::STATUS_WARNING, 'M527');
            }
        }
        $criteria['date'] = $this->treatment->getStartDate();
        $criteria['specialtyCode'] = $this->treatment->getEpisode()->getSpecialty()->getCode();
        $criteria['premature'] = true;
        $criteria['mutation'] = 3;
        $criteria['treatment'] = $this->treatment;

        return $criteria;
    }

    /**
     * Has the treatment a dbc property?
     *
     * @return boolean
     *
     * @access private Lowered accessibility due to unit testing
     */
    protected function isDbcTreatment()
    {
        return $this->treatmentService->isDbcTreatment($this->treatment);
    }

    /**
     * Get appropriate closure reason service by treatment.
     *
     * @return \Generic\ClosureReason\ClosureReasonServiceInterface
     *
     * @access private Lowered accessibility due to unit testing
     */
    protected function getClosureReasonService()
    {
        return $this->closureReasonServiceFactory->getByTreatment($this->treatment);
    }

    /**
     * Prepares closure reason for GUI.
     *
     * @param array $closureReasons
     *
     * @return array
     *
     * @access private Lowered accessibility due to unit testing
     */
    protected function prepareClosureReasonsForGui(array $closureReasons)
    {
        return array_values(array_map(
            function (ClosureReasonInterface $closureReason) {
                return $closureReason->toListArray();
            },
            $closureReasons
        ));
    }
}
