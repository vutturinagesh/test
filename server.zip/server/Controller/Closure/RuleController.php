<?php

namespace Controller\Closure;

use Actinidium\API\Response\Meta;
use Controller\AbstractController;
use Factory\TranslatorFactory;
use Legacy\Gateway;
use Medical\TreatmentService;
use Swagger\Annotations as SWG;
use Exception;

/**
 * @SWG\Resource(
 *     apiVersion="1.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/closure",
 *     basePath="/api"
 * )
 */
class RuleController extends AbstractController
{
    /**
     * Although the closure rules give always false on if the enddate is editable,
     * Currently in 1.10 for these reason codes exceptions are built in in dossierui.js.
     *
     * Because we do not want to break current closure rules, especially with the deadline of 1 jan 2015 coming,
     * we have these exceptions in the Controller as well.
     *
     * When we will build the closure rules in 3.x, we can implement these exceptions.
     *
     * @var array
     */
    private $reasonCodesWhereEndDateShouldBeEditable = array(22, 40, 41);


    /**
     * Sets the translator on this controller.
     */
    public function __construct()
    {
        parent::__construct();
        $this->translator = $this->get('medicore.translation.default');
    }

    /**
     * @SWG\Api(
     *     path="/closure-rule/getlist",
     *     @SWG\Operation(
     *        summary="Apply the closure rules",
     *        method="GET",
     *        @SWG\Parameter(name="treatmentId", type="integer", required=true, paramType="query"),
     *     )
     * )
     */
    public function getListAction()
    {
        //check if treatmentId is OK
        $treatment = $this->createEntity(
            $this->getRequest()->query->get('treatmentId'),
            'treatmentId',
            new TreatmentService(),
            'Medical\Treatment'
        );

        if (!$this->hasError()) {
            $result = null;
            $data = array();
            $gateway = new Gateway();
            try {
                $result = $gateway->execute(
                    'ClosureRuleResult',
                    $treatment->getId(),
                    'findOneForTreatment',
                    array($treatment->getId(), false)
                );
            } catch (Exception $e) {
                $this->addMessage(
                    Meta::STATUS_ERROR,
                    'MEXC',
                    array(
                        'message' =>
                            $this->translator->trans(
                                $e->getMessage(),
                                array(),
                                TranslatorFactory::TRANS_DOMAIN_MEDICAL
                            )
                    )
                );
            }

            if ($result) {
                $data['closureReason'] = array(
                    'id' => (int)$result->getClosureReason()->getId(),
                    'code' => $result->getClosureReason()->getCode(),
                    'shortDescription' => $result->getClosureReason()->getDescription(),
                    'description' => $result->getClosureReason()->getDescription(),
                );
                $data['endDate'] = $result->getClosureDate() ? $result->getClosureDate()->format('Y-m-d') : null;
                $data['isEndDateEditable'] = $this->isEndDateEditable($result);

                return $data;
            }
        }

        return array();
    }

    /**
     * Determines if the end date of the treatment should be editable or not.
     *
     * @note Typehinting not possible as this is an object from Legacy.
     *
     * @param $closureResult
     *
     * @return boolean
     */
    private function isEndDateEditable($closureResult)
    {
        if (in_array(
                $closureResult->getClosureReason()->getCode(),
                $this->reasonCodesWhereEndDateShouldBeEditable
            )
        ) {
            return true;
        }
        return $closureResult->isEndDateEditable();
    }

}
