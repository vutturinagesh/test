<?php

namespace Controller;

use Actinidium\API\Response\Meta;
use Actinidium\API\AnonymousAccessInterface;
use Actinidium\API\MetaBaseController;
use Exception;
use Factory\TranslatorFactory;
use Generic\EmployeeService;
use Generic\UserService;
use Symfony\Component\Translation\Translator;
use UserService as UserService2x;

/**
 * User controller.
 *
 * Callable via /api/user/:action where :action is one of the public *Action methods
 *
 * @SWG\Resource(
 *     apiVersion="1.0",
 *     swaggerVersion="1.2",
 *     resourcePath="/user",
 *     basePath="/api"
 * )
 */
class UserController extends MetaBaseController implements AnonymousAccessInterface
{
    /** @var \Generic\UserService */
    private $userService;

    /** @var \Generic\EmployeeService */
    private $employeeService;

    /** @var \Symfony\Component\Translation\Translator */
    private $translator;

    /** @var \Generic\Authorizer */
    private $authorizer;

    /**
     * @var array
     */
    private $anonymousAccessAllowedActions = array(
        'currentAction',
        'nonceLoginAction',
        'loginAction',
        'logoutAction',
    );

    /**
     * Constructor.
     *
     * @param \Generic\UserService                      $userService
     * @param \Generic\EmployeeService                  $employeeService
     * @param \Symfony\Component\Translation\Translator $translator;
     *
     * @return \Controller\UserController
     */
    public function __construct(
        UserService $userService = null,
        EmployeeService $employeeService = null,
        Translator $translator = null
    ) {
        parent::__construct();
        $this->userService = $userService;
        $this->employeeService = $employeeService;
        $this->translator = $translator;

        if (!$this->userService) {
            $this->userService = $this->get('medicore.generic.user_service');
        }
        if (!$this->employeeService) {
            $this->employeeService = $this->get('medicore.generic.employee_service');
        }
        if (!$this->translator) {
            $this->translator = $this->get('medicore.translation.default');
        }
    }

    /**
     * Check if anonymous access is allowed.
     *
     * @return boolean
     */
    public function anonymousAccessAllowed()
    {
        return (in_array($this->method, $this->anonymousAccessAllowedActions));
    }

    /**
     * Get current logged in user.
     *
     * @SWG\Api(
     *     path="/user/current",
     *     description="Get the current logged in user.",
     *     @SWG\Operation(
     *         method="GET",
     *         summary="Get current user.",
     *     )
     * )
     *
     * @return array
     */
    public function currentAction()
    {
        $this->employeeService = $this->get('medicore.generic.employee_service');

        $currentEmployee = $this->employeeService->getCurrentEmployee();
        if (null === $currentEmployee) {
            return array();
        }

        $currentUser = $currentEmployee->getUser();
        if (null === $currentUser) {
            return array();
        }

        $this->authorizer = $this->get('medicore.generic.authorizer');

        return array_merge(
            array_merge(
                $currentEmployee->getUser()->toListArray(),
                $this->employeeService->getUserRights()
            ),
            array(
                'isSpecialist' => ($currentEmployee->isAttendingPhysician() || $currentEmployee->isSupportAccount()),
                'authorizedSpecialisms' => $this->authorizer->getAuthorizedSpecialismsForCurrentEmployee(),
                'authorizedSpecialists' => $this->employeeService->getSpecialistAuthorizationsForCurrentEmployee()
            )
        );
    }

    /**
     * User nonce login.
     *
     * @SWG\Api(
     *     path="/user/nonceLogin",
     *     description="User nonce login.",
     *     @SWG\Operation(
     *         method="POST",
     *         summary="User login.",
     *         notes="User login.",
     *         @SWG\Parameter(
     *             name="username",
     *             description="Username.",
     *             type="string",
     *             paramType="body",
     *             required=true,
     *         ),
     *         @SWG\Parameter(
     *             name="nonce",
     *             description="Nonce.",
     *             type="string",
     *             paramType="body",
     *             required=true,
     *         )
     *     )
     * )
     */
    public function nonceLoginAction()
    {
        $request = $this->getRequest();
        $post = $request->request;
        $username = $post->get('username');
        $nonce = $post->get('nonce');

        $postedFields = $post->keys();
        $mandatoryFields = array('username', 'nonce');
        $missingFields = array_diff($mandatoryFields, $postedFields);
        if ($missingFields) {
            $this->addMissingFieldsMessage($missingFields);
            return;
        }

        try {
            $this->userService->nonceLogin($username, $nonce);
        } catch (Exception $exception) {
            $errorMessage = $this->translator->trans(
                $exception->getMessage(),
                array(),
                TranslatorFactory::TRANS_DOMAIN_GENERIC
            );
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, $errorMessage);
        }
    }

    /**
     * User login.
     *
     * @SWG\Api(
     *     path="/user/login",
     *     description="User login.",
     *     @SWG\Operation(
     *         method="POST",
     *         summary="User login.",
     *         notes="User login.",
     *         @SWG\Parameter(
     *             name="username",
     *             description="Username.",
     *             type="string",
     *             paramType="body",
     *             required=true,
     *         ),
     *         @SWG\Parameter(
     *             name="password",
     *             description="Password.",
     *             type="string",
     *             paramType="body",
     *             required=true,
     *         )
     *     )
     * )
     */
    public function loginAction()
    {
        $request = $this->getRequest();
        $post = $request->request;
        $username = $post->get('username');
        $password = $post->get('password');

        $postedFields = $post->keys();
        $mandatoryFields = array('username', 'password');
        $missingFields = array_diff($mandatoryFields, $postedFields);
        if ($missingFields) {
            $this->addMissingFieldsMessage($missingFields);
            return;
        }

        try {
            $this->userService->login($username, $password);
        } catch (Exception $exception) {
            $errorMessage = $this->translator->trans(
                $exception->getMessage(),
                array(),
                TranslatorFactory::TRANS_DOMAIN_GENERIC
            );
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, $errorMessage);
        }
    }

    /**
     * User logout.
     *
     * @SWG\Api(
     *     path="/user/logout",
     *     description="User logout.",
     *     @SWG\Operation(
     *         method="GET",
     *         summary="User logout.",
     *         notes="User logout."
     *     )
     * )
     */
    public function logoutAction()
    {
        $this->userService->logout();
    }

    /**
     * Change password of current logged in user.
     *
     * @todo Use validation service?
     *
     * @SWG\Api(
     *     path="/user/changePassword",
     *     description="Change password of current logged in user.",
     *     @SWG\Operation(
     *         method="POST",
     *         summary="Change password of current logged in user.",
     *         notes="Change password of current logged in user.",
     *         @SWG\Parameter(
     *             name="currentPassword",
     *             description="Current password.",
     *             type="string",
     *             paramType="body",
     *             required=true,
     *         ),
     *         @SWG\Parameter(
     *             name="password",
     *             description="Password.",
     *             type="string",
     *             paramType="body",
     *             required=true,
     *         )
     *     )
     * )
     */
    public function changePasswordAction()
    {
        $request = $this->getRequest();
        $post = $request->request;
        $currentPassword = $post->get('currentPassword');
        $password = $post->get('password');
        $passwordAgain = $post->get('passwordAgain');

        $postedFields = $post->keys();
        $mandatoryFields = array('currentPassword', 'password', 'passwordAgain');
        $missingFields = array_diff($mandatoryFields, $postedFields);
        if ($missingFields) {
            $this->addMissingFieldsMessage($missingFields);
            return;
        }

        if ($password !== $passwordAgain) {
            $errorMessage = $this->translator->trans(
                'SE-M3',
                array(),
                TranslatorFactory::TRANS_DOMAIN_GENERIC
            );
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, $errorMessage);
            return;
        }

        try {
            $this->userService->changePassword($currentPassword, $password);
        } catch (Exception $exception) {
            $errorMessage = $this->translator->trans(
                $exception->getMessage(),
                array(),
                TranslatorFactory::TRANS_DOMAIN_GENERIC
            );
            $this->getMeta()->addMessage(Meta::STATUS_ERROR, $errorMessage);
        }
    }

    /**
     * Add "missing fields" error.
     *
     * @param array $missingFields
     *
     * @access private lowered accessibility due to unit testing
     */
    protected function addMissingFieldsMessage(array $missingFields)
    {
        $errorMessage = $this->translator->trans(
            'MG01',
            array('%fields%' => implode(', ', $missingFields)),
            TranslatorFactory::TRANS_DOMAIN_GENERIC
        );
        $this->getMeta()->addMessage(Meta::STATUS_ERROR, $errorMessage);
    }
}
