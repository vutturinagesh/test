<?php
/**
 * Created by dev.
 * User: hank.kam
 * Date: 21-8-13
 * 
 */

namespace Controller;

use Actinidium\API\Response\Meta;
use Security\Sanitizer;
use Message\MessageHandler;
use Generic\CustomerSettingsService;
use System\Dbc\CharacterizationService;
use Generic\Specialism;
use Generic\SpecialismService;
use Medical\Somatic\DbcService;

class DbcController extends AbstractController
{
    /**
     * @var CharacterizationService
     */
    private $model;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->model = $this->getModel();
        parent::__construct();
    }

    public function getAction($id)
    {
        $this->getMeta()->addMessage(Meta::STATUS_ERROR, __CLASS__ . "#" . __FUNCTION__ . "() Not yet implemented.");
    }

    /**
     * Rest full getListAction
     * @return array|
     */
    public function getListAction()
    {
        $order = array('componentcode' => 'ASC');
        $this->data = array();
        $criteria = array();
        $request = $this->getRequest()->query;
        if ($request->has('specialtyId')) {
            $criteria['specialty'] = $this->validateSpecialty($request->get('specialtyId'));
        }

        if ($request->has('validOn')) {
            $criteria['validOn']= $this->validateValidOnDate($request->get('validOn'));
        }

        if (!$this->getMeta()->hasError()) {
            $dbcList    = $this->model->findAllBy($criteria, $order);
            $this->data = $this->prepareForGui($dbcList);

            $this->getMeta()->setCount(count($dbcList));
        }
        return $this->data;
    }


    /**
     * @param int $id
     * @return Specialism|bool
     */
    protected function validateSpecialty($id)
    {
        $model = new SpecialismService();
        $this->specialty = $this->createEntity(
            $id,
            'specialtyId',
            $model,
            "Generic\\Specialism"
        );
    }

    /**
     * @param string $validOn
     * @return \DateTime
     */
    private function validateValidOnDate($validOn)
    {
        if ( strtolower($validOn) == 'systemdate') {
            return CustomerSettingsService::getSystemDate();
        }
        return $this->validateDate($validOn, 'validOn');
    }

    /**
     * @param CharacterizationService $model
     */
    public function setModel(CharacterizationService $model)
    {
        $this->model = $model;
    }

    /**
     * @return CharacterizationService
     */
    private function getModel()
    {
        if (!$this->model) {
           $this->model = new CharacterizationService();
        }
        return $this->model;
    }

    /**
     * @param $list
     * @return array
     */
    private function prepareForGui($list)
    {
        $listArray = array();
        foreach ($list as $dbc) {
            /** @var $dbc Dbc */
            $summary = $dbc->toListArray();
            $careType = $dbc->getCareType();
            $group = $dbc->getGroup();
            $listArray[$careType][$group][] = $summary;
        }
        return $listArray;
    }
}
