<?php

namespace Controller;

use Actinidium\API\RestBaseController;

/**
 * MenuController
 *
 * Callable via /api/resource
 */
class ResourceController extends RestBaseController
{
    
    /**
     * Get resource by id
     *
     * @param mixed $id
     *
     * @return null
     */
    public function getAction($id) 
    {
        $this->getMeta()->addMessage(Meta::STATUS_ERROR, 'Not implemented');
        
        return null;
    }

    /**
     * Create new resource
     *
     * @param mixed $data
     *
     * @return null
     */
    public function createAction($data) 
    {
        $this->getMeta()->addMessage(Meta::STATUS_ERROR, 'Not implemented');
        
        return null;
    }

    /**
     * Update resource
     *
     * @param mixed $id
     * @param mixed $data
     *
     * @return null
     */
    public function updateAction($id, $data) 
    {
        $this->getMeta()->addMessage(Meta::STATUS_ERROR, 'Not implemented');
        
        return null;
    }

    /**
     * Delete resource
     *
     * @param int $id
     *
     * @return null
     */
    public function deleteAction($id) 
    {
        $this->getMeta()->addMessage(Meta::STATUS_ERROR, 'Not implemented');
        
        return null;
    }

    /**
     * Delete multiple resources
     *
     * @return null
     */
    public function deleteListAction() 
    {
        $this->getMeta()->addMessage(Meta::STATUS_ERROR, 'Not implemented');
        
        return null;
    }
    
    /**
     * Function used to get the resources.
     *
     * @return array
     */
    public function getListAction()
    {
        $service = $this->getResourceService();

        $result = $service->getAll();

        $data = array();
        foreach ($result as $res) {
            $data[] = $res->toListArray();
        }
        
        return $data;
    }
    
    /**
     * Function used to get the type service.
     *
     * @return Generic\ResourceService
     */
    protected function getResourceService()
    {
        if ($this->resourceService == null) {
            $this->resourceService = new \Generic\ResourceService();
        }
        
        return $this->resourceService;
    }
    
    /**
     * Function used to set the resource service.
     *
     * @param Generic\ResourceService $resourceService
     */
    public function setResourceService(\Generic\ResourceService $resourceService)
    {
        $this->resourceService = $resourceService;
    }

}