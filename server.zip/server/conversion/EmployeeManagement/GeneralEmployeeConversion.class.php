<?php

class GeneralEmployeeConversion extends AutoConversion_DatabaseChange {

     final public function getTitle() {
        return "Employee MINSERT IGNORE INTOanagement conversion";
    }


    final public function run() {
        $this->query("SET NAMES utf8");
        // commented queries will presumably be performed automatically by SMS

        /*



        -- new employee table

        */
        
        //fix broken medee
        $this->query("UPDATE medewerker SET eigennaam=login where eigennaam=''");
        $this->query("UPDATE medewerker SET eigennaam='leeg' where eigennaam=''");

        $this->query("INSERT IGNORE INTO employee
                     SELECT id, 1, titel, voorletters, afkorting, voornaam, eigennaam, tussenvoegseleigennaam, echtgenootnaam, tussenvoegselechtgenootnaam,
                     CASE geslacht WHEN 'man' THEN 1  WHEN 'vrouw' THEN 2 WHEN 'nvt' THEN 3 END,
                     geboortedatum, email, telefoonthuis, telefoonwerk, telefoonmobiel, agb, IF(bignr = 0, '', bignr),
                     functie, productieafspraak, opmerking, latestperformancecheck, CASE type
                     WHEN 'specialist' THEN 1 WHEN 'anesthesist' THEN 2 WHEN 'normaal'  THEN 3 WHEN 'gevorderd' THEN 4
                     WHEN 'hoofdbehandelaar' THEN 5 WHEN 'behandelaar' THEN 6 WHEN 'nvt'    THEN 7 END,
                     systeemspecialisme_id, 0, systeemggzberoep_id, CASE rapportage WHEN 'nee' THEN 0 WHEN 'ja' THEN 1 END,
                     deactiveren, CASE mayeditpatientinfo WHEN 'no' THEN 0 WHEN 'yes' THEN 1 END,
                     CASE resourcetype WHEN 'tool' THEN 1 WHEN 'room' THEN 2 END,
                     CASE resource_status WHEN 'inactive' THEN 0 WHEN 'active' THEN 1 END,
                     if (verwijderd = 'ja', 1, 0), 0, 0000-00-00
                     FROM medewerker WHERE resourcetype = 'human'");

        //fix



        // fix date(s)
        $this->query("UPDATE employee SET deactivate = NULL WHERE deactivate = '0000-00-00'");
        $this->query("UPDATE employee SET includeinreporttill = NULL WHERE includeinreporttill = '0000-00-00'");

         /*
        -- employee type




        */
        $this->query("INSERT IGNORE INTO employeetype(id,name) VALUES (1,'specialist')");
        $this->query("INSERT IGNORE INTO employeetype(id,name) VALUES (2,'anesthesist')");
        $this->query("INSERT IGNORE INTO employeetype(id,name) VALUES (3,'normaal')");
        $this->query("INSERT IGNORE INTO employeetype(id,name) VALUES (4,'gevorderd')");
        $this->query("INSERT IGNORE INTO employeetype(id,name) VALUES (5,'hoofdbehandelaar')");
        $this->query("INSERT IGNORE INTO employeetype(id,name) VALUES (6,'behandelaar')");
        $this->query("INSERT IGNORE INTO employeetype(id,name) VALUES (7,'nvt')");



        /*
        -- resources



        */

        $this->query("INSERT IGNORE INTO resourcetype(id,name) VALUES (1,'tool')");
        $this->query("INSERT IGNORE INTO resourcetype(id,name) VALUES (2,'room')");
        $this->query("INSERT IGNORE INTO resourcetype(id,name) VALUES (3,'human')");



        // conversion of resources (employees of resourcetype tool/room)

        $this->query("INSERT IGNORE INTO resource SELECT NULL, 1, id, eigennaam, CASE resourcetype " .
                     "WHEN 'tool' THEN 1 WHEN 'room' THEN 2 END, " .
                     "IF (resource_status = 'active', 1, 0) " .
                     "FROM medewerker WHERE resourcetype != 'human';");

        // DELETE FROM medewerker WHERE resourcetype != 'human';

        $this->query("INSERT IGNORE INTO resource_clinic " .
                    "SELECT NULL, r.id, mk.kliniek_id " .
                    "FROM resource r " .
                    "LEFT JOIN medewerker_kliniek mk ON r.employee_id = mk.medewerker_id");


        /* addresses


        */

        $this->query("INSERT IGNORE INTO addresstype(id,name) VALUES (1,'home')");
        $this->query("INSERT IGNORE INTO addresstype(id,name) VALUES (2,'mailing')");

        /*

        */

        $this->query("INSERT IGNORE INTO address " .
        "SELECT NULL, " .
          "adresstraatnaam, " .
            "plaats, " .
            "postcode, " .
            "adreshuisnummer, " .
            "adreshuisnummertoevoeging, " .
            "land_id, NULL, NULL " .
        "FROM medewerker " .
        "WHERE adresstraatnaam != '' AND plaats != '' AND postcode != '' AND adreshuisnummer != ''  " .
        "GROUP BY adresstraatnaam, plaats, postcode, adreshuisnummer, adreshuisnummertoevoeging, land_id");

        /*

        */

        $this->query("INSERT IGNORE INTO employee_address SELECT NULL, medewerker.id, address.id, 1 " .
        "FROM medewerker " .
       "LEFT JOIN address " .
        "ON medewerker.adresstraatnaam = address.street " .
        "AND medewerker.plaats = address.city " .
        "AND medewerker.postcode = address.postal " .
        "AND medewerker.adreshuisnummer = address.housenumber " .
        "AND medewerker.adreshuisnummertoevoeging = address.housenumbersuffix " .
        "WHERE medewerker.adresstraatnaam != '' AND medewerker.plaats != '' AND medewerker.postcode != '' AND medewerker.adreshuisnummer != '' ");



        // user info
        $this->query("UPDATE employee e " .
                    "JOIN medewerker m ON e.id = m.id " .
                    "JOIN ACTINIDIUM_user su ON m.login = su.username " .
                    "SET user_id = su.id");


        /*
        -- create view in old format for backwards compatibility

          */

        $this->query("INSERT IGNORE INTO employee_appointmenttype (employee_id, appointmenttype_id, duration) " .
                    "SELECT medewerker_id, bloktype_id, duur FROM medewerker_bloktype");

        /*



        -- employee clinic


        */

        $this->query("INSERT IGNORE INTO employee_clinic " .
                     "SELECT NULL, medewerker_id, kliniek_id FROM medewerker_kliniek");

        /*



        */

        $this->query("REPLACE INTO `employee_specialism` ( " .
                        "`id`, " .
                        "`employee_id`, " .
                        "`systeemspecialisme_id`, " .
                        "`accesstype`" .
        ") SELECT  " .
                      "  `id`, " .
                       " `medewerker_id`, " .
                       " `systeemspecialisme_id`, " .
                        " 1 " .
        "FROM `specialist_systeemspecialismetoegang`");

         /*



        -- employee right
        -- we insert rights for all medewerker except for support account

        */

        $this->query("INSERT IGNORE INTO employee_right " .
                     "SELECT r.id, r.medewerker_id, r.recht_id FROM medewerker_recht r ".
                     "INNER JOIN medewerker ON medewerker.id = r.medewerker_id ".
                     "WHERE medewerker.eigennaam NOT LIKE '%supportaccount%'");


        /*






        -- advanced planning right which we want to manage in this module
        */
        $this->query("REPLACE INTO ACTINIDIUM_systemright (name) VALUES ('advanced planning')");
        /*

        -- link this right to everybody who currently has any of the following rights
            -- 1 wijzigen_standaard_bloktype
            -- 2 buiten_rooster_plannen
            -- 3 dubbel_plannen
            -- 4 andere_bloktypen

        */

        $this->query("INSERT IGNORE INTO employee_right (employee_id, systemright_id) " .
                    "select DISTINCT(e.id), 9 " .
                    "from employee e " .
                    "inner join employee_right AS er1 ON e.id = er1.employee_id AND er1.systemright_id IN (1,2,3,4)");


        // add some more new rights

        $this->query("INSERT IGNORE INTO `ACTINIDIUM_systemright` (`id` ,`name`) VALUES ( '10', 'deduplicate patients'), ('11', 'not allowed to delete patients')");
        $this->query("INSERT IGNORE INTO `ACTINIDIUM_systemright` (`id` ,`name`) VALUES ( '12', 'allowed to reopen medical forms that were closed'), ('13' , 'allowed to credit invoices')");
        $this->query("INSERT IGNORE INTO `ACTINIDIUM_systemright` (`id` ,`name`) VALUES ( '14', 'allowed_to_change_employee_specialism')");

        // link right to supportaccount except 'alleen eigen patienten inzien'
        $this->query("INSERT IGNORE INTO `employee_right` (`id` , `employee_id` ,`systemright_id`) " .
                     "SELECT NULL, (SELECT id FROM employee WHERE surname LIKE '%supportaccount%'), id FROM ACTINIDIUM_systemright WHERE ACTINIDIUM_systemright.name != 'alleen eigen patienten inzien'");


        /*

        -- employee authorization



        */

        $this->query("INSERT IGNORE INTO employeeauthorization " .
        "SELECT bt.id, bt.behandeling_id, bt.medewerker_id, bt.toegelatenmedewerker_id, IF (bt.accesstype = 'full', 1, IF (bt.accesstype='readonly', 3, IF (bt.accesstype='intermediate', 2, '')) ) " .
        "FROM behandelingtoegang bt " .
        "INNER JOIN medewerker ON bt.toegelatenmedewerker_id = medewerker.id");

        /*


        -- delete links to non existing employees
        */

        $this->query("UPDATE `employeeauthorization`  " .
                "left join employee on employeeauthorization.accessedemployee_id = employee.id " .
                "SET employeeauthorization.accesstype = 99  " .
                "where isnull(employee.id) or employee.__active = 0");

        $this->query("delete from employeeauthorization where accesstype = 99");



        /*
        -- menuitem group


        */

        $this->query("INSERT IGNORE INTO menuitemgroup SELECT id, naam FROM menuitemgroep");

        /*

         */

        $this->query("INSERT IGNORE INTO employee_menuitemgroup SELECT NULL, medewerker_id, menuitemgroep_id FROM medewerker_menuitemgroep");


        /*


        -- attending physician, Marianne: "dat werd in 1.10 afgeleid van het feit of iemand hoofdbehandelaar/specialist als type had"

        */
        $this->query("UPDATE employee SET attendingphysician=1 WHERE employeetype_id IN (1,5)");



    }

}
