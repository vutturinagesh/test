-- --------------------------------------------------------------
--  Conversion MCIS 2.0
--  Project :         Employee Management
--
-- History
--  13-03-2008        Jordy            Initial version, based on Peter's queries from the Wiki
--  17-03-2008        Jordy            Added employee_appointmenttype
--  02-04-2008        Jordy            some more changes after testing
--  02-04-2008        Jordy            added discipline
--  03-04-2008        Jordy            removed discipline
--  03-04-2008        Jordy            medewerker.discipline_id is based on first characters of employee.code
--  11-04-2008        Jordy            added region/subregion
--  11-04-2008        Jordy            added country
--  14-04-2008        Jordy            some fixes, corrected addresses (with normalization), filled attending physician
--  16-04-2008        Jordy            resources conversion moved to here
--  09-05-2008		  Jordy			   standard duration appointment types
--  23-07-2008		  Jordy			   moved to general_sms.php
-- --------------------------------------------------------------


