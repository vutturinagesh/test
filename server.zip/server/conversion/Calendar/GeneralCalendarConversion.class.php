<?php

class GeneralCalendarConversion extends AutoConversion_DatabaseChange {
 
      final public function getTitle() {
        return "Employee Management conversion, general part";
    }
 
    final public function run() {

        // commented queries will presumably be performed automatically by SMS
        
        /*
 

            -- clinic  extra status
            
            CREATE TABLE IF NOT EXISTS `clinic_appointmentextrastatus` (
              `id` int(11) unsigned NOT NULL auto_increment,
              `clinic_id` smallint(3) unsigned NOT NULL,
              `appointmentextrastatus_id` smallint(3) unsigned NOT NULL,
              PRIMARY KEY  (`id`)
            );
            
            
            -- availability
            
            DROP TABLE IF EXISTS `systemavailabilitytype`;
            
            CREATE TABLE `systemavailabilitytype` (
              `id` int(10) unsigned NOT NULL auto_increment,
              `__active` tinyint(1) unsigned NOT NULL default '1',
              `name` varchar(20) default NULL,
              PRIMARY KEY  (`id`)
            );

           
                                    
            INSERT INTO `systemavailabilitytype` (`id`, `__active`, `name`) VALUES
            (1, 1, 'available'),
            (2, 1, 'unavailable'),
            (3, 1, 'busy'),
            (4, 1, 'transparent');
            
            
            
            -- appointment statuses
            
            CREATE TABLE IF NOT EXISTS `systemappointmentstatus` (
              `id` int(10) unsigned NOT NULL auto_increment,
              `__active` tinyint(1) unsigned NOT NULL default '1',
              `name` varchar(45) NOT NULL,
              `description` varchar(255) default NULL,
              PRIMARY KEY  (`id`)
            );
            
            INSERT INTO `systemappointmentstatus` (`id`, `__active`, `name`, `description`) VALUES
            (1, 1, 'checked in', NULL),
            (2, 1, 'not checked in', NULL),
            (3, 1, 'canceled less than 24 hours', NULL);
            
            
            
            -- contactmanner
            
            CREATE TABLE IF NOT EXISTS `contactmanner` (
              `id` mediumint(6) unsigned NOT NULL auto_increment,
              `__active` tinyint(1) unsigned NOT NULL default '1',
              `name` varchar(64) default NULL,
              `description` varchar(255) default NULL,
              PRIMARY KEY  (`id`)
            );
            
            */
            
            $this->query("INSERT INTO contactmanner SELECT id, 1, naam, NULL FROM contactwijze");
            
            /*
            DROP TABLE IF EXISTS contactwijze;
            
            CREATE VIEW contactwijze AS
            SELECT id, name AS naam
            FROM contactmanner;
            
            
            
            -- extra status
            
            DROP TABLE IF EXISTS `appointmentextrastatus`;
            CREATE TABLE IF NOT EXISTS `appointmentextrastatus` (
              `id` int(10) unsigned NOT NULL auto_increment,
              `__active` tinyint(1) unsigned NOT NULL default '1',
              `name` varchar(45) NOT NULL,
              `description` varchar(255) default NULL,
              `color` varchar(7) NOT NULL,
              `active` TINYINT( 1 ) UNSIGNED NOT NULL DEFAULT '1',
              PRIMARY KEY  (`id`)
            );
            */
            
            $this->query("INSERT INTO appointmentextrastatus " . 
                         "SELECT id, 1, statusname, '', color, IF (status = 'actief', 1, 0) FROM extrastatus");
            
            /*
            DROP TABLE IF EXISTS extrastatus;
            
            CREATE VIEW extrastatus AS
            SELECT id, name AS statusname, IF (active = 1, 'actief', 'niet-actief') AS status, color
            FROM appointmentextrastatus;
            
            
            -- appointment type
            
            CREATE TABLE IF NOT EXISTS `appointmenttype` (
              `id` int(10) unsigned NOT NULL auto_increment,
              `__active` tinyint(1) unsigned NOT NULL default '1',
              `active` TINYINT UNSIGNED NOT NULL default '1',
              `name` varchar(64) NOT NULL,
              `description` varchar(255) default NULL,
              `standardduration` int(10) unsigned default NULL,
              `blockgroup_id` smallint(5) unsigned NOT NULL COMMENT 'needed for pre 2.0 compatiblity',
              `referrermandatory` tinyint(3) unsigned NOT NULL,
              `maximumdaysahead` int(11) NOT NULL,
              `online` tinyint(3) unsigned NOT NULL COMMENT 'needed for pre 2.0 compatiblity',
              `maxunit` varchar(16) NOT NULL,
              `maxper` tinyint(3) unsigned NOT NULL,
              `maximum` tinyint(3) unsigned NOT NULL,
              `maxlimit` tinyint(3) unsigned NOT NULL,
            
              PRIMARY KEY  (`id`)
            );
            */
            
            $this->query("INSERT INTO appointmenttype " .
                        "SELECT id, 1, IF (actief = 'ja', 1, 0), naam, '', 0, blokgroep_id, IF(doorverwijzerverplicht = 'ja', 1, 0), maxdagenvooruit, online, " .
                        "maxunit, maxper, maximum, IF (maxlimit = 'no', 1, 0) FROM bloktype");
            
            // b260
            
            $this->query("UPDATE appointmenttype SET maxunit = ROUND(maxunit/maxper), maxper=1 WHERE maxper > 1");
            
            
            // fill standard durations according to duration for random linked employee
            $this->query("update appointmenttype a " . 
                         "left join employee_appointmenttype ea ON ea.appointmenttype_id = a.id " . 
                         "set a.standardduration = IF (isnull(ea.duration), 0, ea.duration) " . 
                         "where a.standardduration = 0");
            
            
            /*
            DROP TABLE IF EXISTS bloktype;
            
            CREATE VIEW bloktype AS
            SELECT id, blockgroup_id AS blokgroep_id,
            name AS naam, IF (referrermandatory = 1, 'ja', 'nee') AS doorverwijzerverplicht,
            maximumdaysahead AS maxdagenvooruit,
            IF(active = 1, 'ja', 'nee') AS actief,
            online, maxunit, maxper, maximum, IF (maxlimit = 1, 'yes', 'no') AS maxlimit FROM appointmenttype;
            
            
            
            -- appointment extra status
            
            DROP TABLE IF EXISTS `appointment_extrastatus`;
            CREATE TABLE IF NOT EXISTS `appointment_extrastatus` (
              `id` int(11) unsigned NOT NULL auto_increment,
              `appointment_id` int(10) unsigned NOT NULL,
              `appointmentextrastatus_id` int(10) unsigned NOT NULL,
              PRIMARY KEY  (`id`)
            );
            
            
            -- create new tables which will be filled by separate (PHP) conversion script
            
            DROP TABLE IF EXISTS `appointment`;
            CREATE TABLE IF NOT EXISTS `appointment` (
              `id` int(11) unsigned NOT NULL auto_increment,
              `__active` tinyint(1) unsigned NOT NULL default '1',
              `systemappointmentstatus_id` smallint(2) unsigned NOT NULL,
              `appointmenttype_id` int(11) unsigned NOT NULL,
              `systemavailabilitytype_id` smallint(2) unsigned NOT NULL,
              `intervalstart` timestamp NOT NULL default '0000-00-00 00:00:00',
              `intervalend` timestamp NOT NULL default '0000-00-00 00:00:00',
              `clinic_id` smallint(5) unsigned NOT NULL,
              `notes` text,
              `created` timestamp NOT NULL default '0000-00-00 00:00:00',
              `sequencenumber` smallint(3) unsigned NOT NULL default '0',
              `contactmanner_id` smallint(2) unsigned default NULL,
            
              `referrertype_id` smallint(4) unsigned default NULL,
              `referrerfixedtype` varchar(128) default NULL,
              `referrerorganization_id` int(10) unsigned default NULL,
              `referrerperson_id` int(10) unsigned default NULL,
              `referrerowninitiative_id` int(10) unsigned default NULL,
              `checkindate` timestamp,
              `seen` tinyint(1) unsigned,
            
              `kind` varchar(32) COMMENT 'needed for pre 2.0 compatiblity',
              `haste` tinyint(1) unsigned COMMENT 'needed for pre 2.0 compatiblity',
              `financiallyprocessed` tinyint(1) unsigned COMMENT 'needed for pre 2.0 compatiblity',
              `cancelreason` varchar(255)  COMMENT 'needed for pre 2.0 compatiblity',
              `break` tinyint(1) unsigned COMMENT 'needed for pre 2.0 compatiblity',
            
              `inroster` tinyint(1) unsigned COMMENT 'needed for pre 2.0 compatiblity',
              `patientgroup_id` int(10) unsigned COMMENT 'needed for pre 2.0 compatiblity',
            
              PRIMARY KEY  (`id`),
              KEY `Appointment_FKIndex1` (`systemavailabilitytype_id`),
              KEY `appointment_FKIndex2` (`appointmenttype_id`),
              KEY `appointment_FKIndex3` (`systemappointmentstatus_id`)
            );
            
            DROP TABLE IF EXISTS `appointmentexception`;
            CREATE TABLE IF NOT EXISTS `appointmentexception` (
              `id` int(11) unsigned NOT NULL auto_increment,
              `appointment_id` int(11) default NULL,
              `start` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
              `end` timestamp NOT NULL default '0000-00-00 00:00:00',
              `reason` varchar(255) default NULL,
              PRIMARY KEY  (`id`)
            );
            
            DROP TABLE IF EXISTS `appointmentparticipation`;
            CREATE TABLE IF NOT EXISTS `appointmentparticipation` (
              `id` int(11) unsigned NOT NULL auto_increment,
              `appointment_id` int(11) unsigned NOT NULL default '0',
              `participant_id` int(11) default NULL,
              `systemparticipationrole_id` smallint(5) default NULL,
              PRIMARY KEY  (`id`)
            );
            
            DROP TABLE IF EXISTS `appointmentprofile`;
            CREATE TABLE IF NOT EXISTS `appointmentprofile` (
              `id` int(10) unsigned NOT NULL auto_increment,
              `name` varchar(255) NOT NULL,
              `active` tinyint(3) unsigned NOT NULL default '1',
              PRIMARY KEY  (`id`),
              KEY `active` (`active`)
            );
            
            DROP TABLE IF EXISTS `appointmentprofileelement`;
            CREATE TABLE IF NOT EXISTS `appointmentprofileelement` (
              `id` int(10) unsigned NOT NULL auto_increment,
              `appointmentprofile_id` int(10) unsigned NOT NULL,
              `appointmenttype_id` int(10) unsigned NOT NULL,
              `proceedappointmentprofileelement_id` int(10) unsigned NOT NULL,
              `proceedasap` tinyint(3) unsigned NOT NULL default '1',
              `proceedunit` varchar(16) NOT NULL,
              `proceedamountmin` int(11) NOT NULL,
              `proceedamountmax` int(11) NOT NULL,
              `sortorder` tinyint(3) unsigned NOT NULL,
              PRIMARY KEY  (`id`),
              KEY `appointmentprofile_id` (`appointmentprofile_id`,`sortorder`)
            );
            
            DROP TABLE IF EXISTS `appointmentseries`;
            CREATE TABLE IF NOT EXISTS `appointmentseries` (
              `id` int(11) unsigned NOT NULL auto_increment,
              `__active` tinyint(1) unsigned NOT NULL default '1',
              `systemappointmentstatus_id` smallint(2) unsigned NOT NULL,
              `appointmenttype_id` int(11) unsigned NOT NULL,
              `systemavailabilitytype_id` smallint(2) unsigned NOT NULL,
              `intervalstart` timestamp NOT NULL default '0000-00-00 00:00:00',
              `intervalend` timestamp NOT NULL default '0000-00-00 00:00:00',
              `clinic_id` smallint(5) unsigned NOT NULL,
              `notes` text,
              `created` timestamp NOT NULL default '0000-00-00 00:00:00',
              `sequencenumber` smallint(3) unsigned NOT NULL default '0',
              `contactmanner_id` smallint(5) unsigned default NULL,
              `referrer_id` int(11) unsigned default NULL,
              `rrulefreq` varchar(32) default NULL,
              `rruleinterval` smallint(2) unsigned default NULL,
              `rruleuntil` timestamp NULL default NULL,
              `rrulecount` mediumint(6) unsigned default NULL,
              `rrulebymonth` varchar(30) default NULL,
              `rrulebyweekno` tinyint(3) unsigned default NULL,
              `rrulebymonthday` varchar(100) default NULL,
              `rrulebyday` varchar(25) default NULL,
              `rrulebyhour` varchar(65) default NULL,
              `rrulebyminute` varchar(255) default NULL,
              PRIMARY KEY  (`id`),
              KEY `Appointment_FKIndex1` (`systemavailabilitytype_id`),
              KEY `appointment_FKIndex2` (`appointmenttype_id`),
              KEY `appointment_FKIndex3` (`systemappointmentstatus_id`),
              KEY `appointment_FKIndex4` (`referrer_id`)
            );
            
            
            DROP TABLE IF EXISTS `appointmentseriesparticipation`;
            CREATE TABLE IF NOT EXISTS `appointmentseriesparticipation` (
              `id` int(11) unsigned NOT NULL auto_increment,
              `appointmentseries_id` int(11) unsigned NOT NULL default '0',
              `participant_id` int(11) default NULL,
              `systemparticipationrole_id` smallint(5) default NULL,
              PRIMARY KEY  (`id`)
            );
            
            DROP TABLE IF EXISTS `appointmentseries_extrastatus`;
            CREATE TABLE IF NOT EXISTS `appointmentseries_extrastatus` (
              `id` int(11) unsigned NOT NULL auto_increment,
              `appointmentseries_id` int(10) unsigned NOT NULL,
              `appointmentextrastatus_id` int(10) unsigned NOT NULL,
              PRIMARY KEY  (`id`)
            );
            
            
            
            -- nice try, but too slow
            -- CREATE VIEW participant AS
            -- (SELECT (1000000+id) AS id, __active, id AS employee_id, NULL AS resource_id, NULL AS patient_id, NULL AS user_id FROM employee)
            -- UNION
            -- (SELECT (2000000+id) AS id, __active, NULL AS employee_id, id AS resource_id, NULL AS patient_id, NULL AS user_id FROM resource)
            -- UNION
            -- (SELECT (3000000+id) AS id, 1 AS __active, NULL AS employee_id, NULL AS resource_id, id AS patient_id, NULL AS user_id FROM patient)
            -- UNION
            -- (SELECT (4000000+id) AS id, 1 AS __active, NULL AS employee_id, NULL AS resource_id, NULL AS patient_id, id user_id FROM ACTINIDIUM_user);
            
            
            DROP TABLE IF EXISTS participant;
            DROP VIEW IF EXISTS participant;
             CREATE TABLE IF NOT EXISTS `participant` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
            `__active` TINYINT UNSIGNED NOT NULL DEFAULT '1',
            `employee_id` INT UNSIGNED NOT NULL ,
            `resource_id` INT UNSIGNED NOT NULL ,
            `patient_id` INT UNSIGNED NOT NULL ,
            `user_id` INT UNSIGNED NOT NULL ,
            PRIMARY KEY ( `id` )
            );
            
            ALTER TABLE `participant` ADD INDEX ( `employee_id` );
            ALTER TABLE `participant` ADD INDEX ( `patient_id` );
            ALTER TABLE `participant` ADD INDEX ( `resource_id` );
            ALTER TABLE `participant` ADD INDEX ( `user_id` );
            
            INSERT INTO participant (__active, employee_id) SELECT __active, id FROM employee;
            INSERT INTO participant (__active, patient_id) SELECT IF(verwijderd = 'ja', 0, 1), id FROM patient;
            INSERT INTO participant (__active, resource_id) SELECT __active, id FROM resource;
            INSERT INTO participant (__active, user_id) SELECT __active, id FROM ACTINIDIUM_user;
            
            DROP TRIGGER IF EXISTS participant_patient_insert;
            CREATE TRIGGER participant_patient_insert AFTER INSERT ON `patient`
             FOR EACH ROW INSERT INTO participant SET __active = IF(NEW.verwijderd = 'ja', 0, 1), patient_id = NEW.id;
            
            DROP TRIGGER IF EXISTS participant_patient_update;
            CREATE TRIGGER participant_patient_update AFTER UPDATE ON `patient`
             FOR EACH ROW UPDATE participant SET __active = IF(NEW.verwijderd = 'ja', 0, 1) WHERE patient_id = NEW.id;
            
            DROP TRIGGER IF EXISTS participant_resource_insert;
            CREATE TRIGGER participant_resource_insert AFTER INSERT ON `resource`
             FOR EACH ROW INSERT INTO participant SET __active = NEW.__active, resource_id = NEW.id;
            
            DROP TRIGGER IF EXISTS participant_resource_update;
            CREATE TRIGGER participant_resource_update AFTER UPDATE ON `resource`
             FOR EACH ROW UPDATE participant SET __active = NEW.__active WHERE resource_id = NEW.id;
            
            DROP TRIGGER IF EXISTS participant_employee_insert;
            CREATE TRIGGER participant_employee_insert AFTER INSERT ON `employee`
             FOR EACH ROW INSERT INTO participant SET __active = NEW.__active, employee_id = NEW.id;
            
            DROP TRIGGER IF EXISTS participant_employee_update;
            CREATE TRIGGER participant_employee_update AFTER UPDATE ON `employee`
             FOR EACH ROW UPDATE participant SET __active = NEW.__active WHERE employee_id = NEW.id;
            
            DROP TRIGGER IF EXISTS participant_user_insert;
            CREATE TRIGGER participant_user_insert AFTER INSERT ON `ACTINIDIUM_user`
             FOR EACH ROW INSERT INTO participant SET __active = NEW.__active, employee_id = NEW.id;
            
            DROP TRIGGER IF EXISTS participant_user_update;
            CREATE TRIGGER participant_user_update AFTER UPDATE ON `ACTINIDIUM_user`
             FOR EACH ROW UPDATE participant SET __active = NEW.__active WHERE user_id = NEW.id;
            
            
            DROP TABLE IF EXISTS `participant_appointmenttype`;
            CREATE TABLE IF NOT EXISTS `participant_appointmenttype` (
              `id` int(11) unsigned NOT NULL auto_increment,
              `appointmenttype_id` int(10) unsigned NOT NULL,
              `participant_id` int(10) unsigned NOT NULL,
              PRIMARY KEY  (`id`),
              KEY `scheduletype_has_participant_FKIndex1` (`appointmenttype_id`),
              KEY `scheduletype_has_participant_FKIndex2` (`participant_id`)
            );
            
            
            DROP TABLE IF EXISTS `rosterrule`;
            CREATE TABLE IF NOT EXISTS `rosterrule` (
              `id` int(11) unsigned NOT NULL auto_increment,
              `__active` tinyint(1) default NULL,
              `rosterrulegroup_id` tinyint(11) unsigned default 0,
              `rosterruleprofile_id` tinyint(11) unsigned default 0,
              `intervalstart` time NULL default NULL,
              `intervalend` time NULL default NULL,
              `multiplicity` tinyint(2) unsigned NOT NULL default '1',
              `created` timestamp NOT NULL default '0000-00-00 00:00:00',
              `counter` smallint(3) unsigned NOT NULL default '0',
              PRIMARY KEY  (`id`)
            );
            
            
            ALTER TABLE `rosterrule` ADD INDEX ( `rosterrulegroup_id` );
            ALTER TABLE `rosterrule` ADD INDEX ( `rosterruleprofile_id` );
            
            DROP TABLE IF EXISTS `rosterruleexception`;
            CREATE TABLE IF NOT EXISTS `rosterruleexception` (
              `id` int(11) NOT NULL auto_increment,
              `rosterrulegroup_id` int(11) NOT NULL,
              `start` timestamp NULL default NULL,
              `end` timestamp NULL default NULL,
              `reason` varchar(255) default NULL,
              PRIMARY KEY  (`id`)
            );
            
            DROP TABLE IF EXISTS `rosterrulegroup`;
            CREATE TABLE IF NOT EXISTS `rosterrulegroup` (
              `id` int(11) unsigned NOT NULL auto_increment,
              `rosterruleprofile_id` int(11) unsigned default 0,
              `name` varchar(255) default '0',
              `intervalstart` timestamp NULL default NULL,
              `intervalend` timestamp NULL default NULL,
              `color` varchar(7) NOT NULL,
              `systemavailabilitytype_id` smallint(2) unsigned NOT NULL,
              `note` text,
              `frequency` varchar(32) default NULL,
              `period` tinyint(2) unsigned default NULL,
              `until` timestamp NULL default NULL,
              `byweekno` tinyint(3) unsigned default NULL,
              `bymonthday` varchar(100) default NULL,
              `byday` varchar(25) default NULL,
              PRIMARY KEY  (`id`)
            );
            
            DROP TABLE IF EXISTS `rosterrulegroup_clinic`;
            CREATE TABLE IF NOT EXISTS `rosterrulegroup_clinic` (
              `id` int(10) unsigned NOT NULL auto_increment,
              `rosterrulegroup_id` int(10) unsigned NOT NULL,
              `clinic_id` int(10) unsigned NOT NULL,
              PRIMARY KEY  (`id`),
              UNIQUE KEY `group_clinic` (`rosterrulegroup_id`,`clinic_id`),
              KEY `rosterrulegroup_id` (`rosterrulegroup_id`),
              KEY `clinic_id` (`clinic_id`)
            
            );
            
            
            ALTER TABLE `rosterrulegroup` ADD INDEX ( `rosterruleprofile_id` );
            
            DROP TABLE IF EXISTS `rosterruleparticipation`;
            CREATE TABLE IF NOT EXISTS `rosterrulegroupparticipation` (
              `id` int(11) NOT NULL auto_increment,
              `rosterrulegroup_id` int(11) default NULL,
              `participant_id` int(11) default NULL,
              PRIMARY KEY  (`id`)
            );
            
            CREATE TABLE IF NOT EXISTS `rosterrgrpparticipation_clinic` (
              `id` int(10) unsigned NOT NULL auto_increment,
              `rosterrulegroupparticipation_id` int(11) NOT NULL,
              `clinic_id` int(11) NOT NULL,
              KEY `clinic_id` (`clinic_id`),
              KEY `rosterrulegroupparticipation_id` (`rosterrulegroupparticipation_id`),
              PRIMARY KEY  (`id`)
            );
            
            DROP TABLE IF EXISTS `rosterruleprofile`;
            CREATE TABLE IF NOT EXISTS `rosterruleprofile` (
              `id` int(11) unsigned NOT NULL auto_increment,
              `name` varchar(255) default NULL,
              PRIMARY KEY  (`id`)
            );
            
            DROP TABLE IF EXISTS `rosterrule_appointmenttype`;
            CREATE TABLE IF NOT EXISTS `rosterrule_appointmenttype` (
              `id` int(10) unsigned NOT NULL auto_increment,
              `appointmenttype_id` int(10) unsigned NOT NULL,
              `rosterrule_id` int(10) unsigned NOT NULL,
              PRIMARY KEY  (`id`),
              KEY `rosterrule_appointmenttype_FKIndex1` (`rosterrule_id`),
              KEY `rosterrule_appointmenttype_FKIndex2` (`appointmenttype_id`)
            );
            
            
            
            CREATE TABLE IF NOT EXISTS `resource_appointmenttype` (
              `id` int(11) unsigned NOT NULL auto_increment,
              `resource_id` int(11) unsigned NOT NULL,
              `appointmenttype_id` mediumint(6) unsigned NOT NULL,
              `duration` int(11) unsigned NOT NULL,
              PRIMARY KEY  (`id`),
              KEY `resource_id` (`resource_id`,`appointmenttype_id`)
            );
            
            
            
            -- table participation role
            
            CREATE TABLE IF NOT EXISTS `systemparticipationrole` (
              `id` smallint(3) unsigned NOT NULL auto_increment,
              `name` varchar(64) NOT NULL,
              `description` varchar(255) default NULL,
              PRIMARY KEY  (`id`)
            );
            
            */
            
            
//            $this->query("INSERT INTO `systemparticipationrole` (`id`, `name`, `description`) VALUES " . 
//                        "(1, 'employee', ''), " .
//                        "(2, 'patient', ''), " .
//                        "(3, 'main care provider', ''), " .
//                        "(4, 'resource', ''), " .
//                        "(5, 'planner', '')");
            
            
            /*
            -- triggers for updating sequencenumber (needed for iCal compatibility)
            
            CREATE TRIGGER `appointment_bu` BEFORE UPDATE ON `appointment`
             FOR EACH ROW SET NEW.sequencenumber = NEW.sequencenumber+1;
            
            CREATE TRIGGER `appointmentseries_bu` BEFORE UPDATE ON `appointmentseries`
             FOR EACH ROW SET NEW.sequencenumber = NEW.sequencenumber +1;
            
            -- indices
            ALTER TABLE `appointmentparticipation` ADD INDEX ( `appointment_id` ) ;
            ALTER TABLE `appointmentparticipation` ADD INDEX ( `participant_id` );
            ALTER TABLE `appointmentseriesparticipation` ADD INDEX ( `appointmentseries_id` )  ;
            ALTER TABLE `appointmentseriesparticipation` ADD INDEX ( `participant_id` );
            ALTER TABLE `appointmentseries_extrastatus` ADD INDEX ( `appointmentseries_id` );
            ALTER TABLE `appointment_extrastatus` ADD INDEX ( `appointment_id` );
            
            
            
            
            -- referrer tables
            
            DROP TABLE IF EXISTS `systemcareinstitution` ;
            
            CREATE TABLE IF NOT EXISTS `systemcareinstitution` (
            
              `id` int(11) unsigned NOT NULL auto_increment,
            
              `systemcareprovidertype_id` smallint(5) NOT NULL default '0',
            
              `practicenumber` int(11) unsigned NOT NULL,
            
              `name` varchar(255) NOT NULL,
            
              `accrediationbegindate` date NOT NULL,
            
              `accrediationenddate` date NOT NULL,
            
              `phone` varchar(11) NOT NULL,
            
              `fax` varchar(11) NOT NULL,
            
              `addressstreetname` varchar(255) NOT NULL,
            
              `addresshousenumber` varchar(5) NOT NULL,
            
              `addresshousenumbersuffix` varchar(6) NOT NULL,
            
              `postcode` varchar(8) NOT NULL,
            
              `organizationform` tinyint(1) unsigned NOT NULL,
            
              `addresssortnumber` tinyint(3) unsigned NOT NULL,
            
              `city` varchar(255) NOT NULL,
            
              `country_id` int(11) unsigned NOT NULL,
            
              `poststreetname` varchar(255) NOT NULL,
            
              `posthousenumber` varchar(5) NOT NULL,
            
              `posthousenumbersuffix` varchar(6) NOT NULL,
            
              `postpostcode` varchar(8) NOT NULL,
            
              `postcity` varchar(255) NOT NULL,
            
              `postcountry_id` int(11) unsigned NOT NULL,
            
              `comment` varchar(255) NOT NULL,
            
              `type` tinyint(1) unsigned NOT NULL default '0',
            
              `postaddressisvisitingaddress` tinyint(1) unsigned NOT NULL default '0',
            
              `region_id` int(11) unsigned NOT NULL,
            
              `subregion_id` int(11) unsigned NOT NULL,
            
              `postregion_id` int(11) unsigned NOT NULL,
            
              `postsubregion_id` int(11) unsigned NOT NULL,
            
              `countryisocode` char(2) NOT NULL default 'NL',
            
              `modified` char(1) default NULL,
            
              `deleted` tinyint(1) default NULL,
            
              `being_deleted` char(1) default NULL,
            
              `_active` tinyint(1) unsigned NOT NULL default '1',
            
              PRIMARY KEY  (`id`),
            
              UNIQUE KEY `systemcareprovidertype_id` (`systemcareprovidertype_id`,`practicenumber`)
            
            ) ;
            
            
            
            REPLACE INTO `systemcareinstitution` (
            
                `id`, 
            
                `systemcareprovidertype_id`, 
            
                `practicenumber`, 
            
                `name`, 
            
                `accrediationbegindate`, 
            
                `accrediationenddate`, 
            
                `phone`,
            
              `fax`, 
            
              `addressstreetname`, 
            
              `addresshousenumber`, 
            
              `addresshousenumbersuffix`, 
            
              `postcode`, 
            
              `organizationform`, 
            
              `addresssortnumber`,
            
              `city`, 
            
              `country_id`, 
            
              `poststreetname`, 
            
              `posthousenumber`, 
            
              `posthousenumbersuffix`, 
            
              `postpostcode`, 
            
              `postcity`, 
            
              `postcountry_id`,
            
              `comment`, 
            
              `type`, 
            
              `postaddressisvisitingaddress`, 
            
              `region_id`,  
            
              `subregion_id`, 
            
              `postregion_id`, 
            
              `postsubregion_id`, 
            
              `countryisocode`,
            
              `modified`, 
            
              `deleted`,
            
              `being_deleted`
            
            ) SELECT 
            
                `id`, 
            
                `zorgverlenersoort_id`, 
            
                `praktijknummer`, 
            
                `naam`, 
            
                `datum_aanvang_praktijk`, 
            
                `datum_einde_praktijk`, 
            
                `telefoonnummer`, 
            
                `fax`,
            
                `adresstraatnaam`,
            
                `adreshuisnummer`, 
            
                `adreshuisnummertoevoeging`, 
            
                `postcode`, 
            
                `organisatievorm`,
            
                `praktijkadresvolgnummer`, 
            
                `plaats`, 
            
                `land_id`, 
            
                `poststraatnaam`,   
            
                `posthuisnummer`,   
            
                `posthuisnummertoevoeging`, 
            
                `postpostcode`, 
            
                `postplaats`, 
            
                `postland_id`, 
            
                `opmerking`, 
            
                IF(`type` = 'praktijk', 0, 1), 
            
                `postadresisbezoekadres`, 
            
                `region_id`, 
            
                `subregion_id`, 
            
                `postregion_id`, 
            
                `postsubregion_id`, 
            
                `landisocode`, 
            
                `bewerkt`, 
            
                IF(`verwijderd` = 'ja', 1, 0),
            
                `wordt_verwijderd`
            
            FROM `systeemzorginstelling`;
            
            
            
            DROP TABLE IF EXISTS `systeemzorginstelling` ;
            
            
            
            DROP VIEW IF EXISTS `systeemzorginstelling` ;
            
            
            
            CREATE VIEW `systeemzorginstelling` AS
            
            SELECT  
            
                `id`,
            
              `systemcareprovidertype_id` AS `zorgverlenersoort_id`,
            
              `practicenumber` AS `praktijknummer`,
            
              `name` AS `naam`,
            
              `accrediationbegindate` AS `datum_aanvang_praktijk`,
            
              `accrediationenddate` AS `datum_einde_praktijk`,
            
              `phone` AS `telefoonnummer`,
            
              `fax`,
            
              `addressstreetname` AS `adresstraatnaam`,
            
              `addresshousenumber` AS `adreshuisnummer`,
            
              `addresshousenumbersuffix` AS `adreshuisnummertoevoeging`,
            
              `postcode`,
            
              `organizationform` AS `organisatievorm`,
            
              `addresssortnumber` AS `praktijkadresvolgnummer`,
            
              `city` AS `plaats`,
            
              `country_id` AS `land_id`,
            
              `poststreetname` AS `poststraatnaam`,
            
              `posthousenumber` AS `posthuisnummer`,
            
              `posthousenumbersuffix` AS `posthuisnummertoevoeging`,
            
              `postpostcode`,
            
              `postcity` AS `postplaats`,
            
              `postcountry_id` AS `postland_id`,
            
              `comment` AS `opmerking`,
            
              IF ( `type` = 1, 'instelling', 'praktijk' ) AS `type`,
            
              `postaddressisvisitingaddress` AS `postadresisbezoekadres`,
            
              `region_id`,
            
              `subregion_id`,
            
              `postregion_id`,
            
              `postsubregion_id`,
            
              `countryisocode` AS `landisocode`,
            
              `modified` AS `bewerkt`,
            
              IF ( `deleted` = 1,'ja','nee' ) AS `verwijderd`,
            
              `being_deleted` AS `wordt_verwijderd`
            
            FROM `systemcareinstitution`;
            
            
            
            DROP TABLE IF EXISTS `systemcareprovider` ;
            
            
            
            CREATE TABLE IF NOT EXISTS `systemcareprovider` (
            
              `id` int(11) unsigned NOT NULL auto_increment,
            
              `systemcareprovidertype_id` int(11) unsigned NOT NULL,
            
              `careprovidernumber` int(11) unsigned NOT NULL,
            
              `uzovicode` mediumint(6) unsigned default NULL,
            
              `zorgmailnumber` varchar(32) default NULL,
            
              `imported` tinyint(1) unsigned NOT NULL default '0',
            
              `surname` varchar(255) NOT NULL,
            
              `surnameprefix` varchar(32) NOT NULL,
            
              `marriedname` varchar(255) NOT NULL,
            
              `marriednameprefix` varchar(32) NOT NULL,
            
              `initials` varchar(16) NOT NULL,
            
              `title` varchar(20) NOT NULL,
            
              `addressstreetname` varchar(255) NOT NULL,
            
              `addresshousenumber` varchar(5) NOT NULL,
            
              `addresshousenumbersuffix` varchar(6) NOT NULL,
            
              `postcode` varchar(8) NOT NULL,
            
              `city` varchar(255) NOT NULL,
            
              `phone` varchar(11) NOT NULL,
            
              `mobile` varchar(11) NOT NULL,
            
              `emergency` varchar(11) NOT NULL,
            
              `email` varchar(255) NOT NULL,
            
              `birthdate` date NOT NULL,
            
              `gender` tinyint(1) unsigned NOT NULL default '0',
            
              `accrediationbegindate` date NOT NULL,
            
              `accrediationenddate` date NOT NULL,
            
              `careproviderspectype` char(2) NOT NULL,
            
              `input` tinyint(1) unsigned NOT NULL default '0',
            
              `modified` char(1) default NULL,
            
              `deleted` tinyint(1) default NULL,
            
              `being_deleted` char(1) default NULL,
            
              `_active` tinyint(1) unsigned NOT NULL default '1',
            
              PRIMARY KEY  (`id`),
            
              UNIQUE KEY `systemcareprovidertype_id` (`systemcareprovidertype_id`,`careprovidernumber`),
            
              KEY `imported` (`imported`,`surname`,`initials`)
            
            )  ;
            
            
            
            REPLACE INTO `systemcareprovider` (
            
                `id`, 
            
                `systemcareprovidertype_id`, 
            
                `careprovidernumber`, 
            
                `uzovicode`, 
            
                `zorgmailnumber`, 
            
                `imported`, 
            
                `surname`, 
            
                `surnameprefix`, 
            
                `marriedname`, 
            
                `marriednameprefix`, 
            
                `initials`, 
            
                `title`, 
            
                `addressstreetname`, 
            
                `addresshousenumber`, 
            
                `addresshousenumbersuffix`, 
            
                `postcode`, 
            
                `city`, 
            
                `phone`, 
            
                `mobile`, 
            
                `emergency`, 
            
                `email`, 
            
                `birthdate`, 
            
                `gender`, 
            
                `accrediationbegindate`, 
            
                `accrediationenddate`, 
            
                `careproviderspectype`, 
            
                `input`,
            
                `modified`, 
            
              `deleted`,
            
              `being_deleted`
            
            ) SELECT 
            
                `id`, 
            
                `zorgverlenersoort_id`, 
            
                `zorgverlenernummer`, 
            
                `uzovicode`, 
            
                `zorgmailnummer`, 
            
                `geimporteerd`, 
            
                `eigennaam`, 
            
                `tussenvoegseleigennaam`, 
            
                `echtgenootnaam`, 
            
                `tussenvoegselechtgenootnaam`, 
            
                `voorletters`, 
            
                `titel`,  
            
                `adresstraatnaam`, 
            
                `adreshuisnummer`, 
            
                `adreshuisnummertoevoeging`, 
            
                `postcode`, 
            
                `plaats`, 
            
                `telefoonnummer`, 
            
                `mobiel`, 
            
                `noodnummer`, 
            
                `email`, 
            
                `geboortedatum`, 
            
                `geslacht`, 
            
                `datumaanvangberoep`, 
            
                `datumeindeberoep`, 
            
                `nadereverbzvlsrt`, 
            
                `invoer`,
            
                `bewerkt`, 
            
                IF(`verwijderd` = 'ja',1,0),
            
                `wordt_verwijderd`
            
            FROM `systeemzorgverlener`;
            
            
            
            DROP TABLE IF EXISTS `systeemzorgverlener` ;
            
            
            
            DROP VIEW IF EXISTS `systeemzorgverlener` ;
            
            
            
            CREATE VIEW `systeemzorgverlener` AS
            
            SELECT  
            
                `id`, 
            
                `systemcareprovidertype_id` AS `zorgverlenersoort_id`, 
            
                `careprovidernumber` AS `zorgverlenernummer`, 
            
                `uzovicode`, 
            
                `zorgmailnumber` AS `zorgmailnummer`, 
            
                `imported` AS `geimporteerd`, 
            
                `surname` AS `eigennaam`, 
            
                `surnameprefix` AS `tussenvoegseleigennaam`, 
            
                `marriedname` AS `echtgenootnaam`, 
            
                `marriednameprefix` AS `tussenvoegselechtgenootnaam`, 
            
                `initials` AS `voorletters`, 
            
                `title` AS `titel`, 
            
                `addressstreetname` AS `adresstraatnaam`, 
            
                `addresshousenumber` AS `adreshuisnummer`, 
            
                `addresshousenumbersuffix` AS `adreshuisnummertoevoeging`, 
            
                `postcode`, 
            
                `city` AS `plaats`, 
            
                `phone` AS `telefoonnummer`, 
            
                `mobile` AS `mobiel`, 
            
                `emergency` AS `noodnummer`, 
            
                `email` AS `email`, 
            
                `birthdate` AS `geboortedatum`, 
            
                `gender` AS `geslacht`, 
            
                `accrediationbegindate` AS `datumaanvangberoep`, 
            
                `accrediationenddate` AS `datumeindeberoep`, 
            
                `careproviderspectype` AS `nadereverbzvlsrt`, 
            
                `input` AS `invoer`,
            
                `modified` AS `bewerkt`,
            
              IF ( `deleted` = 1,'ja','nee' ) AS `verwijderd`,
            
              `being_deleted` AS `wordt_verwijderd`
            
            FROM `systemcareprovider`;
            
            
            
            
            
            
            
            DROP TABLE IF EXISTS `systemcareprovidertype` ;
            
            
            
            CREATE TABLE IF NOT EXISTS `systemcareprovidertype` (
            
              `id` int(11) unsigned NOT NULL auto_increment,
            
              `name` varchar(255) NOT NULL,
            
              PRIMARY KEY  (`id`)
            
            ) ;
            
            
            
            REPLACE INTO `systemcareprovidertype` (
            
                `id`,
            
              `name`
            
            ) SELECT 
            
                `id`, `naam`
            
            FROM `systeemzorgverlenersoort`;
            
            
            
            DROP TABLE IF EXISTS `systeemzorgverlenersoort` ;
            
            
            
            DROP VIEW IF EXISTS `systeemzorgverlenersoort` ;
            
            
            
            CREATE VIEW `systeemzorgverlenersoort` AS
            
            SELECT 
            
                `id`,
            
                `name` AS `naam`
            
            FROM `systemcareprovidertype`;
            
            
            
            
            
            
            
            DROP TABLE IF EXISTS `systemcareprovider_careinst`;
            
            
            
            CREATE TABLE IF NOT EXISTS `systemcareprovider_careinst` (
            
              `id` int(11) unsigned NOT NULL auto_increment,
            
              `systemcareprovidertype_id` int(11) unsigned NOT NULL,
            
              `accrediationbegindate` date NOT NULL,
            
              `accrediationenddate` date NOT NULL,
            
              `status` tinyint(1) unsigned NOT NULL default '1',
            
              `input` tinyint(1) unsigned NOT NULL default '0',
            
              `systemcareprovider_id` int(11) unsigned NOT NULL,
            
              `systemcareinstitution_id` int(11) unsigned NOT NULL,
            
              `modified` char(1) default NULL,
            
              `deleted` tinyint(1) default NULL,
            
              `being_deleted` char(1) default NULL,
            
              `_active` tinyint(1) unsigned NOT NULL default '1',
            
              PRIMARY KEY  (`id`),
            
              KEY `systemcareprovidertype_id` (`systemcareprovidertype_id`)
            
            )  ;
            
            
            
            REPLACE INTO `systemcareprovider_careinst` (
            
                `id`,
            
              `systemcareprovidertype_id`,
            
              `accrediationbegindate`,
            
              `accrediationenddate`,
            
              `status`,
            
              `input`,
            
              `systemcareprovider_id`,
            
              `systemcareinstitution_id`,
            
                `modified`, 
            
              `deleted`,
            
              `being_deleted`
            
            ) SELECT 
            
                `id`, `zorgverlenersoort_id`, `datumtoetreding`, `datumuittreding`, `statusinpraktijk`, `invoer`, `systeemzorgverlener_id`, `systeemzorginstelling_id`,
            
                `bewerkt`, 
            
                IF(`verwijderd` = 'ja',1,0),
            
                `wordt_verwijderd`
            
            FROM `systeemzorgverlener_zorginstelling`;
            
            
            
            DROP TABLE IF EXISTS `systeemzorgverlener_zorginstelling` ;
            
            
            
            DROP VIEW IF EXISTS `systeemzorgverlener_zorginstelling` ;
            
            
            
            CREATE VIEW `systeemzorgverlener_zorginstelling` AS
            
            SELECT 
            
                `id`,
            
              `systemcareprovidertype_id` AS `zorgverlenersoort_id`,
            
              `accrediationbegindate` AS `datumtoetreding`,
            
              `accrediationenddate` AS `datumuittreding`,
            
              `status` AS `statusinpraktijk`,
            
              `input` AS `invoer`,
            
              `systemcareprovider_id` AS `systeemzorgverlener_id`,
            
              `systemcareinstitution_id` AS `systeemzorginstelling_id`,
            
                `modified` AS `bewerkt`,
            
              IF ( `deleted` = 1,'ja','nee' ) AS `verwijderd`,
            
              `being_deleted` AS `wordt_verwijderd`
            
            FROM `systemcareprovider_careinst`;
            
            
            
            
            
            DROP TABLE IF EXISTS `referrerindividual`;
            
            
            
            CREATE TABLE IF NOT EXISTS `referrerindividual` (
            
              `id` int(11) unsigned NOT NULL auto_increment,
            
              `status` tinyint(1) unsigned NOT NULL default '1',
            
              `referrerorganization_id` int(11) unsigned NOT NULL,
            
              `gender` tinyint(1) unsigned NOT NULL default '0',
            
              `initials` varchar(16) NOT NULL,
            
              `surname` varchar(255) NOT NULL,
            
              `surnameprefix` varchar(32) NOT NULL,
            
              `marriedname` varchar(255) NOT NULL,
            
              `marriednameprefix` varchar(32) NOT NULL,
            
              `phone` varchar(11) NOT NULL,
            
              `mobile` varchar(11) NOT NULL,
            
              `fax` varchar(11) NOT NULL,
            
              `email` varchar(255) NOT NULL,
            
              PRIMARY KEY  (`id`)
            
            );
            
            
            */
            
            
            $this->query("REPLACE INTO `referrerindividual` (" .
                        "`id`, `status`, `referrerorganization_id`, `gender`, `initials`, `surnameprefix`, `surname`, `marriedname`, " . 
                        "`marriednameprefix`, `phone`,`mobile`,`fax`,`email`) SELECT `id`, IF(`status` = 'man',0,1), " . 
                        "`referrerorganisation_id`, `geslacht`, `voorletters`, `tussenvoegseleigennaam`, `eigennaam`, " . 
                        "`echtgenootnaam`, `tussenvoegselechtgenootnaam`, `telefoonvast`, `telefoonmobiel`, `fax`, `email` " . 
                        "FROM `referrerperson`");
            
            
            /*
            
            
            DROP TABLE IF EXISTS `referrerperson` ;
            
            
            
            DROP VIEW IF EXISTS `referrerperson` ;
            
            
            
            CREATE VIEW `referrerperson` AS
            
            SELECT 
            
                `id`,
            
              `status`,
            
              `referrerorganization_id`,
            
              IF(`gender` = 0,'man','vrouw') AS `geslacht`,
            
              `initials` AS `voorletters`,
            
              `surnameprefix` AS `tussenvoegseleigennaam`,
            
              `surname` AS `eigennaam`,
            
              `marriedname` AS `echtgenootnaam`,
            
              `marriednameprefix` AS `tussenvoegselechtgenootnaam`,
            
              `phone` AS `telefoonvast`,
            
              `mobile` AS `telefoonmobiel`,
            
              `fax`,
            
              `email`
            
            FROM `referrerindividual`;
            
            
            
            
            
            DROP TABLE IF EXISTS `referrerorganization`;
            
            
            
            CREATE TABLE IF NOT EXISTS `referrerorganization` (
            
              `id` int(10) unsigned NOT NULL auto_increment,
            
              `referrerorganizationtype_id` smallint(4) NOT NULL default '0',
            
              `name` varchar(255) NOT NULL,
            
              `addressstreetname` varchar(255) NOT NULL,
            
              `addresshousenumber` varchar(5) NOT NULL,
            
              `addresshousenumbersuffix` varchar(6) NOT NULL,
            
              `postcode` varchar(8) NOT NULL,
            
              `city` varchar(255) NOT NULL,
            
              `country_id` int(11) unsigned NOT NULL,
            
              `region_id` int(11) unsigned NOT NULL,
            
              `subregion_id` int(11) unsigned NOT NULL,
            
              `phone` varchar(11) NOT NULL,
            
              `fax` varchar(11) NOT NULL,
            
              `email` varchar(255) NOT NULL,
            
              `status` tinyint(1) unsigned NOT NULL default '1',
            
              `discount` int(11) unsigned NOT NULL,
            
              PRIMARY KEY  (`id`)
            
            )  ;
            
            */
            
             $this->query("REPLACE INTO `referrerorganization` (" . 
                          "`id`, `referrerorganizationtype_id`, `name`, `addressstreetname`, `addresshousenumber`, `addresshousenumbersuffix`, " . 
                          "`postcode`, `city`, `country_id`, `region_id`, `subregion_id`, `phone`, `fax`, `email`, `status`, `discount` " . 
                          ") SELECT " . 
                          "`id`, `referrertype_id`, `naam`, `adresstraatnaam`, `adreshuisnummer`, `adreshuisnummertoevoeging`, " . 
                          "`postcode`, `plaats`, `land_id`, `region_id`, `subregion_id`, `telefoon`, `fax`, `email`, `status`, `korting` " . 
                          "FROM `referrerorganisation`");
                        
            
            /*
            DROP TABLE IF EXISTS `referrerorganisation` ;
            
            
            
            DROP VIEW IF EXISTS `referrerorganisation` ;
            
            
            
            CREATE VIEW `referrerorganisation` AS
            
            SELECT 
            
                `id`,
            
              `referrerorganizationtype_id` AS `referrertype_id`,
            
              `name` AS `naam`,
            
              `addressstreetname` AS `adresstraatnaam`,
            
              `addresshousenumber` AS `adreshuisnummer`,
            
              `addresshousenumbersuffix` AS `adreshuisnummertoevoeging`,
            
              `postcode`,
            
              `city` AS `plaats`,
            
              `country_id` AS `land_id`,
            
              `region_id`,
            
              `subregion_id`,
            
              `phone` AS `telefoon`,
            
              `fax` AS `fax`,
            
              `email`,
            
              `status`,
            
              `discount` AS `korting`
            
            FROM `referrerorganization`;
            
            
            
            
            
            
            DROP TABLE IF EXISTS `referrerorganizationtype`;
            
            
            
            CREATE TABLE IF NOT EXISTS `referrerorganizationtype` (
            
              `id` int(11) unsigned NOT NULL auto_increment,
            
              `name` varchar(255) NOT NULL,
            
              `active` tinyint(1) unsigned NOT NULL default '1',
            
              `debtor` tinyint(1) unsigned NOT NULL default '1',
            
              PRIMARY KEY  (`id`)
            
            );
            
            
            */
            $this->query("REPLACE INTO `referrerorganizationtype` (   `id`,   `name`,     `active`,   `debtor`) " . 
                        "SELECT    `id`,   `name`,     `actief`,   `debtor` FROM `referrertype`");
            
            /*
            
            DROP TABLE IF EXISTS `referrertype` ;
            
            
            
            DROP VIEW IF EXISTS `referrertype` ;
            
            
            
            CREATE VIEW `referrertype` AS
            
            SELECT 
            
                `id`,   
            
                `name` AS `name`,   
            
                `active` AS `actief`,   
            
                `debtor`
            
            FROM `referrerorganizationtype`;
            
            
            
            
            
            
            
            DROP TABLE IF EXISTS `referrerselfinitiative`;
            
            
            
            CREATE TABLE IF NOT EXISTS `referrerselfinitiative` (
            
              `id` int(11) unsigned NOT NULL auto_increment,
            
              `name` varchar(255) NOT NULL,
            
              `active` tinyint(1) unsigned NOT NULL default '1',
            
              PRIMARY KEY  (`id`)
            
            ) ;
            
            */
            
            $this->query("REPLACE INTO `referrerselfinitiative` ( `id`,  `name`,  `active` ) " . 
                        "SELECT  `id`, `name`, `actief` FROM `referrerowninitiative`");
            
            
            /*
            
            DROP TABLE IF EXISTS `referrerowninitiative` ;
            
            
            
            DROP VIEW IF EXISTS `referrerowninitiative` ;
            
            
            
            CREATE VIEW `referrerowninitiative` AS
            
            SELECT 
            
                `id`, 
            
                `name` AS `name`, 
            
                `active` AS `actief`
            
            FROM `referrerselfinitiative`;

         
         */



   
    
    
        /*
        
        -- not possible and/or needed to create views in old format
        DROP TABLE IF EXISTS beschikbaarheidblok;
        DROP TABLE IF EXISTS beschikbaarheidcache;
        DROP TABLE IF EXISTS beschikbaarheidkliniekvakantiedag;
        DROP TABLE IF EXISTS liniekvakantiedag;
        DROP TABLE IF EXISTS beschikbaarheidregel;
        DROP TABLE IF EXISTS beschikbaarheidregelonderbreking;
        DROP TABLE IF EXISTS beschikbaarheidregeluitzondering;
        DROP TABLE IF EXISTS combinedappointment;
        DROP TABLE IF EXISTS combinedappointmentitem;
        
        
        
        
        
        -- missing indices on old tables
        
        */

        $this->query("ALTER TABLE `kliniek` ADD INDEX ( `naam` );");
        
        
        /*
        
        -- create Dutch views for appointment tables filled in php script
        
        DROP TABLE IF EXISTS afspraak;
        DROP VIEW IF EXISTS afspraak;
        CREATE VIEW afspraak AS
        
        SELECT 
        appointment.id AS id,
        IF (ISNULL(mcp_participant.employee_id), resource_participant.resource_id, mcp_participant.employee_id) AS medewerker_id,
        planner_employee.id AS planner_id,
        zorgtraject1.id AS zorgtraject_id,
        appointment.clinic_id AS kliniek_id,
        appointment.appointmenttype_id AS bloktype_id,
        appointment.kind AS soort,
        IF (appointment.haste = 1, 'ja', 'nee') AS spoed,
        CASE appointment.systemappointmentstatus_id
                 WHEN '1' THEN 'aangemeld'
                 WHEN '2' THEN 'niet aangemeld'
                 WHEN '3' THEN 'afgezegd <24u'
        END AS status,
        IF (appointment.financiallyprocessed = 1, 'verwerkt', 'niet verwerkt')  AS financielestatus,
        appointment.intervalstart AS datumtijd_van,
        appointment.intervalend AS datumtijd_tot,
        appointment.notes AS opmerking,
        appointment.cancelreason AS redenafzeggen,
        appointment.created AS invoerdatum,
        CASE appointment.break
                 WHEN '0' THEN 'nee'
                 WHEN '1' THEN 'ja'
        END AS pauze,
        appointment.checkindate AS aanmeldingstijd,
        IF (appointment.inroster = 1, 'ja', 'nee') AS binnenrooster,
        IF (appointment.seen = 1, 'ja', 'nee') AS gezien,
        behandeling.id AS behandeling_id,
        appointment.referrertype_id AS referrertype_id,
        appointment.referrerfixedtype AS referrerfixedtype,
        appointment.referrerorganization_id AS referrerorganisation_id,
        appointment.referrerperson_id AS referrerperson_id,
        appointment.referrerowninitiative_id AS referrerowninitiative_id,
        appointment.patientgroup_id AS patientgroup_id,
        appointment.contactmanner_id AS contactwijze_id
        FROM appointment
        LEFT JOIN appointmentparticipation AS mcp_participation ON mcp_participation.systemparticipationrole_id = 3 AND appointment.id = mcp_participation.appointment_id
        LEFT JOIN participant AS mcp_participant ON mcp_participation.participant_id = mcp_participant.id
        LEFT JOIN appointmentparticipation AS resource_participation ON resource_participation.systemparticipationrole_id = 4 AND appointment.id = resource_participation.appointment_id
        LEFT JOIN participant AS resource_participant ON resource_participation.participant_id = resource_participant.id
        LEFT JOIN appointmentparticipation AS patient_participation ON patient_participation.systemparticipationrole_id = 2 AND appointment.id = patient_participation.appointment_id
        LEFT JOIN participant AS patient_participant ON patient_participation.participant_id = patient_participant.id
        LEFT JOIN zorgtraject as zorgtraject1 ON patient_participant.patient_id = zorgtraject1.patient_id 
        LEFT JOIN zorgtraject as zorgtraject2 ON patient_participant.patient_id = zorgtraject2.patient_id AND zorgtraject1.id > ifnull(zorgtraject2.id, 0)
        LEFT JOIN behandeling ON zorgtraject1.id = behandeling.id
        LEFT JOIN appointmentparticipation AS planner_participation ON planner_participation.systemparticipationrole_id = 5 AND appointment.id = planner_participation.appointment_id
        LEFT JOIN participant AS planner_participant ON planner_participation.participant_id = planner_participant.id
        LEFT JOIN employee AS planner_employee ON planner_participant.user_id = planner_employee.user_id
        WHERE zorgtraject2.id is NULL;
        
        
        
        DROP TABLE IF EXISTS afspraak_patient;
        CREATE VIEW afspraak_patient AS
        SELECT appointmentparticipation.appointment_id AS afspraak_id, participant.patient_id AS patient_id
        FROM appointmentparticipation 
        INNER JOIN participant ON appointmentparticipation.systemparticipationrole_id = 2 AND appointmentparticipation.participant_id = participant.id;
        
        
        DROP TABLE IF EXISTS afspraak_extrastatus;
        CREATE VIEW afspraak_extrastatus AS
        SELECT id AS id, appointment_id AS afspraak_id, appointmentextrastatus_id  AS extrastatus_id
        FROM appointment_extrastatus;
        
        
        -- new features
        
        
       
        
        $this->query("INSERT INTO `systeemfeature` (`naam` ,`beschrijving` ,`type` ,`soort` ,`wijzigbaar`) VALUES " . 
                     "( 'keep patient selected', 'Wanneer er een afspraak wordt gemaakt, blijft de patient geselecteerd.', 'beide', 'medicore', '1'), " .
                     "( 'show participant selection', 'Wanneer er een afpraak wordt gemaakt, wordt het ''selecteer deelnemers'' scherm automatisch getoont', 'beide', 'medicore', '1'), " .
                     "('keep appointment details', 'wanneer een nieuwe afspraak wordt gemaakt, wordt de specialist, het specialisme en afspraaktype van de laatst gemaakte afspraak automatisch geselecteerd', 'beide', 'medicore', '1'), " .
                     "('keep specialist', 'wanneer een nieuwe afspraak wordt gemaakt, wordt de specialist en het specialisme van de laatst gemaakte afspraak automatisch geselecteerd', 'beide', 'medicore', '1')");
        
        
        
        
        
        // logs
        
       
        INSERT INTO `systeemlogtype` (`id` ,`naam` ,`sjabloon` ,`soort` ,`logfilter_id` ,`object_tabel` ,`object_veld`) VALUES 
        
        ('282', 'afspraak toegevoegd', 'Toegevoegd: datum: [date], starttijd: [starttime], eindtijd: [endtime], patient: [patient], specialisme : [specialism], kliniek: [clinic], hoofdbehandelaar: [mainCareProvider], medewerker:[employee], resource:[resource], soort afspraak: [kind_of_appointment], benodigde tijd: [duration], contactwijze: [contactmanner], doorverwijzer: [referrer], status: [status], extrastatus: [extra_status]', 'systeem', '2', 'appointment', 'id'),
        
        ('283', 'afspraak aangemeld', 'op [dateandtime], soort afspraak: [appointmenttype]', 'systeem', '2', 'appointment', 'id'),
        
        ('284', 'afspraak afgemeld', 'op [dateandtime], soort afspraak: [appointmenttype]', 'systeem', '2', 'appointment', 'id'),
        
        ('285', 'Afspraak gewijzigd', 'Oud: datum: [old_date], starttijd: [old_starttime], eindtijd: [old_endtime], patient: [old_patient], specialisme : [old_specialism], kliniek: [old_clinic], hoofdbehandelaar: [old_mainCareProvider], medewerker:[old_employee], resource:[old_resource], soort afspraak: [old_kind_of_appointment], benodigde tijd: [old_duration], contactwijze: [old_contactmanner], doorverwijzer: [old_referrer], status: [old_status], extrastatus: [old_extra_status] Nieuw: datum: [new_date], starttijd: [new_starttime], eindtijd: [new_endtime], patient: [new_patient], specialisme : [new_specialism], kliniek: [new_clinic], hoofdbehandelaar: [new_mainCareProvider], medewerker:[new_employee], resource:[new_resource], soort afspraak: [new_kind_of_appointment], benodigde tijd: [new_duration], contactwijze: [new_contactmanner], doorverwijzer: [new_referrer], status: [new_status], extrastatus: [new_extra_status]', 'systeem', 2,'appointment', 'id'),
        
        ('286', 'afspraak geannuleerd binnen 24 uur', 'op [dateandtime], soort afspraak: [appointmenttype]', 'systeem', '2', 'appointment', 'id'),
        
        ('287', 'afspraak verwijderd', 'Verwijderd: datum: [date], starttijd: [starttime], eindtijd: [endtime], patient: [patient], specialisme : [specialism], kliniek: [clinic], hoofdbehandelaar: [mainCareProvider], medewerker:[employee], resource:[resource], soort afspraak: [kind_of_appointment], benodigde tijd: [duration], contactwijze: [contactmanner], doorverwijzer: [referrer], status: [status], extrastatus: [extra_status]', 'systeem', '2', 'appointment', 'id'),
        
        ('288', 'roosterregel toegevoegd', 'Toegevoegd: naam [name], employees/resource: [owner], startdatum: [startdate], einddatum: [enddate], terugkeerpatroon: [recurrency], profiel: [rosterprofile], opmerking: [note], afspraakperioden: [appointment periods]', 'systeem', '8', 'rosterrulegroup', 'id'),
        
        ('289', 'roosterregel gewijzigd', 'Oud: naam [old_name], employees/resource: [old_owner], startdatum: [old_startdate], einddatum: [old_enddate], terugkeerpatroon: [old_recurrency], profiel: [old_rosterprofile], opmerking: [old_note], afspraakperioden: [old_appointment_periods] Nieuw: naam [new_name], employees/resource: [new_owner], startdatum: [new_startdate], einddatum: [new_enddate], terugkeerpatroon: [new_recurrency], profiel: [new_rosterprofile], opmerking: [new_note], afspraakperioden: [new_appointment periods]', 'systeem', '8', 'rosterrulegroup', 'id'),
        
        ('290', 'roosterregel verwijderd','Verwijderd: naam [name], employees/resource: [owner], startdatum: [startdate], einddatum: [enddate], terugkeerpatroon: [recurrency], profiel: [rosterprofile], opmerking: [note], afspraakperioden: [appointment periods]', 'systeem', '8', 'rosterrulegroup', 'id'),
        
        ('291', 'roosterregeluitzondering toegevoegd','Toegevoegd: roosteregel: [id], startdatum: [datefrom], einddatum: [datetill], starttijd: [timefrom], eindtijd: [timetill], reden: [reason]', 'systeem', '8', 'rosterruleexception', 'id'),
        
        ('292', 'roosterregeluitzondering gewijzigd','Oud: roosteregel: [old_id], startdatum: [old_datefrom], einddatum: [old_datetill], starttijd: [old_timefrom], eindtijd: [old_timetill], reden: [old_reason] Nieuw: roosteregel: [new_id], startdatum: [new_datefrom], einddatum: [new_datetill], starttijd: [new_timefrom], eindtijd: [new_timetill], reden: [new_reason]', 'systeem', '8', 'rosterruleexception', 'id'),
        
        ('293', 'roosterregeluitzondering verwijderd','Verwijderd: roosteregel: [id], startdatum: [datefrom], einddatum: [datetill], starttijd: [timefrom], eindtijd: [timetill], reden: [reason]', 'systeem', '8', 'rosterruleexception', 'id'),
        
        ('294', 'afwezigheid toegevoegd', 'Toegevoegd: naam: [name], opmerking: [note], terugkeerpatroon: [recurrency], startdatum: [startdate], einddatum: [enddate], starttijd: [starttime], eindtijd: [endtime], kliniek: [clinic], medewerker: [employee], resource: [resource]', 'systeem', '8', 'rosterrulegroup', 'id'),
        
        ('295', 'afwezigheid gewijzigd','Gewijzigd: Oud: naam: [old_name], opmerking: [old_note], terugkeerpatroon: [old_recurrency], startdatum: [old_startdate], einddatum: [old_enddate], starttijd: [old_starttime], eindtijd: [old_endtime], kliniek: [old_clinic], medewerker: [old_employee], resource: [old_resource] Nieuw: Oud: naam: [new_name], opmerking: [new_note], terugkeerpatroon: [new_recurrency], startdatum: [new_startdate], einddatum: [new_enddate], starttijd: [new_starttime], eindtijd: [new_endtime], kliniek: [new_clinic], medewerker: [new_employee], resource: [new_resource]', 'systeem', '8', 'rosterrulegroup', 'id'),
        
        ('296', 'afwezigheid verwijderd', 'Verwijderd: naam: [name], opmerking: [note], terugkeerpatroon: [recurrency], startdatum: [startdate], einddatum: [enddate], starttijd: [starttime], eindtijd: [endtime], kliniek: [clinic], medewerker: [employee], resource: [resource]', 'systeem', '8', 'rosterrulegroup', 'id'),
        
        ('297', 'roosterprofiel toegevoegd','Toegevoegd: naam [name], afspraakperioden: [appointment periods]', 'systeem', '8', 'rosterruleprofile', 'id'),
        
        ('298', 'roosterprofiel gewijzigd','Gewijzigd: Oud: naam [old_name], afspraakperioden: [old_appointment periods] Nieuw: naam [new_name], afspraakperioden: [new_appointment periods]', 'systeem', '8', 'rosterruleprofile', 'id'),
        
        ('299', 'roosterprofiel verwijderd','Verwijderd: naam [name], afspraakperioden: [appointment periods]', 'systeem', '8', 'rosterruleprofile', 'id'),
        
        ('300', 'afspraaksoort toegevoegd','Toegevoegd: naam: [name], doorverwijzer verplicht: [referrer_mandatory], maximum dagen vooruit: [days_ahead], frequentie: [frequency], default duration: [duration]', 'systeem', '8', 'appointmenttype', 'id'),
        
        ('301', 'afspraaksoort gewijzigd','Gewijzigd: Oud: naam: [old_name], doorverwijzer verplicht: [old_referrer_mandatory], maximum dagen vooruit: [old_days_ahead], frequentie: [old_frequency], default duration: [old_duration] Nieuw: naam: [new_name], doorverwijzer verplicht: [new_referrer_mandatory], maximum dagen vooruit: [new_days_ahead], frequentie: [new_frequency], default duration: [new_duration]', 'systeem', '8', 'appointmenttype', 'id'),
        
        ('302', 'afspraaksoort verwijderd','Verwijderd: naam: [name], doorverwijzer verplicht: [referrer_mandatory], maximum dagen vooruit: [days_ahead], frequentie: [frequency], default duration: [duration]', 'systeem', '8', 'appointmenttype', 'id'),
        
        ('303', 'afspraaksoort gekoppeld', 'Toegevoegd: medewerker: [employee], afspraaktype: [appointmenttype], duur: [duration]', 'systeem', '8', 'employee_appointmenttype', 'id'),
        
        ('304', 'afspraaksoort koppeling gewijzigd','Gewijzigd: Oud: medewerker: [old_employee], afspraaktype: [old_appointmenttype], duur: [old_duration] Nieuw: medewerker: [new_employee], afspraaktype: [new_appointmenttype], duur: [new_duration]', 'systeem', '8', 'employee_appointmenttype', 'id'),
        
        ('305', 'afspraaksoort ontkoppeld', 'Verwijderd: medewerker: [employee], afspraaktype: [appointmenttype], duur: [duration]', 'systeem', '8', 'employee_appointmenttype', 'id'),
        
        ('306', 'afspraaksoort gekoppeld', 'Toegevoegd: resource: [resource], afspraaktype: [appointmenttype], duur: [duration]', 'systeem', '8', 'employee_appointmenttype', 'id'),
        
        ('307', 'afspraaksoort koppeling gewijzigd', 'Gewijzigd: Oud: resource: [old_resource], afspraaktype: [old_appointmenttype], duur: [old_duration] Nieuw: resource: [new_resource], afspraaktype: [new_appointmenttype], duur: [new_duration]', 'systeem', '8', 'employee_appointmenttype', 'id'),
        
        ('308', 'afspraaksoort ontkoppeld','Verwijderd: resource: [resource], afspraaktype: [appointmenttype], duur: [duration]', 'systeem', '8', 'employee_appointmenttype', 'id'),
        
        ('309', 'resource toegevoegd', 'Toegevoegd: naam: [name], type: [type], specialisme: [specialism]', 'systeem', '8', 'resource', 'id'),
        
        ('310', 'resource gewijzigd', 'Gewijzigd: Oud: naam: [old_name], type: [old_type], specialisme: [old_specialism] Nieuw: naam: [new_name], type: [new_type], specialisme: [new_specialism]', 'systeem', '8', 'resource', 'id'),
        
        ('311', 'resource verwijderd','Verwijderd: naam: [name], type: [type], specialisme: [specialism]', 'systeem', '8', 'resource', 'id'),
        
        ('312', 'extra status toegevoegd', 'Toegevoegd: Toegevoegd: naam: [name], status: [status], kleur: [color], kliniek: [clinic]', 'systeem', '8', 'resource', 'id'),
        
        ('313', 'extra status gewijzigd','Gewijzigd: Oud: Toegevoegd: naam: [old_name], status: [old_status], kleur: [old_color], kliniek: [old_clinic] Nieuw: naam: Toegevoegd: naam: [new_name], status: [new_status], kleur: [new_color], kliniek: [new_clinic]', 'systeem', '8', 'resource', 'id'),
        
        ('314', 'extra status verwijderd', 'Verwijderd: Toegevoegd: naam: [name], status: [status], kleur: [color], kliniek: [clinic]', 'systeem', '8', 'resource', 'id')");
        

        -- menu items
        
        UPDATE `systeemmenuitem` SET actief = 'nee' WHERE id in (44, 52, 53, 81, 125, 256, 258, 259, 260, 284, 63, 38, 162, 264, 266);
         
        INSERT INTO `systeemmenuitem` ( `id` , `parent_id` , `actief` , `volgorde` , `naam` , `url` , `module` ) VALUES 
        ('279', '51', 'ja', '7', 'agenda', '/modules/calendar/day', ''),
        ('280', '51', 'ja', '6', 'nieuwe afspraak', '/modules/calendar/appointment', ''),
        ('281', '233', 'ja', '6', 'resources', '', ''),
        ('282', '281', 'ja', '1', 'resources', '/modules/resource/resourcemanagement', ''),
        ('285', '257', 'ja', '4', 'rooster', '/modules/calendar/rosterrulemanagement', ''),
        ('286', '257', 'ja', '5', 'roosterprofiel', '/modules/calendar/rosterruleprofilemanagement', ''),
        ('287', '257', 'ja', '6', 'afspraaktype', '/modules/calendar/appointmenttypemanagement', ''),
        ('288', '257', 'ja', '7', 'afspraakprofiel', '/modules/calendar/appointmentprofilemanagement', ''),
        ('289', '62', 'ja', '1', 'medewerker', '/modules/employee/employeemanagement', ''),
        ('291', '62', 'ja', '3', 'rollen', '/modules/rol/rolemanagement', ''),
        ('292', '46', 'ja', '0', 'patientafspraken', '/modules/calendar/searchappointments', ''),
        ('293', '257', 'ja', '8', 'extra status', '/modules/calendar/statusmanagement', '');
         
         
        INSERT INTO `systeemvertalingsysteemtabellen` ( `tabel` , `kolom` , `tabel_id` , `taal` , `waarde` ) VALUES 
        ('systeemmenuitem', 'naam', '279', 'nl', 'agenda'),
        ('systeemmenuitem', 'naam', '280', 'nl', 'nieuwe afspraak'),
        ('systeemmenuitem', 'naam', '281', 'nl', 'resources'),
        ('systeemmenuitem', 'naam', '282', 'nl', 'resources'),
        ('systeemmenuitem', 'naam', '285', 'nl', 'rooster'),
        ('systeemmenuitem', 'naam', '286', 'nl', 'roosterprofiel'),
        ('systeemmenuitem', 'naam', '287', 'nl', 'afspraaktype'),
        ('systeemmenuitem', 'naam', '288', 'nl', 'afspraakprofiel'),
        ('systeemmenuitem', 'naam', '289', 'nl', 'medewerker'),
        ('systeemmenuitem', 'naam', '291', 'nl', 'rollen'),
        ('systeemmenuitem', 'naam', '292', 'nl', 'patientafspraken'),
        ('systeemmenuitem', 'naam', '293', 'nl', 'extra status');
                 
                 
     
     */

        
    }
    
    
}