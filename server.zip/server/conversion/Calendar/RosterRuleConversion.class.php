<?php
 
class RosterRuleConversion extends AutoConversion_DatabaseChange {
 
       final public function getTitle() {
        return "Employee Management conversion, roster rules";
    }
 
   final public function run() {

        // init
        $userlogaantallen = array();
        $userlog = array();
        $log = array();
        $errors = array();
        
        
        $this->query("TRUNCATE TABLE rosterrulegroup");
        $this->query("TRUNCATE TABLE rosterrulegroupparticipation");
        $this->query("TRUNCATE TABLE rosterrgrpparticipation_clinic");
        $this->query("TRUNCATE TABLE rosterrulegroup_clinic");
        $this->query("TRUNCATE TABLE rosterrule");
        $this->query("TRUNCATE TABLE rosterruleexception");
        $this->query("TRUNCATE TABLE rosterrule_appointmenttype");
        
        $roster_rule_colors = array("#D5D9B4", "#DEB4B2", "#B4D9BB", "#B4CCD9", "#C8B4D9");
        $dag_to_day = array('ZO'=>'SU', 'MA'=>'MO', 'DI'=>'TU', 
                            'WO'=>'WE', 'DO'=>'TH', 'VR'=>'FR', 'ZA'=>'SA');
        
        // remember names of all appointment types
        $appointment_type_names = array();
        
        $res = $this->query("SELECT id, name FROM appointmenttype");
        
        if ($res->getSuccess()) {
            $types = $res->getData();
            
            for ($a = 0 ; $a < count($types) ; $a++) {
                $appointment_type_names[$types[$a]['id']] = $types[$a]['name'];  
            }    
        }
        
        
        // remember all active employees
        
        $res = $this->query("SELECT id FROM employee");
        $activeemployees = array();
        
        if ($res->getSuccess()) {
            $employeedata = $res->getData();
            
            for ($a = 0 ; $a < count($employeedata) ; $a++) {
                $activeemployees[] = $employeedata[$a]['id'];  
            }    
        }
        
        $res = $this->query("SELECT employee_id FROM resource");
        
        if ($res->getSuccess()) {
            $employeedata = $res->getData();
            
            for ($a = 0 ; $a < count($employeedata) ; $a++) {
                $activeemployees[] = $employeedata[$a]['employee_id'];  
            }    
        }
        
        // remember names of all clinics
        $clinic_names = array();
        
        $res = $this->query("SELECT id, naam FROM kliniek");
        
        if ($res->getSuccess()) {
            $clinics = $res->getData();
            
            for ($a = 0 ; $a < count($clinics) ; $a++) {
                $clinic_names[$clinics[$a]['id']] = $clinics[$a]['naam'];  
            }    
        }
        
        
        
        // log
        
        $res = $this->query("SELECT count(id) AS amount FROM beschikbaarheidregel WHERE soort = 'aanwezigheid'")->getData();
        $userlogaantallen[] = 'Aantal aanwezigheidregels voor conversie: ' . $res[0]['amount'];
        
        $res = $this->query("SELECT count(id) AS amount FROM beschikbaarheidregelonderbreking")->getData();
        $userlogaantallen[] = 'Aantal onderbrekingregels voor conversie: ' . $res[0]['amount'];
        
        $res = $this->query("SELECT count(id) AS amount FROM beschikbaarheidregeluitzondering")->getData();
        $userlogaantallen[] = 'Aantal uitzonderingregels voor conversie: ' . $res[0]['amount'];
        
        $res = $this->query("SELECT count(id) AS amount FROM beschikbaarheidregel WHERE soort = 'afwezigheid'")->getData();
        $userlogaantallen[] = 'Aantal afwezigheidregels voor conversie: ' . $res[0]['amount'];
        
        $res = $this->query("SELECT count(id) AS amount FROM kliniekvakantiedag")->getData();
        $userlogaantallen[] = 'Aantal kliniek gesloten regels voor conversie: ' . $res[0]['amount'];
            
            
                
        // beschikbaarheidsregels
        $res = $this->query("SELECT count(id) AS amount FROM beschikbaarheidregel")->getData();
        $count_beschikbaarheidregel = $res[0]['amount'];
        
        
            
        $start = 0;
        
        for ($start = 0 ; $start < $count_beschikbaarheidregel ; $start += 1000) {
        
            $res = $this->query("SELECT * FROM beschikbaarheidregel ORDER BY id LIMIT " . $start . ", 1000");     
            
            if ($res->getSuccess()) {
        
                foreach ($res->getData() as $regel) { 
                    $group_names = array();
                        
                    $beschikbaarheidregel_id = $regel['id'];
        
                    // fix discussed with Wouter and Bianca            
                    if ($regel['datumvan'] == $regel['datumtot'] && $regel['tijdtot'] == '00:00:00') {
                        $regel['tijdtot'] = '23:59:59';   
                    }
                               
                    $startstamp = strtotime($regel['datumvan'] . ' ' . $regel['tijdvan']);
                    $endstamp = strtotime($regel['datumtot'] . ' ' . $regel['tijdtot']);
                    
                    if ($startstamp >= $endstamp) {
        
                        $userlog[] = "niet geconverteerde " . ($regel['soort'] == 'afwezigheid' ? 'afwezigheidregel' : 'aanwezigheidregel') . ":\n" . 
                                     "id: " . $regel['id'] . "\n" .
                                     "specialist: " . $this->getSpecialistName($regel['medewerker_id']) . ", " .   
                                     "kliniek: " . ($regel['kliniek_id'] > 0 ? $clinic_names[$regel['kliniek_id']] : '(geen)') . "\n" .  
                                     "datum van: " . $regel['datumvan'] . "\n" .  
                                     "datum tot: " . $regel['datumtot'] . "\n" .  
                                     "tijd van: " . $regel['tijdvan'] . "\n" .  
                                     "tijd tot: " . $regel['tijdtot'] . "\n" .   
                                     ($regel['soort'] == 'afwezigheid'  ? "reden: " . $regel['opmerking'] . "\n" : "") .                         
                                     "oorzaak: startdatum/tijd gelijk aan of groter dan einddatum/tijd\n"; 
        
                        continue;  
                    }
        
                    if (intval($regel['kliniek_id']) == 0) {
        
                        $userlog[] = "niet geconverteerde " . ($regel['soort'] == 'afwezigheid' ? 'afwezigheidregel' : 'aanwezigheidregel') . ":\n" . 
                                     "id: " . $regel['id'] . "\n" .
                                     "specialist: " . $this->getSpecialistName($regel['medewerker_id']) . "\n" .   
                                     "kliniek: " . ($regel['kliniek_id'] > 0 ? $clinic_names[$regel['kliniek_id']] : '(geen)') . "\n" .  
                                     "datum van: " . $regel['datumvan'] . "\n" .  
                                     "datum tot: " . $regel['datumtot'] . "\n" .  
                                     "tijd van: " . $regel['tijdvan'] . "\n" .  
                                     "tijd tot: " . $regel['tijdtot'] . "\n" .  
                                     ($regel['soort'] == 'afwezigheid'  ? "reden: " . $regel['opmerking'] . "\n" : "") .                             
                                     "oorzaak: geen kliniek gekoppeld\n"; 
        
                        continue;  
                    }
                    
                    if (!isset($clinic_names[$regel['kliniek_id']])) {
                        $userlog[] = "niet geconverteerde " . ($regel['soort'] == 'afwezigheid' ? 'afwezigheidregel' : 'aanwezigheidregel') . "\n" . 
                                     "id: " . $regel['id'] . "\n" .
                                     "specialist: " . $this->getSpecialistName($regel['medewerker_id']) . "\n" .   
                                     "kliniek: (onbekend)\n" .  
                                     "datum van: " . $regel['datumvan'] . "\n" .  
                                     "datum tot: " . $regel['datumtot'] . "\n" .  
                                     "tijd van: " . $regel['tijdvan'] . "\n" .  
                                     "tijd tot: " . $regel['tijdtot'] . "\n" .  
                                     ($regel['soort'] == 'afwezigheid'  ? "reden: " . $regel['opmerking'] . "\n" : "") .                             
                                     "oorzaak: niet bestaande kliniek gekoppeld (kliniek_id " . $regel['kliniek_id'] . ")"; 
        
                        continue;  
                    }
                    
        
                    if (intval($regel['medewerker_id']) == 0) {
        
                        $userlog[] = "niet geconverteerde " . ($regel['soort'] == 'afwezigheid' ? 'afwezigheidregel' : 'aanwezigheidregel') . ":\n" . 
                                     "id: " . $regel['id'] . "\n" .
                                     "specialist: " . $this->getSpecialistName($regel['medewerker_id']) . "\n" .   
                                     "kliniek: " . ($regel['kliniek_id'] > 0 ? $clinic_names[$regel['kliniek_id']] : '(geen)') . "\n" .  
                                     "datum van: " . $regel['datumvan'] . "\n" .  
                                     "datum tot: " . $regel['datumtot'] . "\n" .  
                                     "tijd van: " . $regel['tijdvan'] . "\n" .  
                                     "tijd tot: " . $regel['tijdtot'] . "\n" .
                                     ($regel['soort'] == 'afwezigheid'  ? "reden: " . $regel['opmerking'] . "\n" : "") .                               
                                     "oorzaak: geen medewerker gekoppeld\n"; 
        
                        continue;  
                    }
                    
                    if (!in_array(intval($regel['medewerker_id']), $activeemployees)) {
                        $userlog[] = "niet geconverteerde " . ($regel['soort'] == 'afwezigheid' ? 'afwezigheidregel' : 'aanwezigheidregel') . ": \n" . 
                                     "id: " . $regel['id'] . "\n" .
                                     "specialist: " . $this->getSpecialistName($regel['medewerker_id']) . "\n" .   
                                     "kliniek: " . ($regel['kliniek_id'] > 0 ? $clinic_names[$regel['kliniek_id']] : '(geen)') . "\n" .  
                                     "datum van: " . $regel['datumvan'] . "\n" .  
                                     "datum tot: " . $regel['datumtot'] . "\n" .  
                                     "tijd van: " . $regel['tijdvan'] . "\n" .  
                                     "tijd tot: " . $regel['tijdtot'] . "\n" .
                                     ($regel['soort'] == 'afwezigheid'  ? "reden: " . $regel['opmerking'] . "\n" : "") .                               
                                     "oorzaak: niet bestaande medewerker gekoppeld (medewerker_id " . $regel['medewerker_id'] . ")\n"; 
        
                        continue;                 
                    }
                    
                    
                    if ($regel['soort'] == 'aanwezigheid' && trim($regel['bloktype']) == '') {
        
                        $userlog[] = "niet geconverteerde " . ($regel['soort'] == 'afwezigheid' ? 'afwezigheidregel' : 'aanwezigheidregel') . ":\n" . 
                                     "id: " . $regel['id'] . "\n" .
                                     "specialist: " . $this->getSpecialistName($regel['medewerker_id']) . "\n" .   
                                     "kliniek: " . ($regel['kliniek_id'] > 0 ? $clinic_names[$regel['kliniek_id']] : '(geen)') . "\n" .  
                                     "datum van: " . $regel['datumvan'] . "\n" .  
                                     "datum tot: " . $regel['datumtot'] . "\n" .  
                                     "tijd van: " . $regel['tijdvan'] . "\n" .  
                                     "tijd tot: " . $regel['tijdtot'] . "\n" .   
                                     ($regel['soort'] == 'afwezigheid'  ? "reden: " . $regel['opmerking'] . "\n" : "") .                          
                                     "oorzaak: aanwezigheidregel zonder gekoppelde bloktypes\n"; 
        
                        continue;  
                    }
                                                
                    // randomly choose on of our colors                      
                    $color = $roster_rule_colors[rand(0, count($roster_rule_colors)-1)];
                    
                    // convert $regel['terugkeerpatroon']/$regel['data1']/$regel['data2'] to rrule fields                                                
                    $byday = "";                       
                    $interval = "";
                    $until = strtotime($regel['datumtot'] . ' ' . $regel['tijdtot']); // end of last occurence
                    $count = "";
                    $bymonth = "";
                    $byweekno = "";
                    $bymonthday = "";
                    $byhour =  "";
                    $byminute = "";
                    
                    switch ($regel['terugkeerpatroon']) {
        
                        case 'wekelijks':
                            $freq = "weekly";   
                            
                            // every x weeks, on days $regel['data2'] (contains ma,wo,za)
                            $parts = explode(",", $regel['data2']);
                            
                            $days = array();
                            for ($p = 0 ; $p < count($parts) ; $p++) {
                                $days[] = $dag_to_day[strtoupper(trim($parts[$p]))];     
                            }
                            
                            $byday = implode(",", $days);                                         
                            
                            if (intval($regel['data1']) == -2) {
                                // even weeks                                    
                                $interval = 2; 
                                $byweekno = 2;
                                
                            } elseif (intval($regel['data1']) == -1) {
                                // odd weeks                                         
                                $interval = 2; 
                                $byweekno = 1;
        
                            } else {  
                                $interval = intval($regel['data1']);                                 
                            }
                                                       
                            break;
                        case 'maandelijks':
                            $freq = "monthly";
                        
                            if ($regel['data1'] == 'dag') {
                                // every Xth of the month
                                $bymonthday = intval($regel['data2']);
                            } else {                                        
                                // converts "2,maandag" to "2MO" ... second monday of the month
                                $parts = explode(",", $regel['data2']);
                                $dag_short = substr(strtoupper(trim($parts[1])), 0, 2);                                        
                                $day = $dag_to_day[$dag_short];                                        
                                $byday = intval($parts[0]) . $day; 
                            }
                            
                            break;
                        case 'aaneengesloten':
                        case 'dagelijks':
                        case 'eenmalig':
                        default:
                            $freq = "daily";
                            break;
                    }
                    
        
        
                    // create rosterrulegroup, we will update the name later
                    $sql = "INSERT INTO rosterrulegroup " . 
                            "(name, intervalstart, intervalend, color, systemavailabilitytype_id, " . 
                            "note, frequency, period, until, byweekno, bymonthday, byday) " . 
                            "VALUES (" . 
                            "'', " . // name
                            "'" . date("Y-m-d H:i:s", strtotime($regel['datumvan'] . ' ' . $regel['tijdvan'])) . "', " . // intervalstart
                            "'" . date("Y-m-d H:i:s", strtotime($regel['datumvan'] . ' ' . $regel['tijdtot'])) . "', " . // intervalend (end of first occurence)                    
                            "'" . $color . "', " . // color
                            ($regel['soort'] == 'aanwezigheid' ? "1" : "2") . ", " . // systemavailabilitytype_id   
                            "'" . addslashes(strip_tags($regel['opmerking'])) . "', " .  // note
                            "'" . $freq . "', '" . $interval . "', '" . date("Y-m-d H:i:s", $until) . "', '" . $byweekno . "', '" . $bymonthday . "', '" . $byday .  "'" . // rrule fields              
                            ")";

                    $res = $this->query($sql);
                    $rosterrulegroup_id = $res->getInsertId();
                    
                    // create rosterrule
                    $sql = "INSERT INTO rosterrule (id, __active, rosterrulegroup_id, rosterruleprofile_id, " .
                           "intervalstart, intervalend, multiplicity, created, counter) VALUES (" . 
                           $regel['id'] . ", 1, " . // id, __active,
                           intval($rosterrulegroup_id) . ", 0, " .  // rosterrulegroup_id, rosterruleprofile_id
                           "'" . date("Y-m-d H:i:s", strtotime($regel['datumvan'] . ' ' . $regel['tijdvan'])) . "', " . // intervalstart
                           "'" . date("Y-m-d H:i:s", strtotime($regel['datumvan'] . ' ' . $regel['tijdtot'])) . "', " . // intervalend (end of first occurence)
                           ($regel['dubbel'] == 'ja' ? 2 : 1) . ", '" . date("Y-m-d H:i:s") . "', 0 " . // multiplicity, created, counter                                   
                           ")";
                    
                    $insertres = $this->query($sql);
        
                    if ($insertres->getSuccess()) {
                        $rosterrule_id = $regel['id'];
                        $log[] = "beschikbaarheidregel " . $beschikbaarheidregel_id . " converted to roster rule " . $rosterrule_id;     
                        
                        // participations, first retrieve participant_id
                        $participant_sql = "SELECT id FROM participant WHERE employee_id = " . $regel['medewerker_id'];                
                        $participant_res = $this->query($participant_sql);
                        $participant_data = $participant_res->getData();
                        
                        if (!$participant_data || count($participant_data) == 0) {
                            $participant_sql = "SELECT participant.id FROM resource " . 
                                                "LEFT JOIN participant ON resource.id = participant.resource_id WHERE resource.employee_id = " . $regel['medewerker_id'];                
                            $participant_res = $this->query($participant_sql);
                            $participant_data = $participant_res->getData();                    
                        }
                        
                        $participant_id = $participant_data[0]['id']; 
                        
                        // link participant to roster rule
                        $insertres = $this->query("INSERT INTO rosterrulegroupparticipation (rosterrulegroup_id, participant_id) VALUES " . 
                                        "(" . intval($rosterrulegroup_id) . ", " . intval($participant_id) . ")");
        
                        $rosterrulegroupparticipation_id = $insertres->getInsertId();
                               
                        // link participation to clinic
                        $this->query("INSERT INTO rosterrgrpparticipation_clinic (rosterrulegroupparticipation_id, clinic_id) VALUES " . 
                                        "(" . intval($rosterrulegroupparticipation_id) . ", " . intval($regel['kliniek_id']) . ")");
        
                        
                        if (trim($regel['bloktype']) != '') {
                            $appointment_types = explode(",", $regel['bloktype']);
                            
                            for ($a = 0 ; $a < count($appointment_types) ; $a++) {
        
                                if (!in_array($appointment_type_names[intval($appointment_types[$a])], $group_names)) {
                                    // add name of appointment types to group name array     
                                    $group_names[] = $appointment_type_names[intval($appointment_types[$a])];
                                }
                                         
                                                                    
                                // insert into rosterrule_appointmenttype
                                $sql = "INSERT INTO rosterrule_appointmenttype (rosterrule_id, appointmenttype_id) VALUES " . 
                                       "(" . intval($rosterrule_id) . ", " . intval($appointment_types[$a]) . ")";
                                
                                if (isset($appointment_type_names[intval($appointment_types[$a])])) {
                                    $this->query($sql);  // please check results, too    
                                    $log[] = "roster rule " . $rosterrule_id . " linked to appointment type " . intval($appointment_types[$a]);     
                                }
                                else {
                                    $log[] = "could not link roster rule " . $rosterrule_id . " linked to non-existing appointment type " . intval($appointment_types[$a]);     
                                }
                            }
                        }
                    } else {
                        $errors[] = "conversion of beschikbaarheidregel " . $beschikbaarheidregel_id . " failed: " . $sql;                                
                    }                        
                    
                    // update group name         
                    
                    if ($regel['soort'] == 'afwezigheid') {
                        $group_name = 'afwezigheid van ' . $regel['datumvan'] . ' ' . substr($regel['tijdvan'], 0, 5) . ' t/m ' . $regel['datumtot'] . ' ' . substr($regel['tijdtot'], 0, 5);
                    } else {
                        $group_name = implode(', ', $group_names);
                    }
                    if (intval($rosterrulegroup_id) > 0) {
                       $this->query("UPDATE rosterrulegroup SET name = '" . addslashes($group_name). "' WHERE id = " . intval($rosterrulegroup_id));
                    }
                }
            }                               
        }
        
        
        // beschikbaarheidsregeluitzondering
        
        $res = $this->query("SELECT count(id) AS amount FROM beschikbaarheidregeluitzondering")->getData();
        $count_beschikbaarheidregeluitzondering = $res[0]['amount'];
        
        $start = 0;
        
        for ($start = 0 ; $start < $count_beschikbaarheidregeluitzondering ; $start += 1000) {
           
            $res = $this->query("SELECT * FROM beschikbaarheidregeluitzondering ORDER BY beschikbaarheidregel_id ASC LIMIT " . $start . ", 1000");     
            
            if ($res->getSuccess()) {
        
                foreach ($res->getData() as $index => $regel) { 
        
                    if (intval($regel['beschikbaarheidregel_id']) == 0) {
        
                        $userlog[] = "niet geconverteerde uitzonderingregel:\n" . 
                                     "id: " . $regel['id'] . "\n" .
                                     "specialist: " . $this->getSpecialistName($regel['medewerker_id']) . "\n" .   
                                     "kliniek: " . ($regel['kliniek_id'] > 0 ? $clinic_names[$regel['kliniek_id']] : '(geen)') . "\n" .  
                                     "datum van: " . $regel['datumvan'] . "\n" .  
                                     "datum tot: " . $regel['datumtot'] . "\n" .  
                                     "tijd van: " . $regel['van'] . "\n" .  
                                     "tijd tot: " . $regel['tot'] . "\n" .                
                                     "reden: " . $regel['opmerking'] . "\n" .               
                                     "oorzaak: geen beschikbaarheidregel gekoppeld\n"; 
        
                        continue;  
                    }
        
                    $startstamp = strtotime($regel['datumvan'] . ' ' . $regel['van']);
                    $endstamp = strtotime($regel['datumtot'] . ' ' . $regel['tot']);
                    
                    if ($startstamp >= $endstamp) {
        
                        $userlog[] = "niet geconverteerde uitzonderingregel:\n" . 
                                     "id: " . $regel['id'] . "\n" .
                                     "specialist: " . $this->getSpecialistName($regel['medewerker_id']) . "\n" .   
                                     "kliniek: " . ($regel['kliniek_id'] > 0 ? $clinic_names[$regel['kliniek_id']] : '(geen)') . "\n" .  
                                     "datum van: " . $regel['datumvan'] . "\n" .  
                                     "datum tot: " . $regel['datumtot'] . "\n" .  
                                     "tijd van: " . $regel['van'] . "\n" .  
                                     "tijd tot: " . $regel['tot'] . "\n" .                
                                     "reden: " . $regel['opmerking'] . "\n" .               
                                     "oorzaak: startdatum/tijd gelijk aan of groter dan einddatum/tijd\n"; 
        
                        continue;  
                    }
        
                    $beschikbaarheidregel_id = $regel['id'];
        
        
                    // link to same group as $regel['beschikbaarheidregel_id']
        
                    $res = $this->query("SELECT rosterrulegroup_id FROM rosterrule WHERE id = " . intval($regel['beschikbaarheidregel_id']));
                    $data = $res->getData();
                    $rosterrulegroup_id = $data[0]['rosterrulegroup_id'];  
         
                    if (intval($rosterrulegroup_id) == 0) {
                        // was obviously not converted
                        continue;    
                    }
                    
                    $sql = "INSERT INTO rosterruleexception (rosterrulegroup_id, start, end, reason) VALUES (" . 
                           intval($rosterrulegroup_id) . ", " . 
                           "'" . date("Y-m-d H:i:s", strtotime($regel['datumvan'] . ' ' . $regel['van'])) . "', " . 
                           "'" . date("Y-m-d H:i:s", strtotime($regel['datumtot'] . ' ' . $regel['tot'])) . "', " . 
                            "'" . addslashes($regel['opmerking']) . "')"; 
                          
                    $insertres = $this->query($sql);
                    
                    if ($insertres->getSuccess()) {
                        $regel['type'] = 'beschikbaarheidregeluitzondering';
                        $rosterruleexception_id = $insertres->getInsertId();
                        
        
                        $orig_rule_res = $this->query("SELECT * FROM rosterrule WHERE id = ". $regel['beschikbaarheidregel_id']);
                        $orig_rule_data = $orig_rule_res->getData();
        
                        $orig_regel_res = $this->query("SELECT * FROM beschikbaarheidregel WHERE id = ". $regel['beschikbaarheidregel_id']);
                        $orig_regel_data = $orig_regel_res->getData();
        
                        $orig_group_res = $this->query("SELECT * FROM rosterrulegroup WHERE id = ". $orig_rule_data[0]['rosterrulegroup_id']);
                        $orig_group_data = $orig_group_res->getData();
                        
                        $original_types = explode(",", $orig_regel_data[0]['bloktype']);
                        $exception_types = explode(",", $regel['bloktype']);
        
                        $multiplicity_org = intval($orig_rule_data[0]['multiplicity']);
                        $multiplicity_exception = ($regel['dubbel'] == 'ja' ? 2 : 1);
                                
                        if (count($exception_types) < count($original_types) || $multiplicity_org != $multiplicity_exception) {
                            
                            
        /*
        SITUATIE 1:
        
        originele regel: jan-dec 2008, gekoppeld aan bloktype 1,2,3, dubbel = 'ja'
        uitzondering: aug 2008, gekoppeld aan bloktype 2, dubbel = 'ja'
        
        ==> ik ga er van uit dat de exceptie zegt "in augustus mag bloktype 2 helemaal niet
        
        
        resultaat:
        roster rule: jan-dec 2008, gelinkt aan appointmenttype 1,2,3, multiplicity 2
        exception: aug 2008
        roster rule: aug 2008, appointment type 1,3, multiplicity 2
        
        ==> hetzelfde geldt als dubbel 'nee' was in ZOWEL oud als nieuw, maar dan natuurlijk multiplicity = 1 als resultaat
        
        
        
        
        SITUATIE 2
        
        originele regel: jan-dec 2008, gekoppeld aan bloktype 1,2,3, dubbel = 'ja'
        uitzondering: aug 2008, gekoppeld aan bloktype 2, dubbel = 'nee'
        
        
        ==> ik ga er van uit dat de exceptie zegt "in augustus mag je bloktype 2 niet dubbel plannen, itt de rest van het jaar)
        
        
        resultaat:
        roster rule: jan-dec 2008, gelinkt aan appointmenttype 1,2,3, multiplicity 2
        exception: aug 2008
        roster rule: aug 2008, gelinkt aan appointmenttype 1,3, multiplicity 2
        roster rule: aug 2008, gelinkt aan appointmenttype 2, multiplicity 1
        
        **/
                            
                            if ($multiplicity_org == $multiplicity_exception) {
                                // situation 1
                                $multiplicity_new = $multiplicity_org;
                            }
                            else {
                                // situation 2
                                $multiplicity_new = ($multiplicity_org - $multiplicity_exception);
                            }
        
                            $new_types = array_diff($original_types, $exception_types);
                            sort($new_types);
                            
                            // randomly choose on of our colors                      
                            $color = $roster_rule_colors[rand(0, count($roster_rule_colors)-1)];
        
                            // update group name         
                            $group_name .= 'uitzondering van ' . 
                                            date("d-m-Y", strtotime($regel['datumvan'])) . ' t/m ' . 
                                            date("d-m-Y", strtotime($regel['datumtot']));
                                    
        
                            // fields based on info from group $orig_group_data, and dates of exception $regel
                            $new_group_sql = "INSERT INTO rosterrulegroup " . 
                                            "(name, intervalstart, intervalend, color, systemavailabilitytype_id, " . 
                                            "note, frequency, period, until, byweekno, bymonthday, byday) " . 
                                            "VALUES (" . 
                                            "'" . addslashes($group_name) . "', " . // name 
                                            "'" . date("Y-m-d H:i:s", strtotime($regel['datumvan'] . ' 00:00:00')) . "', " . // intervalstart (start of exception)
                                            "'" . date("Y-m-d H:i:s", strtotime($regel['datumvan'] . ' 23:59:59')) . "', " . // intervalend (end of exception)                    
                                            "'" . $color . "', " . // color
                                            $orig_group_data[0]['systemavailabilitytype_id'] . ", " . // systemavailabilitytype_id   
                                            "'" . addslashes(strip_tags($orig_group_data[0]['note'])) . "', " .  // note
                                            "'" . $orig_group_data[0]['frequency'] . "', '" . $orig_group_data[0]['period'] . "', " . 
                                            "'" . $orig_group_data[0]['until'] . "', '" . $orig_group_data[0]['byweekno'] . "', " . 
                                            "'" . $orig_group_data[0]['bymonthday'] . "', '" . $orig_group_data[0]['byday'] . "' " . // rrule fields              
                                            ")";
                                                                 
                            $new_group_res = $this->query($new_group_sql);
                            $rosterrulegroup_id_new = $new_group_res->getInsertId();
                         
        
        
                            
                            // fields based on info from rule $orig_rule_data, and dates of exception $regel, made sure id is not used
                            $new_sql = "INSERT INTO rosterrule (id, __active, rosterrulegroup_id, rosterruleprofile_id, " .
                                       "intervalstart, intervalend, multiplicity, created, counter) VALUES (" . 
                                       ($orig_rule_data[0]['id']+$count_beschikbaarheidregeluitzondering+$index+100000) . ", 1, " . // id, __active,
                                       intval($rosterrulegroup_id) . ", 0, " .  // rosterrulegroup_id, rosterruleprofile_id
                                        "'" . date("Y-m-d H:i:s", strtotime($regel['datumvan'] . ' 00:00:00')) . "', " . // intervalstart (start of exception)
                                        "'" . date("Y-m-d H:i:s", strtotime($regel['datumvan'] . ' 23:59:59')) . "', " . // intervalend (end of exception)
                                        $multiplicity_new . ", '" . date("Y-m-d H:i:s") . "', 0 " . // multiplicity, created, counter                                   
                                       ")";
        
                            $insertres = $this->query($new_sql);
                            $rosterrule_id_new = $insertres->getInsertId();
                                       
                            // and link this new rule to types $new_types
                            foreach ($new_types as $appointmenttype_id) {
                                
                                if (isset($appointment_type_names[$appointmenttype_id])) {
                                    $this->query("INSERT INTO rosterrule_appointmenttype (rosterrule_id, appointmenttype_id) " . 
                                                    "VALUES (" . intval($rosterrule_id_new) . ", " . intval($appointmenttype_id) . ")");
                                } else {
                                    $log[] = "could not link roster rule " . $rosterrule_id_new . " linked to non-existing appointment type " . $appointmenttype_id;     
                                }
                                
                            }
                            
                            
                            if ($multiplicity_org != $multiplicity_exception) {
                                // extra action for situation 2   
                                // create group/rule with differente multiplicity for appointment types rule and exception have in common
                               
                                $new_types = array_intersect($original_types, $exception_types);
                                sort($new_types);
                                $multiplicity_new = $multiplicity_exception;
        
                
            
                               // randomly choose on of our colors                      
                                $color = $roster_rule_colors[rand(0, count($roster_rule_colors)-1)];
        
                                // update group name         
                                $group_name .= 'uitzondering van ' . 
                                                date("d-m-Y", strtotime($regel['datumvan'])) . ' t/m ' . 
                                                date("d-m-Y", strtotime($regel['datumtot']));
                                                     
                                // fields based on info from group $orig_group_data, and dates of exception $regel
                                $new_group_sql = "INSERT INTO rosterrulegroup " . 
                                                "(name, intervalstart, intervalend, color, systemavailabilitytype_id, " . 
                                                "note, frequency, period, until, byweekno, bymonthday, byday) " . 
                                                "VALUES (" . 
                                                "'" . addslashes($group_name). "', " . // name
                                                "'" . date("Y-m-d H:i:s", strtotime($regel['datumvan'] . ' 00:00:00')) . "', " . // intervalstart (start of exception)
                                                "'" . date("Y-m-d H:i:s", strtotime($regel['datumvan'] . ' 23:59:59')) . "', " . // intervalend (end of exception)                    
                                                "'" . $color . "', " . // color
                                                $orig_group_data[0]['systemavailabilitytype_id'] . ", " . // systemavailabilitytype_id   
                                                "'" . addslashes(strip_tags($orig_group_data[0]['note'])) . "', " .  // note
                                                "'" . $orig_group_data[0]['frequency'] . "', '" . $orig_group_data[0]['period'] . "', " . 
                                                "'" . $orig_group_data[0]['until'] . "', '" . $orig_group_data[0]['byweekno'] . "', " . 
                                                "'" . $orig_group_data[0]['bymonthday'] . "', '" . $orig_group_data[0]['byday'] . "'" . // rrule fields              
                                                ")";
                                                                     
                                $new_group_res = $this->query($new_group_sql);
                                $rosterrulegroup_id_new = $new_group_res->getInsertId();
                                                   
                                // fields based on info from rule $orig_rule_data, and dates of exception $regel, made sure id is not used
                                $new_sql = "INSERT INTO rosterrule (id, __active, rosterrulegroup_id, rosterruleprofile_id, " .
                                           "intervalstart, intervalend, multiplicity, created, counter) VALUES (" . 
                                           ($orig_rule_data[0]['id']+$count_beschikbaarheidregeluitzondering+$index+200000) . ", 1, " . // id, __active,
                                           $rosterrulegroup_id . ", 0, " .  // rosterrulegroup_id, rosterruleprofile_id
                                            "'" . date("Y-m-d H:i:s", strtotime($regel['datumvan'] . ' 00:00:00')) . "', " . // intervalstart (start of exception)
                                            "'" . date("Y-m-d H:i:s", strtotime($regel['datumvan'] . ' 23:59:59')) . "', " . // intervalend (end of exception)
                                            $multiplicity_new . ", '" . date("Y-m-d H:i:s") . "', 0 " . // multiplicity, created, counter                                   
                                           ")";
                        
                             
                                
                                $insertres = $this->query($new_sql);
                                $rosterrule_id_new = $insertres->getInsertId();
                                           
                                // and link this new rule to types $new_types
                                foreach ($new_types as $appointmenttype_id) {
                                    
                                    if (isset($appointment_type_names[$appointmenttype_id])) {
        
                                        $this->query("INSERT INTO rosterrule_appointmenttype (rosterrule_id, appointmenttype_id) " . 
                                                        "VALUES (" . $rosterrule_id_new . ", " . $appointmenttype_id . ")");
                                    } else {
                                        $log[] = "could not link roster rule " . $rosterrule_id_new . " linked to non-existing appointment type " . $appointmenttype_id;     
                                    }
                                
                                }
                            }
                        }
                                 
                        $log[] = "beschikbaarheidregeluitzondering " . $beschikbaarheidregel_id . " converted to roster rule exception " . $rosterruleexception_id;     
                    } else {
                        $errors[] = "conversion of beschikbaarheidregeluitzondering " . $beschikbaarheidregel_id . " failed: " . $sql;                                
                    }
                }
            }
        }
        
        
        
        // beschikbaarheidregelonderbreking
        
        $res = $this->query("SELECT count(id) AS amount FROM beschikbaarheidregelonderbreking")->getData();
        $count_beschikbaarheidregelonderbreking = $res[0]['amount'];
        
        $log[] = 'found ' . $count_beschikbaarheidregelonderbreking . ' beschikbaarheidregelonderbreking records';
            
        $start = 0;
        
        for ($start = 0 ; $start < $count_beschikbaarheidregelonderbreking ; $start += 1000) {
        
            $res = $this->query("SELECT * FROM beschikbaarheidregelonderbreking LIMIT " . $start . ", 1000");     
            
            if ($res->getSuccess()) {
        
                foreach ($res->getData() as $regel) { 
        
        
                    if (intval($regel['beschikbaarheidregel_id']) == 0) {
        
                        $userlog[] = "niet geconverteerde onderbrekingregel:\n" . 
                                     "id: " . $regel['id'] . "\n" .
                                     "tijd van: " . $regel['van'] . "\n" .  
                                     "tijd tot: " . $regel['tot'] . "\n" .                             
                                     "oorzaak: geen beschikbaarheidregel gekoppeld\n"; 
        
                        continue;  
                    }
        
                    if ($regel['van'] >= $regel['tot']) {
        
                        $userlog[] = "niet geconverteerde onderbrekingregel: \n" . 
                                     "id: " . $regel['id'] . "\n" .
                                     "tijd van: " . $regel['van'] . "\n" .  
                                     "tijd tot: " . $regel['tot'] . "\n" .                             
                                     "oorzaak: starttijd gelijk aan of groter dan eindtijd\n"; 
        
                        continue;  
                    }
                
                    // link to same group as $regel['beschikbaarheidregel_id']
                    $res = $this->query("SELECT rosterrulegroup_id FROM rosterrule WHERE id = " . $regel['beschikbaarheidregel_id']);
                    $data = $res->getData();
                    $rosterrulegroup_id = $data[0]['rosterrulegroup_id'];  
        
                    if (intval($rosterrulegroup_id) == 0) {
                        // was obviously not converted
                        continue;    
                    }
        
                    // based on start date of original beschikbaarheidregel
                    $originalres = $this->query("SELECT datumvan FROM beschikbaarheidregel WHERE id = " . $regel['beschikbaarheidregel_id']);
                    
                    if ($originalres->getSuccess()) {
                        $original_regels = $originalres->getData();
                        $original_regel = $original_regels[0];
                        
                        $sql = "INSERT INTO rosterruleexception (rosterrulegroup_id, start, end, reason) VALUES (" . 
                               $rosterrulegroup_id . ", '" . date("Y-m-d H:i:s", strtotime($original_regel['datumvan'] . ' ' . $regel['van'])) . "', '" . 
                               date("Y-m-d H:i:s", strtotime($original_regel['datumtot'] . ' ' . $regel['tot'])) . "', '')"; 
                               
                        $insertres = $this->query($sql);
                        
                        if ($insertres->getSuccess()) {
                            $regel['type'] = 'beschikbaarheidregelonderbreking';
                            $valid_rules_in_this_block[] = $regel;
                            $rosterruleexception_id = $insertres->getInsertId();
                            $log[] = "beschikbaarheidregelonderbreking " . $beschikbaarheidregel_id . " converted to roster rule exception " . $rosterruleexception_id;     
                        } else {
                            $errors[] = "conversion of beschikbaarheidregelonderbreking " . $beschikbaarheidregel_id . " failed: " . $sql;                                
                        }
                    } else {
                        $errors[] = "conversion of beschikbaarheidregelonderbreking " . $beschikbaarheidregel_id . " failed: corresponding beschikbaarheidregel not found";                                
                    } 
                }
            }        
        }
        
        
        $res = $this->query("SELECT count(id) AS amount FROM kliniekvakantiedag")->getData();
        $count_kliniekvakantiedag = $res[0]['amount'];
        
        $start = 0;
        
        for ($start = 0 ; $start < $count_beschikbaarheidregelonderbreking ; $start += 1000) {
        
            $clinicres = $this->query("SELECT * FROM kliniekvakantiedag LIMIT " . $start . ", 1000");     
            
            if ($clinicres->getSuccess()) {
                $rules = $clinicres->getData();
               
                for ($r = 0 ; $r < count($rules) ; $r++) {
            
                    // create rosterrulegroup entry, empty name for now, will update later
                    $color = $roster_rule_colors[rand(0, count($roster_rule_colors)-1)];           
                    $regel =& $rules[$r];
                    
                    $new_group_sql = "INSERT INTO rosterrulegroup " . 
                                    "(name, intervalstart, intervalend, color, systemavailabilitytype_id, " . 
                                    "note, frequency, period, until) " . 
                                    "VALUES (" . 
                                    "'', " . // name
                                    "'" . date("Y-m-d H:i:s", strtotime($regel['van'])) . "', " . // intervalstart 
                                    "'" . date("Y-m-d H:i:s", strtotime("+1 day", strtotime(substr($regel['van'], 0, 10) . ' 23:59:59'))) . "', " . // intervalend                     
                                    "'" . $color . "', " . // color
                                    "2, " . // systemavailabilitytype_id   
                                    "'kliniek afwezigheid', " .  // note
                                    "'DAILY', '" . $orig_group_data[0]['period'] . "', " . 
                                    "'" . date("Y-m-d H:i:s", strtotime("+1 day", strtotime(substr($regel['van'], 0, 10) . ' 23:59:59'))) . "'" . // rrule fields              
                                    ")";
                                    
                                    
                    $res = $this->query($new_group_sql);
                    $rosterrulegroup_id = $res->getInsertId();        
        
        
                    // link group to clinic            
                    $sql = "INSERT INTO rosterrulegroup_clinic (rosterrulegroup_id, clinic_id) VALUES " .
                            "(" . $rosterrulegroup_id . ", " . $regel['kliniek_id'] . ")";
        
                    
                    // logic taken from kliniekvakantie.js
                    $regel['tot'] = substr($regel['tot'], 0, 10) . " 23:59:59";
                    
                    if ($regel['van'] >= $regel['tot']) {
        
                        $userlog[] = "niet geconverteerde kliniek gesloten regel:\n" . 
                                     "id: " . $regel['id'] . "\n" .
                                     "kliniek: " . ($regel['kliniek_id'] > 0 ? $clinic_names[$regel['kliniek_id']] : '(geen)') . "\n" .  
                                     "datum/tijd van: " . $regel['van'] . "\n" .  
                                     "datum/tijd tot: " . $regel['tot'] . "\n" .                               
                                     "oorzaak: startdatum/tijd gelijk aan of groter dan einddatum/tijd\n"; 
        
                        continue;  
                    }
        
        
                    if (intval($regel['kliniek_id']) == 0) {
        
                        $userlog[] = "niet geconverteerde kliniek gesloten regel:\n" . 
                                     "id: " . $regel['id'] . "\n" .
                                     "kliniek: " . ($regel['kliniek_id'] > 0 ? $clinic_names[$regel['kliniek_id']] : '(geen)') . "\n" .  
                                     "datum/tijd van: " . $regel['van'] . "\n" .  
                                     "datum/tijd tot: " . $regel['tot'] . "\n" .                               
                                     "oorzaak: geen kliniek gekoppeld\n"; 
        
                        continue;  
                    }
        
        
                    if (!isset($clinic_names[$regel['kliniek_id']])) {
        
                        $userlog[] = "niet geconverteerde kliniek gesloten regel:\n" . 
                                     "id: " . $regel['id'] . "\n" .
                                     "kliniek: (onbekend)\n" .  
                                     "datum/tijd van: " . $regel['van'] . "\n" .  
                                     "datum/tijd tot: " . $regel['tot'] . "\n" .                               
                                     "oorzaak: niet bestaande kliniek gekoppeld (kliniek_id " . $regel['kliniek_id'] . ")\n"; 
        
                        continue;  
                    }
         
                    $sql = "INSERT INTO rosterrule (id, __active, rosterrulegroup_id, rosterruleprofile_id, intervalstart, " . 
                           "intervalend, multiplicity, created, counter) VALUES (" .
                           "NULL, 1, " .
                           $rosterrulegroup_id . ", 0, '" . date("Y-m-d H:i:s", strtotime($regel['van'])) . "', " . 
                           "'" . date("Y-m-d H:i:s", strtotime(substr($regel['van'],0,10) . ' 23:59:59')) . "', 1, '" . date("Y-m-d H:i:s") . "', 0)";
            
                    $insertres = $this->query($sql);
                    
                    if ($insertres->getSuccess()) {
                        $rosterrule_id = $insertres->getInsertId();
                                                       
                        $log[] = "kliniekvakantiedag " . $regel['id'] . " converted to roster rule group " . $rosterrulegroup_id . " / roster rule " . $rosterrule_id;     
            
                    }  else {
                        $errors[] = "conversion of kliniekvakantiedag " . $regel['id'] . " failed: " . $sql;                                
                    }
                    
                    // update group name         
                    $group_name = 'kliniek vakantiedag ' . date("m-d-Y", strtotime($regel['van']));
                    if (intval($rosterrulegroup_id) > 0) {
                        $this->query("UPDATE rosterrulegroup SET name = '" . addslashes($group_name). "' WHERE id = " . intval($rosterrulegroup_id));
                    }
                }
            }
        }
             
        $res = $this->query("SELECT count(id) AS amount FROM rosterrule")->getData();
        $userlogaantallen[] = 'Aantal roosterregels na conversie: ' . $res[0]['amount'];

        foreach ($log as $logitem) {
            $this->logger->writeLine($logitem);
        }
        
        foreach ($userlogaantallen as $logitem) {
            $this->logger->writeLine($logitem);
        }
        
        foreach ($userlog as $logitem) {
            $this->logger->writeLine($logitem);
        }
        
        foreach ($errors as $logitem) {
            $this->logger->writeLine('error: ' . $logitem);
        }

    } 



    function getSpecialistName($specialist_id) {

        $specialist_name = "(onbekend)"; 
        
        if ($specialist_id > 0) {
            $specialistres = $this->query("SELECT title, initials, firstname, surname, surnameprefix, marriedname, marriednameprefix " . 
                                              "FROM employee WHERE id = " . $specialist_id);
                                              
            if ($specialistres->getSuccess()) {
                $specialistsdata = $specialistres->getData();
                $specialistdata = $specialistsdata[0];
                
                $specialist_name = ($specialistdata['title'] != '' ? $specialistdata['title'] . ' ' : '') .
                              ($specialistdata['initials'] != '' ? $specialistdata['initials'] . ' ' : '') . 
                              ($specialistdata['surnameprefix'] != '' ? $specialistdata['surnameprefix'] . ' ' : '') .
                              $specialistdata['surname'];
            } 
        } 
        
        return $specialist_name;
    }

}

