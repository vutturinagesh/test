<?php

class AppointmentConversion extends AutoConversion_DatabaseChange {
 
        final public function getTitle() {
        return "Employee Management conversion, appointments";
    }
 
    final public function run() {

        
        // init
        $log = array();
        $userlog = array();
        $userlogaantallen = array();
        $errors = array();
        
        
        // tables for new functionality which won't be filled
        $this->query("TRUNCATE TABLE appointmentseries");
        $this->query("TRUNCATE TABLE appointmentseriesparticipation");
        $this->query("TRUNCATE TABLE appointmentseries_extrastatus");
        $this->query("TRUNCATE TABLE appointmentexception");
        
        // retrieve info from afspraak, afspraak_patient, afspraak_extrastatus
        $this->query("TRUNCATE TABLE appointment");
        $this->query("TRUNCATE TABLE appointmentparticipation");
        $this->query("TRUNCATE TABLE appointment_extrastatus");
        
        // retrieve info from combinedappointment, combinedappointmenitem
        $this->query("TRUNCATE TABLE appointmentprofile");
        $this->query("TRUNCATE TABLE appointmentprofileelement");
        
        // remember names of all appointment types
        $appointment_type_names = array();
        
        $res = $this->query("SELECT id, name FROM appointmenttype");
        
        if ($res->getSuccess()) {
            $types = $res->getData();
            
            for ($a = 0 ; $a < count($types) ; $a++) {
                $appointment_type_names[$types[$a]['id']] = $types[$a]['name'];  
            }    
        }
        
        
        // remember names of all clinics
        $clinic_names = array();
        
        $res = $this->query("SELECT id, naam FROM kliniek");
        
        if ($res->getSuccess()) {
            $clinics = $res->getData();
            
            for ($a = 0 ; $a < count($clinics) ; $a++) {
                $clinic_names[$clinics[$a]['id']] = $clinics[$a]['naam'];  
            }    
        }
        
        
        
        
        // appointments
        
        $res = $this->query("SELECT count(id) AS amount FROM afspraak")->getData();
        $count_afspraak = $res[0]['amount'];
        $userlogaantallen[] = 'Aantal afspraken voor conversie: ' . $count_afspraak;
            
        $start = 0;
        
        for ($start = 0 ; $start < $count_afspraak ; $start += 1000) {
        
            $res = $this->query("SELECT * FROM afspraak LIMIT " . $start . ", 1000");     
            
            if ($res->getSuccess()) {
                foreach ($res->getData() as $afspraak) {
                    $afspraak_id = $afspraak['id'];
                       
                    switch ($afspraak['status']) {
                        case 'aangemeld':
                            $systemappointmentstatus_id = 2;
                            break;
                        case 'afgezegd <24u':
                            $systemappointmentstatus_id = 3;
                            break;
                        default:
                            $systemappointmentstatus_id = 1;
                            break;
                    }
                    
                    $sql = "INSERT INTO appointment (" .
                           "id, __active, systemappointmentstatus_id, appointmenttype_id, systemavailabilitytype_id, " . 
                           "intervalstart, intervalend, clinic_id, notes, created, sequencenumber, contactmanner_id, " . 
                           "referrertype_id, referrerfixedtype, referrerorganization_id, referrerperson_id, referrerowninitiative_id," .
                           "kind, haste, financiallyprocessed, cancelreason, break, checkindate, inroster, seen, patientgroup_id) VALUES (" . 
        
                           $afspraak['id'] . ", " . // id
                           "1, " . // __active
                           $systemappointmentstatus_id . ", " .// systemappointmentstatus_id
                           $afspraak['bloktype_id'] . ", " . // appointmenttype_id
                           ($afspraak['pauze'] == 'nee' ? 1 : 2) . ", " . // systemavailabilitytype_id
                           "'" . date("Y-m-d H:i:s", strtotime($afspraak['datumtijd_van'])) . "', " . // intervalstart
                           "'" . date("Y-m-d H:i:s", strtotime($afspraak['datumtijd_tot'])) . "', " . // intervalend
                           $afspraak['kliniek_id'] . ", " . // clinic_id
                           "'" . addslashes($afspraak['opmerking']) . "', " . // notes
                           "'" . date("Y-m-d H:i:s") . "', " . // created
                           "0, " . // sequencenumber
                           $afspraak['contactwijze_id'] . ", " . // contactmanner_id
        
                           $afspraak['referrertype_id'] . ", " .  // referrer fields
                           "'" . $afspraak['referrerfixedtype'] . "', " .
                           $afspraak['referrerorganisation_id'] . ", " .
                           $afspraak['referrerperson_id'] . ", " .
                           $afspraak['referrerowninitiative_id'] . ", " .
                           
                           "'" . addslashes($afspraak['soort']) . "', " . // compatibility fields
                           ($afspraak['spoed'] == 'ja' ? 1 : 0) . ", " .
                            ($afspraak['financielestatus'] == 'verwerkt' ? 1 : 0) . ", " .
                           "'" . addslashes($afspraak['redenafzeggen']) . "', " .
                           ($afspraak['pauze'] == 'ja' ? 1 : ($afspraak['pauze'] == 'vakantiedag' ? 2 : 0)) . ", " .
                           "'" . $afspraak['aanmeldingstijd'] . "', " .
                           ($afspraak['binnenrooster'] == 'ja' ? 1 : 0) . ", " .
                           ($afspraak['gezien'] == 'ja' ? 1 : 0) . ", " .
                           $afspraak['patientgroup_id'] . ")"; 
                    
                    $insert_res = $this->query($sql);
                    
                    if ($insert_res->getSuccess()) {
                        $appointment_id = $afspraak['id'];
                        
                        // participations (patientgroup_id!)
                        
                        // mcp
                        $mcp_id = $afspraak['medewerker_id'];
                        
                        // human or resource?
                        $medewerker_res = $this->query("SELECT resourcetype FROM medewerker WHERE id = " . $mcp_id);
                        $data = $medewerker_res->getData();
                        
                        if ($data && count($data) > 0) {
                            
                            $resourcetype = $data['resourcetype']; // DEZE REGEL FAALT OOK HEEL VAAK!
                /*
                 * Non- fatal Error : [8] msg:Undefined index:  resourcetype,
                 * file:
                 * /home/misactie/sms_upgradefiles/73/AppointmentConversion.
                 * class.php, line:143, context:Array **

                 */
                            
                            
                            if ($resourcetype == 'room' || $resourcetype == 'tool') {
                                
                                // link resource
                            
                                $participant_res = $this->query("SELECT id FROM participant WHERE resource_id = " . $mcp_id);
                                
                                $data = $participant_res->getData();
                                
                                if ($data && count($data) > 0) {
                                    $participant_id = $data[0]['id'];
                                    
                                    $this->query("INSERT INTO appointmentparticipation (appointment_id, participant_id, systemparticipationrole_id) " .
                                                   "VALUES " . 
                                                   "(" . $appointment_id . ", " . $participant_id . ", 4)");
                                }
                                else {
                                    // delete and abort this one
                                    $this->query("DELETE FROM appointment WHERE id = " .   $appointment_id);
                                    
                                    $ztres = $this->query("SELECT patient_id FROM zorgtraject WHERE id = " . $afspraak['zorgtraject_id']);
                                    $ztdata = $ztres->getData();
                                    
                                    
                                    if ($ztdata[0]['patient_id'] > 0) {
                                        $patientres = $this->query("SELECT geboortedatum FROM patient WHERE id = " . $ztdata[0]['patient_id']);
                                        $patientdata = $patientres->getData();
                                    }
                                    else {
                                        $patientdata = array();   
                                    }

                                                                
                                    $userlog[] = "niet geconverteerde afspraak:\n" . 
                                                 "id: " . $afspraak['id'] . "\n" .
                                                 "patientnaam: " . $this->getPatientName($afspraak['zorgtraject_id']) . "\n" .
                                                 "geboortedatum: " . (isset($patientdata[0]) ? $patientdata[0]['geboortedatum'] : '') . "\n" .
                                                 "kliniek: " . ($afspraak['kliniek_id'] > 0 ? $clinic_names[$afspraak['kliniek_id']] : '(geen)') . "\n" .
                                                 "specialist: " . $this->getSpecialistName($afspraak['medewerker_id']) . "\n" .
                                                 "soort afspraak: " . ($afspraak['bloktype_id'] > 0 ? $appointment_type_names[$afspraak['bloktype_id']] : '(geen)') . "\n" .
                                                 "datum/tijd: " . $afspraak['datumtijd_van'] . "\n" .                                  
                                                 "oorzaak: gekoppeld aan niet bestaande resource (resource_id " . $mcp_id . ")\n"; 
                                                 
                                                 
                                    continue;     
                                }                        
                            }
                            else {
                                // link main care provider
                                
                                $link_mcp_success = false;
                                
                                $participant_res = $this->query("SELECT id FROM participant WHERE employee_id = " . $mcp_id);
                                $data = $participant_res->getData();
                                
                                if ($data && count($data) > 0) {
        
                                    $participant_id = $data[0]['id'];
                                    
                                    $this->query("INSERT INTO appointmentparticipation (appointment_id, participant_id, systemparticipationrole_id) " .
                                                   "VALUES " . 
                                                   "(" . $appointment_id . ", " . $participant_id . ", 3)");
                                    
                                    $link_mcp_success = true;                                           
                                }
                                else {
                                    
                                    
                                    // maybe this $mcp_id is actually a resource
                                    $resource_res = $this->query("SELECT id FROM resource WHERE employee_id = " . $mcp_id);
                                    $data = $resource_res->getData();
                                    
                                    
                                    if ($data && count($data) > 0) {
                
                                        $participant_res = $this->query("SELECT id FROM participant WHERE resource_id = " . $data[0]['id']);
                                        $data = $participant_res->getData();    
                                        
                                        if ($data && count($data) > 0) {                                
                                            $participant_id = $data[0]['id'];
                                            
                                            $this->query("INSERT INTO appointmentparticipation (appointment_id, participant_id, systemparticipationrole_id) " .
                                                           "VALUES " . 
                                                           "(" . $appointment_id . ", " . $participant_id . ", 3)");                                
                                            
                                            $link_mcp_success = true;
                                        }
                                        
                                    }
                                }
                                
                                if ($link_mcp_success == false) {
                                 
                                    // delete and abort this one
                                    $this->query("DELETE FROM appointment WHERE id = " .   $appointment_id);

                                    $ztres = $this->query("SELECT patient_id FROM zorgtraject WHERE id = " . $afspraak['zorgtraject_id']);
                                    $ztdata = $ztres->getData();
                                    
                                    if ($ztdata[0]['patient_id'] > 0) {
                                        $patientres = $this->query("SELECT geboortedatum FROM patient WHERE id = " . $ztdata[0]['patient_id']);
                                        $patientdata = $patientres->getData();
                                    }
                                    else {
                                        $patientdata = array();
                                           
                                    }
                                    $userlog[] = "niet geconverteerde afspraak:\n" . 
                                                 "id: " . $afspraak['id'] . "\n" .
                                                 "patientnaam: " . $this->getPatientName($afspraak['zorgtraject_id'], true) . "\n" .
                                                 "geboortedatum: " . (isset($patientdata[0]) ? $patientdata[0]['geboortedatum'] : '') . "\n" .
                                                 "kliniek: " . ($afspraak['kliniek_id'] > 0 ? $clinic_names[$afspraak['kliniek_id']] : '(geen)') . "\n" .
                                                 "specialist: " . $this->getSpecialistName($afspraak['medewerker_id']) . "\n" .
                                                 "soort afspraak: " . ($afspraak['bloktype_id'] > 0 ? $appointment_type_names[$afspraak['bloktype_id']] : '(geen)') . "\n" .
                                                 "datum/tijd: " . $afspraak['datumtijd_van'] . "\n" .                                  
                                                 "oorzaak: gekoppeld aan niet bestaande specialist/resource (medewerker_id " . $mcp_id . ")\n"; 
                                                 
                                    continue;     
                                
                                }
                            }
                        }
                        else {
                            // delete and abort this one
                            $this->query("DELETE FROM appointment WHERE id = " .   $appointment_id);

                            $ztres = $this->query("SELECT patient_id FROM zorgtraject WHERE id = " . $afspraak['zorgtraject_id']);
                            $ztdata = $ztres->getData();
                            
                            if ($ztdata[0]['patient_id'] > 0) {
                                $patientres = $this->query("SELECT geboortedatum FROM patient WHERE id = " . $ztdata[0]['patient_id']);
                                $patientdata = $patientres->getData();
                            }
                            else {
                                 $patientdata = array();
                            }
                             
                            $userlog[] = "niet geconverteerde afspraak:\n" . 
                                         "id: " . $afspraak['id'] . "\n" .
                                         "patientnaam: " . $this->getPatientName($afspraak['zorgtraject_id']) . "\n" .
                                         "geboortedatum: " . (isset($patientdata[0]) ? $patientdata[0]['geboortedatum'] : '') . "\n" .
                                         "kliniek: " . ($afspraak['kliniek_id'] > 0 ? $clinic_names[$afspraak['kliniek_id']] : '(geen)') . "\n" .
                                         "specialist: " . $this->getSpecialistName($afspraak['medewerker_id']) . "\n" .
                                         "soort afspraak: " . ($afspraak['bloktype_id'] > 0 ? $appointment_type_names[$afspraak['bloktype_id']] : '(geen)') . "\n" .
                                         "datum/tijd: " . $afspraak['datumtijd_van'] . "\n" .                                  
                                         "oorzaak: gekoppeld aan niet bestaande specialist (medewerker_id " . $mcp_id . ")\n"; 
                
                            continue;     
                        }   
                       
                      
                        // planner
                        $planner_id = $afspraak['planner_id'];                
                        $plan_res = $this->query("SELECT user_id FROM employee WHERE id = " . $planner_id);
                        $data = $plan_res->getData();
                   
                        if ($data && count($data) > 0) {
                           
                            $user_id = $data[0]['user_id'];
                            
                            $participant_res = $this->query("SELECT id FROM participant WHERE user_id = " . $user_id);
                            
                            $data = $participant_res->getData();
                                
                            if ($data && count($data) > 0) {
                                $participant_id = $data[0]['id'];
                                
                                $this->query("INSERT INTO appointmentparticipation (appointment_id, participant_id, systemparticipationrole_id) " .
                                               "VALUES " . 
                                               "(" . $appointment_id . ", " . $participant_id . ", 5)");
                            }
                            else {
                                // planner not found? too bad, but don't abort this appointment   
                            }     
                        }
                        else {
                            // planner not found? too bad, but don't abort this appointment   
                        }   
                        
                        
                        
                        // patients
                        $patients = array();
                        
                        // retrieve main patient from zorgtraject
                        $zorgtraject_res = $this->query("SELECT patient_id FROM zorgtraject WHERE id = " . $afspraak['zorgtraject_id']);
                        $data = $zorgtraject_res->getData();
                        
                        if ($data && count($data) > 0) {
                            
                            $patients[] = $data[0]['patient_id'];
                            
                            // extra patients?
                            $morepatients_res = $this->query("SELECT patient_id FROM afspraak_patient WHERE afspraak_id = " . $afspraak['id']);
                            
                            if ($morepatients_res->getSuccess()) {
                                foreach ($morepatients_res->getData()  as $extra_patient) {
                                    $patients[] = $extra_patient['patient_id'];   
                                }   
                            }
                            
                            
                            $patients = array_unique($patients);
                            
                            for ($p = 0 ; $p < count($patients) ; $p++) {
                                $patient_id = $patients[$p];
        
                                $participant_res = $this->query("SELECT id FROM participant WHERE patient_id = " . $patient_id);
                                $data = $participant_res->getData();
                                
                                if ($data && count($data) > 0) {
                                    $participant_id = $data[0]['id'];
                                    $this->query("INSERT INTO appointmentparticipation (appointment_id, participant_id, systemparticipationrole_id) " .
                                                   "VALUES " . 
                                                   "(" . $appointment_id . ", " . $participant_id . ", 2)");
                                }
                                else {
                                    // delete and abort this one
                                    $this->query("DELETE FROM appointment WHERE id = " .   $appointment_id);
                                    $this->query("DELETE FROM appointmentparticipation WHERE appointment_id = " .   $appointment_id);
                                    
                                    $patientres = $this->query("SELECT geboortedatum FROM patient WHERE id = " . $patient_id);
                                    $patientdata = $patientres->getData();
                                    
                                    $userlog[] = "niet geconverteerde afspraak:\n" . 
                                                 "id: " . $afspraak['id'] . "\n" .
                                                 "patientnaam: " . $this->getPatientName($patient_id) . "\n" .
                                                 "geboortedatum: " . $patientdata[0]['geboortedatum'] . "\n" .
                                                 "kliniek: " . ($afspraak['kliniek_id'] > 0 ? $clinic_names[$afspraak['kliniek_id']] : '(geen)') . "\n" .
                                                 "specialist: " . $this->getSpecialistName($afspraak['medewerker_id']) . "\n" .
                                                 "soort afspraak: " . ($afspraak['bloktype_id'] > 0 ? $appointment_type_names[$afspraak['bloktype_id']] : '(geen)') . "\n" .
                                                 "datum/tijd: " . $afspraak['datumtijd_van'] . "\n" .                                  
                                                 "oorzaak: gekoppeld aan niet bestaande patient (patient_id " . $patient_id . ")\n"; 
                                                             
                                    break;    
                                }
                                
                            }
                            
                        }
                        else {
                            // delete and abort this one
                            $this->query("DELETE FROM appointment WHERE id = " .   $appointment_id);
                            $this->query("DELETE FROM appointmentparticipation WHERE appointment_id = " .   $appointment_id);
                            
                            $userlog[] = "niet geconverteerde afspraak:\n" . 
                                         "id: " . $afspraak['id'] . "\n" .
                                         "patientnaam: (onbekend)\n" .
                                         "geboortedatum: (onbekend)\n" .
                                         "kliniek: " . ($afspraak['kliniek_id'] > 0 ? $clinic_names[$afspraak['kliniek_id']] : '(geen)') . "\n" .
                                         "specialist: " . $this->getSpecialistName($afspraak['medewerker_id']) . "\n" .
                                         "soort afspraak: " . ($afspraak['bloktype_id'] > 0 ? $appointment_type_names[$afspraak['bloktype_id']] : '(geen)') . "\n" .
                                         "datum/tijd: " . $afspraak['datumtijd_van'] . "\n" .                                  
                                         "oorzaak: geen patient gevonden bij zorgtraject van afspraak (zorgtraject_id " . $afspraak['zorgtraject_id'] . ")\n";                                              
                            continue;     
                        }   
                        
        
                        $extrastastus_res = $this->query("SELECT extrastatus_id FROM afspraak_extrastatus WHERE afspraak_id = " . $afspraak_id);
                        $data = $extrastastus_res->getData();
                         
                        if ($data && count($data) > 0) {
                            foreach ($data as $status) {
                                $this->query("INSERT INTO appointment_extrastatus (appointment_id, appointmentextrastatus_id) " . 
                                                "VALUES " . 
                                                "(" . $appointment_id . ", " . $status['extrastatus_id'] . ")");
                            }
                        }
                        
                        
                        $log[] = 'afspraak ' . $afspraak_id . ' converted to appointment ' . $appointment_id; 
                    } else {
                        $errors[] = 'conversion of afspraak ' . $afspraak_id . ' failed: ' . $sql;
                    }
                }   
            }
        }
        
        
        $res = $this->query("SELECT count(id) AS amount FROM appointment")->getData();
        $count_afspraak = $res[0]['amount'];
        $userlogaantallen[] = 'Aantal afspraken na conversie: ' . $count_afspraak;
        
        
        // combined appointments ==> appointment profiles
        $res = $this->query("SELECT count(id) AS amount FROM combinedappointment")->getData();
        $count_combinedappointment = $res[0]['amount'];
        $userlogaantallen[] = 'Aantal combineerde afspraken voor conversie: ' . $count_combinedappointment;
            
        $start = 0;
        
        for ($start = 0 ; $start < $count_combinedappointment ; $start += 1000) {
        
            $res = $this->query("SELECT * FROM combinedappointment LIMIT " . $start . ", 1000");     
        
            if ($res->getSuccess()) {
                foreach ($res->getData() as $combinedappointment) {
                    $combinedappointment_id = $combinedappointment['id'];
                    
                    $itemres = $this->query("SELECT * FROM combinedappointmentitem WHERE combinedappointment_id = " . $combinedappointment_id);
                                     
                    if ($itemres->getSuccess()) {
                        $items = $itemres->getData();
                        
                        if ($items && count($items) > 0) {
        
                            $res = $this->query("INSERT INTO appointmentprofile (name) VALUES ('" . addslashes($combinedappointment['name']) . "')");           
                            $appointmentprofile_id = $res->getInsertId();     
                            $itemcount = 0;
                           
                            foreach ($items as $item) {
        
                                    
                                    $sql = "INSERT INTO appointmentprofileelement (" .
                                           "appointmentprofile_id, appointmenttype_id, proceedappointmentprofileelement_id, " . 
                                           "proceedasap, proceedunit, proceedamountmin, proceedamountmax, sortorder) " . 
                                           "VALUES " .
                                           "(" .
                                           $appointmentprofile_id . ", " .  // appointmentprofile_id
                                           $appointmentprofile_id . ", " .  // appointmenttype_id
                                           $item['bloktype_id'] . ", " .  // proceedappointmentprofileelement_id
                                           $item['after'] . ", " .  // proceedasap
                                           "'" . $item['resolution'] . "', " .  // proceedunit
                                           ($item['temporalrelation'] == 'minimum' ? $item['relativetime']  : 0) . ", " .  // proceedamountmin
                                           ($item['temporalrelation'] == 'maximum' ? $item['relativetime']  : 0) .  ", " .  // proceedamountmax
                                           $item['sequencenumber'] . ")";  // sortorder
                            
                                    $insertres = $this->query($sql);
                                    
                                    if ($insertres->getSuccess()) {
                                        $itemcount++;   
                                    }
                                    else {
                                        // abort   
                                        $error[] = "can't convert combined appointment " . $combinedappointment_id . ': ' . $sql;
                                        $this->query("DELETE FROM appointmentprofileelement WHERE appointmentprofile_id = " . $appointmentprofile_id);
                                        $this->query("DELETE FROM appointmentprofile WHERE id = " . $appointmentprofile_id);
                                    }
                            }
                            
                            $log[] = 'combined appointment ' . $combinedappointment_id . ' converted to appointment profile ' . $appointmentprofile_id . ' with ' . $itemcount . ' elements';
                        } else {
                            
                            $userlog[] = "niet geconverteerde gecombineerde afspraak:\n" . 
                                         "id " . $combinedappointment['id'] . "\n" .
                                         "naam: " . $combinedappointment['name'] . "\n" .
                                         "oorzaak: geen items gevonden";
          
                        }
                    }                      
                }   
            }
        
        }
        
        $res = $this->query("SELECT count(id) AS amount FROM appointmentprofile")->getData();
        $count_appoinmtentprofiles = $res[0]['amount'];
        $userlogaantallen[] = 'Aantal afspraakprofielen na conversie: ' . $count_appoinmtentprofiles;


        foreach ($log as $logitem) {
            $this->logger->writeLine($logitem);
        }
        
        foreach ($userlogaantallen as $logitem) {
            $this->logger->writeLine($logitem);
        }
        
        foreach ($userlog as $logitem) {
            $this->logger->writeLine($logitem);
        }
        
        foreach ($errors as $logitem) {
            $this->logger->writeLine('error: ' . $logitem);
        }
    }
 
     
    function getSpecialistName($specialist_id) {

        $specialist_name = "(onbekend)"; 
        
        if ($specialist_id > 0) {
            $specialistres = $this->query("SELECT title, initials, firstname, surname, surnameprefix, marriedname, marriednameprefix " . 
                                              "FROM employee WHERE id = " . $specialist_id);
                                              
            if ($specialistres->getSuccess()) {
                $specialistsdata = $specialistres->getData();
                $specialistdata = $specialistsdata[0];
                
                $specialist_name = ($specialistdata['title'] != '' ? $specialistdata['title'] . ' ' : '') .
                              ($specialistdata['initials'] != '' ? $specialistdata['initials'] . ' ' : '') . 
                              ($specialistdata['surnameprefix'] != '' ? $specialistdata['surnameprefix'] . ' ' : '') .
                              $specialistdata['surname'];
            } 
        } 
        
        return $specialist_name;
    } 
    
    

    function getPatientName($id, $id_is_zt = false) {

        $patient_name = " (onbekend)"; 
            
        if ($id_is_zt) {
            $res = $this->query("SELECT patient_id FROM zorgtraject WHERE id = " . $id);
            
            if ($res->getSuccess()) {
                $data = $res->getData();
                $patient_id = $data[0]['patient_id'];
            }            
        } else {
            $patient_id = $id;    
        }
        
        if (isset($patient_id) && $patient_id > 0) {
            $patientres = $this->query("SELECT title, initials, firstname, surname, surnameprefix, marriedname, marriednameprefix " . 
                                              "FROM employee WHERE id = " . $patient_id);
                                              
            if ($patientres->getSuccess()) {
                $patientsdata = $patientres->getData();
                $patientdata = $patientsdata[0]; // DEZE REGEL FAALT HEEL VAAK!
                /*
                ** Non-fatal Error : [8] msg:Undefined offset:  0, file:
                * /home/misactie/sms_upgradefiles/73/AppointmentConversion.
                * class. php, line: 551, context:Array *

                 */
                
                $patient_name = ($patientdata['title'] != '' ? $patientdata['titel'] . ' ' : '') .
                              ($patientdata['initials'] != '' ? $patientdata['initials'] . ' ' : '') . 
                              ($patientdata['surnameprefix'] != '' ? $patientdata['surnameprefix'] . ' ' : '') .
                              $patientdata['surname'];
            } 
        } 
        
        return $patient_name;
    }
        
      
}