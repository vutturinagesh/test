<?php
// INC 12903 - BSN : Addition for conversion 
class BSNData extends AutoConversion_DatabaseChange {

    final public function getTitle() {
        return "BSN Data Conversion";
    }


    final public function run() {

        $this->query("SET NAMES utf8");

        $res = $this->query("INSERT IGNORE INTO actief_systeemguiitem ( scherm, systeemguiitem_id, mandatory, fatal, validation, systeemguiwarning_id, actief) VALUES
		('patientregistratie', 230, 0, 1, '/\\\\d{9}/', 19, 'ja'),
		('patientregistratie', 231, 0, 0, '', 0, 'ja'),
		('patientregistratie', 232, 0, 0, '/[0-1]/', 0, 'ja'),
		('patientregistratie', 233, 0, 0, '', 0, 'ja'),
		('patientregistratie', 234, 0, 1, '/(none)|(passport)|(idcard)|(driverslicense)|(foreignerdocument)/', 20, 'ja'),
		('patientregistratie', 235, 0, 0, '/[0-1]/', 0, 'ja'),
		('patientregistratie', 236, 0, 0, '', 0, 'ja'),
		('patientregistratie', 237, 0, 0, '', 0, 'ja'),
		('patientregistratie', 238, 0, 0, '', 0, 'ja')");


		$res = $this->query("UPDATE patient SET opmerking = CONCAT(opmerking,IF(opmerking = '','','\n\n'),'----------\nIdentificatie: ', identificatie,': ', bsn, '\n----------') WHERE bsn != '' or identificatie != '' ");

		$res = $this->query("INSERT IGNORE INTO feature_actief (feature_id) VALUES (177), (178) ");

    } 


}