<?php

class GeneralConversion extends AutoConversion_DatabaseChange {
 
    final public function getTitle() {
        return "Actinidium compatibility";
    }
 
 
    final public function run() {
        
        // commented queries will presumably be performed automatically by SMS
                
        
        $this->query("UPDATE IGNORE menuitemgroep_menuitem SET menuitem_id = 280 where menuitem_id = 44");
        $this->query("UPDATE IGNORE menuitemgroep_menuitem SET menuitem_id = 279 where menuitem_id = 52");
        $this->query("UPDATE IGNORE menuitemgroep_menuitem SET menuitem_id = 279 where menuitem_id = 53");
        $this->query("UPDATE IGNORE menuitemgroep_menuitem SET menuitem_id = 279 where menuitem_id = 81");
        $this->query("DELETE FROM menuitemgroep_menuitem WHERE menuitem_id = 125");
        $this->query("UPDATE IGNORE menuitemgroep_menuitem SET menuitem_id = 280 where menuitem_id = 256");
        $this->query("UPDATE IGNORE menuitemgroep_menuitem SET menuitem_id = 288 where menuitem_id = 258");
        $this->query("UPDATE IGNORE menuitemgroep_menuitem SET menuitem_id = 293 where menuitem_id = 259");
        $this->query("UPDATE IGNORE menuitemgroep_menuitem SET menuitem_id = 282 where menuitem_id = 260");
        $this->query("UPDATE IGNORE menuitemgroep_menuitem SET menuitem_id = 289 where menuitem_id = 63");
        $this->query("UPDATE IGNORE menuitemgroep_menuitem SET menuitem_id = 285 where menuitem_id = 38");
        $this->query("UPDATE IGNORE menuitemgroep_menuitem SET menuitem_id = 287 where menuitem_id = 162");
        $this->query("UPDATE IGNORE menuitemgroep_menuitem SET menuitem_id = 292 where menuitem_id = 264");
        $this->query("UPDATE IGNORE menuitemgroep_menuitem SET menuitem_id = 292 where menuitem_id = 264");
        $this->query("DELETE FROM menuitemgroep_menuitem WHERE menuitem_id = 266");
        $this->query("REPLACE INTO menuitemgroep_menuitem (menuitemgroep_id, menuitem_id) SELECT menuitemgroep_id, 286 FROM menuitemgroep_menuitem WHERE menuitem_id = 285");      
     /*
        -- --------------------------------------------------------------
        -- Insert systemrights records
        -- --------------------------------------------------------------
        
        */
        
        $this->query("INSERT IGNORE INTO ACTINIDIUM_systemright (id, name) SELECT id, naam FROM systeemrecht");
        
        /*

        -- --------------------------------------------------------------
        -- Create medicore user
        -- --------------------------------------------------------------
        */
        
        $this->query("INSERT IGNORE INTO ACTINIDIUM_user (username, password, expires, name, defaultlanguage) VALUES " . 
                     "('medicore', '8c17926af7d2f0152e18b11074ee0355', '2099-12-31 23:59:59', 'M. van Supportaccount', 'nl')");
        
        /*

        -- --------------------------------------------------------------
        -- Create system users with medewerkers, employee.user_id will
        -- have to be filled by employee management conversion
        -- --------------------------------------------------------------
        */

        $res = $this->query("SELECT defaulttaal AS defaultlanguage FROM klant");
        
        if ($res->getSuccess()) {
            $customer = $res->getData();
            $language = $customer[0]['defaultlanguage'];  
        }
        
        if ($language == 'es') {
            $dhr = 'Sr.';
            $mevr = 'Sra.';
            $mevr_miss = 'Srta.';                       
        }
        else if ($language == 'en_uk') {              
            $dhr = 'Mr.';
            $mevr = 'Mrs.';
            $mevr_miss = 'Ms';
        }
        else {
            $dhr = 'Dhr.';
            $mevr = 'Mevr.';
            $mevr_miss = 'Mevr.';            
        }
        
        $this->query("INSERT IGNORE INTO ACTINIDIUM_user (username, password, expires, name, defaultlanguage) " . 
                     "SELECT login, password, passwordgeldigtot,  " . 
                     "CONCAT(IF(titel!='',CONCAT(titel,' '),IF(geslacht='nvt','',  " . 
                     "CONCAT(IF(geslacht='man',  " . 
                     "'" . $dhr . "',IF (geboortedatum < DATE_SUB(NOW(), INTERVAL 18 YEAR), '" . $mevr_miss . "', '" . $mevr . "')),' '))),IF(voorletters!='',CONCAT(voorletters,' '),''),  " . 
                     "CONCAT(IF(tussenvoegselechtgenootnaam!='',CONCAT(tussenvoegselechtgenootnaam,' '),''), echtgenootnaam,  " . 
                     "IF(eigennaam='' OR echtgenootnaam='','','-'),IF(tussenvoegseleigennaam='','',CONCAT(tussenvoegseleigennaam,' ')),eigennaam)) AS naam, defaulttaal  " . 
                     "FROM medewerker " . 
                     "WHERE login != '' AND login != 'medicore' ORDER BY id");
        
        
        /*
        -- delete references to non existing features
        */
        
        $this->query("DELETE FROM feature_actief WHERE feature_id != ALL (select id from systeemfeature)");
        
        
        /*
        -- klant to ACTINIDIUM_setting
        

        */
        
        
        $this->query("REPLACE INTO ACTINIDIUM_setting (client, valuetype, name, value) VALUES (0, 'varchar', 'application_name', 'Medicore Information System')");
        $this->query("REPLACE INTO ACTINIDIUM_setting (client,  valuetype, name, value) VALUES (0, 'varchar', 'application_name_short', 'mcis')");        
        $this->query("REPLACE INTO ACTINIDIUM_setting (client,  valuetype, name, value) VALUES (0, 'varchar', 'date_format', '%d-%m-%Y')");
        $this->query("REPLACE INTO ACTINIDIUM_setting (client, valuetype, valueoptions, name, value) SELECT 0, 'enum', 'nl,es,en_uk', 'default_language', defaulttaal FROM klant");
        $this->query("REPLACE INTO ACTINIDIUM_setting (valuetype, valueoptions, name, value) " . 
                     "SELECT 'enum','158,65,75', 'default_country_id', " . 
                     "CASE defaulttaal " . 
                             " WHEN 'nl' THEN 158 " . 
                             " WHEN 'es' THEN 65 " . 
                             " WHEN 'en_uk' THEN 75 " . 
                     "END " . 
                     "FROM klant");
        
        $this->query("REPLACE INTO ACTINIDIUM_setting (valuetype, valueoptions, name, value) " . 
                     "SELECT 'enum','somatic,ggz','customer_type', IF(zorgverleningtype = 'somatisch', 'somatic', 'mhc')  FROM klant");
        
//        $this->query("RENAME TABLE `klant` TO `klantsettings`");
        // Gerben removed the schema changes
        $this->query("INSERT INTO `klantsettings`
                    SELECT
                        klantnaam,
                        klantversie,
                        ems_adres,
                        ems_id,                  
                        ems_login,  
                        ems_password, 
                        icd9soort, 
                        vecozocertificaatlocatie,  
                        lifelineusername,          
                        lifelinepassword,          
                        usbkey,                    
                        zoeknaamcode,              
                        landisocode,               
                        overloopdatum,             
                        honorariumdatum,           
                        astraiaconfig,             
                        alysisconfig,              
                        lastclosetreatmentscall,   
                        systeemlicentiemodel_id,   
                        license_ban,               
                        checkperformance,          
                        xmlimporturl,              
                        xmlimportusername,         
                        xmlimportpassword,         
                        lastepdload
                    FROM klant
                    WHERE 1");

//        $this->query("ALTER TABLE `klantsettings` DROP `defaulttaal` , " . 
//                     "DROP `zorgverleningtype`, DROP `revision`");
         
        /*
        DROP VIEW IF EXISTS `klant`;
        CREATE VIEW klant AS 
        SELECT klantsettings.klantnaam,
        languagesettings.value AS defaulttaal,
        klantsettings.klantversie,
        (SELECT max(revision) FROM smsrelease) AS revision,
        klantsettings.ems_adres,
        klantsettings.ems_id,
        klantsettings.ems_login,
        klantsettings.ems_password,
        klantsettings.icd9soort,
        klantsettings.vecozocertificaatlocatie,
        klantsettings.lifelineusername,
        klantsettings.lifelinepassword,
        klantsettings.usbkey,
        klantsettings.zoeknaamcode,
        klantsettings.landisocode,
        IF (customertypesettings.value = 'mhc', 'ggz', 'somatisch') AS zorgverleningtype,
        klantsettings.overloopdatum,
        klantsettings.honorariumdatum,
        klantsettings.astraiaconfig,
        klantsettings.alysisconfig,
        klantsettings.lastclosetreatmentscall,
        klantsettings.systeemlicentiemodel_id,
        klantsettings.license_ban,
        klantsettings.checkperformance,
        klantsettings.xmlimporturl,
        klantsettings.xmlimportusername,
        klantsettings.xmlimportpassword,
        klantsettings.lastepdload
        FROM klantsettings
        LEFT JOIN ACTINIDIUM_setting AS languagesettings ON languagesettings.name = 'default_language'
        LEFT JOIN ACTINIDIUM_setting AS customertypesettings ON languagesettings.name = 'customer_type';
        */



    }
    
}