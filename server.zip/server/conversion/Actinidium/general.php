<?php

die('old! see _sms version');


/* 
// this can be deleted when we "really" use the SMS
define('DBAPPTYPE', 'mysql');
define('DBAPPHOST', '10.100.0.117');
define('DBAPPUSER', 'mis');
define('DBAPPPASS', 'DPnb848g');
define('DBAPPDBNAME', 'snapshot_feature900');

define('ADODBROOT', '/home/misactie/subversion/jordy/axilla/adodb5/');

require('/home/misactie/subversion/jordy/axilla/_classes/Database/Connection.class.php');
require('/home/misactie/subversion/jordy/axilla/_classes/Database/ResultSet.class.php');

$db = Database_Connection::getInstance();

$db->executeSql("UPDATE IGNORE menuitemgroep_menuitem SET menuitem_id = 280 where menuitem_id = 44");
$db->executeSql("UPDATE IGNORE menuitemgroep_menuitem SET menuitem_id = 279 where menuitem_id = 52");
$db->executeSql("UPDATE IGNORE menuitemgroep_menuitem SET menuitem_id = 279 where menuitem_id = 53");
$db->executeSql("UPDATE IGNORE menuitemgroep_menuitem SET menuitem_id = 279 where menuitem_id = 81");
$db->executeSql("DELETE FROM menuitemgroep_menuitem WHERE menuitem_id = 125");
$db->executeSql("UPDATE IGNORE menuitemgroep_menuitem SET menuitem_id = 280 where menuitem_id = 256");
$db->executeSql("UPDATE IGNORE menuitemgroep_menuitem SET menuitem_id = 288 where menuitem_id = 258");
$db->executeSql("UPDATE IGNORE menuitemgroep_menuitem SET menuitem_id = 293 where menuitem_id = 259");
$db->executeSql("UPDATE IGNORE menuitemgroep_menuitem SET menuitem_id = 282 where menuitem_id = 260");
$db->executeSql("UPDATE IGNORE menuitemgroep_menuitem SET menuitem_id = 289 where menuitem_id = 63");
$db->executeSql("UPDATE IGNORE menuitemgroep_menuitem SET menuitem_id = 285 where menuitem_id = 38");
$db->executeSql("UPDATE IGNORE menuitemgroep_menuitem SET menuitem_id = 287 where menuitem_id = 162");
$db->executeSql("UPDATE IGNORE menuitemgroep_menuitem SET menuitem_id = 292 where menuitem_id = 264");
$db->executeSql("UPDATE IGNORE menuitemgroep_menuitem SET menuitem_id = 292 where menuitem_id = 264");
$db->executeSql("DELETE FROM menuitemgroep_menuitem WHERE menuitem_id = 266");
$db->executeSql("REPLACE INTO menuitemgroep_menuitem (menuitemgroep_id, menuitem_id) SELECT menuitemgroep_id, 286 FROM menuitemgroep_menuitem WHERE menuitem_id = 285");

*/